Under ui-test folder - Dev team can create environment/layer specific properties files. 
- Selenium tests when run locally will bring up the defined/set browser/popup window and run the tests (non-headless way).
- For Jenkins based selenium test runs, it'll run the tests headless (using Xvfb Linux command and plugin available in Jenkins)

The properties files are mandatory for Selenium tests to run against a given environment/layer
 - i.e. using the settings defined in a given property file

For ex: 
1. Look ui-test folder for CPA project in SVN. http://cmprod2svn.tsh.thomson.com/THIDSCore/CPA/trunk/ui-test/ 
OR 
2. Jenkins job: http://cmprod2jenk.tsh.thomson.com:8082/view/App%20Builds/job/CPA (Main Jenkins job for this project)
   - http://cmprod2jenk.tsh.thomson.com:8082/view/App%20Builds/job/CPA/ws/ui-test/ (properties file )

Guide on setting Selenium tests: 
1. 2_THIDS_Apps_Svcs_Desktop_Builds - See section "SELENIUM USER INTERFACE TESTS"
   Sharepoint Link: https://truvenhealth.sharepoint.com/sites/theng/infastructure/_layouts/15/WopiFrame.aspx?sourcedoc={7494A649-4F6A-4900-A630-C999D77DDF56}&file=2_THIDS_Apps_Svcs_Desktop_Builds.docx&action=default