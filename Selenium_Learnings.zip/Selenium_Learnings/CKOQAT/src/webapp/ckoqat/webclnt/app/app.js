'use strict';

var app = angular.module( 'app', [ 'ngRoute' ] );
app.value( 'app', 'MyCKOQATApp' );

var str = "Location=";
str += this.location;


app.config( ['$routeProvider', function( $routeProvider ) {


} ] );


