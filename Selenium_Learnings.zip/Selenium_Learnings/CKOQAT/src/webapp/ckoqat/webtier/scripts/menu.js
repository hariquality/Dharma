/*
This function tests to make sure we are using a supported browser, 
before calling the makeStatic function.
*/
function menu3() {

    if ( (document.documentElement && document.documentElement.scrollTop) ||
         (document.body) ||
         (document.getElementById&&!document.all) ||
         (document.layers) )
    {   
       makeStatic();
    }
}  //end menu3()

/*
This function checks to see the current position of the page relative
to the top.  If the top is less than the offsetmiddle value, it positions
the menu at offsetmiddle.  If the page has scrolled so that the current top 
position is now greater than the offsetmiddle value, the menu position is 
set to offsettop.
*/
function makeStatic() {

   if (document.layers) //ns4
   {
      if (window.pageYOffset < offsetmiddle)
      {
         eval(document.object1.top=eval(offsetmiddle));
      }
      else
      {
         eval(document.object1.top=eval(window.pageYOffset+offsettop));
      }
   }
   else if (document.documentElement && document.documentElement.scrollTop) //ie6
   {
      element = document.getElementById("object1");

      if (document.documentElement.scrollTop < offsetmiddle)
      {
         element.style.top=offsetmiddle + "px";
      }
      else
      {
         element.style.top=document.documentElement.scrollTop+offsettop + "px";
      }
   }
   else if (document.getElementById && !document.all) //ns6
   {
      element = document.getElementById("object1");

      if (window.pageYOffset < offsetmiddle)
      {
         element.style.top=offsetmiddle;
      }
      else
      {
         element.style.top=window.pageYOffset+offsettop;
      }
   }
   else if (document.body.scrollTop) //ie4 and ie5
   {
      if (document.body.scrollTop < offsetmiddle)
      {
         object1.style.pixelTop=offsetmiddle;
      }
      else
      {
         object1.style.pixelTop=document.body.scrollTop+offsettop;
      }
   }

   //the second parameter specifies the time between running the function.
   //in this case it is 0, so it will run continuously.  This could have
   //an effect on resources on slower machines.  Increasing the number creates
   //a "jerky" effect on the outline.
   setTimeout("makeStatic()",0);
   
}  //end makeStatic() 
