#!/bin/sh

## -------------------------------------------------------------
##
## Script:  deploy.sh
## Author:  Match Grun
## Purpose: This script deploys app server and web server files
##          to server.
## Args:    $!  deploy-app or deploy-web
##
## -------------------------------------------------------------

if [ "$1" == "" ] ; then
  echo "Target not specified!"
  exit 1
fi

DEST_TGT=$1
DEST_DIR=/production
DEST_APP=@build.name@
DEST_VER=@build.version@
DEST_GRP=dmadmin
DEST_OWN=@deploy.uid@

DEST_ROOT=$DEST_DIR/$DEST_APP

echo "Deployment Target: $DEST_TGT"
echo "DEST_ROOT = $DEST_ROOT"

# Check directory structure
DEST_TMP=$DEST_ROOT/$DEST_VER
if [ -d "$DEST_TMP" ] ; then
  echo "[ERROR] The Target directory already exists:"
  echo "[ERROR]   $DEST_TMP"
  rm -rf "$DEST_TMP"
fi

# Create application directory
if [ ! -d "$DEST_ROOT" ] ; then
  mkdir "$DEST_ROOT"
  chown "$DEST_OWN.$DEST_GRP" $DEST_ROOT
fi

# Deploy App Server files
if [ $DEST_TGT == "deploy-app" ] ; then

# Unpacking files
if [ -f common.zip ] ; then
  echo "$DEST_TGT: Unpacking files..."
  unzip -o common.zip -d $DEST_ROOT
fi

if [ -f appserver.zip ] ; then
  echo "$DEST_TGT: Unpacking files..."
  unzip -o appserver.zip -d $DEST_ROOT
fi

if [ -f appserver-modules.zip ] ; then
  echo "$DEST_TGT: Unpacking files..."
  unzip -o appserver-modules.zip -d $DEST_ROOT
fi

if [ -f appserver-other.zip ] ; then
  echo "$DEST_TGT: Unpacking files..."
  unzip -o appserver-other.zip -d $DEST_ROOT
fi

echo "$DEST_TGT: Setting ownership..."
chown -R "$DEST_OWN.$DEST_GRP" $DEST_ROOT

echo "$DEST_TGT: Setting permissions..."
chmod 755 $DEST_ROOT/$DEST_VER/bin/*.sh
chmod 755 $DEST_ROOT/$DEST_VER/tomcat/*.sh

echo "$DEST_TGT: Successfully deployed."
exit 0

fi

# Deploy Web Server files
if [ $DEST_TGT == "deploy-web" ] ; then

# Unpacking files
if [ -f common.zip ] ; then
  echo "$DEST_TGT: Unpacking files..."
  unzip -o common.zip -d $DEST_ROOT
fi

if [ -f webserver.zip ] ; then
  echo "$DEST_TGT: Unpacking files..."
  unzip -o webserver.zip -d $DEST_ROOT
fi

if [ -f webserver-other.zip ] ; then
  echo "$DEST_TGT: Unpacking files..."
  unzip -o webserver-other.zip -d $DEST_ROOT
fi

echo "$DEST_TGT: Creating symlink for web client..."
rm -f "$DEST_ROOT/htdocs/$DEST_APP/webclnt"
ln -s "$DEST_ROOT/htdocs/$DEST_APP/$DEST_VER/webclnt" "$DEST_ROOT/htdocs/$DEST_APP/webclnt"

echo "$DEST_TGT: Setting ownership..."
chown -R "$DEST_OWN.$DEST_GRP" $DEST_ROOT

echo "$DEST_TGT: Setting permissions..."
chmod 755 $DEST_ROOT/$DEST_VER/bin/*.sh

echo "$DEST_TGT: Successfully deployed."
exit 0

fi

echo "$DEST_TGT: Unrecognized deployment target."
exit 1

