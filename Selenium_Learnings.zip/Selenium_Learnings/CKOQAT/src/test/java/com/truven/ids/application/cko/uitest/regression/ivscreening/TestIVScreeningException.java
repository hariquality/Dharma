package com.truven.ids.application.cko.uitest.regression.ivscreening;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.IVScreeningDoc;

/**
 * 
 * 
 * @author APeavy
 * 
 */
public class TestIVScreeningException extends CKOBaseTest  {

	/**
	 * TC186801
	 * Verify error with only current drugs
	 * 
	 * @throws Exception
	 */
	@Test
	public void testOnlyCurrent() throws Exception {
		System.out.println("In method 'testOnlyCurrent'");
		IVScreeningDoc doc = getIVScreeningResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<IVScreeningRequest>"
				+ "  <CurrentDrugList SIZE=\"2\">"
				+ "    <Drug CODE=\"00074-1027-02\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "    <Drug CODE=\"00074-1995-20\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "  </CurrentDrugList>"
				+ "</IVScreeningRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1");
		Assert.assertEquals(doc.getDocumentListSize(),"0");
		Assert.assertEquals(doc.getErrorListErrorText(),
				"Error: Unable to process request. IVScreening Exception: At least one new drug is required to test compatibility.");
	}
	
	/**
	 * TC186802
	 * Verify error with invalid type
	 * 
	 * @throws Exception
	 */
	@Test
	public void testInvalidType() throws Exception {
		System.out.println("In method 'testInvalidType'");
		IVScreeningDoc doc = getIVScreeningResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<IVScreeningRequest>"
				+ "  <NewDrugList SIZE=\"2\">"
				+ "    <Drug CODE=\"00004-2002-78\" TYPE=\"ABC\" STATUS=\"ACTIVE\"/>"
				+ "    <Drug CODE=\"00074-1995-20\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "  </NewDrugList>"
				+ "</IVScreeningRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1");
		Assert.assertEquals(doc.getErrorListErrorText(),
				"Invalid drug identifier type given: valid values are GFC or NDC.");
		Assert.assertEquals(doc.getDocumentListSize(),"1");
		Assert.assertTrue(doc.isPhraseInTextElement("WARNING: DRUGS NOT SCREENED"));
		Assert.assertTrue(doc.isPhraseInTextElement("Drug identified by ABC 00004-2002-78 is not valid input."));
		Assert.assertTrue(doc.isPhraseInTextElement("<font face=\"Arial\">Acyclovir sodium</font>"));
	}
	
	/**
	 * TC186803
	 * Verify error with some invalid drug IDs
	 * 
	 * @throws Exception
	 */
	@Test
	public void testInvalidIDs() throws Exception {
		System.out.println("In method 'testInvalidIDs'");
		IVScreeningDoc doc = getIVScreeningResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<IVScreeningRequest>"
				+ "  <NewDrugList SIZE=\"2\">"
				+ "    <Drug CODE=\"00074-1027-02\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "    <Drug CODE=\"00074-1995-20\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "    <Drug CODE=\"98765-9876-98\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "    <Drug CODE=\"987654\" TYPE=\"GFC\" STATUS=\"ACTIVE\"/>"
				+ "  </NewDrugList>"
				+ "</IVScreeningRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDocumentListSize(),"1");
		Assert.assertTrue(doc.isPhraseInTextElement("Amikacin sulfate - Acyclovir sodium"));
		Assert.assertTrue(doc.isPhraseInTextElement("WARNING: DRUGS NOT SCREENED"));
		Assert.assertTrue(doc.isPhraseInTextElement("Drug identified by NDC 98765-9876-98 was not found."));
		Assert.assertTrue(doc.isPhraseInTextElement("Drug identified by GFC 987654 was not found."));
	}
	
	/**
	 * TC186804
	 * Verify error with valid NDC that isn't in IV data
	 * 
	 * @throws Exception
	 */
	@Test
	public void testNDCsNotInIVTable() throws Exception {
		System.out.println("In method 'testNDCsNotInIVTable'");
		IVScreeningDoc doc = getIVScreeningResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<IVScreeningRequest>"
				+ "  <NewDrugList SIZE=\"2\">"
				+ "    <Drug CODE=\"00074-1027-02\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "    <Drug CODE=\"00074-1995-20\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "    <Drug CODE=\"00001-0597-60\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "  </NewDrugList>"
				+ "</IVScreeningRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDocumentListSize(),"1");
		Assert.assertTrue(doc.isPhraseInTextElement("Amikacin sulfate - Acyclovir sodium"));
		Assert.assertTrue(doc.isPhraseInTextElement("WARNING: DRUGS NOT SCREENED"));
		Assert.assertTrue(doc.isPhraseInTextElement("Drug identified by NDC 00001-0597-60 was not found."));
	}
	
	/**
	 * TC186805
	 * Verify error with valid GFCs that aren't in IV data tables
	 * 
	 * @throws Exception
	 */
	@Test
	public void testGFCsNotInIVTables() throws Exception {
		System.out.println("In method 'testGFCsNotInIVTables'");
		IVScreeningDoc doc = getIVScreeningResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<IVScreeningRequest>"
				+ "  <NewDrugList SIZE=\"2\">"
				+ "    <Drug CODE=\"00074-1027-02\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "    <Drug CODE=\"00074-1995-20\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "    <Drug CODE=\"101296\" TYPE=\"GFC\" STATUS=\"ACTIVE\"/>"
				+ "  </NewDrugList>"
				+ "</IVScreeningRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDocumentListSize(),"1");
		Assert.assertTrue(doc.isPhraseInTextElement("Amikacin sulfate - Acyclovir sodium"));
		Assert.assertTrue(doc.isPhraseInTextElement("WARNING: DRUGS NOT SCREENED"));
		Assert.assertTrue(doc.isPhraseInTextElement("Drug DRONABINOL identified by GFC 101296 was not found."));
	}
	
	/**
	 * TC186807
	 * Verify error empty drug list
	 * 
	 * @throws Exception
	 */
	@Test
	public void testEmptyDrugList() throws Exception {
		System.out.println("In method 'testEmptyDrugList'");
		IVScreeningDoc doc = getIVScreeningResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<IVScreeningRequest>"
				+ "  <NewDrugList SIZE=\"0\">"
				+ "  </NewDrugList>"
				+ "</IVScreeningRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1");
		Assert.assertEquals(doc.getDocumentListSize(),"0");
		Assert.assertEquals("Error: Unable to process request. IVScreening Exception: At least one new drug is required to test compatibility.", 
				doc.getErrorListErrorText());
	}
	
}
