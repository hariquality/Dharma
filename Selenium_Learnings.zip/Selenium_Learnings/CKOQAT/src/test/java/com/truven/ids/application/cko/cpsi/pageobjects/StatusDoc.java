package com.truven.ids.application.cko.cpsi.pageobjects;


import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class StatusDoc extends CPSIBaseDoc{

	
	
	public StatusDoc(JSONObject jsonObject) {
		super(jsonObject);
	}

	public String getDataSetListSize() {
		return jo.getJSONObject("Response").getJSONObject("DataSetList").getString("SIZE");
				
	}
	
	public Boolean verifyStatusResponseForType(String expectedValue) {
	   
	   JSONArray drugsList = jo.getJSONObject("Response").
	         getJSONObject("DataSetList").getJSONArray("DataSet");
	   // iterate through all returned records
	   
	   for (int i = 0; i < drugsList.length(); i++ ) {
	    JSONObject jo1 = (JSONObject)drugsList.get(i);

	    String statusType = jo1.getString("TYPE");
	    
	    if (statusType.contains(expectedValue)) {
	       return true;
	    }
	   }
	   return false;
	  }
	
	
	
public Boolean verifyStatusServiceFor(String key,String expectedValue) {
    
    JSONArray drugsList = jo.getJSONObject("Response").
          getJSONObject("DataSetList").getJSONArray("DataSet");
    // iterate through all returned records
    
    for (int i = 0; i < drugsList.length(); i++ ) {
     JSONObject jo1 = (JSONObject)drugsList.get(i);
     
     if(jo1.getString("TYPE").equals(key)) {
     
     JSONArray drugsList1 = jo1.getJSONObject("ContentSetList").
           getJSONArray("ContentSet");
     
     for (int i1 = 0; i1 < drugsList1.length(); i1++ ) {
     JSONObject jo2 = (JSONObject)drugsList1.get(i1);
     
     if(jo2.get("NAME").equals(expectedValue)) {
        return true;
     }
    }}
    
   }
    return false;
}
	
}
