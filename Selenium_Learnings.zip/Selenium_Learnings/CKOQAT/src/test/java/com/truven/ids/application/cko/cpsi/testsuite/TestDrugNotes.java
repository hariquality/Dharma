package com.truven.ids.application.cko.cpsi.testsuite;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.cpsi.pageobjects.DrugNotesDoc;
import com.truven.ids.application.cko.uitest.CPSIBaseTest;

public class TestDrugNotes extends CPSIBaseTest{
	
	@Test (groups={"Smoke","Regression","DN"})
	public void testDrugNotesRequestforLanguage() throws Exception {
	   System.out.println("In method 'testDrugNotesRequestforLanguage'");
	   DrugNotesDoc doc = getDrugNotesResultDoc("drugnotes/DrugNotesRequest");
	   Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"DrugNotesResult",
          "Server not connected OR Response is not displayed");
	   Assert.assertTrue(doc.verifyDrugNotesTextContains("ES"),"Expected Response is incorrect");
	  }
	
	@Test (groups={"Regression","DN"})
	public void testDrugNotesRequestforSpanishLanguage() throws Exception {
    System.out.println("In method 'testDrugNotesRequestforSpanishLanguage'");
    DrugNotesDoc doc = getDrugNotesResultDoc("drugnotes/DrugNotes_request_1");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"DrugNotesResult",
          "Server not connected OR Response is not displayed");
    Assert.assertTrue(doc.verifyDrugNotesTextContains("ES"),"Expected Response is incorrect");
   
   }
  
	
	@Test (groups={"Regression","DN"})
	public void testDrugNotesRequestforEnglishLanguage() throws Exception {
    System.out.println("In method 'testDrugNotesRequestforEnglishLanguage'");
    DrugNotesDoc doc = getDrugNotesResultDoc("drugnotes/DrugNotes_request_2");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"DrugNotesResult",
          "Server not connected OR Response is not displayed");
    Assert.assertTrue(doc.verifyDrugNotesTextContains("EN"),"Expected Response is incorrect");
   }
	
	
	@Test (groups={"Regression","DN"})
	public void testDrugNotesRequestForChineseSimplified() throws Exception {
		System.out.println("In method 'testDrugNotesRequestforChineseSimplified'");
    DrugNotesDoc doc = getDrugNotesResultDoc("drugnotes/DrugNotes_testChineseSimplified");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"DrugNotesResult",
          "Server not connected OR Response is not displayed");
    Assert.assertTrue(doc.verifyDrugNotesTextContains("zh-cn"),"Expected Response is incorrect");
   }
	
	@Test (groups={"Regression","DN"})
	public void testDrugNotesRequestForChinesetraditionald() throws Exception {
		System.out.println("In method 'DrugNotes_testChineseTraditional'");
    DrugNotesDoc doc = getDrugNotesResultDoc("drugnotes/DrugNotes_testChineseSimplified");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"DrugNotesResult",
          "Server not connected OR Response is not displayed");
    Assert.assertTrue(doc.verifyDrugNotesTextContains("zh-tw"),"Expected Response is incorrect");
   }
  
	@Test (groups={"Regression","DN"})
	public void testDrugNotesRequestForCanadian() throws Exception {
		System.out.println("In method 'testDrugNotesRequestForCanadian'");
    DrugNotesDoc doc = getDrugNotesResultDoc("drugnotes/testDrugNotesRequestForCanadian");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"DrugNotesResult",
          "Server not connected OR Response is not displayed");
    Assert.assertTrue(doc.verifyDrugNotesTextContains("zh-tw"),"Expected Response is incorrect");
   }
  
		
		
}
