package com.truven.ids.application.cko.uitest;

 
//OB: ExtentReports extent instance created here. That instance can be reachable by getReporter() method.
 
import java.io.File;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentManager {
    protected static ExtentReports extent;
    static String getExecutionType ="";
    public static ExtentTest test;
    private static String titleName = "";
    private static String reportFileName = "CKOQAT_Test_Results_Summary.html";
    private static String fileSeperator = System.getProperty("file.separator");
    private static String reportFilepath = System.getProperty("user.dir") +fileSeperator+ "TestReport";
    private static String reportFileLocation =  reportFilepath +fileSeperator+ reportFileName;
    private static final String TIMESTAMP_FORMAT = "MMM dd, yyyy HH:mm:ss";
  
 
    public static ExtentReports getInstance() {
        if (extent == null)
            createInstance();
        return extent;
    }
 
    //Create an extent report instance
    public static ExtentReports createInstance() {
        if(CKOJenkinsConfiguration.JenkinsRun){
        	getExecutionType = System.getenv("Execute");
        }
        else{
        	 getExecutionType = CKOJenkinsConfiguration.executeType;
        }
        titleName = getExecutionType + " - Test Results Summary";
        String fileName = getReportPath(reportFilepath);
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(fileName);
        htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
        htmlReporter.config().setChartVisibilityOnOpen(true);
        htmlReporter.config().setTheme(Theme.STANDARD);
        htmlReporter.config().setDocumentTitle(titleName);
        htmlReporter.config().setEncoding("utf-8");
        htmlReporter.config().setReportName(titleName);
        htmlReporter.config().setTimeStampFormat(TIMESTAMP_FORMAT);
 
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
        //Set environment details
        extent.setSystemInfo("AppType", getExecutionType);
        if(CKOJenkinsConfiguration.executeType.equalsIgnoreCase("THIDS")){
		extent.setSystemInfo("OS", "Windows");
		extent.setSystemInfo("Environment", CKOJenkinsConfiguration.executeEnv);
        }
        else if(CKOJenkinsConfiguration.executeType.equalsIgnoreCase("THIAS")){
        	extent.setSystemInfo("OS", "Windows");
        	extent.setSystemInfo("THIAS_Machine", CKOJenkinsConfiguration.targetServerForTHIDS_THIAS);
        	
        }
        else if(CKOJenkinsConfiguration.executeType.equalsIgnoreCase("CPSI")){
        	extent.setSystemInfo("OS", "Linux");
        	extent.setSystemInfo("CPSI_Machine", CKOJenkinsConfiguration.targetServerforCPSI);
        }
		
        return extent;
    }
     
    //Create the report path
    private static String getReportPath (String path) {
    	File testDirectory = new File(path);
        if (!testDirectory.exists()) {
        	if (testDirectory.mkdir()) {
                System.out.println("Directory: " + path + " is created!" );
                return reportFileLocation;
            } else {
                System.out.println("Failed to create directory: " + path);
                return System.getProperty("user.dir");
            }
        } else {
            System.out.println("Directory already exists: " + path);
        }
		return reportFileLocation;
    }
 
}
