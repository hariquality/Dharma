package com.truven.ids.application.cko.cpsi.pageobjects;


import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class WarningLabelDoc extends CPSIBaseDoc{

	public WarningLabelDoc(JSONObject jsonObject) {
		super(jsonObject);
	}

	public String getDrugSize() {
		return jo.getJSONObject("Response").getJSONObject("DrugList").getString("SIZE");
				
	}
	
public Boolean verifyWarningLabelTextFor(String key,String requestDataFor, String expectedValue) {
    
    JSONArray drugsList = jo.getJSONObject("Response").
          getJSONObject("DrugList").getJSONArray("Drug");
    // iterate through all returned records
    
    for (int i = 0; i < drugsList.length(); i++ ) {
     JSONObject jo1 = (JSONObject)drugsList.get(i);
     if(jo1.getString("CODE").equals(key)) {
        
        JSONArray drugsList1 = jo1.getJSONObject("WarningLabelList").
              getJSONArray("WarningLabel");
        
        for (int i1 = 0; i1 < drugsList1.length(); i1++ ) {
        JSONObject jo2 = (JSONObject)drugsList1.get(i1);
        
        if(jo2.get(requestDataFor).toString().contains(expectedValue)){
           return true;
        }
       }}
       
      }
       return false;
   }


}
