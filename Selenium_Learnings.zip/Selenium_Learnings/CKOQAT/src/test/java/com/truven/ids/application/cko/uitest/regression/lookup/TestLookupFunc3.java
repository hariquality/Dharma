package com.truven.ids.application.cko.uitest.regression.lookup;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.LookupDoc;

/**
 * 
 * 
 * @author BHreen
 * 
 */
public class TestLookupFunc3 extends CKOBaseTest  {

	/**
	 * 
	 * LU030.xml
	 */

@Test
	public void testPSDCOMBODOSEKEY() throws Exception {
		System.out.println("In method 'testPSDCOMBODOSEKEY'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='PSDCOMBODOSEKEY'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='gcr_name' VALUE='Acetaminophen/Codeine Phosphate'/>"		
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),
				"gfc_id|gcr_name|age_lower|age_lower_unit_code|age_upper|age_upper_unit_code|weight_kg_lower|weight_kg_upper|product_form_code|product_form_name|product_route_code|product_route_name|strength|hl7_clinical_route_id|hl7_clinical_route_name|mdx_route_id|dose_type_id|dose_type_name|indication_id|indication_snomed_concept_id|indication_icd9_code|indication_name|ncpdp_unit");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("gcr_name", "Acetaminophen/Codeine Phosphate"),
				"Acetaminophen/Codeine Phosphate is not in gcr_name field");


	}

	/**
	 * 
	 * LU031.xml
	 */

@Test
	public void testPSDSINGLEDOSEKEY() throws Exception {
		System.out.println("In method 'testPSDSINGLEDOSEKEY'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='PSDSINGLEDOSEKEY'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='gcr_id' VALUE='188945'/>"		
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),
				"gcr_id|gcr_name|age_lower|age_lower_unit_code|age_upper|age_upper_unit_code|weight_kg_lower|weight_kg_upper|product_form_code|product_form_name|product_route_code|product_route_name|hl7_clinical_route_id|hl7_clinical_route_name|mdx_route_id|dose_type_id|dose_type_name|indication_id|indication_snomed_concept_id|indication_icd9_code|indication_name|dose_unit_code");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("gcr_id", "188945"),
				"188945 is not in gcr_id field");

	}

	/**
	 * 
	 * LU032.xml
	 */

@Test
	public void testPSDDOSEMODIFIER() throws Exception {
		System.out.println("In method 'testPSDDOSEMODIFIER'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='PSDDOSEMODIFIER'>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"dose_modifier_type_id|dose_modifier_type_name");
		Assert.assertEquals (doc.getLookUpRecordListSize(),"4");

	}

	/**
	 * 
	 * LU033.xml
	 */

@Test
	public void testPSDDOSETYPE() throws Exception {
		System.out.println("In method 'testPSDDOSETYPE'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='PSDDOSETYPE'>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"dose_type_id|dose_type_name");
		Assert.assertEquals (doc.getLookUpRecordListSize(),"4");

	}

	/**
	 * 
	 * LU034.xml
	 */

@Test

	public void testDOSEUNIT() throws Exception {
		System.out.println("In method 'testDOSEUNIT'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='DOSEUNIT'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='dose_unit_name' VALUE='cartridge'/>"	
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"dose_unit_code|dose_unit_name");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("dose_unit_name", "Cartridge"),
				"cartridge is not in dose_unit_name field");

	}

	/**
	 * 
	 * LU035.xml
	 */

@Test
	public void testPSDDOSEWEIGHTTYPE() throws Exception {
		System.out.println("In method 'testPSDDOSEWEIGHTTYPE'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='PSDDOSEWEIGHTTYPE'>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),
				"dosing_weight_type_id|dosing_weight_type_name");
		Assert.assertEquals (doc.getLookUpRecordListSize(),"4");

	}

	/**
	 * 
	 * LU036.xml
	 */

@Test
	public void testPSDDOSEMETHOD() throws Exception {
		System.out.println("In method 'testPSDDOSEMETHOD'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='PSDDOSEMETHOD'>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"dose_method_id|dose_method_name");
		Assert.assertEquals (doc.getLookUpRecordListSize(),"3");		

	}

	/**
	 * 
	 * LU037.xml
	 */

@Test
	public void testPSDDOSEPATH() throws Exception {
		System.out.println("In method 'testPSDDOSEPATH'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='PSDDOSEPATH'>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"dose_path_id|dose_path_name");
		Assert.assertEquals (doc.getLookUpRecordListSize(),"2");		

	}

	/**
	 * 
	 * LU038.xml
	 */

@Test
	public void testPSDHEPATIC() throws Exception {
		System.out.println("In method 'testPSDHEPATIC'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='PSDHEPATIC'>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),
				"hepatic_severity_type_id|hepatic_severity_type_name");
		Assert.assertEquals (doc.getLookUpRecordListSize(),"8");		

	}

	/**
	 * 
	 * LU039.xml
	 */

@Test
	public void testHL7ROUTE() throws Exception {
		System.out.println("In method 'testHL7ROUTE'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='HL7ROUTE'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='hl7_clinical_route_name' VALUE='Injection'/>"	
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),
				"hl7_clinical_route_id|hl7_clinical_route_name|mdx_route_id");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("hl7_clinical_route_name", "Injection"),
				"Injection is not in hl7_clinical_route_name field");

	}

	/**
	 * 
	 * LU040.xml
	 */

@Test
	public void testPSDINDICATIONIcd9() throws Exception {
		System.out.println("In method 'testPSDINDICATIONIcd9'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='PSDINDICATION'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='icd9_code' VALUE='720.0'/>"	
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),
				"indication_id|snomed_concept_id|icd9_code|indication_name");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("icd9_code", "720.0"),
				"720.0 is not in icd9_code field");

	}

	/**
	 * 
	 * LU041.xml
	 */

@Test
	public void testNCPDP() throws Exception {
		System.out.println("In method 'testNCPDP'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='NCPDP'>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"ncpdp_unit_code|ncpdp_unit_name");
		Assert.assertEquals (doc.getLookUpRecordListSize(),"3");	
	}

	/**
	 * 
	 * LU042.xml
	 */

@Test
	public void testPSDRENALMODIFIER() throws Exception {
		System.out.println("In method 'testPSDRENALMODIFIER'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='PSDRENALMODIFIER'>"		
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"renal_modifier_type_id|renal_modifier_type_name");
		Assert.assertEquals (doc.getLookUpRecordListSize(),"2");	

	}

	/**
	 * 
	 * LU043.xml
	 */

@Test
	public void testPSDINDICATIONSnomed() throws Exception {
		System.out.println("In method 'testPSDINDICATIONSnomed'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='PSDINDICATION'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='snomed_concept_id' VALUE='9631008'/>"	
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),
				"indication_id|snomed_concept_id|icd9_code|indication_name");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("snomed_concept_id", "9631008"),
				"9631008 is not in icd9_code field");		

	}

	/**
	 * 
	 * LU044.xml
	 */

@Test
	public void testTIMEUNIT() throws Exception {
		System.out.println("In method 'testTIMEUNIT'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TIMEUNIT'>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"time_unit_code|time_unit_name");
		Assert.assertEquals (doc.getLookUpRecordListSize(),"7");

	}


}
