package com.truven.ids.application.cko.uitest.regression.pageobjects;

import java.util.Iterator;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;


/**
 * PhysiologyDoc contains Physiology specific methods.
 * @author APeavy
 * 
 */
public class PhysiologyDoc extends BaseDoc {

	public PhysiologyDoc(Document inputDoc) {
		super(inputDoc);
	}

	public String getCalcValueByType(String calcType) {
		String totalValue = null;
		List<?> warnings = doc.getRootElement()
				.getChild("PhysiologyCalculatorResponseList").getChildren();
		Iterator<?> i = warnings.iterator();
		while (i.hasNext()) {
			Element calcResponse = (Element) i.next();
			if (calcResponse.getAttributeValue("TYPE").compareTo(calcType) == 0) {
				totalValue = calcResponse.getAttributeValue("CALC_VALUE");
				break;
			}
		}
		return totalValue;
	}

	public String getPhysiologyCalculatorListSize() {
		return doc.getRootElement()
				.getChild("PhysiologyCalculatorResponseList")
				.getAttributeValue("SIZE"); 
	}

	public Boolean isPhraseInErrorElement(String phrase) {
		if (doc.getRootElement()
				.getChild("ErrorList")
				.getChild("Error")
				.getAttributeValue("ERROR_TEXT").contains(phrase)) {
			return true;
		} else return false;
	}


	public String getMessageListSize() {
		return doc.getRootElement()
				.getChild("PSDMessageList")
				.getAttributeValue("SIZE");
	}


	public String getPhraseInMessageElement() {
		StringBuilder messages = new StringBuilder();
		List<?> pSDMesssages = doc.getRootElement()
			.getChild("PSDMessageList")
			.getChildren("PSDMessage");
				for (Object pSDMessage : pSDMesssages) {
					messages.append(((Element) pSDMessage).getAttributeValue("MSG_TEXT"));
					messages.append("|");
							
				}
						return messages.toString();
	}

}
