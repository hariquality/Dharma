package com.truven.ids.application.cko.cpsi.pageobjects;

import net.sf.json.JSONArray;
import net.sf.json.JSONException;
import net.sf.json.JSONObject;

/**
 * BasePage to contain common JSON document methods
 * 
 * @author Hari
 */
public class CPSIBaseDoc {

	JSONObject jo;
	JSONObject jo1;
	Object jsonError;
	JSONArray jsonArray;

	public CPSIBaseDoc(JSONObject jsonObject) {
		jo = jsonObject;
	}

	public String getResponseValueForAttribute(String attributeName) {
		return jo.getJSONObject("Response").getString(attributeName);
	}

	public String getResponseType() {
		return jo.getString("ResponseType");
	}

	public String getErrorListSize() {
		try {
			String errorListSize = jo.getJSONObject("Response").getJSONObject("ErrorList").getString("SIZE");
			return errorListSize;
		}

		catch (JSONException je) {
			return "0";
		}
	}

	public String getErrorName(String jsonArrayName, String fieldName) {
		try {
			return jo.getJSONObject("Response").getJSONArray(jsonArrayName).getJSONObject(0).getString(fieldName);
		} catch (JSONException je) {
			return "0";
		}
	}
	
	public String getResponsefromParentChildObject(String ParentObject,String ChildObject,String fieldName) {
		return jo.getJSONObject(ParentObject).getJSONObject(ChildObject).getString(fieldName);
	}

	public String getResponseFromChildObjectArrayField(String ParentObject,String ChildObject,String fieldName, String arrayName) {
		try {
			return jo.getJSONObject(ParentObject).getJSONObject(ChildObject).getJSONArray(arrayName).getJSONObject(0).getString(fieldName);
		} catch (JSONException je) {
			return "0";
		}
	}
	

	/*
	 * public void getJsonArray(String passJsonExpected) {
	 * 
	 * try { JsonObject arrayKeyName = jo.getJSONObject(passJsonExpected); JsonArray
	 * ja = new JsonArray(); Iterator<?> keys = (Iterator<?>) arrayKeyName.keySet();
	 * while (keys.hasNext()) { String key = (String) keys.next(); String value =
	 * arrayKeyName.getString(key); arrayKeyName.put(new JsonObject("{\"name\":" +
	 * key + ",\"value\":" + value + "}")); } JSONObj.put("supplyPrice",
	 * supplyPriceArray); return JSONObj; } catch (JSONException e) {
	 * e.printStackTrace(); }
	 * 
	 * }
	 */

	/*
	 * private String extractErrors() { StringBuilder sb = new StringBuilder();
	 * Iterator<?> itr =
	 * (doc.getRootElement().getChild("ErrorList").getChildren("Error")).iterator();
	 * while(itr.hasNext()) { Element error = (Element)itr.next(); try {
	 * sb.append(XMLOutputter.class.newInstance().outputString(error)); } catch
	 * (InstantiationException e) { e.printStackTrace(); } catch
	 * (IllegalAccessException e) { e.printStackTrace(); } sb.append("\n"); } return
	 * sb.toString();
	 * 
	 * }
	 */
}
