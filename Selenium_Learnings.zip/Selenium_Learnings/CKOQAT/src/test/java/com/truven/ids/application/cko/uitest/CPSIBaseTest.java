package com.truven.ids.application.cko.uitest;

import static org.testng.Assert.fail;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;

import com.truven.ids.application.cko.cpsi.pageobjects.CrClDoc;
import com.truven.ids.application.cko.cpsi.pageobjects.DrugNotesDoc;
import com.truven.ids.application.cko.cpsi.pageobjects.DrugPointsDoc;
import com.truven.ids.application.cko.cpsi.pageobjects.IVScreeningDoc;
import com.truven.ids.application.cko.cpsi.pageobjects.ImagesAndImprintsDoc;
import com.truven.ids.application.cko.cpsi.pageobjects.LookUpDoc;
import com.truven.ids.application.cko.cpsi.pageobjects.MasDoc;
import com.truven.ids.application.cko.cpsi.pageobjects.PSDDoc;
import com.truven.ids.application.cko.cpsi.pageobjects.PhysiologyDoc;
import com.truven.ids.application.cko.cpsi.pageobjects.StatusDoc;
import com.truven.ids.application.cko.cpsi.pageobjects.ValidateDoc;
import com.truven.ids.application.cko.cpsi.pageobjects.WarningLabelDoc;

import net.sf.json.JSONObject;

public class CPSIBaseTest extends CKOJenkinsConfiguration
{

   /**
    * Base Method to read a json request and response
    * 
    * @param request
    *           json input from file
    * @return
    * @throws IOException
    */
   public LookUpDoc getLookUpResultDoc(String request) throws IOException
   {
      String inputRequest = readJsonFile(request);
      String responseStream = getJSONResponseAsString(inputRequest);
      LookUpDoc lookUpDocPage = new LookUpDoc(buildDoc(responseStream));
      return lookUpDocPage;
   }

   public ImagesAndImprintsDoc getImagesAndImprintsResultDoc(String request) throws IOException
   {
      String inputRequest = readJsonFile(request);
      String responseStream = getJSONResponseAsString(inputRequest);
      ImagesAndImprintsDoc imagesAndImprintsDocPage = new ImagesAndImprintsDoc(buildDoc(responseStream));
      return imagesAndImprintsDocPage;
   }

   public DrugPointsDoc getDrugPointsResultDoc(String request) throws IOException
   {
      String inputRequest = readJsonFile(request);
      String responseStream = getJSONResponseAsString(inputRequest);
      DrugPointsDoc imagesAndImprintsDocPage = new DrugPointsDoc(buildDoc(responseStream));
      return imagesAndImprintsDocPage;
   }

   public DrugNotesDoc getDrugNotesResultDoc(String request) throws IOException
   {
      String inputRequest = readJsonFile(request);
      String responseStream = getJSONResponseAsString(inputRequest);
      DrugNotesDoc imagesAndImprintsDocPage = new DrugNotesDoc(buildDoc(responseStream));
      return imagesAndImprintsDocPage;
   }

   public CrClDoc getCrclResultDoc(String request) throws IOException
   {
      String inputRequest = readJsonFile(request);
      String responseStream = getJSONResponseAsString(inputRequest);
      CrClDoc crClDoc = new CrClDoc(buildDoc(responseStream));
      return crClDoc;
   }

   public PhysiologyDoc getPhysiologyResultDoc(String request) throws IOException
   {
      String inputRequest = readJsonFile(request);
      String responseStream = getJSONResponseAsString(inputRequest);
      PhysiologyDoc crClDoc = new PhysiologyDoc(buildDoc(responseStream));
      return crClDoc;
   }

   public IVScreeningDoc getIVScreeningResultDoc(String request) throws IOException
   {
      String inputRequest = readJsonFile(request);
      String responseStream = getJSONResponseAsString(inputRequest);
      IVScreeningDoc crClDoc = new IVScreeningDoc(buildDoc(responseStream));
      return crClDoc;
   }

   public MasDoc getMASResultDoc(String request) throws IOException
   {
      String inputRequest = readJsonFile(request);
      String responseStream = getJSONResponseAsString(inputRequest);
      MasDoc crClDoc = new MasDoc(buildDoc(responseStream));
      return crClDoc;
   }

   public PSDDoc getPSDResultDoc(String request) throws IOException
   {
      String inputRequest = readJsonFile(request);
      String responseStream = getJSONResponseAsString(inputRequest);
      PSDDoc crClDoc = new PSDDoc(buildDoc(responseStream));
      return crClDoc;
   }

   public StatusDoc getStatusDoc(String request) throws IOException
   {
      String inputRequest = readJsonFile(request);
      String responseStream = getJSONResponseAsString(inputRequest);
      StatusDoc statusDoc = new StatusDoc(buildDoc(responseStream));
      return statusDoc;
   }

   public ValidateDoc getValidateDoc(String request) throws IOException
   {
      String inputRequest = readJsonFile(request);
      String responseStream = getJSONResponseAsString(inputRequest);
      ValidateDoc validateDoc = new ValidateDoc(buildDoc(responseStream));
      return validateDoc;
   }

   public WarningLabelDoc getWarningLabelDoc(String request) throws IOException
   {
      String inputRequest = readJsonFile(request);
      String responseStream = getJSONResponseAsString(inputRequest);
      WarningLabelDoc warningLabelDoc = new WarningLabelDoc(buildDoc(responseStream));
      return warningLabelDoc;
   }

   /**
    * Sends request to CPSI server and forms the connection and returns the
    * response stream
    */
   public InputStream sendRequestToCPSIServer(String reqString) throws IOException
   {
      InputStream is = null;
      try
      {

         String urlValue;
         if (JenkinsRun)
         {
            urlValue = getCKOTargetServerForCPSI();
         }
         else
         {
            urlValue = targetServerforCPSI;
         }
         URL url = new URL(urlValue
               + "ckoapp/librarian/PFActionId/ckoapp.JsonRequest");
         System.out.println("url:" + url.toString());
         HttpURLConnection con = (HttpURLConnection) url.openConnection();
         con.setConnectTimeout(10000);
         con.setDoOutput(true);
         con.setDoInput(true);
         // set the request method and properties.
         con.setRequestMethod("POST");
         con.setRequestProperty("Content-Type", "application/json");
         con.setRequestProperty("Accept", "application/json");

         OutputStream os = con.getOutputStream();
         os.write(reqString.getBytes(), 0, reqString.getBytes().length);
         os.close();

         is = con.getInputStream();
      }
      catch (Exception exception)
      {
         fail("caught exception in sendRequestToCKOServer:"
               + exception.getMessage());
      }
      return is;
   }

   /**
    * Method to get the JSON response as a String.
    */
   public String getJSONResponseAsString(String request) throws IOException
   {
      InputStream responseStream = sendRequestToCPSIServer(request);
      // read responseStream into string result to return
      BufferedInputStream buf = new BufferedInputStream(responseStream);
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      int i = 0;
      while (i >= 0)
      {
         try
         {
            i = buf.read();
         }
         catch (IOException e)
         {
            e.printStackTrace();
         }
         if (i != -1)
         {
            out.write(i);
         }
      }
      String response = out.toString();
      System.out.println("response:" + response + "|endOfResponse");
      return response;
   }

   /**
    * this method converts a json response(String) into JSON Object
    * 
    * @param request
    *           json Response obtained from request
    * @return
    */
   private JSONObject buildDoc(String request)
   {
      JSONObject jo = JSONObject.fromObject(request);
      return jo;
   }

   /**
    * @param fileName
    *           (json input request)
    * @return
    * @throws IOException
    */
   public String readJsonFile(String fileName) throws IOException
   {
      return new String(Files
            .readAllBytes(Paths.get("./json/" + fileName + ".json")));
   }

}
