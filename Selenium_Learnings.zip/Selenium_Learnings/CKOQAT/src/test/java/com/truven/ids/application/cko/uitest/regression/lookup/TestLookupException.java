package com.truven.ids.application.cko.uitest.regression.lookup;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.LookupDoc;

/**
 * 
 * 
 * @author BHreen
 * 
 */
public class TestLookupException extends CKOBaseTest  {

	/**
	 * 
	 * TC187144
	 */
@Test
	public void testInvalidLookupType() throws Exception {
		System.out.println("In method 'testInvalidLookupType'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='FERBIBBLE'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='gfc' VALUE='1032'/>"
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1");
		Assert.assertEquals (doc.getErrorListErrorText(),"Invalid LookUp Type for Category");	

	}
	
	/**
	 * 
	 * TC187145
	 */
	@Test
	public void testInvalidSearchParamenterForLanguage() throws Exception {
		System.out.println("In method 'testInvalidSearchParamenterForLanguage'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='LANGUAGE'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='form' VALUE='table'/>"
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1");
		Assert.assertEquals (doc.getErrorListErrorText(),"Invalid Search Parameter for LANGUAGE LookUp");
				
	}
	
	/**
	 * 
	 * TC187146
	 */
	@Test
	public void testMissingLookupType() throws Exception {
		System.out.println("In method 'testMissingLookupType'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType=''>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='language' VALUE='4'/>"
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1");
		Assert.assertEquals (doc.getErrorListErrorText(),"Invalid LookUp Type for Category");
		
	}

	


}
