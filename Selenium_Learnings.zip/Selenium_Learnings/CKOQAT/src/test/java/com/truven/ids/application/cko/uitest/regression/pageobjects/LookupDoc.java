package com.truven.ids.application.cko.uitest.regression.pageobjects;

import java.util.List;

import org.jdom.Document;
import org.jdom.Element;

/**
 * LookupDoc contains Lookup specific methods.
 * 
 * @author APeavy
 * 
 */
public class LookupDoc extends BaseDoc {

	public LookupDoc(Document inputDoc) {
		super(inputDoc);
	}

	public String getLookUpRecordListSize() {
		return doc.getRootElement().getChild("LookUpRecordList").getAttributeValue("SIZE");
	}

	public String getLookUpRecordListHeader() {
		return doc.getRootElement().getChild("LookUpRecordList").getAttributeValue("HEADER");
	}

	public String getLookUpRecordFieldCount() {
		return doc.getRootElement().getChild("LookUpRecordList").getAttributeValue("NUMBER_OF_FIELDS");
	}

	public Boolean verifyLookUpRecordsByFieldStartsWith(String fieldName, String expectedValue) {
		int errorCount = 0;
		// get and split header
		String header = doc.getRootElement().getChild("LookUpRecordList").getAttributeValue("HEADER");
		String[] headers = header.split("[|]");
		// determine index for input fieldName
		int index = 0;
		for (int i = 0; i < headers.length; i++) {
			System.out.println("headers[" + i + "]" + headers[i]);
			if (headers[i].contentEquals(fieldName)) {
				index = i;
				break;
			}
		}
		System.out.println("index:" + index);
		// get all records
		List<?> lookUpRecords = doc.getRootElement().getChild("LookUpRecordList").getChildren("LookUpRecord");
		// iterate through all returned records
		for (Object lookUpRecord : lookUpRecords) {
			String record = ((Element) lookUpRecord).getText();
			// split record
			String[] recordData = record.split("[|]");
			if (!recordData[index].startsWith(expectedValue)) {
				errorCount++;
			}
		}
		System.out.println("fieldName:" + fieldName);
		System.out.println("expectedValue:" + expectedValue);
		System.out.println("errorCount:" + errorCount);
		if (errorCount > 0) {
			return false;
		} else
			return true;
	}

	public Boolean isPhraseInErrorElement(String phrase) {
		if (doc.getRootElement().getChild("ErrorList").getChild("Error").getAttributeValue("ERROR_TEXT")
				.contains(phrase)) {
			return true;
		} else
			return false;
	}
	
	/*Method will iterate all LookupRecords and check the expected value by field text */
	public Boolean verifyLookUpRecordsByFieldText(String fieldName, String expectedValue) {
		int recordscount = 0;
		// get and split header
		String header = doc.getRootElement().getChild("LookUpRecordList").getAttributeValue("HEADER");
		String[] headers = header.split("[|]");
		// determine index for input fieldName
		int index = 0;
		for (int i = 0; i < headers.length; i++) {
			System.out.println("headers[" + i + "]" + headers[i]);
			if (headers[i].contentEquals(fieldName)) {
				index = i;
				break;
			}
		}
		System.out.println("index:" + index);
		// get all records
		List<?> lookUpRecords = doc.getRootElement().getChild("LookUpRecordList").getChildren("LookUpRecord");
		// iterate through all returned records
		for (Object lookUpRecord : lookUpRecords) {
			String record = ((Element) lookUpRecord).getText();
			// split record
			String[] recordData = record.split("[|]");
			if (recordData[index].startsWith(expectedValue)) {
				recordscount++;
			}
		}
		System.out.println("fieldName:" + fieldName);
		System.out.println("expectedValue:" + expectedValue);
		System.out.println("recordscountFound:" + recordscount);
		if (recordscount > 0) {
			return true;
		} else
			return false;
	}
	
	/*Method will iterate all LookupRecords,Filter local lookup records and check region field Result */
	
	public Boolean verifyLookUpRecordsByFieldTextRegion(String fieldName, String expectedValue) {
		int recordscount = 0;
		// get and split header
		String header = doc.getRootElement().getChild("LookUpRecordList").getAttributeValue("HEADER");
		String[] headers = header.split("[|]");
		// determine index for input fieldName
		int index = 0;
		for (int i = 0; i < headers.length; i++) {
			System.out.println("headers[" + i + "]" + headers[i]);
			if (headers[i].contentEquals(fieldName)) {
				index = i;
				break;
			}
		}
		System.out.println("index:" + index);
		System.out.println("headerlength:" + headers.length);
		// get all records
		List<?> lookUpRecords = doc.getRootElement().getChild("LookUpRecordList").getChildren("LookUpRecord");
		// iterate through all returned records
		for (Object lookUpRecord : lookUpRecords) {
			String record = ((Element) lookUpRecord).getText();
			// split record
			String[] recordData = record.split("[|]");
			// to process the Local content
			if (recordData.length == headers.length) {
				if (recordData[index].startsWith(expectedValue)) {
					recordscount++;
				}
			}
		}
		System.out.println("fieldName:" + fieldName);
		System.out.println("expectedValue:" + expectedValue);
		System.out.println("recordscount:" + recordscount);
		if (recordscount > 0) {
			return true;
		} else
			return false;
	}
}