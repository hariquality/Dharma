package com.truven.ids.application.cko.uitest.regression.pageobjects;

import org.jdom.Document;


/**
 * DrugNotesDoc to contain DrugNotes specific methods
 * @author APeavy
 * 
 */
public class DrugNotesDoc extends BaseDoc {
	
	public DrugNotesDoc(Document inputDoc) {
		super(inputDoc);
	}

	public String getDocumentListSize() {
		return doc.getRootElement()
				.getChild("DocumentList")
				.getAttributeValue("SIZE");
	}
	
	public String getDocumentDrugCodeAttribute() {
		return doc.getRootElement()
				.getChild("DocumentList")
				.getChild("Document")
				.getAttributeValue("DRUG_CODE");
	}
	
	public Boolean isPhraseInTextElement(String phrase) {
		if (doc.getRootElement()
				.getChild("DocumentList")
				.getChild("Document")
				.getChildText("Text").contains(phrase)) {
			return true;
		} else return false;
	}
	
	public Boolean isPhraseInErrorElement(String phrase) {
		if (doc.getRootElement()
				.getChild("ErrorList")
				.getChild("Error")
				.getAttributeValue("ERROR_TEXT").contains(phrase)) {
			return true;
		} else return false;
	}

}
