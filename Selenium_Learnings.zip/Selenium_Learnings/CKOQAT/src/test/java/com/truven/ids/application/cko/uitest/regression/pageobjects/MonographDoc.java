package com.truven.ids.application.cko.uitest.regression.pageobjects;

import java.util.Iterator;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;


/**
 * MonographDoc contains MAS monograph specific methods.
 * @author APeavy
 * 
 */
public class MonographDoc extends BaseDoc {
	
	public MonographDoc(Document inputDoc) {
		super(inputDoc);
	}

	public String getDocumentListSize() {
		return doc.getRootElement()
				.getChild("DocumentList")
				.getAttributeValue("SIZE");
	}
	
	public String getDocumentID() {
		return doc.getRootElement()
				.getChild("DocumentList")
				.getChild("Document")
				.getAttributeValue("ID");
	}
	
	public String getDocumentText() {
		return doc.getRootElement()
				.getChild("DocumentList")
				.getChild("Document")
				.getChildText("Text");
	}
	
	public Boolean getDocumentId(String inputText) {
		int i = 0;
		int flag=0;
		List<?> Documents = doc.getRootElement()
		.getChild("DocumentList").getChildren("Document");
		i= Documents.size();
		System.out.println("size"+i);
		//multiple DocumentId
		if(i>0) {
		Iterator<?> w = Documents.iterator();
		while (w.hasNext()) {
		Element DocumentIds = (Element) w.next();
		if((DocumentIds.getAttributeValue("ID").equalsIgnoreCase(inputText))){
		System.out.println("success");
		System.out.println("response Value"+(DocumentIds.getAttributeValue("ID")));
		System.out.println("Expected Value"+inputText);
		flag=1;
		}
		else {
		System.out.println("not equal fail");
		System.out.println("response Value : "+(DocumentIds.getAttributeValue("ID")));
		System.out.println("Expected Value : "+inputText);
		}
		}
		}
		if (flag==1)
		return true;
		else
		return false;
		}
		public Boolean getDocumentText(String inputText) {
		int i = 0;
		int flag=0;
		List<?> Documents = doc.getRootElement()
		.getChild("DocumentList").getChildren("Document");
		i= Documents.size();
		System.out.println("size"+i);
		//multiple Documents
		if(i>0) {
		Iterator<?> w = Documents.iterator();
		while (w.hasNext()) {
		Element DocumentIds = (Element) w.next();
		if((DocumentIds.getChildText("Text").contains(inputText))){
		System.out.println("success");
		System.out.println("response Value"+(DocumentIds.getChildText("Text")));
		System.out.println("Expected Value"+inputText);
		flag=1;
		}
		else {
		System.out.println("not equal");
		System.out.println("response Value : "+(DocumentIds.getChildText("Text")));
		System.out.println("Expected Value : "+inputText);
		}
		}
		}
		if (flag==1)
		return true;
		else
		return false;
		}
		
		public String getErrorText() {
			return doc.getRootElement()
					.getChild("ErrorList")
					.getChild("Error")
					.getAttributeValue("ERROR_TEXT");
		}
}
