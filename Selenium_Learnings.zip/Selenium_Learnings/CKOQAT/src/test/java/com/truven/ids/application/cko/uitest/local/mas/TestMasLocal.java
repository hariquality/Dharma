package com.truven.ids.application.cko.uitest.local.mas;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.MasDoc;
import com.truven.ids.application.cko.uitest.regression.pageobjects.MonographDoc;

/**
 * MAS functional tests
 * 
 * @author APeavy
 * 
 */
public class TestMasLocal extends CKOBaseTest  {

	/**
	 * TC349746, TC349734, TC349745, TC349740
	 * International data - Spain 
	 * Registry code NC and GFC combination to validate the Drug - drug interaction local content
	 * Validating the number of interactions occurred
	 * Validate whether the corresponding region value is returned 
	 * Verify whether Pregnancy,lactation warning messages displays for registry type when PREGNANCY, LACTATION value set as TRUE
	 * Verify whether other local country warning message is not displayed in the response
	 * @throws Exception
	 */
	@Test
	public void testmaslocalwithgfcregistry() throws Exception {
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" REGION=\"ES\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\""
				+ getBirthdateForGivenAgeInYears(20)
				+ "\" SMOKER=\"TRUE\" PREGNANT=\"TRUE\" LACTATING=\"TRUE\"/>" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"725009\" TYPE=\"REGISTRY\" REGISTRY_TYPE=\"NC\"/>"+
				"    <Drug CODE=\"103687\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"10","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"10","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"5","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"1","Number of Drug warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("FOOD"),"1","Number of Food warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("LAB"),"2","Number of Lab warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("PREGNANCY"),"3","Number of Pregnancy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("LACTATION"),"3","Number of Lactation warnings"); 
		Assert.assertEquals(doc.getFirstRegionValue(),"ES","Region");
		Assert.assertTrue(doc.getWarningRegion("ES"));
		Assert.assertEquals(doc.getFirstWarningText(),"Concurrent use of ACETYLCYSTEINE and TETRACYCLINES may result in inactivation of tetracycline antibiotic.","Warning Text");	
		
	}

	/**
	 * TC349735
	 * International data - Spain 
	 * Registry code NC and GFC combination to validate the Drug - drug interaction local content
	 * Validating the number of interactions occurred
	 * Validate whether the Pregnancy and Lactation content is not displayed for MALE Patient
	 * @throws Exception
	 */
	@Test
	public void testmaslocalwithgfcregistryformale() throws Exception {
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" REGION=\"ES\">" + 
				"  <Patient GENDER=\"MALE\" BIRTH_DATE=\""
				+ getBirthdateForGivenAgeInYears(20)
				+ "\" SMOKER=\"TRUE\" PREGNANT=\"FALSE\" LACTATING=\"FALSE\"/>" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"725009\" TYPE=\"REGISTRY\" REGISTRY_TYPE=\"NC\"/>"+
				"    <Drug CODE=\"103687\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"4","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"4","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"3","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"1","Number of Drug warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("FOOD"),"1","Number of Food warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("LAB"),"2","Number of Lab warnings");  
		Assert.assertEquals(doc.getFirstRegionValue(),"ES","Region"); 
		Assert.assertTrue(doc.getWarningRegion("ES"));
		Assert.assertEquals(doc.getFirstWarningText(),"Concurrent use of ACETYLCYSTEINE and TETRACYCLINES may result in inactivation of tetracycline antibiotic.","Warning Text");	
		
	}
	/**
	 * TC349735
	 * International data - Spain 
	 * Validate whether the appropriate error text is displayed on setting Pregnancy and Lactation as "TRUE" for Male patient 
	 * @throws Exception
	 */
	@Test
	public void testmaslocalformalehavingpreglacttrue() throws Exception {
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" REGION=\"ES\">" + 
				"  <Patient GENDER=\"MALE\" BIRTH_DATE=\""
				+ getBirthdateForGivenAgeInYears(20)
				+ "\" SMOKER=\"TRUE\" PREGNANT=\"TRUE\" LACTATING=\"TRUE\"/>" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"725009\" TYPE=\"REGISTRY\" REGISTRY_TYPE=\"NC\"/>"+
				"    <Drug CODE=\"103687\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"2"); // no errors
		Assert.assertEquals(doc.getErrorTextforMALE(),"The Patient's Gender must be Female when Lactating is set to true","Error Text"); 
		
	}
	
	/**
	 * TC349736, TC349744
	 * International data - Spain 
	 * Registry code NC and GFC combination to validate the Drug - drug interaction local content
	 * Validating the number of interactions occurred
	 * Validate whether the corresponding region value is returned 
	 * Validate whether the Pregnancy and Lactation content are not displayed when pregnancy and lactation content is set as false
	 * Validate the TC_Duplication message
	 * @throws Exception
	 */
	@Test
	public void testmaslocalforfemalehavingpreglacfalse() throws Exception {
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" REGION=\"ES\">" + 
				"  <Patient GENDER=\"FEMALE\" BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" LACTATING=\"FALSE\" PREGNANT=\"FALSE\" SMOKER=\"TRUE\"  />" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"724626\" TYPE=\"REGISTRY\" REGISTRY_TYPE=\"NC\"/>"+
				"    <Drug CODE=\"108077\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <CurrentDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"111850\" TYPE=\"GFC\" />" + 
				"  </CurrentDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"14","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"14","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"5","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"4","Number of Drug warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("FOOD"),"3","Number of Food warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("TOBACCO"),"1","Number of Tobacco warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DISEASE"),"3","Number of Disease warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("TC_DUPLICATION"),"3","Number of Tc duplication warnings"); 
		Assert.assertTrue(doc.getWarningRegion("ES"));
		Assert.assertTrue(true, "A therapeutic class duplication has occurred.  The duplication exists between ABCIXIMAB and ANAGRELIDE HYDROCHLORIDE of therapeutic class Platelet Aggregation Inhibitor.");
		Assert.assertTrue(true, "A therapeutic class duplication has occurred.  The duplication exists between CLOPIDOGREL TEVA and ANAGRELIDE HYDROCHLORIDE of therapeutic class Platelet Aggregation Inhibitor.");
		//Assert.assertEquals(doc.getFirstRegionValue(),"ES","Region"); 
		
	}
	/**
	 * TC351111
	 * International data - Italy 
	 * Search Allergen - Drug using Registry type and code
	 * Validating the number of interactions occurred
	 * Validate whether the corresponding region value is returned 
	 * Validate whether the Allergy warnings are returned
	 * @throws Exception
	 */
	@Test
	public void testmaslocalforallergywarninghavingdrug() throws Exception {
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" REGION=\"IT\">" + 
				"  <Patient GENDER=\"FEMALE\" BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" LACTATING=\"TRUE\" PREGNANT=\"TRUE\" SMOKER=\"TRUE\"  />" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"038529069\" TYPE=\"REGISTRY\" REGISTRY_TYPE=\"AIC\"/>"+
				"  </NewDrugList>" + 
				"  <AllergenList SIZE=\"2\">" + 
				"    <Allergen CODE=\"038529069\" TYPE=\"REGISTRY\" REGISTRY_TYPE=\"AIC\"/> "+
				"	 <Allergen CODE=\"7709223\" TYPE=\"MDX_ALG\"/>" +
				"  </AllergenList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"13","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"13","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"5","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("ETHANOL"),"1","Number of Ethanol warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("ALLERGY"),"2","Number of Allergy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("PREGNANCY"),"4","Number of Pregnancy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("LACTATION"),"4","Number of Lactation warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("PRECAUTIONS"),"2","Number of Precautions warnings"); 
		Assert.assertTrue(doc.getWarningRegion("IT"));
		Assert.assertTrue(doc.getWarningTextseq("A history of hypersensitivity to the following substance has been noted for this patient: GLUBRAVA."));
		Assert.assertTrue(doc.getWarningTextseq("A history of hypersensitivity to the following substance has been noted for this patient: GLUBRAVA."));
	}

	/**
	 * TC351117
	 * International data - Spain 
	 * Validating the number of interactions occurred
	 * Validate whether the corresponding region value is returned 
	 * Validate whether the Allergy warnings are returned for Allergen - Excipient
	 * @throws Exception
	 */
	@Test
	public void testmaslocalforallergywarninghavingexcipient() throws Exception {
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" REGION=\"ES\">" + 
				"  <Patient GENDER=\"FEMALE\" BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" LACTATING=\"TRUE\" PREGNANT=\"TRUE\" SMOKER=\"TRUE\"  />" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"59032\" TYPE=\"REGISTRY\" REGISTRY_TYPE=\"AIC\"/>"+
				"  </NewDrugList>" + 
				"  <AllergenList SIZE=\"1\">" + 
				"	 <Allergen CODE=\"7709214\" TYPE=\"MDX_ALG\"/>" +
				"  </AllergenList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"3","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"3","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"3","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("ALLERGY"),"1","Number of Allergy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("PREGNANCY"),"1","Number of Pregnancy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("LACTATION"),"1","Number of Lactation warnings"); 
		Assert.assertTrue(doc.getWarningRegion("ES"));
		Assert.assertTrue(doc.getWarningTextseq("A history of hypersensitivity to the following substance has been noted for this patient: BLASTON."));
		//Assert.assertEquals(doc.getFirstRegionValue(),"ES","Region"); 
		
	}
	
	/**
	 * TC349738
	 * US Data
	 * Verify only US warnings are displayed for US region
	 * @throws Exception
	 */
	@Test
	public void testmaslocalnotpresentforUS() throws Exception {
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\">" + 
				"  <Patient GENDER=\"FEMALE\" BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" LACTATING=\"TRUE\" PREGNANT=\"TRUE\" SMOKER=\"TRUE\"  />" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"112655\" TYPE=\"GFC\" />"+
				"    <Drug CODE=\"108077\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <CurrentDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"111850\" TYPE=\"GFC\" />" + 
				"  </CurrentDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"16","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"16","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"7","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"2","Number of Drug warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("FOOD"),"3","Number of Food warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("TOBACCO"),"1","Number of Tobacco warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DISEASE"),"3","Number of Disease warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("PREGNANCY"),"2","Number of Pregnancy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("LACTATION"),"2","Number of Lactation warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("TC_DUPLICATION"),"3","Number of Tc duplication warnings"); 
		//Assert.assertTrue(doc.getWarningRegion("ES"));
		//Assert.assertEquals(doc.getFirstRegionValue(),"ES","Region"); 
		
	}
	/**
	 * TC3511122
	 * International data - Spain 
	 * Search Allergen - Drug using Registry type and code
	 * Validating the number of interactions occurred
	 * Validate whether the corresponding region value is returned 
	 * Verify whether Allergy Warning message is displayed as expected on adding Allergy Kit for Local Region
	 * @throws Exception
	 */
	@Test
	public void testmaslocalallergywarningforkit() throws Exception {
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" REGION=\"ES\">" + 
				"  <Patient GENDER=\"FEMALE\" BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" LACTATING=\"TRUE\" PREGNANT=\"TRUE\" SMOKER=\"TRUE\"  />" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"726530\" TYPE=\"REGISTRY\" REGISTRY_TYPE=\"NC\"/>"+
				"  </NewDrugList>" + 
				"  <AllergenList SIZE=\"2\">" + 
				"  <Allergen CODE=\"7709227\" TYPE=\"MDX_ALG\"/>"+
				"	 <Allergen CODE=\"7700945\" TYPE=\"MDX_ALG\"/>" +
				"  </AllergenList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"8","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"8","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"3","Type Summary");  
		Assert.assertEquals(doc.getNumberOfWarningsByType("ALLERGY"),"2","Number of Allergy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("PREGNANCY"),"3","Number of Pregnancy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("LACTATION"),"3","Number of Lactation warnings"); 
		Assert.assertTrue(doc.getWarningRegion("ES"));
		Assert.assertTrue(doc.getWarningTextseq("A history of hypersensitivity to the following substance has been noted for this patient: ESPEROCT."));
		//Assert.assertEquals(doc.getFirstRegionValue(),"ES","Region"); 
		
	}
	
}