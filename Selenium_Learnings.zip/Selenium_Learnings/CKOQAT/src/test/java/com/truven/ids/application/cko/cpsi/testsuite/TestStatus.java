package com.truven.ids.application.cko.cpsi.testsuite;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.cpsi.pageobjects.StatusDoc;
import com.truven.ids.application.cko.uitest.CPSIBaseTest;

public class TestStatus extends CPSIBaseTest{

  @Test
	public void testStatus_Request() throws Exception {
	   System.out.println("In method 'testPSD_withRX_DoseKey'");
	   StatusDoc doc = getStatusDoc("status/StatusRequest");
	   Assert.assertEquals(doc.getErrorListSize(),"0", "ErrorList is present for Valid Request");
	   Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected OR Response is not displayed");
	   Assert.assertEquals(doc.getResponseType(),"ServiceStatusResult","Server not connected OR Response is not displayed");
	   Assert.assertEquals(doc.getDataSetListSize(),"9","Content set list size is incorrect");
	   Assert.assertTrue(doc.verifyStatusResponseForType("LOOKUP_DATA"),"LookUp Data Service is not Present");
	   
	   Assert.assertTrue(doc.verifyStatusServiceFor("MAS_DATA","CKOTHIDS2"),"Mas Data Service is not Present");
	   
	   Assert.assertTrue(doc.verifyStatusServiceFor("LOOKUP_DATA","REDBOOK"),"LookUp Data Service is not Present");
	  }
	
	
 
		
}
