package com.truven.ids.application.cko.uitest.regression.imagesimprints;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.ImagesImprintsDoc;

/**
 * 
 * 
 * @author BHreen
 * 
 */
public class TestImagesImprintsFunc extends CKOBaseTest  {

	/*
	 * TC186909
	 */
@Test
	public void testShapeHourglass() throws Exception {
		System.out.println("In method 'testShapeHourglass'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsSearchRequest>"
				+ "<DrugSearchDescription SHAPE=\"Hourglass\" />"
				+ "</ImagesImprintsSearchRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getDrugListSize(),"22");
		Assert.assertEquals(doc.getFirstDrugCode(),"00075-0032-00");
		Assert.assertEquals(doc.getFirstShape(),"Hourglass-shape");

	}

	/*
	 * TC186910
	 */
@Test
	public void testPatternBanded() throws Exception {
		System.out.println("In method 'testPatternBanded'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsSearchRequest>"
				+ "<DrugSearchDescription PATTERN=\"Banded\" >"
				+ "<ImprintList SIZE=\"1\">"
				+ "<Imprint>130"
				+ "</Imprint>"
				+ "</ImprintList>"
				+ "</DrugSearchDescription>"
				+ "</ImagesImprintsSearchRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getDrugListSize(),"2");
		Assert.assertEquals(doc.getFirstDrugCode(),"27437-0110-01");
		Assert.assertEquals(doc.getFirstPattern(),"Banded");

	}

	/*
	 * TC186911
	 */
@Test
	public void testShapeAndPattern() throws Exception {
		System.out.println("In method 'testShapeAndPattern'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsSearchRequest>"
				+ "<DrugSearchDescription SHAPE=\"Egg-shape\" PATTERN=\"Speckled\"/>"
				+ "</ImagesImprintsSearchRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getDrugListSize(),"2");
		Assert.assertTrue(doc.getDrugcodes("00074-6290-53"));
		Assert.assertEquals(doc.getFirstShape(),"Egg-shape");
		Assert.assertEquals(doc.getFirstPattern(),"Speckled");

	}

	/*
	 * TC186912
	 */
@Test
	public void testSingleImprint() throws Exception {
		System.out.println("In method 'testSingleImprint'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsSearchRequest>"
				+ "<DrugSearchDescription>"
				+ "<ImprintList SIZE=\"1\">"
				+ "<Imprint>PCE"
				+ "</Imprint>"
				+ "</ImprintList>"
				+ "</DrugSearchDescription>"
				+ "</ImagesImprintsSearchRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getDrugListSize(),"3");
		Assert.assertEquals(doc.getFirstDrugCode(),"24338-0112-60");
		Assert.assertEquals(doc.getFirstImprintCodes(),"LOGO PCE");

	}

	/*
	 * TC186913
	 */
@Test
	public void testMultipleImprints() throws Exception {
		System.out.println("In method 'testMultipleImprints'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsSearchRequest>"
				+ "<DrugSearchDescription>"
				+ "<ImprintList SIZE=\"2\">"
				+ "<Imprint>cardizem"
				+ "</Imprint>"
				+ "<Imprint>90 mg"
				+ "</Imprint>"
				+ "</ImprintList>"
				+ "<ColorList SIZE='1'>"
				+ "<Color>Green"
				+ "</Color>"
				+ "</ColorList>"
				+ "</DrugSearchDescription>"
				+ "</ImagesImprintsSearchRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getDrugListSize(),"3");
		Assert.assertEquals(doc.getFirstDrugCode(),"64455-0791-47");
		Assert.assertEquals(doc.getFirstImprintCodes(),"CARDIZEM; 90 mg");

	}

	/*
	 * TC186914
	 */
@Test
	public void testSingleColor() throws Exception {
		System.out.println("In method 'testSingleColor'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsSearchRequest>"
				+ "<DrugSearchDescription>"
				+ "<ImprintList SIZE=\"2\">"
				+ "<Imprint>5 mg"
				+ "</Imprint>"
				+ "<Imprint>Logo"
				+ "</Imprint>"
				+ "</ImprintList>"
				+ "<ColorList SIZE =\"1\">"
				+ "<Color>Red"
				+ "</Color>"
				+ "</ColorList>"
				+ "</DrugSearchDescription>"
				+ "</ImagesImprintsSearchRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getDrugListSize(),"5");
		Assert.assertEquals(doc.getFirstDrugCode(),"00469-0687-73");
		Assert.assertEquals(doc.getFirstPrimaryColor(),"Red");

	}

	/*
	 * TC186915, TC186937
	 */
@Test
	public void testMultipleColors() throws Exception {
		System.out.println("In method 'testMultipleColors'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsSearchRequest>"
				+ "<DrugSearchDescription>"
				+ "<ColorList SIZE =\"2\">"
				+ "<Color>Black"
				+ "</Color>"
				+ "<Color>Red"
				+ "</Color>"
				+ "</ColorList>"
				+ "</DrugSearchDescription>"
				+ "</ImagesImprintsSearchRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getDrugListSize(),"4");
		Assert.assertEquals(doc.getFirstDrugCode(),"00781-2025-13");
		Assert.assertEquals(doc.getFirstPrimaryColor(),"Black");
		Assert.assertEquals(doc.getFirstSecondaryColor(),"Red");

	}

	/*
	 * TC186923, TC186937
	 */
@Test
	public void testMultipleValues() throws Exception {
		System.out.println("In method 'testMultipleValues'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsSearchRequest>"
				+ "<DrugSearchDescription SHAPE=\"Capsule-shape\" PATTERN=\"Two-toned\">"
				+ "<ImprintList SIZE=\"1\">"
				+ "<Imprint>90 mg"
				+ "</Imprint>"
				+ "</ImprintList>"
				+ "<ColorList SIZE =\"2\">"
				+ "<Color>Red"
				+ "</Color>"
				+ "<Color>White"
				+ "</Color>"
				+ "</ColorList>"
				+ "</DrugSearchDescription>"
				+ "</ImagesImprintsSearchRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getDrugListSize(),"11");
		Assert.assertTrue(doc.getDrugcodes("54868-4943-01"));
		Assert.assertEquals(doc.getFirstPattern(),"Two-toned");
		Assert.assertEquals(doc.getFirstImprintCodes(),"90 mg");
		Assert.assertEquals(doc.getFirstPrimaryColor(),"Red");


	}




}
