package com.truven.ids.application.cko.uitest.regression.pageobjects;

import java.util.List;

import org.jdom.Document;
import org.jdom.Element;


/**
 * ServiceStatusDoc contains Service Status specific methods.
 * @author APeavy
 * 
 */
public class ServiceStatusDoc extends BaseDoc {
	
	public ServiceStatusDoc(Document inputDoc) {
		super(inputDoc);
	}

	public String getDataSetListSize() {
		return doc.getRootElement()
				.getChild("DataSetList")
				.getAttributeValue("SIZE");
	}
	
	public String getAllDataSetTypes() {
		StringBuffer types = new StringBuffer();
		List<?> dataSets = doc.getRootElement()
				.getChild("DataSetList").getChildren("DataSet");
		for (Object dataSet : dataSets) {
			types.append( ((Element) dataSet).getAttributeValue("TYPE") );
			types.append("|");
		}
		return types.toString();
	}
	
}
