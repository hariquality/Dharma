package com.truven.ids.application.cko.uitest.local.lookup;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.LookupDoc;

public class TestRegistryTypeLookup extends CKOBaseTest {

	/**
	 * TC349823 ---Verify whether user able to filter lookup records which
	 * registry_type value is GTIN
	 * 
	 */

	@Test
	public void testRegistryTypeLookup() throws Exception {
		System.out.println("In method 'testRegistryTypeLookup'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGISTRY_TYPE' REGION='IT'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='registry_type' VALUE='GTIN'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "registry_type|registry_type_full");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("registry_type", "GTIN"),
				"GTIN is not in registry_type field");
	}

	/**
	 * TC349809 ---Verify whether the appropriate values based on the request are
	 * getting displayed for ""REGISTRY_TYPE"" lookup on using
	 * SearchParameterItemList and ""OR"" OPERATOR
	 * 
	 */

	@Test
	public void testRegistryTypeLookup1() throws Exception {
		System.out.println("In method 'testRegistryTypeLookup1'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGISTRY_TYPE' >" + "<SearchParameterList SIZE='4' OPERATOR='OR'>"
				+ "<SearchParameter NAME='registry_type' VALUE='GTIN'/>"
				+ "<SearchParameter NAME='registry_type_full' VALUE='National Trade Item Number'/>"
				+ "<SearchParameterItemList>" + "<Item NAME='registry_type' VALUE='NC'/>"
				+ "<Item NAME='registry_type_full' VALUE='National Code'/>" + "</SearchParameterItemList>"
				+ "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "registry_type|registry_type_full");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("registry_type", "GTIN"),
				"GTIN is not in registry_type field");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("registry_type_full", "National Trade Item Number"),
				"National Trade Item Number is not in registry_type_full field");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("reregistry_type", "NC"),
				"NC is not in registry_type field");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("registry_type_full", "National Code"),
				"National Code is not in registry_type_full field");

	}

	/**
	 * TC349810 --- Verify whether the appropriate values based on the request are
	 * getting displayed for ""REGISTRY_TYPE"" lookup on using
	 * SearchParameterItemList and ""AND"" OPERATOR
	 * 
	 */

	@Test
	public void testRegistryTypeLookup2() throws Exception {
		System.out.println("In method 'testRegistryTypeLookup2'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGISTRY_TYPE'>" + "<SearchParameterList SIZE='4' OPERATOR='AND'>"
				+ "<SearchParameter NAME='registry_type' VALUE='GTIN'/>"
				+ "<SearchParameter NAME='registry_type_full' VALUE='Global Trade Item Number'/>"

				+ "<SearchParameterItemList>" + "<Item NAME='registry_type' VALUE='GTIN'/>"
				+ "<Item NAME='registry_type_full' VALUE='Global Trade Item Number'/>"

				+ "</SearchParameterItemList>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "registry_type|registry_type_full");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("registry_type", "GTIN"),
				"GTIN is not in registry_type field");
	}

	/**
	 * TC349773 --- Verify whether all the registry_type content are displayed for
	 * Registry_type LookupType
	 * 
	 */

	@Test
	public void testRegistryTypeLookup3() throws Exception {
		System.out.println("In method 'testRegistryTypeLookup3'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGISTRY_TYPE' >" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "registry_type|registry_type_full");
		Assert.assertEquals(doc.getLookUpRecordListSize(), "4");
	}

	/**
	 * TC349809 ---Verify whether the appropriate values based on the request are
	 * getting displayed for ""REGISTRY_TYPE"" lookup on using
	 * SearchParameterItemList and ""OR"" OPERATOR
	 * 
	 */

	@Test
	public void testRegistryTypeLookup4() throws Exception {
		System.out.println("In method 'testRegistryTypeLookup4'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGISTRY_TYPE' >" + "<SearchParameterList SIZE='2' OPERATOR='OR'>"
				+ "<SearchParameter NAME='registry_type' VALUE='GTIN'/>"
				+ "<SearchParameter NAME='registry_type_full' VALUE='National Trade Item Number'/>"
				+ "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "registry_type|registry_type_full");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("registry_type", "GTIN"),
				"GTIN is not in registry_type field");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("registry_type_full", "National Trade Item Number"),
				"National Trade Item Number is not in registry_type_full field");

	}

	/**
	 * TC349807 --- Verify whether the appropriate values based on the request are
	 * getting displayed for ""REGISTRY_TYPE"" lookup on using ""AND"" OPERATOR
	 * 
	 */

	@Test
	public void testRegistryTypeLookup5() throws Exception {
		System.out.println("In method 'testRegistryTypeLookup5'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGISTRY_TYPE' >" + "<SearchParameterList SIZE='2' OPERATOR='AND'>"
				+ "<SearchParameter NAME='registry_type' VALUE='GTIN'/>"
				+ "<SearchParameter NAME='registry_type_full' VALUE='Global Trade Item Number'/>"
				+ "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "registry_type|registry_type_full");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("registry_type", "GTIN"),
				"GTIN is not in registry_type field");
	}

	/**
	 * TC349811 --- Verify whether all the data of "REGISTRY_TYPE" lookup is not
	 * displayed on providing incorrect region.
	 * 
	 */

	@Test
	public void testRegistryTypeLookup6() throws Exception {
		System.out.println("In method 'testRegistryTypeLookup6'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGISTRY_TYPE' REGION='' >" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "registry_type|registry_type_full");
		Assert.assertEquals(doc.getLookUpRecordListSize(), "4");
	}

	/**
	 * TC349774 --- Verify whether the following error message "Invalid Search
	 * Parameter for Registry_type" is displayed on providing Invalid Search
	 * Parameter for Registry_type lookup
	 * 
	 * 
	 */

	@Test
	public void testRegistryTypeLookup7() throws Exception {
		System.out.println("In method 'testRegistryTypeLookup7'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGISTRY_TYPE' REGION='IT'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='form' VALUE='table'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "1");
		Assert.assertEquals(doc.getErrorListErrorText(), "Invalid Search Parameter for REGISTRY_TYPE LookUp");
	}

	/**
	 * TC349772 ---Registry_type search using "registry_type"
	 * 
	 */

	@Test
	public void testRegistryTypeLookup8() throws Exception {
		System.out.println("In method 'testRegistryTypeLookup8'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGISTRY_TYPE' >" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='registry_type' VALUE='NC'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "registry_type|registry_type_full");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("registry_type", "NC"),
				"NC is not in registry_type field");
	}

	/**
	 * TC349771 ---Registry_type search using "registry_type"
	 * 
	 */

	@Test
	public void testRegistryTypeLookup9() throws Exception {
		System.out.println("In method 'testRegistryTypeLookup9'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGISTRY_TYPE' >" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='registry_type_full' VALUE='Global Trade Item Number'/>"
				+ "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "registry_type|registry_type_full");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("registry_type_full", "Global Trade Item Number"),
				"Global Trade Item Number is not in registry_type_full field");
	}

}
