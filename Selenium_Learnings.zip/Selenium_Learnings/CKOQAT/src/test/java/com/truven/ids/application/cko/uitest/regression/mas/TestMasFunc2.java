package com.truven.ids.application.cko.uitest.regression.mas;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.MasDoc;

/**
 * MAS functional tests
 * 
 * @author APeavy
 * 
 */
public class TestMasFunc2 extends CKOBaseTest  {
	
	/**
	 * TC186880 TC186879
	 * verify a TC duplication warning doesn't have GM_IDs and
	 * does have TC_IDs
	 * 
	 * @throws Exception
	 */
	@Test
	public void testNoPregLactWarningsWithMalePatient() throws Exception {
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"MALE\" BIRTH_DATE=\""
				+ getBirthdateForGivenAgeInYears(20)
				+ "\" SMOKER=\"TRUE\" PREGNANT=\"FALSE\" LACTATING=\"FALSE\"/>" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"68084-0101-11\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"00456-4010-01\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"TC_DUPLICATION\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(), "2", "Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"2", "Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(), "1", "Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("TC_DUPLICATION"), "2", "Number of TC_DUPLICATION warnings");
		Assert.assertFalse(doc.isItemPresentByType("GM_ID"));
		Assert.assertTrue(doc.isItemPresentByType("TC_ID"));
		
	}
	
	
}
