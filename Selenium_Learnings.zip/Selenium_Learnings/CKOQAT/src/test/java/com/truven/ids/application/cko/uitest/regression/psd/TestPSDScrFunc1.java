package com.truven.ids.application.cko.uitest.regression.psd;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.PSDDoc;

/**
 * 
 * 
 * @author APeavy
 * 
 */
public class TestPSDScrFunc1 extends CKOBaseTest  {

	/**
	 * trying normal screen - CMS2285344
	 * @throws Exception
	 */
	@Test 
	public void testSimpleScreen() throws Exception {
		System.out.println("In method 'testSimpleScreen'");
		
		PSDDoc doc = getPSDResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
				"<PSDScreeningRequest RECOMMEND=\"FALSE\">" + 
				"  <Patient GENDER=\"MALE\" AGE_IN_DAYS=\"20000\" WEIGHT=\"105\" HEIGHT=\"180\" />" + 
				"  <RequestScreeningRxList SIZE=\"1\">" + 
				"     <RequestScreeningRx>" + 
				"        <PSDDrug ID=\"101517\" TYPE=\"GFC\"/>" + 
				"        <RxDoseKey ROUTE_ID=\"103\" ROUTE_ID_TYPE=\"HL7\" DOSE_TYPE_ID=\"105\" INDICATION_ID=\"1384\" INDICATION_ID_TYPE=\"TH\"/>" + 
				"        <RequestScreeningParms DOSE=\"200\" DOSE_UNIT=\"mg\" PERIOD_INTERVAL_UNIT=\"hr\" DOSE_INTERVAL=\"4\" PRN=\"FALSE\"/>" + 
				"     </RequestScreeningRx>" + 
				"  </RequestScreeningRxList>" + 
				"  <DosingFilters INDICATION_NOT_SPECIFIED=\"NONSPECIFIC\" NO_INDICATION_MATCH=\"DONOTDOSE\" NORMAL_RESULTS_NO_RENAL_HEPATIC=\"TRUE\" RETURN_DOSE_KEYS=\"FALSE\"/>" + 
				"</PSDScreeningRequest>" + 
				"");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getScrResponseListSize(),"1");
		Assert.assertEquals(doc.getScrPSDDrugID(),"101517");
		Assert.assertEquals(doc.getScrPSDDrugType(),"GFC");
		Assert.assertEquals(doc.getScrDoseKeySize(),"1");
		//RxDoseKey
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("ROUTE_ID"),"103");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("ROUTE_ID_TYPE"),"HL7");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("ROUTE_NAME"),"Swallow, oral");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("DOSE_TYPE_ID"),"105");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("DOSE_TYPE_NAME"),"Maintenance");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("INDICATION_ID"),"1384");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("INDICATION_ID_TYPE"),"TH");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("INDICATION_NAME"),"Mild pain");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("SNOMED_CONCEPT_ID"),"40196000");
		//RecmndDosingUnits
		Assert.assertEquals(doc.getScrDosingUnitsAttrValue("DOSE_UNIT"),"MG");
		Assert.assertEquals(doc.getScrDosingUnitsAttrValue("NCPDP_FLAG"),"FALSE");
		Assert.assertEquals(doc.getScrDosingUnitsAttrValue("PERIOD_INTERVAL_UNIT"),"HR");
		// GeneralDoseParms
		Assert.assertEquals(doc.getScrGeneralDoseParmsAttrValue("DOSING_PATH"),"General");
		Assert.assertEquals(doc.getScrGeneralDoseParmsAttrValue("DOSING_METHOD"),"Flat");
		Assert.assertEquals(doc.getScrGeneralDoseParmsAttrValue("PRN"),"TRUE");
		// DoseModifierDescriptor
		Assert.assertEquals(doc.getScrDoseModifierScreeningResultAttrValue("SCREENING_PERFORMED"),"TRUE");
		Assert.assertEquals(doc.getScrDoseModifierScreeningResultAttrValue("RECOMMENDATION_PERFORMED"),"FALSE");
		// DoseModifierDescriptor
		Assert.assertEquals(doc.getScrDoseModifierDescriptorAttrValue("DOSE_MODIFIER_TYPE"),"Normal");
		Assert.assertEquals(doc.getScrDoseModifierDescriptorAttrValue("CONTRAINDICATED"),"FALSE");
		Assert.assertEquals(doc.getScrDoseModifierDescriptorAttrValue("NO_DOSE"),"FALSE");
		//ScreeningStatusFlags
		Assert.assertEquals(doc.getScrScreeningStatusFlagsAttrValue("SCREENING_STATUS"),"PASS");
		Assert.assertEquals(doc.getScrScreeningStatusFlagsAttrValue("DOSE_CHECK_STATUS"),"PASS");
		Assert.assertEquals(doc.getScrScreeningStatusFlagsAttrValue("PERIOD_DOSE_CHECK_STATUS"),"PASS");
		Assert.assertEquals(doc.getScrScreeningStatusFlagsAttrValue("INTERVAL_CHECK_STATUS"),"PASS");
		//DoseModifierScreeningParms
		Assert.assertEquals(doc.getScrDoseModifierScreeningParmsAttrValue("MIN_RECOMMENDED_DOSE"),"200");
		Assert.assertEquals(doc.getScrDoseModifierScreeningParmsAttrValue("MAX_RECOMMENDED_DOSE"),"200");
		Assert.assertEquals(doc.getScrDoseModifierScreeningParmsAttrValue("RECOMMENDED_PERIOD"),"24");
		Assert.assertEquals(doc.getScrDoseModifierScreeningParmsAttrValue("MIN_RECOMMENDED_PERIOD_DOSE"),"800");
		Assert.assertEquals(doc.getScrDoseModifierScreeningParmsAttrValue("MAX_RECOMMENDED_PERIOD_DOSE"),"1,200");
		Assert.assertEquals(doc.getScrDoseModifierScreeningParmsAttrValue("MIN_RECOMMENDED_DOSE_INTERVAL"),"4");
		Assert.assertEquals(doc.getScrDoseModifierScreeningParmsAttrValue("MAX_RECOMMENDED_DOSE_INTERVAL"),"6");
		// DerivedPeriodData
		Assert.assertEquals(doc.getScrDerivedPeriodDataAttrValue("PERIOD"),"24");
		Assert.assertEquals(doc.getScrDerivedPeriodDataAttrValue("PERIOD_UNIT"),"hr");
		Assert.assertEquals(doc.getScrDerivedPeriodDataAttrValue("PERIOD_STATUS"),"C");
		Assert.assertEquals(doc.getScrDerivedPeriodDataAttrValue("PERIOD_DOSE"),"1,200");
		
	}
	
	/**
	 * trying high dose screen - CMS2285344
	 * @throws Exception
	 */
	@Test 
	public void testHighDoseScreen() throws Exception {
		System.out.println("In method 'testHighDoseScreen'");
		
		PSDDoc doc = getPSDResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
				"<PSDScreeningRequest RECOMMEND=\"FALSE\">" + 
				"  <Patient GENDER=\"MALE\" AGE_IN_DAYS=\"20000\" WEIGHT=\"105\" HEIGHT=\"180\" />" + 
				"  <RequestScreeningRxList SIZE=\"1\">" + 
				"     <RequestScreeningRx>" + 
				"        <PSDDrug ID=\"114207\" TYPE=\"GFC\"/>" + 
				"        <RxDoseKey ROUTE_ID=\"103\" ROUTE_ID_TYPE=\"HL7\" DOSE_TYPE_ID=\"105\" INDICATION_ID=\"1531\" INDICATION_ID_TYPE=\"TH\"/>" + 
				"        <RequestScreeningParms DOSE=\"800\" DOSE_UNIT=\"mg\" PERIOD_INTERVAL_UNIT=\"hr\" DOSE_INTERVAL=\"24\" PRN=\"FALSE\"/>" + 
				"     </RequestScreeningRx>" + 
				"  </RequestScreeningRxList>" + 
				"  <DosingFilters INDICATION_NOT_SPECIFIED=\"NONSPECIFIC\" NO_INDICATION_MATCH=\"DONOTDOSE\" NORMAL_RESULTS_NO_RENAL_HEPATIC=\"TRUE\" RETURN_DOSE_KEYS=\"FALSE\"/>" + 
				"</PSDScreeningRequest>" + 
				"");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getScrResponseListSize(),"1");
		Assert.assertEquals(doc.getScrPSDDrugID(),"114207");
		Assert.assertEquals(doc.getScrPSDDrugType(),"GFC");
		Assert.assertEquals(doc.getScrDoseKeySize(),"1");
		//RxDoseKey
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("ROUTE_ID"),"103");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("ROUTE_ID_TYPE"),"HL7");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("ROUTE_NAME"),"Swallow, oral");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("DOSE_TYPE_ID"),"105");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("DOSE_TYPE_NAME"),"Maintenance");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("INDICATION_ID"),"1531");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("INDICATION_ID_TYPE"),"TH");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("INDICATION_NAME"),"Acute bacterial sinusitis");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("SNOMED_CONCEPT_ID"),"75498004");
		//RecmndDosingUnits
		Assert.assertEquals(doc.getScrDosingUnitsAttrValue("DOSE_UNIT"),"MG");
		Assert.assertEquals(doc.getScrDosingUnitsAttrValue("NCPDP_FLAG"),"FALSE");
		Assert.assertEquals(doc.getScrDosingUnitsAttrValue("PERIOD_INTERVAL_UNIT"),"HR");
		// GeneralDoseParms
		Assert.assertEquals(doc.getScrGeneralDoseParmsAttrValue("DOSING_PATH"),"General");
		Assert.assertEquals(doc.getScrGeneralDoseParmsAttrValue("DOSING_METHOD"),"Flat");
		Assert.assertEquals(doc.getScrGeneralDoseParmsAttrValue("PRN"),"FALSE");
		// DoseModifierDescriptor
		Assert.assertEquals(doc.getScrDoseModifierScreeningResultAttrValue("SCREENING_PERFORMED"),"TRUE");
		Assert.assertEquals(doc.getScrDoseModifierScreeningResultAttrValue("RECOMMENDATION_PERFORMED"),"FALSE");
		// DoseModifierDescriptor
		Assert.assertEquals(doc.getScrDoseModifierDescriptorAttrValue("DOSE_MODIFIER_TYPE"),"Normal");
		Assert.assertEquals(doc.getScrDoseModifierDescriptorAttrValue("CONTRAINDICATED"),"FALSE");
		Assert.assertEquals(doc.getScrDoseModifierDescriptorAttrValue("NO_DOSE"),"FALSE");
		//ScreeningStatusFlags
		Assert.assertEquals(doc.getScrScreeningStatusFlagsAttrValue("SCREENING_STATUS"),"FAIL");
		Assert.assertEquals(doc.getScrScreeningStatusFlagsAttrValue("DOSE_CHECK_STATUS"),"HIGH");
		Assert.assertEquals(doc.getScrScreeningStatusFlagsAttrValue("PERIOD_DOSE_CHECK_STATUS"),"HIGH");
		Assert.assertEquals(doc.getScrScreeningStatusFlagsAttrValue("INTERVAL_CHECK_STATUS"),"PASS");
		//DoseModifierScreeningParms
		Assert.assertEquals(doc.getScrDoseModifierScreeningParmsAttrValue("MIN_RECOMMENDED_DOSE"),"400");
		Assert.assertEquals(doc.getScrDoseModifierScreeningParmsAttrValue("MAX_RECOMMENDED_DOSE"),"400");
		Assert.assertEquals(doc.getScrDoseModifierScreeningParmsAttrValue("RECOMMENDED_PERIOD"),"24");
		Assert.assertEquals(doc.getScrDoseModifierScreeningParmsAttrValue("MIN_RECOMMENDED_PERIOD_DOSE"),"400");
		Assert.assertEquals(doc.getScrDoseModifierScreeningParmsAttrValue("MAX_RECOMMENDED_PERIOD_DOSE"),"400");
		Assert.assertEquals(doc.getScrDoseModifierScreeningParmsAttrValue("MIN_RECOMMENDED_DOSE_INTERVAL"),"24");
		Assert.assertEquals(doc.getScrDoseModifierScreeningParmsAttrValue("MAX_RECOMMENDED_DOSE_INTERVAL"),"24");
		// DerivedPeriodData
		Assert.assertEquals(doc.getScrDerivedPeriodDataAttrValue("PERIOD"),"24");
		Assert.assertEquals(doc.getScrDerivedPeriodDataAttrValue("PERIOD_UNIT"),"hr");
		Assert.assertEquals(doc.getScrDerivedPeriodDataAttrValue("PERIOD_STATUS"),"C");
		Assert.assertEquals(doc.getScrDerivedPeriodDataAttrValue("PERIOD_DOSE"),"800");
		// PSDMessage
		Assert.assertEquals(doc.getAllScrErrors(),"WARNING|OVERDOSE|Entered dose of 800 mg is greater than the usual maximum dose of 400 mg.|"
				+ "WARNING|OVERDOSE|Derived period dose of 800 mg per 24 hr is greater than the usual maximum period dose of 400 mg per 24 hr.|" +
				"INFORMATION_PLUS|DOSE INFORMATION|Usual duration of therapy is 10 Day.|");
	}
	
	/**
	 * trying low dose screen - CMS2285344
	 * @throws Exception
	 */
	@Test 
	public void testLowDoseScreen() throws Exception {
		System.out.println("In method 'testLowDoseScreen'");
		
		PSDDoc doc = getPSDResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
				"<PSDScreeningRequest RECOMMEND=\"FALSE\">" + 
				"  <Patient GENDER=\"MALE\" AGE_IN_DAYS=\"20000\" WEIGHT=\"105\" HEIGHT=\"180\" />" + 
				"  <RequestScreeningRxList SIZE=\"1\">" + 
				"     <RequestScreeningRx>" + 
				"        <PSDDrug ID=\"107197\" TYPE=\"GFC\"/>" + 
				"        <RxDoseKey ROUTE_ID=\"103\" ROUTE_ID_TYPE=\"HL7\" DOSE_TYPE_ID=\"105\" INDICATION_ID=\"1299\" INDICATION_ID_TYPE=\"TH\"/>" + 
				"        <RequestScreeningParms DOSE=\"400\" DOSE_UNIT=\"mg\" PERIOD_INTERVAL_UNIT=\"hr\" DOSE_INTERVAL=\"8\" PRN=\"FALSE\"/>" + 
				"     </RequestScreeningRx>" + 
				"  </RequestScreeningRxList>" + 
				"  <DosingFilters INDICATION_NOT_SPECIFIED=\"NONSPECIFIC\" NO_INDICATION_MATCH=\"DONOTDOSE\" NORMAL_RESULTS_NO_RENAL_HEPATIC=\"TRUE\" RETURN_DOSE_KEYS=\"FALSE\"/>" + 
				"</PSDScreeningRequest>" + 
				"");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getScrResponseListSize(),"1");
		Assert.assertEquals(doc.getScrPSDDrugID(),"107197");
		Assert.assertEquals(doc.getScrPSDDrugType(),"GFC");
		Assert.assertEquals(doc.getScrDoseKeySize(),"1");
		//RxDoseKey
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("ROUTE_ID"),"103");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("ROUTE_ID_TYPE"),"HL7");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("ROUTE_NAME"),"Swallow, oral");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("DOSE_TYPE_ID"),"105");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("DOSE_TYPE_NAME"),"Maintenance");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("INDICATION_ID"),"1299");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("INDICATION_ID_TYPE"),"TH");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("INDICATION_NAME"),"Malaria");
		Assert.assertEquals(doc.getScrRxDoseKeyAttrValue("SNOMED_CONCEPT_ID"),"61462000");
		//RecmndDosingUnits
		Assert.assertEquals(doc.getScrDosingUnitsAttrValue("DOSE_UNIT"),"MG");
		Assert.assertEquals(doc.getScrDosingUnitsAttrValue("NCPDP_FLAG"),"FALSE");
		Assert.assertEquals(doc.getScrDosingUnitsAttrValue("PERIOD_INTERVAL_UNIT"),"HR");
		// GeneralDoseParms
		Assert.assertEquals(doc.getScrGeneralDoseParmsAttrValue("DOSING_PATH"),"General");
		Assert.assertEquals(doc.getScrGeneralDoseParmsAttrValue("DOSING_METHOD"),"Flat");
		Assert.assertEquals(doc.getScrGeneralDoseParmsAttrValue("PRN"),"FALSE");
		// DoseModifierDescriptor
		Assert.assertEquals(doc.getScrDoseModifierScreeningResultAttrValue("SCREENING_PERFORMED"),"TRUE");
		Assert.assertEquals(doc.getScrDoseModifierScreeningResultAttrValue("RECOMMENDATION_PERFORMED"),"FALSE");
		// DoseModifierDescriptor
		Assert.assertEquals(doc.getScrDoseModifierDescriptorAttrValue("DOSE_MODIFIER_TYPE"),"Normal");
		Assert.assertEquals(doc.getScrDoseModifierDescriptorAttrValue("CONTRAINDICATED"),"FALSE");
		Assert.assertEquals(doc.getScrDoseModifierDescriptorAttrValue("NO_DOSE"),"FALSE");
		//ScreeningStatusFlags
		Assert.assertEquals(doc.getScrScreeningStatusFlagsAttrValue("SCREENING_STATUS"),"FAIL");
		Assert.assertEquals(doc.getScrScreeningStatusFlagsAttrValue("DOSE_CHECK_STATUS"),"LOW");
		Assert.assertEquals(doc.getScrScreeningStatusFlagsAttrValue("PERIOD_DOSE_CHECK_STATUS"),"LOW");
		Assert.assertEquals(doc.getScrScreeningStatusFlagsAttrValue("INTERVAL_CHECK_STATUS"),"PASS");
		//DoseModifierScreeningParms
		Assert.assertEquals(doc.getScrDoseModifierScreeningParmsAttrValue("MIN_RECOMMENDED_DOSE"),"520");
		Assert.assertEquals(doc.getScrDoseModifierScreeningParmsAttrValue("MAX_RECOMMENDED_DOSE"),"650");
		Assert.assertEquals(doc.getScrDoseModifierScreeningParmsAttrValue("RECOMMENDED_PERIOD"),"24");
		Assert.assertEquals(doc.getScrDoseModifierScreeningParmsAttrValue("MIN_RECOMMENDED_PERIOD_DOSE"),"1,560");
		Assert.assertEquals(doc.getScrDoseModifierScreeningParmsAttrValue("MAX_RECOMMENDED_PERIOD_DOSE"),"1,950");
		Assert.assertEquals(doc.getScrDoseModifierScreeningParmsAttrValue("MIN_RECOMMENDED_DOSE_INTERVAL"),"8");
		Assert.assertEquals(doc.getScrDoseModifierScreeningParmsAttrValue("MAX_RECOMMENDED_DOSE_INTERVAL"),"8");
		// DerivedPeriodData
		Assert.assertEquals(doc.getScrDerivedPeriodDataAttrValue("PERIOD"),"24");
		Assert.assertEquals(doc.getScrDerivedPeriodDataAttrValue("PERIOD_UNIT"),"hr");
		Assert.assertEquals(doc.getScrDerivedPeriodDataAttrValue("PERIOD_STATUS"),"C");
		Assert.assertEquals(doc.getScrDerivedPeriodDataAttrValue("PERIOD_DOSE"),"1,200");
		// PSDMessage
		Assert.assertEquals(doc.getAllScrErrors(),"WARNING|SUBTHERAPEUTIC|Entered dose of 400 mg is less than the usual minimum dose of 520 mg.|"
				+ "WARNING|SUBTHERAPEUTIC|Derived period dose of 1,200 mg per 24 hr is less than the usual minimum period dose of 1,560 mg per 24 hr.|" +
				"INFORMATION_PLUS|DOSE INFORMATION|Usual duration of therapy is 7 Day.|");
	}
	

}