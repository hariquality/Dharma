package com.truven.ids.application.cko.cpsi.pageobjects;


import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class MasDoc extends CPSIBaseDoc{

	
	
	public MasDoc(JSONObject jsonObject) {
		super(jsonObject);
	}

	public String getDrugSize() {
		return jo.getJSONObject("Response").getJSONObject("WarningList").getString("SIZE");
				
	}
	
	public Boolean verifyMAsResponseContains(String expectedValue) {
	   
	   JSONArray drugsList = jo.getJSONObject("Response").
	         getJSONObject("WarningList").getJSONArray("Warning");
	   // iterate through all returned records
	   
	   for (int i = 0; i < drugsList.length(); i++ ) {
	    JSONObject jo1 = (JSONObject)drugsList.get(i);

	    String imprintCode = jo1.getString("WarningText");
	    
	    if (imprintCode.contains(expectedValue)) {
	       return true;
	    }
	   }
	   return false;
	  }
	
	
public Boolean verifyMAS_Monograph_Text(String expectedValue) {
    
    JSONArray drugsList = jo.getJSONObject("Response").
          getJSONObject("DocumentList").getJSONArray("Document");
    // iterate through all returned records
    
    for (int i = 0; i < drugsList.length(); i++ ) {
     JSONObject jo1 = (JSONObject)drugsList.get(i);

     String imprintCode = jo1.getString("Text");
     
     if (imprintCode.contains(expectedValue)) {
        return true;
     }
    }
    return false;
   }
	
	
	
}
