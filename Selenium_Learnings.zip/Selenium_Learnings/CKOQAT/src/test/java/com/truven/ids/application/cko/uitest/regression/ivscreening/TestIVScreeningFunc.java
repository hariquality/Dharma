package com.truven.ids.application.cko.uitest.regression.ivscreening;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.IVScreeningDoc;

/**
 * 
 * 
 * @author APeavy
 * 
 */
public class TestIVScreeningFunc extends CKOBaseTest  {

	/**
	 * TC186795
	 * Verify happy path with NDC
	 * 
	 * @throws Exception
	 */
	@Test
	public void testNDCs() throws Exception {
		System.out.println("In method 'testNDCs'");
		IVScreeningDoc doc = getIVScreeningResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<IVScreeningRequest>"
				+ "  <NewDrugList SIZE=\"2\">"
				+ "    <Drug CODE=\"00074-1027-02\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "    <Drug CODE=\"00074-1990-10\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "  </NewDrugList>"
				+ "</IVScreeningRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDocumentListSize(),"1");
		Assert.assertTrue(doc.isPhraseInTextElement("<font face=\"Verdana\">Amikacin sulfate - Acyclovir sodium</font>"),
				"Expected drug-drug signature not found in HTML");
	}
	
	/**
	 * TC186796
	 * Verify happy path with GFC
	 * 
	 * @throws Exception
	 */
	@Test
	public void testGFCs() throws Exception {
		System.out.println("In method 'testGFCs'");
		IVScreeningDoc doc = getIVScreeningResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<IVScreeningRequest>"
				+ "  <NewDrugList SIZE=\"2\">"
				+ "    <Drug CODE=\"100086\" TYPE=\"GFC\" STATUS=\"ACTIVE\"/>"
				+ "    <Drug CODE=\"100036\" TYPE=\"GFC\" STATUS=\"ACTIVE\"/>"
				+ "  </NewDrugList>"
				+ "</IVScreeningRequest>");
		Assert.assertEquals("0", doc.getErrorListSize());
		Assert.assertEquals("1", doc.getDocumentListSize());
		Assert.assertTrue(doc.isPhraseInTextElement("<font face=\"Verdana\">Amikacin sulfate - Acyclovir sodium</font>"),
				"Expected drug-drug signature not found in HTML");
	}
	
	/**
	 * TC186797
	 * Verify mix of NDCs and GFCs
	 * 
	 * @throws Exception
	 */
	@Test
	public void testMixNDCsGFCs() throws Exception {
		System.out.println("In method 'testMixNDCsGFCs'");
		IVScreeningDoc doc = getIVScreeningResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<IVScreeningRequest>"
				+ "  <NewDrugList SIZE=\"2\">"
				+ "    <Drug CODE=\"100086\" TYPE=\"GFC\" STATUS=\"ACTIVE\"/>"
				+ "    <Drug CODE=\"00074-1990-10\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "  </NewDrugList>"
				+ "</IVScreeningRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDocumentListSize(),"1");
		Assert.assertTrue(doc.isPhraseInTextElement("<font face=\"Verdana\">Amikacin sulfate - Acyclovir sodium</font>"),
				"Expected drug-drug signature not found in HTML");
	}
	
	/**
	 * TC186798
	 * Verify current vs new
	 * 
	 * @throws Exception
	 */
	@Test
	public void testCurrentVsNew() throws Exception {
		System.out.println("In method 'testCurrentVsNew'");
		IVScreeningDoc doc = getIVScreeningResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<IVScreeningRequest>"
				+ "  <CurrentDrugList SIZE=\"2\">"
				+ "    <Drug CODE=\"00074-1027-02\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "    <Drug CODE=\"00074-1995-20\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "  </CurrentDrugList>"
				+ "  <NewDrugList SIZE=\"2\">"
				+ "    <Drug CODE=\"101092\" TYPE=\"GFC\" STATUS=\"ACTIVE\"/>"
				+ "    <Drug CODE=\"103488\" TYPE=\"GFC\" STATUS=\"ACTIVE\"/>"
				+ "  </NewDrugList>"
				+ "</IVScreeningRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDocumentListSize(),"1");
		// assert that a comparison of the two drugs will not be found
		Assert.assertFalse(doc.isPhraseInTextElement("Amikacin sulfate - Acyclovir sodium"),
				"Unexpected drug-drug signature found in HTML");
		// assert each drug individually will be found
		Assert.assertTrue(doc.isPhraseInTextElement("Amikacin sulfate"));
		Assert.assertTrue(doc.isPhraseInTextElement("Acyclovir sodium"));
	}
	
	/**
	 * TC186799
	 * Verify drug with premix isn't compared to its own solution
	 * 
	 * @throws Exception
	 */
	@Test
	public void testPremixNotScreened() throws Exception {
		System.out.println("In method 'testPremixNotScreened'");
		IVScreeningDoc doc = getIVScreeningResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<IVScreeningRequest>"
				+ "  <NewDrugList SIZE=\"2\">"
				+ "    <Drug CODE=\"00004-2002-78\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "    <Drug CODE=\"00074-1990-10\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "  </NewDrugList>"
				+ "</IVScreeningRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDocumentListSize(),"1");
		Assert.assertTrue(doc.isPhraseInTextElement("Ceftriaxone sodium - Acyclovir sodium"),
				"Expected drug-drug signature not found in HTML");
		Assert.assertTrue(doc.isPhraseInTextElement("Drug-Solution"),
				" drug-solution signature not found in HTML");
	}
	
	/**
	 * TC186800
	 * Verify drug with premix is compared to premix when 
	 * explicitly specified 
	 * 
	 * @throws Exception
	 */
	@Test
	public void testPremixIsScreened() throws Exception {
		System.out.println("In method 'testPremixIsScreened'");
		IVScreeningDoc doc = getIVScreeningResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<IVScreeningRequest>"
				+ "  <NewDrugList SIZE=\"3\">"
				+ "    <Drug CODE=\"00004-2002-78\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "    <Drug CODE=\"00074-1990-10\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "    <Drug CODE=\"101092\" TYPE=\"GFC\" STATUS=\"ACTIVE\"/>"
				+ "  </NewDrugList>"
				+ "</IVScreeningRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDocumentListSize(),"1");
		Assert.assertTrue(doc.isPhraseInTextElement("Ceftriaxone sodium - Acyclovir sodium"),
				"Expected drug-drug signature not found in HTML");
		Assert.assertTrue(doc.isPhraseInTextElement("Drug-Solution"),
				"Expected drug-solution signature not found in HTML");
	}
	
}
