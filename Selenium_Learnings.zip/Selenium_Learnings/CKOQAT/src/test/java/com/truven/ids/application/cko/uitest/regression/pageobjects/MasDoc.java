package com.truven.ids.application.cko.uitest.regression.pageobjects;

import java.util.Iterator;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;

import com.truven.ids.application.cko.uitest.regression.pageobjects.BaseDoc;

/**
 * MasDoc contains MAS specific methods.
 * 
 * @author APeavy
 * 
 */
public class MasDoc extends BaseDoc {

	public MasDoc(Document inputDoc) {
		super(inputDoc);
	}

	public String getSummaryInteractionTotal() {
		return doc.getRootElement().getChild("Summary").getAttributeValue("INTERACTION_TOTAL");
	}

	public String getSummaryWarningTotal() {
		return doc.getRootElement().getChild("Summary").getAttributeValue("WARNING_TOTAL");
	}

	public String getInteractionsTypeSummarySize() {
		return doc.getRootElement().getChild("Summary").getChild("InteractionTypeSummaryList")
				.getAttributeValue("SIZE");
	}

	public String getNumberOfWarningsByType(String inputType) {
		String totalValue = null;
		List<?> warnings = doc.getRootElement().getChild("Summary").getChild("InteractionTypeSummaryList")
				.getChildren();
		Iterator<?> i = warnings.iterator();
		while (i.hasNext()) {
			Element summary = (Element) i.next();
			if (summary.getAttributeValue("TYPE").compareTo(inputType) == 0) {
				totalValue = summary.getAttributeValue("TOTAL");
				break;
			}
		}
		return totalValue;
	}

	/**
	 * So far, only a need to get one monograph_id, so need to force request so that
	 * only one warning returned
	 * 
	 * @return
	 */
	public String getFirstWarningMonographId() {
		return doc.getRootElement().getChild("WarningList").getChild("Warning").getAttributeValue("MONOGRAPH_ID");
	}

	/**
	 * So far, only a need to get one WarningText, so need to force only one warning
	 * returned
	 * 
	 * @return
	 */
	public String getFirstWarningText() {
		return doc.getRootElement().getChild("WarningList").getChild("Warning").getChildText("WarningText");
	}

	/**
	 * Return a string representing the GFC and matching ORDER_ID for each warning.
	 * Highly specialized, not sure if it will be useful outside of the one test
	 * case.
	 * 
	 * @return
	 */
	public String getOrderIdPairs() {
		StringBuilder idOrder = new StringBuilder();
		List<?> warnings = doc.getRootElement().getChild("WarningList").getChildren("Warning");
		for (Object warning : warnings) {
			List<?> itemLists = ((Element) warning).getChildren("ItemList");
			for (Object itemList : itemLists) {
				List<?> items = ((Element) itemList).getChildren("Item");
				for (Object item : items) {
					if (((Element) item).getAttributeValue("TYPE").contentEquals("GFC")
							| ((Element) item).getAttributeValue("TYPE").contentEquals("ORDER_ID")) {
						idOrder.append(((Element) item).getAttributeValue("ID"));
						idOrder.append("|");
					}
				}
			}
			idOrder.append("--");
		}
		System.out.println("idOrder:" + idOrder.toString());
		return idOrder.toString();
	}

	/**
	 * Return a boolean if the given Item TYPE is in the warning
	 * 
	 * @return
	 */
	public Boolean isItemPresentByType(String inputType) {
		Boolean typePresent = false;
		List<?> warnings = doc.getRootElement().getChild("WarningList").getChildren("Warning");
		for (Object warning : warnings) {
			List<?> itemLists = ((Element) warning).getChildren("ItemList");
			for (Object itemList : itemLists) {
				List<?> items = ((Element) itemList).getChildren("Item");
				for (Object item : items) {
					if (((Element) item).getAttributeValue("TYPE").contentEquals(inputType)) {
						typePresent = true;
					}
				}
			}
		}
		return typePresent;
	}

	/**
	 * This method has been introduced to validate the region tag in the XML
	 * response
	 * 
	 * @return
	 */
	public String getFirstRegionValue() {
		return doc.getRootElement().getChild("WarningList").getChild("Warning").getAttributeValue("REGION");
	}

	public String getErrorTextforMALE() {
		return doc.getRootElement().getChild("ErrorList").getChild("Error").getAttributeValue("ERROR_TEXT");

	}

	public Boolean getWarningTextseq(String inputText) {
		int i = 0;
		int flag = 0;
		List<?> warnings = doc.getRootElement().getChild("WarningList").getChildren("Warning");
		i = warnings.size();
		// multiple warning
		if (i > 0) {
			Iterator<?> w = warnings.iterator();
			while (w.hasNext()) {
				Element summary = (Element) w.next();
				if ((summary.getChildText("WarningText").equalsIgnoreCase(inputText))) {
					System.out.println("success");
					System.out.println("response Value" + (summary.getChildText("WarningText")));
					System.out.println("Expected Value" + inputText);
					// w.next();
					flag = 1;
				} else {
					System.out.println("not equal fail");
					System.out.println("response Value : " + (summary.getChildText("WarningText")));
					System.out.println("Expected Value : " + inputText);
				}
			}
		}
		if (flag == 1)
			return true;
		else
			return false;
	}

	public Boolean getWarningRegion(String inputText) {
		int i = 0;
		int flag = 0;
		List<?> warnings = doc.getRootElement().getChild("WarningList").getChildren("Warning");
		i = warnings.size();
		Iterator<?> w = warnings.iterator();
		while (w.hasNext()) {
			Element totalwarnings = (Element) w.next();
			List<?> s = totalwarnings.getAttributes();
			i = s.size();
			if (i == 7) {
				System.out.println("Region : " + totalwarnings.getAttributeValue("REGION"));
				if (totalwarnings.getAttributeValue("REGION").equalsIgnoreCase(inputText)) {
					flag = 1;
				}
			}
		}
		if (flag == 1)
			return true;
		else
			return false;
	}
}
