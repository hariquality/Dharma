package com.truven.ids.application.cko.uitest.local.lookup;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.LookupDoc;

public class TestLookupTypeLocal extends CKOBaseTest {

	/**
	 * TC349775 ---Verify whether all the LOOKUP_TYPE are getting displayed along
	 * with newly created lookups
	 * GENERIC_NAME_LOCAL,GNGCRRT_LOCAL,REGISTRYCODE_GFC_LOCAL, TRADE_NAME_LOCAL,
	 * REGION_LOCALE_MAP, REGISTRY_TYPE for local customers
	 * 
	 */

	@Test
	public void testLookupTypeLocal() throws Exception {
		System.out.println("In method 'testLookupTypeLocal'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='LOOKUP_TYPE' REGION='IT'>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "lookup_type");
		Assert.assertEquals(doc.getLookUpRecordListSize(), "32");
	}

	/**
	 * TC349777 ---Verify whether all the LOOKUP_TYPE except the newly created
	 * lookups like GENERIC_NAME_LOCAL,GNGCRRT_LOCAL,REGISTRYCODE_GFC_LOCAL,
	 * TRADE_NAME_LOCAL, REGION_LOCALE_MAP, REGISTRY_TYPE are getting displayed
	 * 
	 */

	@Test
	public void testLookupTypeLocal1() throws Exception {
		System.out.println("In method 'testLookupTypeLocal1'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='LOOKUP_TYPE' REGION='US'>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "lookup_type");
		Assert.assertEquals(doc.getLookUpRecordListSize(), "26");
	}

	/**
	 * TC349776 ---Verify whether all the LOOKUP_TYPE except the newly created
	 * lookups like GENERIC_NAME_LOCAL,GNGCRRT_LOCAL,REGISTRYCODE_GFC_LOCAL,
	 * TRADE_NAME_LOCAL, REGION_LOCALE_MAP, REGISTRY_TYPE are getting displayed
	 * 
	 */

	@Test
	public void testLookupTypeLocal2() throws Exception {
		System.out.println("In method 'testLookupTypeLocal2'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='LOOKUP_TYPE'>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "lookup_type");
		Assert.assertEquals(doc.getLookUpRecordListSize(), "26");
	}

	/**
	 * TC349835 ---Verify whether only the US Content are getting displayed when
	 * request for ""NDCGFC"" lookup type only
	 * 
	 */

	@Test
	public void testLookupTypeLocal3() throws Exception {
		System.out.println("In method 'testLookupTypeLocal3'");
		LookupDoc doc = getLookupResultDoc(
				"<?xml version='1.0' encoding='iso-8859-1'?>" + "<LUSRequest LookUpType='NDCGFC' >" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "ndc|gfc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("ndc", "00002-0329-02"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("gfc", "102913"));
	}

	/**
	 * TC349834 ---Verify whether only the US Content are getting displayed for
	 * "NDCGFC" lookup on search with US
	 * 
	 */

	@Test
	public void testLookupTypeLocal4() throws Exception {
		System.out.println("In method 'testLookupTypeLocal4'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='NDCGFC' >" + "<SearchParameterList SIZE='2' OPERATOR='OR'>"
				+ "<SearchParameter NAME='ndc' VALUE='49836-0019-19'/>" + "<SearchParameter NAME='gfc' VALUE='133865'/>"
				+ "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "ndc|gfc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("ndc", "49836-0019-19"),
				"49836-0019-19 is not in ndc field");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("gfc", "133865"), "133865 is not in gfc field");
	}

	/**
	 * TC349833 ---Verify whether only the US Content are getting displayed for
	 * "NDCGFC" lookup on search using searchparameter item list
	 * 
	 */

	@Test
	public void testLookupTypeLocal5() throws Exception {
		System.out.println("In method 'testLookupTypeLocal5'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='NDCGFC' >" + "<SearchParameterList SIZE='4' OPERATOR='OR'>"
				+ "<SearchParameter NAME='ndc' VALUE='49836-0019-19'/>" + "<SearchParameter NAME='gfc' VALUE='133865'/>"
				+ "<SearchParameterItemList>" + "<Item NAME='ndc' VALUE='00000-4301-02'/>"
				+ "<Item NAME='gfc' VALUE='124693'/>" + "</SearchParameterItemList>" + "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "ndc|gfc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("ndc", "49836-0019-19"),
				"49836-0019-19 is not in ndc field");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("gfc", "133865"), "133865 is not in gfc field");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("ndc", "00000-4301-02"),
				"00000-4301-02 is not in ndc field");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("gfc", "124693"), "124693 is not in gfc field");

	}

	/**
	 * TC349764 ---Verify whether all the local and US content are displayed for
	 * GNGCRRT_LOCAL LookupType.
	 * 
	 */

	@Test
	public void testLookupTypeLocal6() throws Exception {
		System.out.println("In method 'testLookupTypeLocal6'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GNGCRRT_LOCAL' REGION='ES'>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "GCRName|RouteName|GCRCode|RouteCode|region");
		// Assert.assertEquals(doc.getLookUpRecordListSize(),"64440");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("GCRName", "bilastine"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("RouteName", "Intravenous"));
	}

	/**
	 * Verify whether the following error message "Invalid LookUp Type for Category"
	 * is displayed on providing Invalid LookUp Type TC349756-TC349759
	 */

	@Test
	public void testLookupTypeLocal7() throws Exception {
		System.out.println("In method 'testLookupTypeLocal7'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='FERBIBBLE' REGION='IT'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='gfc' VALUE='1032'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "1");
		Assert.assertEquals(doc.getErrorListErrorText(), "Invalid LookUp Type for Category");
	}

}
