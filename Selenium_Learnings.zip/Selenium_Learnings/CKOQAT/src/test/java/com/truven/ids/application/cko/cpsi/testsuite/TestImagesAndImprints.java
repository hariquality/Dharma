package com.truven.ids.application.cko.cpsi.testsuite;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.cpsi.pageobjects.ImagesAndImprintsDoc;
import com.truven.ids.application.cko.uitest.CPSIBaseTest;

public class TestImagesAndImprints extends CPSIBaseTest{

	
	@Test 
	public void testImageImprintsRequest() throws Exception {
	   System.out.println("In method 'testImageImprintsRequest'");
	   ImagesAndImprintsDoc doc = getImagesAndImprintsResultDoc("drug_images/ImagesImprints_Request_1");
	   Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"ImagesImprintsResult",
          "Server not connected OR Response is not displayed");
	   Assert.assertTrue(doc.verifyImprintCodePresentInDrug("DROXIA 6337"),"Expected Response is incorrect");
	  }
	
	
 @Test 
 public void testImageCodeRequest() throws Exception {
    System.out.println("In method 'testImageCodeRequest'");
    ImagesAndImprintsDoc doc = getImagesAndImprintsResultDoc("drug_images/ImagesImprints_Request_2");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"ImagesImprintsResult",
          "Server not connected OR Response is not displayed");
    Assert.assertTrue(doc.verifyImprintCodePresentInDrug("AMOXIL; 125"),"Expected Response is incorrect");
   }
	
	
	
		
}
