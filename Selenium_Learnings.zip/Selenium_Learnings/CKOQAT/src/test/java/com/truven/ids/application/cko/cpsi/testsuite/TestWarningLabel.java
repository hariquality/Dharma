package com.truven.ids.application.cko.cpsi.testsuite;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.cpsi.pageobjects.WarningLabelDoc;
import com.truven.ids.application.cko.uitest.CPSIBaseTest;

public class TestWarningLabel extends CPSIBaseTest{

	@Test 
	public void testWarningLabelsForArchitectureRequest() throws Exception {
	   System.out.println("In method 'testWarningLabelsForArchitectureRequest'");
	   WarningLabelDoc doc = getWarningLabelDoc("warning_labels/WarningLabelsArchitextRequest");
	   Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
	   Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected OR Response is not displayed");
	   Assert.assertEquals(doc.getDrugSize(),"1","Content set list size is incorrect");
	   Assert.assertTrue(doc.verifyWarningLabelTextFor("49884-0027-01","Text","IF THIS MEDICATION CAUSES UPSET STOMACH, TAKE WITH FOOD"),"Expected Warning messages is not displayed");
	   Assert.assertTrue(doc.verifyWarningLabelTextFor("49884-0027-01","PRINTER_GRAPHIC_CODE","77/4d"),"Expected Warning messages is not displayed");
	  }
	
	
 @Test 
 public void testWarningLabelsForInterconRequest() throws Exception {
    System.out.println("In method 'testWarningLabelsForInterconRequest'");
    WarningLabelDoc doc = getWarningLabelDoc("warning_labels/WarningLabelsInterconRequest");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getDrugSize(),"1","Content set list size is incorrect");
    Assert.assertTrue(doc.verifyWarningLabelTextFor("49884-0027-01","Text","MAY CAUSE DIZZINESS"),"Expected Warning messages is not displayed");
    Assert.assertTrue(doc.verifyWarningLabelTextFor("49884-0027-01","PRINTER_GRAPHIC_CODE","67/43"),"Expected Warning messages is not displayed");
   }
 
 
 @Test 
 public void testWarningLabelsRequest() throws Exception {
    System.out.println("In method 'testWarningLabelsRequest'");
    WarningLabelDoc doc = getWarningLabelDoc("warning_labels/WarningLabels_Request");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getDrugSize(),"1","Content set list size is incorrect");
    Assert.assertTrue(doc.verifyWarningLabelTextFor("101997","Text","TAKE WITH A FULL GLASS OF WATER"),"Expected Warning messages is not displayed");
    Assert.assertTrue(doc.verifyWarningLabelTextFor("101997","PRINTER_GRAPHIC_CODE",""),"Expected Warning messages is not displayed");
   }
		
	
}
