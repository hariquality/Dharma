package com.truven.ids.application.cko.uitest.regression.drugnotes;


import org.testng.Assert;
import org.testng.annotations.Test;

//import junit.framework.TestSuite;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.DrugNotesDoc;

/**
 * 
 * 
 * @author BHreen
 * 
 */
public class TestDrugNotesException extends CKOBaseTest  {


/**
 * TC187029
 * 
 */
	@Test
	
	public void testInvalidGFCDrugIdentifierType() throws Exception {
		System.out.println("In method 'testInvalidGFCDrugIdentifierType'");
 		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"English\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"102367\" TYPE=\"ABC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1");  // assert error
		Assert.assertTrue(doc.isPhraseInErrorElement("Invalid drug identifier type given: valid values are GFC or NDC."),
				"Invalid drug identifier type given: valid values are GFC or NDC.' not found in text element.");  //assert phrase in the text element
	
	}
	
	/**
	 * 
	 * TC187030
	 */
	@Test
	public void testWithoutGFCDrugIdentifierType() throws Exception {
		System.out.println("In method 'testWithoutGFCDrugIdentifierType'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"English\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"102367\" TYPE=\"\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals("1", doc.getErrorListSize());  // assert error
		Assert.assertTrue(doc.isPhraseInErrorElement("Invalid drug identifier type given: valid values are GFC or NDC."),
				"Invalid drug identifier type given: valid values are GFC or NDC.' not found in text element");  //assert phrase in the text element
	}
	
	
	
	/**
	 * 
	 * TC187031
	 */
	@Test
	public void testNoLanguage() throws Exception {
		System.out.println("In method 'testNoLanguage'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"12345-1234-12\" TYPE=\"NDC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals("1", doc.getErrorListSize());  // assert error
		Assert.assertTrue(doc.isPhraseInErrorElement("Invalid Patient Language."),"Invalid Patient Language.' not found in text element");  //assert phrase in the text element
	}
	
	
	/**
	 * 
	 * TC187032
	 */
	@Test
	public void testInvalidLanguage() throws Exception {
		System.out.println("In method 'testInvalidLanguage'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"ABCDEFG\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"12345-1234-12\" TYPE=\"NDC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals("1", doc.getErrorListSize());  // assert error
		Assert.assertTrue(doc.isPhraseInErrorElement("Invalid Patient Language."),
				"Invalid Patient Language.' not found in text element");  //assert phrase in the text element
	}
	
	/**
	 * 
	 * TC187035
	 */
	@Test
	public void testInvalidNDC() throws Exception {
		System.out.println("In method 'testInvalidNDC'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"English\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"12345-1234-12\" TYPE=\"NDC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals("1", doc.getErrorListSize()); // assert error
		Assert.assertTrue(doc.isPhraseInErrorElement("No data exists for the given drug identifier."),
				"No data exists for the given drug identifier.' not found in text element");  //assert phrase in the text element
	}
	
	
	
	/**
	 * 
	 * TC187036
	 */
	@Test
	public void testInvalidGFC() throws Exception {
		System.out.println("In method 'testInvalidGFC'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"English\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"654321\" TYPE=\"GFC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals("1", doc.getErrorListSize());  // assert error
		Assert.assertTrue(doc.isPhraseInErrorElement("No data exists for the given drug identifier."),
				"No data exists for the given drug identifier.' not found in text element");  //assert phrase in the text element
	}

	
	
	/**
	 * 
	 * TC187037
	 */
	@Test
	public void testInvalidGFCFormat() throws Exception {
		System.out.println("In method 'testInvalidGFCFormat'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"English\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"11-11-11\" TYPE=\"GFC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals("1", doc.getErrorListSize());  // assert error
		Assert.assertTrue(doc.isPhraseInErrorElement("Invalid GFC format: valid format is 123456"),
				"Invalid GFC format: valid format is 123456' not found in text element");  //assert phrase in the text element
	}

	
	/**
	 * 
	 * TC187038
	 */
	@Test
	public void testWithoutNDCCode() throws Exception {
		System.out.println("In method 'testWithoutNDCCode'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"English\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"\" TYPE=\"NDC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals("1", doc.getErrorListSize());  // assert no errors
		Assert.assertTrue(doc.isPhraseInErrorElement("Invalid NDC format: valid format is 12345-6789-10"),
				"Invalid NDC format: valid format is 12345-6789-10' not found in text element");  //assert phrase in the text element
	}
	
	
}