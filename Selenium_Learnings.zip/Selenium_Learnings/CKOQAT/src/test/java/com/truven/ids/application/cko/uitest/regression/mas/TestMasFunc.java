package com.truven.ids.application.cko.uitest.regression.mas;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.MasDoc;
import com.truven.ids.application.cko.uitest.regression.pageobjects.MonographDoc;

/**
 * MAS functional tests
 * 
 * @author APeavy
 * 
 */
public class TestMasFunc extends CKOBaseTest  {

	/**
	 * TC186864
	 * must be a male patient with an age that would be a 'possible child bearing' age
	 * I believe CKO's default is 16-60 years old.
	 * 
	 * @throws Exception
	 */
	@Test
	public void testNoPregLactWarningsWithMalePatient() throws Exception {
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"MALE\" BIRTH_DATE=\""
				+ getBirthdateForGivenAgeInYears(20)
				+ "\" SMOKER=\"TRUE\" PREGNANT=\"FALSE\" LACTATING=\"FALSE\"/>" + 
				"  <NewDrugList SIZE=\"4\">" + 
				"    <Drug CODE=\"00182-1908-01\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"00108-5012-20\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"00056-0169-70\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"114423\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"34","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"34","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"6","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"3","Number of Drug warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("FOOD"),"15","Number of Food warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("ETHANOL"),"3","Number of Ethanol warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("LAB"),"4","Number of Lab warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("TOBACCO"),"1","Number of Tobacco warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DISEASE"),"8","Number of Disease warnings"); 
		
	}
	
	/**
	 * TC186865 TC186866
	 * must be a female patient with an age that would be trigger a precaution
	 * 
	 * @throws Exception
	 */
	@Test
	public void testAgeSpecificPediatricPrecaution() throws Exception {
		// 16yo should get pre-pubertal precautions
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\""
				+ getBirthdateForGivenAgeInYears(15)
				+ "\" SMOKER=\"FALSE\" PREGNANT=\"FALSE\" LACTATING=\"FALSE\"/>" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"00403-3027-20\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"PRECAUTIONS\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"1","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"1","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"1","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("PRECAUTIONS"),"1","Number of Precautions warnings"); 
		
		// 20yo should not get pre-pubertal precautions, but should get pregnancy
		doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\""
				+ getBirthdateForGivenAgeInYears(20)
				+ "\" SMOKER=\"FALSE\" PREGNANT=\"FALSE\" LACTATING=\"FALSE\"/>" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"00403-3027-20\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"PRECAUTIONS\" />" + 
				"    <TypeFilter NAME=\"PREGNANCY\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"1","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"1","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"1","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("PREGNANCY"),"1","Number of Pregnancy warnings"); 

	}
	
	/**
	 * TC186867 TC186868
	 * must be a female patient with an age that would be trigger a precaution
	 * 
	 * @throws Exception
	 */
	@Test
	public void testAgeSpecificGeriatricPrecaution() throws Exception {
		// 65yo should get geriatric precautions
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\""
				+ getBirthdateForGivenAgeInYears(65)
				+ "\" SMOKER=\"FALSE\" PREGNANT=\"FALSE\" LACTATING=\"FALSE\"/>" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"00555-0363-05\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"PRECAUTIONS\" />" + 
				"    <TypeFilter NAME=\"ETHANOL\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"3","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"3","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"2","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("PRECAUTIONS"),"2","Number of Precautions warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("ETHANOL"),"1","Number of Ethanol warnings"); 
		
		// 20yo should not get GERIATRIC precautions, but should get ETHANOL
		doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\""
				+ getBirthdateForGivenAgeInYears(20)
				+ "\" SMOKER=\"FALSE\" PREGNANT=\"FALSE\" LACTATING=\"FALSE\"/>" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"00555-0363-05\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"PRECAUTIONS\" />" + 
				"    <TypeFilter NAME=\"ETHANOL\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"1","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"1","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"1","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("ETHANOL"),"1","Number of Ethanol warnings"); 
		
	}
	
	/**
	 * TC186869 TC186870 TC186871 TC186872
	 * Monograph requests
	 * 
	 * @throws Exception
	 */
	@Test
	public void testMonographRequests() throws Exception {
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\""
				+ getBirthdateForGivenAgeInYears(65)
				+ "\" SMOKER=\"FALSE\" PREGNANT=\"FALSE\" LACTATING=\"FALSE\"/>" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"100064\" TYPE=\"GFC\" />" + 
				"    <Drug CODE=\"100268\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"DRUG\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"1","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"1","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"1","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"1","Number of DRUG warnings");
		MonographDoc mono = getMonographDoc("<?xml version=\"1.0\" ?>" + 
				"<DocumentRequest VERSION=\"1.00\">" + 
				"  <DocumentList SIZE=\"1\">" + 
				"    <Document ID=\"" +
				doc.getFirstWarningMonographId() +
				"\" TYPE=\"MONOGRAPH\" />" + 
				"  </DocumentList>" + 
				"</DocumentRequest>");
		Assert.assertEquals(mono.getDocumentID(),"1001371");
		Assert.assertEquals(mono.getDocumentListSize(),"1");
		Assert.assertTrue(mono.getDocumentText().contains("Concurrent use of ALLOPURINOL and AZATHIOPRINE may result in azathioprine toxicity"));
		Assert.assertEquals(mono.getErrorListSize(),"0");
		
	}
	
	/**
	 * TC186873
	 * disease contraindications
	 * 
	 * @throws Exception
	 */
	@Test
	public void testDiseaseContraindications() throws Exception {
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\"" + 
				getBirthdateForGivenAgeInYears(65) +
				"\" SMOKER=\"FALSE\" PREGNANT=\"FALSE\" LACTATING=\"FALSE\"/>" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"00006-3406-17\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"  <IndicationList SIZE=\"1\">" + 
				"    <Indication CODE=\"428.0\" TYPE=\"ICD_9\" />" + 
				"  </IndicationList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"DISEASE\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"1","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"1","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"1","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DISEASE"),"1","Number of DISEASE warnings");
		Assert.assertEquals(doc.getFirstWarningText(),"There may be a contraindication to the use of INDOCIN in patients with Heart Failure.","Warning Text is Incorrect");
	}
	
	/**
	 * TC186874 TC168675
	 * consumer vs professional warning text
	 * 
	 * @throws Exception
	 */
@Test
	public void testConsumerVsProfessionalWarnings() throws Exception {
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"CONSUMER\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"MALE\" BIRTH_DATE=\"" + 
				getBirthdateForGivenAgeInYears(50) +
				"\" SMOKER=\"FALSE\" PREGNANT=\"FALSE\" LACTATING=\"FALSE\"/>" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"00006-0110-28\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"00056-0172-30\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"DRUG\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"1","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"1","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"1","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"1","Number of DRUG warnings");
		Assert.assertTrue(doc.getFirstWarningText().startsWith(
				"Treatment with both an anticoagulant and an NSAID may increase"),
				"Warning doesn't start as expected");
		doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"MALE\" BIRTH_DATE=\"" + 
				getBirthdateForGivenAgeInYears(50) +
				"\" SMOKER=\"FALSE\" PREGNANT=\"FALSE\" LACTATING=\"FALSE\"/>" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"00006-0110-28\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"00056-0172-30\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"DRUG\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"1","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"1","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"1","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"1","Number of DRUG warnings");
		Assert.assertTrue(doc.getFirstWarningText().startsWith(
				"Concurrent use of ANTICOAGULANTS and NSAIDS may result"),
				"Warning doesn't start as expected");
	}
	
	
}
