package com.truven.ids.application.cko.uitest.regression.pageobjects;

import java.util.List;

import org.jdom.Document;
import org.jdom.Element;


/**
 * CrClCalcDoc contains CrCl Calc specific methods.
 * @author APeavy
 * 
 */
public class CrClCalcDoc extends BaseDoc {

	public CrClCalcDoc(Document inputDoc) {
		super(inputDoc);
	}

	public String getValueFromRoot(String attrName) {
		return doc.getRootElement()
				.getAttributeValue(attrName); 
	}
	
	public String getValueFromPatient(String attrName) {
		return doc.getRootElement()
				.getChild("Patient")
				.getAttributeValue(attrName); 
	}
	
	public String getPSDMessageListSize() {
		return doc.getRootElement()
				.getChild("PSDMessageList")
				.getAttributeValue("SIZE"); 
	}
	
	public String getPSDMessageTexts() {
		StringBuilder messages = new StringBuilder();
		List<?> pSDMesssages = doc.getRootElement()
			.getChild("PSDMessageList")
			.getChildren("PSDMessage");
				for (Object pSDMessage : pSDMesssages) {
					messages.append(((Element) pSDMessage).getAttributeValue("MSG_TEXT"));
					messages.append("|");
							
				}
		return messages.toString();
	}


	
}
