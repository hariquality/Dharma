package com.truven.ids.application.cko.uitest.regression.pageobjects;

import org.jdom.Document;


/**
 * IVScreeningDoc contains IV Screening specific methods.
 * @author APeavy
 * 
 */
public class IVScreeningDoc extends BaseDoc {
	
	public IVScreeningDoc(Document inputDoc) {
		super(inputDoc);
	}

	public String getDocumentListSize() {
		if (doc.getRootElement().getChild("DocumentList") == null) {
			return "0";
		} else {
			return doc.getRootElement()
					.getChild("DocumentList")
					.getAttributeValue("SIZE");
		}
	}
	
	public Boolean isPhraseInTextElement(String phrase) {
		if (doc.getRootElement()
				.getChild("DocumentList")
				.getChild("Document")
				.getChildText("Text").replaceAll("\\s+", " ").contains(phrase)) {
			return true;
		} else return false;
	}
	


}
