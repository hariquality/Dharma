package com.truven.ids.application.cko.uitest.regression.warninglabels;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.WarningLabelsDoc;

/**
 * Warning Labels Exception tests
 * 
 * @author APeavy
 * 
 */
public class TestWarningLabelException extends CKOBaseTest  {

	/**
	 * TC186821
	 * Verifying invalid GFC
	 * Drug items
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testInvalidGFC() throws Exception {
		WarningLabelsDoc doc = getWarningLabelsDoc("<?xml version=\"1.0\" ?>\r\n" + 
				"<WarningLabelsRequest VERSION=\"1.00\" GRAPHIC_CODE=\"Architext\" >" + 
				"  <Patient LANGUAGE=\"English\" />" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"</WarningLabelsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1" ); 
		Assert.assertEquals(doc.getErrorListErrorText(),"Invalid GFC format: valid format is 123456." ); 

	}
	
	/**
	 * TC186822
	 * Verifying invalid drug id type
	 * Drug items
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testInvalidDrugIdType() throws Exception {
		WarningLabelsDoc doc = getWarningLabelsDoc("<?xml version=\"1.0\" ?>\r\n" + 
				"<WarningLabelsRequest VERSION=\"1.00\" GRAPHIC_CODE=\"Architext\" >" + 
				"  <Patient LANGUAGE=\"English\" />" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"102367\" TYPE=\"ABC\" />" + 
				"  </NewDrugList>" + 
				"</WarningLabelsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1"); 
		Assert.assertEquals(doc.getErrorListErrorText(),"Invalid drug identifier type given: valid values are GFC or NDC."); 
		
	}
	
	/**
	 * TC186823
	 * Verifying request w/o drug id type
	 * Drug items
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testWithoutDrugIdType() throws Exception {
		WarningLabelsDoc doc = getWarningLabelsDoc("<?xml version=\"1.0\" ?>" + 
				"<WarningLabelsRequest VERSION=\"1.00\" GRAPHIC_CODE=\"Architext\" >" + 
				"  <Patient LANGUAGE=\"English\" />" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"102367\" />" + 
				"  </NewDrugList>" + 
				"</WarningLabelsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1"); 
		Assert.assertTrue(doc.getErrorListErrorText().contains("In XMLParseUtility.toObject got the error: Missing required attribute \"TYPE\"")); 
		
	}
	
	/**
	 * TC186825
	 * Verifying with invalid language
	 * Drug items
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testInvalidLanguage() throws Exception {
		WarningLabelsDoc doc = getWarningLabelsDoc("<?xml version=\"1.0\" ?>" + 
				"<WarningLabelsRequest VERSION=\"1.00\" GRAPHIC_CODE=\"Architext\" >" + 
				"  <Patient LANGUAGE=\"Abcdef\" />" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"102367\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"</WarningLabelsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1"); 
		Assert.assertEquals(doc.getErrorListErrorText(),"Invalid Patient Language.  Valid values are 'English' or 'Spanish'."); 
		
	}
	
	/**
	 * TC186826
	 * Verifying with invalid graphics code
	 * Drug items
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testInvalidGraphicsCode() throws Exception {
		WarningLabelsDoc doc = getWarningLabelsDoc("<?xml version=\"1.0\" ?>" + 
				"<WarningLabelsRequest VERSION=\"1.00\" GRAPHIC_CODE=\"Abcdef\" >" + 
				"  <Patient LANGUAGE=\"English\" />" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"102367\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"</WarningLabelsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1"); 
		Assert.assertEquals(doc.getErrorListErrorText(),"Invalid manufacturer graphic code given: valid values are 'ARCHITEXT', 'INTERCON', 'PHARMEX', 'PHARMEXPRE-PRINTED'"); 
		
	}
	
	/**
	 * TC186829
	 * Verifying with NDC not found
	 * Drug items
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testNDCNotFound() throws Exception {
		WarningLabelsDoc doc = getWarningLabelsDoc("<?xml version=\"1.0\" ?>" + 
				"<WarningLabelsRequest VERSION=\"1.00\" GRAPHIC_CODE=\"Architext\" >" + 
				"  <Patient LANGUAGE=\"English\" />" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"12345-6789-01\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"</WarningLabelsRequest>");
		Assert.assertEquals("1", doc.getErrorListSize()); 
		Assert.assertEquals("No data exists for the given drug identifier", doc.getErrorListErrorText()); 
		
	}
	
	/**
	 * TC186830
	 * Verifying with GFC not found
	 * Drug items
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testGFCNotFound() throws Exception {
		WarningLabelsDoc doc = getWarningLabelsDoc("<?xml version=\"1.0\" ?>" + 
				"<WarningLabelsRequest VERSION=\"1.00\" GRAPHIC_CODE=\"Architext\" >" + 
				"  <Patient LANGUAGE=\"English\" />" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"999987\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"</WarningLabelsRequest>");
		Assert.assertEquals("1", doc.getErrorListSize()); 
		Assert.assertEquals("No data exists for the given drug identifier", doc.getErrorListErrorText()); 
		
	}
	
	/**
	 * TC186831
	 * Verifying invalid NDC 
	 * Drug items
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testInvalidNDC() throws Exception {
		WarningLabelsDoc doc = getWarningLabelsDoc("<?xml version=\"1.0\" ?>" + 
				"<WarningLabelsRequest VERSION=\"1.00\" GRAPHIC_CODE=\"Architext\" >" + 
				"  <Patient LANGUAGE=\"English\" />" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"11-11-11\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"</WarningLabelsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1"); 
		Assert.assertEquals(doc.getErrorListErrorText(),"Invalid NDC format: valid format is 12345-6789-10."); 
		
	}
	
}
