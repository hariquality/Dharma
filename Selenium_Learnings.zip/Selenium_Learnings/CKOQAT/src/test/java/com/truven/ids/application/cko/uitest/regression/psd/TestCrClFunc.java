package com.truven.ids.application.cko.uitest.regression.psd;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.CrClCalcDoc;

/**
 * 
 * 
 * @author APeavy
 * 
 */
public class TestCrClFunc extends CKOBaseTest  {

	@Test 
	public void testCrCl001() throws Exception {
		System.out.println("In method 'testCrCl001'");
        CrClCalcDoc doc = getCrClResultDoc("<?xml version=\"1.0\" ?>" + 
        		"<CrClCalculatorRequest SCR=\"2.00\">" + 
        		"	<Patient GENDER=\"MALE\" HEIGHT=\"153\" WEIGHT=\"100\" AGE_IN_DAYS=\"36235\" />" + 
        		"</CrClCalculatorRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getValueFromRoot("SUCCESS"),"TRUE");
		Assert.assertEquals(doc.getValueFromRoot("CRCL"),"14.39");
		Assert.assertEquals(doc.getValueFromRoot("MAX_CRCL"),"34");
		Assert.assertEquals(doc.getValueFromRoot("CALC_METHOD"),"Cockcroft-Gault");
		Assert.assertEquals(doc.getValueFromRoot("SCR"),"2");
		Assert.assertEquals(doc.getValueFromRoot("BSA"),"1.951");
		Assert.assertEquals(doc.getValueFromRoot("BSA_STATUS"),"C");
		Assert.assertEquals(doc.getValueFromRoot("IBW"),"50.543");
		Assert.assertEquals(doc.getValueFromPatient("WEIGHT5"),"56.159");
		Assert.assertEquals(doc.getValueFromPatient("WEIGHT95"),"101.441");
		Assert.assertEquals(doc.getValueFromPatient("HEIGHT5"),"156.468");
		Assert.assertEquals(doc.getValueFromPatient("HEIGHT95"),"186.132");
		Assert.assertEquals(doc.getPSDMessageListSize(),"1");
		Assert.assertTrue(doc.getPSDMessageTexts().contains("Patient's Height of 153 cm is outside normal range for patient's age and gender of 156.468 to 186.132 cm."));
	}
	
	@Test 
	public void testCrCl003() throws Exception {
		System.out.println("In method 'testCrCl003'");
		CrClCalcDoc doc = getCrClResultDoc("<?xml version=\"1.0\" ?>" + 
				"<CrClCalculatorRequest SCR=\"1.20\">" + 
				"	<Patient GENDER=\"MALE\" HEIGHT=\"188\" WEIGHT=\"80\" AGE_IN_DAYS=\"6573\" />" + 
				"</CrClCalculatorRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getValueFromRoot("SUCCESS"),"TRUE");
		Assert.assertEquals(doc.getValueFromRoot("CRCL"),"109.67");
		Assert.assertEquals(doc.getValueFromRoot("MAX_CRCL"),"122");
		Assert.assertEquals(doc.getValueFromRoot("CALC_METHOD"),"Schwartz 1987");
		Assert.assertEquals(doc.getValueFromRoot("SCR"),"1.2");
		Assert.assertEquals(doc.getValueFromRoot("BSA"),"2.06");
		Assert.assertEquals(doc.getValueFromRoot("BSA_STATUS"),"C");
		Assert.assertEquals(doc.getValueFromRoot("IBW"),"70.816");
		Assert.assertEquals(doc.getValueFromPatient("WEIGHT5"),"53.227");
		Assert.assertEquals(doc.getValueFromPatient("WEIGHT95"),"93.92");
		Assert.assertEquals(doc.getValueFromPatient("HEIGHT5"),"164.242");
		Assert.assertEquals(doc.getValueFromPatient("HEIGHT95"),"188.236");
	}
	
	@Test 
	public void testCrCl004() throws Exception {
		System.out.println("In method 'testCrCl004'");
		CrClCalcDoc doc = getCrClResultDoc("<?xml version=\"1.0\" ?>" + 
				"<CrClCalculatorRequest SCR=\"1.20\">" + 
				"	<Patient GENDER=\"MALE\" HEIGHT=\"188\" WEIGHT=\"80\" AGE_IN_DAYS=\"6575\" />" + 
				"</CrClCalculatorRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getValueFromRoot("SUCCESS"),"TRUE");
		Assert.assertEquals(doc.getValueFromRoot("CRCL"),"112.96");
		Assert.assertEquals(doc.getValueFromRoot("MAX_CRCL"),"122");
		Assert.assertEquals(doc.getValueFromRoot("CALC_METHOD"),"Cockcroft-Gault");
		Assert.assertEquals(doc.getValueFromRoot("SCR"),"1.2");
		Assert.assertEquals(doc.getValueFromRoot("BSA"),"2.06");
		Assert.assertEquals(doc.getValueFromRoot("BSA_STATUS"),"C");
		Assert.assertEquals(doc.getValueFromRoot("IBW"),"80");
		Assert.assertEquals(doc.getValueFromPatient("WEIGHT5"),"53.227");
		Assert.assertEquals(doc.getValueFromPatient("WEIGHT95"),"93.92");
		Assert.assertEquals(doc.getValueFromPatient("HEIGHT5"),"164.242");
		Assert.assertEquals(doc.getValueFromPatient("HEIGHT95"),"188.236");
	}
	
	@Test 
	public void testCrCl005() throws Exception {
		System.out.println("In method 'testCrCl005'");
		CrClCalcDoc doc = getCrClResultDoc("<?xml version=\"1.0\" ?>" + 
				"<CrClCalculatorRequest SCR=\".50\">" + 
				"	<Patient GENDER=\"FEMALE\" HEIGHT=\"76.2\" WEIGHT=\"9\" AGE_IN_DAYS=\"121\" />" + 
				"</CrClCalculatorRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getValueFromRoot("SUCCESS"),"TRUE");
		Assert.assertEquals(doc.getValueFromRoot("CRCL"),"68.58");
		Assert.assertEquals(doc.getValueFromRoot("MAX_CRCL"),"90.6");
		Assert.assertEquals(doc.getValueFromRoot("CALC_METHOD"),"Schwartz 1987");
		Assert.assertEquals(doc.getValueFromRoot("SCR"),"0.5");
		Assert.assertEquals(doc.getValueFromRoot("BSA"),"0.423");
		Assert.assertEquals(doc.getValueFromRoot("BSA_STATUS"),"C");
		Assert.assertEquals(doc.getValueFromRoot("IBW"),"9");
		Assert.assertEquals(doc.getValueFromPatient("WEIGHT5"),"5.22");
		Assert.assertEquals(doc.getValueFromPatient("WEIGHT95"),"7.757");
		Assert.assertEquals(doc.getValueFromPatient("HEIGHT5"),"58.453");
		Assert.assertEquals(doc.getValueFromPatient("HEIGHT95"),"66.594");
		Assert.assertEquals(doc.getPSDMessageListSize(),"2");
		Assert.assertTrue(doc.getPSDMessageTexts().contains("Patient's Weight of 9 kg is outside normal range for patient's age and gender of 5.22 to 7.757 kg."));
		Assert.assertTrue(doc.getPSDMessageTexts().contains("Patient's Height of 76.2 cm is outside normal range for patient's age and gender of 58.453 to 66.594 cm."));
	}
	
	@Test 
	public void testCrCl006() throws Exception {
		System.out.println("In method 'testCrCl006'");
		CrClCalcDoc doc = getCrClResultDoc("<?xml version=\"1.0\" ?>" + 
				"<CrClCalculatorRequest SCR=\".50\">" + 
				"	<Patient GENDER=\"FEMALE\" HEIGHT=\"76.2\" WEIGHT=\"9\" AGE_IN_DAYS=\"119\" />" + 
				"</CrClCalculatorRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1");
		Assert.assertEquals(doc.getErrorListErrorText(),"Patient's Age must be greater than or equal to 120 days and less than or equal to 99 years.");
	}
	
}
