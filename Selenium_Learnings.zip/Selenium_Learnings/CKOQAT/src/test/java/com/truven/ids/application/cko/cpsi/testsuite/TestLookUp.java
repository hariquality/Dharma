package com.truven.ids.application.cko.cpsi.testsuite;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.cpsi.pageobjects.LookUpDoc;
import com.truven.ids.application.cko.uitest.CPSIBaseTest;

public class TestLookUp extends CPSIBaseTest{

	@Test 
	public void testNoKnownAllergy() throws Exception {
	   System.out.println("In method 'testNoKnownAllergy'");
	   LookUpDoc doc = getLookUpResultDoc("lookup/ALLERGY_request_1");
	   Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
	   Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
	   Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"allergy_name|mdxalg","Header value is incorrect in the Response");
	   Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"2","LOOKUP_TYPE size is incorrect");
	   Assert.assertTrue(doc.verifyLookUpRecords("NO KNOWN ALLERGIES - NKA|7708581"),"No known Allergies response is incorrect");
	  }
	
	@Test 
	public void testEggAllergy() throws Exception {
    System.out.println("In method 'testEggAllergy'");
    LookUpDoc doc = getLookUpResultDoc("lookup/ALLERGY_request_2");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"allergy_name|mdxalg","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"8","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("EGG WHITE|7705332"),"Egg Allergen Response is incorrect");
   }	
	
	
	@Test 
	public void testDoseUnitforM() throws Exception {
    System.out.println("In method 'testDoseUnitforM'");
    String [] expectedResponseData = {"MCG|Microgram", "MCI|Millicurie", "MEQ|Milliequivalent", 
                                        "MG|Milligram", "ML|Milliliter", "MMOLE|Millimole", "Micromole|Micromole", 
                                        "Million IU|Million international unit", 
                                        "Million U|Million unit", "mg PE|Milligram phenytoin sodium equivalent"};
    LookUpDoc doc = getLookUpResultDoc("lookup/DOSEUNIT_request");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"dose_unit_code|dose_unit_name","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"10","LOOKUP_TYPE size is incorrect");
      Assert.assertTrue(doc.verifyLookUpRecordsList(expectedResponseData,true),"For Dose Unit 'M' response in incorrect");
   } 
	
	
	@Test
	public void testGenericNameForSingleValue() throws Exception {
    System.out.println("In method 'testGenericNameForSingleValue'");
    LookUpDoc doc = getLookUpResultDoc("lookup/GENERIC_NAME_request_1");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"generic_name|route_name|form|strength|gfc","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"8","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("SERTRALINE HYDROCHLORIDE|Oral (systemic)|CAPSULE|25 MG|117849"),"Expected Response is incorrect");
   } 
	
	@Test 
	public void testGenericNameForGFC() throws Exception {
    System.out.println("In method 'testGenericNameForGFC'");
    LookUpDoc doc = getLookUpResultDoc("lookup/GENERIC_NAME_request_2");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"generic_name|route_name|form|strength|gfc","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"1","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("SERTRALINE HYDROCHLORIDE|Oral (systemic)|TABLET|100 MG|103456"),"Expected Response is incorrect");
   } 
	
	@Test 
	public void testGFCNCPDPForGFCInput() throws Exception {
    System.out.println("In method 'testGFCNCPDPForGFCInput'");
    LookUpDoc doc = getLookUpResultDoc("lookup/GFCNCPDP_request_1");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"gfc|ncpdp","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"1","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("103456|EA"),"Expected Response is incorrect");
   } 
	
	@Test 
	public void testGFCNCPDPForUnitML() throws Exception {
    System.out.println("In method 'testGFCNCPDPForUnitML'");
    LookUpDoc doc = getLookUpResultDoc("lookup/GFCNCPDP_request_2");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"gfc|ncpdp","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"691","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("100005|ML"),"Expected Response is incorrect");
   } 
	
	@Test 
	public void testGenericNameForGNGCRRT() throws Exception {
    System.out.println("In method 'testGenericNameForGNGCRRT'");
    LookUpDoc doc = getLookUpResultDoc("lookup/GNGCRRT_request");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"GCRName|RouteName|GCRCode|RouteCode","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"10","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("Oxycodone Hydrochloride|Oral (systemic)|432180|111000"),"Expected Response is incorrect");
   } 
	
	@Test 
	public void testHL7ROUTEForMDXFRouteID() throws Exception {
    System.out.println("In method 'testHL7ROUTEForMDXFRouteID'");
    LookUpDoc doc = getLookUpResultDoc("lookup/HL7ROUTE_request_1");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"hl7_clinical_route_id|hl7_clinical_route_name|mdx_route_id","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"1","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("263|Oral route|111000"),"Expected Response is incorrect");
   } 
	
	@Test
	public void testHL7ROUTEForClinicalRouteID() throws Exception {
    System.out.println("In method 'testHL7ROUTEForMDXFRouteID'");
    LookUpDoc doc = getLookUpResultDoc("lookup/HL7ROUTE_request_2");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"hl7_clinical_route_id|hl7_clinical_route_name|mdx_route_id","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"1","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("103|Swallow, oral|"),"Expected Response is incorrect");
   } 
	
	@Test 
	public void testHL7ROUTEForClinicalRouteName() throws Exception {
    System.out.println("In method 'testHL7ROUTEForClinicalRouteName'");
    LookUpDoc doc = getLookUpResultDoc("lookup/HL7ROUTE_request_3");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"hl7_clinical_route_id|hl7_clinical_route_name|mdx_route_id","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"3","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("144|Injection, intramuscular|"),"Expected Response is incorrect");
   } 
	
	
	@Test 
	public void testLanguage() throws Exception {
	   System.out.println("In method 'testLanguage'");
	   LookUpDoc doc = getLookUpResultDoc("lookup/LANGUAGE_request");
	   Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
	   Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
	   Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"language_code|language_name","Header value is incorrect in the Response");
	   Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"1","LOOKUP_TYPE size is incorrect");
	   Assert.assertTrue(doc.verifyLookUpRecords("S|SPANISH"),"Expected Response is incorrect");
	  }
	
	@Test 
	public void testtradeName() throws Exception {
	   System.out.println("In method 'testtradeName'");
	   LookUpDoc doc = getLookUpResultDoc("lookup/LOOKUP_TYPE_request");
	   Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
	   Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
	   Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"lookup_type","Header value is incorrect in the Response");
	   Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"26","LOOKUP_TYPE size is incorrect");
	   Assert.assertTrue(doc.verifyLookUpRecords("ALLERGY"),"Expected Response is incorrect");
	  }
	
	@Test public void testNCPDPForUnitEA() throws Exception {
    System.out.println("In method 'testNCPDPForUnitEA'");
    LookUpDoc doc = getLookUpResultDoc("lookup/NCPDP_request");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
	Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"ncpdp_unit_code|ncpdp_unit_name","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"1","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("EA|Each"),"Expected Response is incorrect");
   } 
	
	@Test
	public void testLookUpTypeForNDCGFC() throws Exception {
    System.out.println("In method 'testLookUpTypeForNDCGFC'");
    LookUpDoc doc = getLookUpResultDoc("lookup/NDCGFC_request");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"ndc|gfc","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"1","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("00006-0735-54|103469"),"Expected Response is incorrect");
   } 
	
	@Test 
	public void testPRDGCRRTforAleve() throws Exception {
    System.out.println("In method 'testPRDGCRRTforAleve'");
    LookUpDoc doc = getLookUpResultDoc("lookup/PRDGCRRT_request");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"ProductName|GCRName|RouteName|GCRCode|RouteCode","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"8","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("ALEVE ARTHRITIS|Naproxen Sodium|Oral (systemic)|391340|111000"));
   } 
	
	@Test 
	public void testPSDcomboKeyforGCRName_Amoxicillin() throws Exception {
    System.out.println("In method 'testPSDcomboKeyforAmoxicillin'");
    LookUpDoc doc = getLookUpResultDoc("lookup/PSDCOMBODOSEKEY_request");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"gfc_id|gcr_name|age_lower|age_lower_unit_code|age_upper|age_upper_unit_code|weight_kg_lower|weight_kg_upper|product_form_code|product_form_name|product_route_code|product_route_name|strength|hl7_clinical_route_id|hl7_clinical_route_name|mdx_route_id|dose_type_id|dose_type_name|indication_id|indication_snomed_concept_id|indication_icd9_code|indication_name|ncpdp_unit","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"9","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("100178|Amoxicillin/Clavulanate Potassium|18|Yr|99|Yr"));
   } 
	
	@Test
	public void testPSD_DOSEMETHOD() throws Exception {
    System.out.println("In method 'testPSD_DOSEMETHOD'");
    LookUpDoc doc = getLookUpResultDoc("lookup/PSDDOSEMETHOD_request");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"dose_method_id|dose_method_name","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"1","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("200|Flat"));
   } 
	
	@Test 
	public void testPSD_DOSEMODIFIER() throws Exception {
    System.out.println("In method 'testPSD_DOSEMODIFIER'");
    LookUpDoc doc = getLookUpResultDoc("lookup/PSDDOSEMODIFIER_request");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"dose_modifier_type_id|dose_modifier_type_name","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"4","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("300|Hepatic"));
   } 
	
	@Test 
	public void testPSD_DOSEPath() throws Exception {
    System.out.println("In method 'testPSD_DOSEPath'");
    LookUpDoc doc = getLookUpResultDoc("lookup/PSDDOSEPATH_request");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"dose_path_id|dose_path_name","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"1","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("100|General"));
   } 
	
	
 @Test 
 public void testPSD_DOSEType() throws Exception {
    System.out.println("In method 'testPSD_DOSEType'");
    LookUpDoc doc = getLookUpResultDoc("lookup/PSDDOSETYPE_request");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"dose_type_id|dose_type_name","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"1","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("166|Load"));
   } 
 
 @Test 
 public void testPSD_DOSEWEIGHT() throws Exception {
    System.out.println("In method 'testPSD_DOSEWEIGHT'");
    LookUpDoc doc = getLookUpResultDoc("lookup/PSDDOSEWEIGHTTYPE_request");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"dosing_weight_type_id|dosing_weight_type_name","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"1","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("100|Actual Body Weight"));
   } 
 
 
 @Test
 public void testPSD_Hepatic_Severe() throws Exception {
    System.out.println("In method 'testPSD_Hepatic_Severe'");
    LookUpDoc doc = getLookUpResultDoc("lookup/PSDHEPATIC_request");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"hepatic_severity_type_id|hepatic_severity_type_name","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"1","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("101|Severe"));
   } 
 
 
 @Test 
 public void testPSD_Indication_Edema() throws Exception {
    System.out.println("In method 'testPSD_Indication_Edema'");
    LookUpDoc doc = getLookUpResultDoc("lookup/PSDINDICATION_request");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"indication_id|snomed_concept_id|icd9_code|indication_name","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"1","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("626|267038008|782.3|Edema"));
   } 
 
 
 @Test 
 public void testPSD_Renal_Modifier_100() throws Exception {
    System.out.println("In method 'testPSD_Renal_Modifier_100'");
    LookUpDoc doc = getLookUpResultDoc("lookup/PSDRENALMODIFIER_request");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"renal_modifier_type_id|renal_modifier_type_name","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"1","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("100|Creatinine clearance"));
   } 
 
 @Test 
 public void testPSD_SingelDoseKey_GCRID() throws Exception {
    System.out.println("In method 'testPSD_SingelDoseKey_GCRID'");
    LookUpDoc doc = getLookUpResultDoc("lookup/PSDSINGLEDOSEKEY_Request_1");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"gcr_id|gcr_name|age_lower|age_lower_unit_code|age_upper|age_upper_unit_code|weight_kg_lower|weight_kg_upper|product_form_code|product_form_name|product_route_code|product_route_name|hl7_clinical_route_id|hl7_clinical_route_name|mdx_route_id|dose_type_id|dose_type_name|indication_id|indication_snomed_concept_id|indication_icd9_code|indication_name|dose_unit_code","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"11","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("924640|Montelukast Sodium|6|Yr|14|Yr|||CTB|TABLET, CHEWABLE|PO|ORAL|118|Chew, oral||123|One-time|3605|31387002||Exercise-induced asthma|MG"));
   } 
 
 
 @Test 
 public void testPSD_SingelDoseKey_GCRName() throws Exception {
    System.out.println("In method 'testPSD_SingelDoseKey_GCRName'");
    LookUpDoc doc = getLookUpResultDoc("lookup/PSDSINGLEDOSEKEY_Request_2");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"gcr_id|gcr_name|age_lower|age_lower_unit_code|age_upper|age_upper_unit_code|weight_kg_lower|weight_kg_upper|product_form_code|product_form_name|product_route_code|product_route_name|hl7_clinical_route_id|hl7_clinical_route_name|mdx_route_id|dose_type_id|dose_type_name|indication_id|indication_snomed_concept_id|indication_icd9_code|indication_name|dose_unit_code","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"3","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("648785|Vancomycin Hydrochloride|120|Day|17|Yr|||PDR|POWDER FOR SUSPENSION|PO|ORAL|103|Swallow, oral||105|Maintenance|1981|32527003|008.41|Staphylococcal enterocolitis|MG"),"Expected Response is incorrect");
   } 
 
 
 @Test 
 public void testRX_CUI_NDC() throws Exception {
    System.out.println("In method 'testRX_CUI_NDC'");
    LookUpDoc doc = getLookUpResultDoc("lookup/RXCUINDC_request");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"rxcui|ndc","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"242","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("198013|00005-3300-43"),"Expected Response is incorrect");
   } 
 
 @Test 
 public void testTime_UNIT_HR() throws Exception {
    System.out.println("In method 'testTime_UNIT_HR'");
    LookUpDoc doc = getLookUpResultDoc("lookup/TIMEUNIT_request");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"time_unit_code|time_unit_name","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"1","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("HR|Hour"),"Expected Response is incorrect");
   } 
 
 @Test
 public void testTradeName_Histex() throws Exception {
    System.out.println("In method 'testTradeName_Histex'");
    LookUpDoc doc = getLookUpResultDoc("lookup/TRADE_NAME_request_1");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"trade_name|route|form|strength|ndc","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"26","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("HISTEX CT|Oral (systemic)|TABLET, EXTENDED RELEASE|8 MG|62022-0258-01"),"Expected Response is incorrect");
   } 
 
 @Test 
 public void testTradeName_NDC() throws Exception {
    System.out.println("In method 'testTradeName_NDC'");
    LookUpDoc doc = getLookUpResultDoc("lookup/TRADE_NAME_request_2");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"trade_name|route|form|strength|ndc","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"1","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("ZYRTEC|Oral (systemic)|TABLET|10 MG|50580-0726-32"),"Expected Response is incorrect");
   } 
 
 @Test 
 public void testDrugCodeTypeLookup() throws Exception {
    System.out.println("In method 'testDrugCodeTypeLookup'");
    LookUpDoc doc = getLookUpResultDoc("lookup/drugcodestypelookup");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"source_code_type|target_code_type","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"1","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("NDC1|GFC"),"Expected Response is incorrect");
   } 
 
 
 @Test 
 public void testdrugcodeslookup() throws Exception {
    System.out.println("In method 'testdrugcodeslookup'");
    LookUpDoc doc = getLookUpResultDoc("lookup/drugcodeslookup");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"source_code_type|source_code_value|target_code_type|target_code_value","Header value is incorrect in the Response");
    Assert.assertTrue(doc.verifyLookUpRecords("NDC1|00000-4301-02|GFC|124693"),"Expected Response is incorrect");
   } 
 
 
 @Test 
 public void testdrugcodesLookUpFor_AND_Operator() throws Exception {
    System.out.println("In method 'testdrugcodesLookUpFor_AND_Operator'");
    LookUpDoc doc = getLookUpResultDoc("lookup/drugcodeLookUpUsingAND");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"source_code_type|source_code_value|target_code_type|target_code_value","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("SIZE"),"1","LOOKUP_TYPE size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("00000-6641-01"),"Expected Source code value Response is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("124693"),"Expected target code value Response is incorrect");
   } 
 
 
 @Test 
 public void testdrugcodesLookUpFor_OR_Operator() throws Exception {
    System.out.println("In method 'testdrugcodesLookUpFor_OR_Operator'");
    LookUpDoc doc = getLookUpResultDoc("lookup/drugcodeLookUpUsingOR");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"source_code_type|source_code_value|target_code_type|target_code_value","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("NUMBER_OF_FIELDS"),"4","No_of_Fields size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("00000-6641-01"),"Expected Source code value Response is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("124693"),"Expected target code value Response is incorrect");
   } 
 
 
 @Test 
 public void testdrugcodesTypeForSourceCodeValue() throws Exception {
    System.out.println("In method 'testdrugcodesTypeForSourceCodeValue'");
    LookUpDoc doc = getLookUpResultDoc("lookup/drugcodetype_SourceVerification");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"source_code_type|source_code_value|target_code_type|target_code_value","Header value is incorrect in the Response");
    Assert.assertEquals(doc.getResponseValueForAttribute("NUMBER_OF_FIELDS"),"4","No_of_Fields size is incorrect");
    Assert.assertTrue(doc.verifyLookUpRecords("00002-0363-03"),"Expected Response is incorrect");
   } 
 
 @Test 
 public void testdrugcodesTypeForTargetCodeType() throws Exception {
    System.out.println("In method 'testdrugcodesTypeForTargetCodeType'");
    LookUpDoc doc = getLookUpResultDoc("lookup/drugcodetype_TargetVerification");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected or Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("HEADER"),"source_code_type|source_code_value|target_code_type|target_code_value","Header value is incorrect in the Response");
    Assert.assertTrue(doc.verifyLookUpRecords("GFC"),"Expected Response is incorrect");
   } 
 
	
}
