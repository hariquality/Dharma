package com.truven.ids.application.cko.cpsi.testsuite;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.cpsi.pageobjects.ValidateDoc;
import com.truven.ids.application.cko.uitest.CPSIBaseTest;

public class TestValidate extends CPSIBaseTest{

	@Test
	public void testValdiateRequest() throws Exception {
	   System.out.println("In method 'testValdiateRequest'");
	   ValidateDoc doc = getValidateDoc("validation/ValidateRequest");
	   Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
	   Assert.assertEquals(
	                doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected OR Response is not displayed");
	   
	   Assert.assertEquals(
                 doc.getDrugListSizeFor("NewDrugList"),"1","Server not connected OR Response is not displayed");
	   Assert.assertTrue(doc.verifyDrugListFor("NewDrugList","DRUGNOTES",""),"For Drug Notes expected response is not present");
	   Assert.assertTrue(doc.verifyDrugListFor("CurrentDrugList","DRUGPOINTS","NOTAPPLICABLE"),"For DRUGPOINTS expected response is not present");
	  }
	
	@Test 
	public void testValdiateRequestForValidPSD() throws Exception {
    System.out.println("In method 'testValdiateRequestForValidPSD'");
    ValidateDoc doc = getValidateDoc("validation/Validation_Request_1");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(
                 doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getDrugListSizeFor("NewDrugList"),"1","Server not connected OR Response is not displayed");
    Assert.assertTrue(doc.verifyDrugListFor("NewDrugList","PSD","VALID"),"For PSD expected response is not present");
   }
	
	
	@Test 
	public void testValdiateRequestForInValidPSD() throws Exception {
    System.out.println("In method 'testValdiateRequestForInValidPSD'");
    ValidateDoc doc = getValidateDoc("validation/Validation_Request_2");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getDrugListSizeFor("NewDrugList"),"2","Server not connected OR Response is not displayed");
    Assert.assertTrue(doc.verifyDrugListFor("NewDrugList","PSD","INVALID"),"For PSD expected response is not present");
   }
	
	
 
		
}
