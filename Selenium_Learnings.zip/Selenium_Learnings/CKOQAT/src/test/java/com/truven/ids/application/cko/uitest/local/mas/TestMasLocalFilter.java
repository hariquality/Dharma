package com.truven.ids.application.cko.uitest.local.mas;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.MasDoc;

/**
 * MAS Filter tests
 * 
 * @author APeavy
 * 
 */
public class TestMasLocalFilter extends CKOBaseTest  {

	
	/**
	 * TC349737
	 * Verify TypeFilter:  <TypeFilter NAME=\"DRUG\" />
	 * 
	 * @throws Exception
	 */
	@Test
	public void testTypeFilter() throws Exception {
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" REGION=\"ES\">" + 
				"  <Patient GENDER=\"FEMALE\" BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" LACTATING=\"TRUE\" PREGNANT=\"TRUE\" SMOKER=\"TRUE\"  />" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"724626\" TYPE=\"REGISTRY\" REGISTRY_TYPE=\"NC\"/>"+
				"    <Drug CODE=\"108077\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <CurrentDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"111850\" TYPE=\"GFC\" />" + 
				"  </CurrentDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"20","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"20","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"7","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"4","Number of Drug warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("FOOD"),"3","Number of Food warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("TOBACCO"),"1","Number of Tobacco warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DISEASE"),"3","Number of Disease warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("PREGNANCY"), "3", "Number of Pregnancy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("LACTATION"), "3", "Number of Lactation warnings");
		Assert.assertEquals(doc.getNumberOfWarningsByType("TC_DUPLICATION"),"3","Number of Tc duplication warnings");  
	
		
		// DRUG only
		doc = getMasResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" REGION=\"ES\">" + 
				"  <Patient GENDER=\"FEMALE\" BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" LACTATING=\"TRUE\" PREGNANT=\"TRUE\" SMOKER=\"TRUE\"  />" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"724626\" TYPE=\"REGISTRY\" REGISTRY_TYPE=\"NC\"/>"+
				"    <Drug CODE=\"108077\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <CurrentDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"111850\" TYPE=\"GFC\" />" + 
				"  </CurrentDrugList>" + 			
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"DRUG\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(), "4", "Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(), "4","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(), "1", "Type Summary"); // only one type (DRUG)
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"), "4", "Number of Drug warnings"); // only drug warnings

		//PREGNANCY, LACTATION only
		doc = getMasResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" REGION=\"ES\">" + 
				"  <Patient GENDER=\"FEMALE\" BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" LACTATING=\"TRUE\" PREGNANT=\"TRUE\" SMOKER=\"TRUE\"  />" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"724626\" TYPE=\"REGISTRY\" REGISTRY_TYPE=\"NC\"/>"+
				"    <Drug CODE=\"108077\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <CurrentDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"111850\" TYPE=\"GFC\" />" + 
				"  </CurrentDrugList>" + 			
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"PREGNANCY\" />" + 
				"    <TypeFilter NAME=\"LACTATION\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(), "6", "Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"6", "Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"2", "Type Summary"); // only one type (DRUG) 
		Assert.assertEquals(doc.getNumberOfWarningsByType("PREGNANCY"), "3", "Number of Pregnancy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("LACTATION"), "3","Number of Lactation warnings");
		

		//FOOD, TOBACCO, DISEASE, TC_DUPLICATION only
		doc = getMasResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" REGION=\"ES\">" + 
				"  <Patient GENDER=\"FEMALE\" BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" LACTATING=\"TRUE\" PREGNANT=\"TRUE\" SMOKER=\"TRUE\"  />" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"724626\" TYPE=\"REGISTRY\" REGISTRY_TYPE=\"NC\"/>"+
				"    <Drug CODE=\"108077\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <CurrentDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"111850\" TYPE=\"GFC\" />" + 
				"  </CurrentDrugList>" + 			
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"FOOD\" />" + 
				"    <TypeFilter NAME=\"TOBACCO\" />" +
				"    <TypeFilter NAME=\"DISEASE\" />" +
				"    <TypeFilter NAME=\"TC_DUPLICATION\" />" +
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(), "10", "Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"10", "Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"4", "Type Summary"); // only one type (DRUG) 
		Assert.assertEquals(doc.getNumberOfWarningsByType("FOOD"),"3","Number of Food warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("TOBACCO"),"1","Number of Tobacco warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DISEASE"),"3","Number of Disease warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("TC_DUPLICATION"),"3","Number of Tc duplication warnings");  
	
	}
	
	/**
	 * TC349737
	 * Verify Severity Filter:  example: SEVERITY="MINOR" />
	 * 
	 * @throws Exception
	 */
	@Test
	public void testSeverityFilter() throws Exception {
		System.out.println("===========  Start of 'MINOR' ==============");
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" REGION=\"ES\">" + 
				"  <Patient GENDER=\"FEMALE\" BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1971\" LACTATING=\"TRUE\" PREGNANT=\"TRUE\" SMOKER=\"TRUE\"  />" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"724626\" TYPE=\"REGISTRY\" REGISTRY_TYPE=\"NC\"/>"+
				"    <Drug CODE=\"108077\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <CurrentDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"111850\" TYPE=\"GFC\" />" + 
				"  </CurrentDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"MINOR\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"20","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"20","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"7","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"4","Number of Drug warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("FOOD"),"3","Number of Food warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("TOBACCO"),"1","Number of Tobacco warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DISEASE"),"3","Number of Disease warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("PREGNANCY"), "3", "Number of Pregnancy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("LACTATION"), "3", "Number of Lactation warnings");
		Assert.assertEquals(doc.getNumberOfWarningsByType("TC_DUPLICATION"),"3","Number of Tc duplication warnings");  

		System.out.println("===========  Start of 'MODERATE' ==============");
		doc = getMasResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" REGION=\"ES\">" + 
				"  <Patient GENDER=\"FEMALE\" BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1971\" LACTATING=\"TRUE\" PREGNANT=\"TRUE\" SMOKER=\"TRUE\"  />" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"724626\" TYPE=\"REGISTRY\" REGISTRY_TYPE=\"NC\"/>"+
				"    <Drug CODE=\"108077\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <CurrentDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"111850\" TYPE=\"GFC\" />" + 
				"  </CurrentDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"MODERATE\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"20","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"20","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"7","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"4","Number of Drug warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("FOOD"),"3","Number of Food warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("TOBACCO"),"1","Number of Tobacco warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DISEASE"),"3","Number of Disease warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("PREGNANCY"), "3", "Number of Pregnancy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("LACTATION"), "3", "Number of Lactation warnings");
		Assert.assertEquals(doc.getNumberOfWarningsByType("TC_DUPLICATION"),"3","Number of Tc duplication warnings");  

		System.out.println("===========  Start of 'MAJOR' ==============");
		doc = getMasResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" REGION=\"ES\">" + 
				"<Patient GENDER=\"FEMALE\" BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1971\" LACTATING=\"TRUE\" PREGNANT=\"TRUE\" SMOKER=\"TRUE\"  />" + 
				"<NewDrugList SIZE=\"2\">" + 
				"<Drug CODE=\"724626\" TYPE=\"REGISTRY\" REGISTRY_TYPE=\"NC\"/>" + 
				"<Drug CODE=\"108077\" TYPE=\"GFC\" />" + 
				"</NewDrugList>" + 
				"<CurrentDrugList SIZE=\"1\">" + 
				"<Drug CODE=\"111850\" TYPE=\"GFC\" />" + 
				" </CurrentDrugList>" + 
				"<Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"MAJOR\">" + 
				"<TypeFilter NAME=\"ALL_TYPES\" />" + 
				"</Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"14","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"14","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"5","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"4","Number of Drug warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("FOOD"),"1","Number of Food warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DISEASE"),"3","Number of Disease warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("LACTATION"), "3", "Number of Lactation warnings");
		Assert.assertEquals(doc.getNumberOfWarningsByType("TC_DUPLICATION"),"3","Number of Tc duplication warnings");  

		System.out.println("===========  Start of 'CONTRAINDICATED' ==============");
		doc = getMasResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" REGION=\"ES\">" + 
				"<Patient GENDER=\"FEMALE\" BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1971\" LACTATING=\"TRUE\" PREGNANT=\"TRUE\" SMOKER=\"TRUE\"  />" + 
				"<NewDrugList SIZE=\"2\">" + 
				"<Drug CODE=\"724626\" TYPE=\"REGISTRY\" REGISTRY_TYPE=\"NC\"/>" + 
				"<Drug CODE=\"108077\" TYPE=\"GFC\" />" + 
				"</NewDrugList>" + 
				"<CurrentDrugList SIZE=\"1\">" + 
				"<Drug CODE=\"111850\" TYPE=\"GFC\" />" + 
				"</CurrentDrugList>" + 
				"<Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"CONTRAINDICATED\">" + 
				"<TypeFilter NAME=\"ALL_TYPES\" />" + 
				"</Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(), "4", "Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(), "4", "Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(), "2", "Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DISEASE"), "1", "Number of Disease warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("TC_DUPLICATION"),"3","Number of Tc duplication warnings");

	}
	
	/**
	 * TC349737
	 * documentation filter
	 * 
	 * @throws Exception
	 */
	@Test
	public void testDocumentationFilter() throws Exception {
		System.out.println("========== starting .testDocumentationFilter()");
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
				"<MasRequest CLASS=\"CONSUMER\" REGION=\"ES\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\"" + 
				getBirthdateForGivenAgeInYears(50) +
				"\" SMOKER=\"FALSE\" PREGNANT=\"TRUE\" LACTATING=\"TRUE\"/>" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"725009\" TYPE=\"REGISTRY\" REGISTRY_TYPE=\"NC\"/>"+
				"    <Drug CODE=\"103687\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"POOR\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		System.out.println("========== End of request .testDocumentationFilter()");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"10", "Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(), "10", "Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(), "5", "Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"1", "Number of DRUG warnings");
		Assert.assertEquals(doc.getNumberOfWarningsByType("FOOD"),"1", "Number of FOOD warnings");
		Assert.assertEquals(doc.getNumberOfWarningsByType("LAB"),"2", "Number of LAB warnings");
		Assert.assertEquals(doc.getNumberOfWarningsByType("PREGNANCY"),"3", "Number of PREGNANCY warnings");
		Assert.assertEquals(doc.getNumberOfWarningsByType("LACTATION"),"3", "Number of LACTATION warnings");
	
			doc = getMasResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
				"<MasRequest CLASS=\"CONSUMER\" REGION=\"ES\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\"" + 
				getBirthdateForGivenAgeInYears(50) +
				"\" SMOKER=\"FALSE\" PREGNANT=\"TRUE\" LACTATING=\"TRUE\"/>" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"725009\" TYPE=\"REGISTRY\" REGISTRY_TYPE=\"NC\"/>" + 
				"    <Drug CODE=\"103687\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"FAIR\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"10", "Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(), "10", "Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(), "5", "Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"1", "Number of DRUG warnings");
		Assert.assertEquals(doc.getNumberOfWarningsByType("FOOD"),"1", "Number of FOOD warnings");
		Assert.assertEquals(doc.getNumberOfWarningsByType("LAB"),"2", "Number of LAB warnings");
		Assert.assertEquals(doc.getNumberOfWarningsByType("PREGNANCY"),"3", "Number of PREGNANCY warnings");
		Assert.assertEquals(doc.getNumberOfWarningsByType("LACTATION"),"3", "Number of LACTATION warnings");
	

		doc = getMasResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
				"<MasRequest CLASS=\"CONSUMER\" REGION=\"ES\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\"" + 
				getBirthdateForGivenAgeInYears(50) +
				"\" SMOKER=\"FALSE\" PREGNANT=\"TRUE\" LACTATING=\"TRUE\"/>" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"725009\" TYPE=\"REGISTRY\" REGISTRY_TYPE=\"NC\"/>"+
				"    <Drug CODE=\"103687\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"GOOD\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"8", "Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(), "8", "Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(), "4", "Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("FOOD"),"1", "Number of FOOD warnings");
		Assert.assertEquals(doc.getNumberOfWarningsByType("LAB"),"1", "Number of LAB warnings");
		Assert.assertEquals(doc.getNumberOfWarningsByType("PREGNANCY"),"3", "Number of PREGNANCY warnings");
		Assert.assertEquals(doc.getNumberOfWarningsByType("LACTATION"),"3", "Number of LACTATION warnings");
	
	
		doc = getMasResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\" ?>" + 
				"<MasRequest CLASS=\"CONSUMER\" REGION=\"ES\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\"" + 
				getBirthdateForGivenAgeInYears(50) +
				"\" SMOKER=\"FALSE\" PREGNANT=\"TRUE\" LACTATING=\"TRUE\"/>" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"725009\" TYPE=\"REGISTRY\" REGISTRY_TYPE=\"NC\"/>"+
				"    <Drug CODE=\"103687\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"EXCELLENT\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"6", "Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(), "6", "Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(), "2", "Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("PREGNANCY"),"3", "Number of PREGNANCY warnings");
		Assert.assertEquals(doc.getNumberOfWarningsByType("LACTATION"),"3", "Number of LACTATION warnings");
	
	}

}
