package com.truven.ids.application.cko.uitest.regression.psd;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.PSDDoc;

/**
 * 
 * 
 * @author APeavy
 * 
 */
public class TestPSDRecFunc1 extends CKOBaseTest  {

	/**
	 * trying to force normal dose - CMS2353244
	 * @throws Exception
	 */
	@Test 
	public void testSimpleRec() throws Exception {
		System.out.println("In method 'testSimpleRec'");
		
		PSDDoc doc = getPSDResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
				"   <PSDRecommendationRequest>" + 
				"      <Patient GENDER=\"MALE\" AGE_IN_DAYS=\"5840\" WEIGHT=\"70\" HEIGHT=\"120\" CLINICIAN_CRCL=\"50\" />  " + 
				"      <RequestRecommendationRxList SIZE=\"1\">" + 
				"         <RequestRecommendationRx>" + 
				"            <PSDDrug ID=\"100852\" TYPE=\"GFC\"/>" + 
				"            <RxDoseKey ROUTE_ID=\"103\" ROUTE_ID_TYPE=\"HL7\" DOSE_TYPE_ID=\"105\" INDICATION_ID=\"949\" INDICATION_ID_TYPE=\"TH\"/>" + 
				"         </RequestRecommendationRx>" + 
				"      </RequestRecommendationRxList>" + 
				"      <DosingFilters INDICATION_NOT_SPECIFIED=\"NORESTRICTION\" NO_INDICATION_MATCH=\"IGNOREIND\" NORMAL_RESULTS_NO_RENAL_HEPATIC=\"TRUE\" RETURN_DOSE_KEYS=\"FALSE\"/>" + 
				"   </PSDRecommendationRequest>" + 
				"");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getRecResponseListSize(),"1");
		Assert.assertEquals(doc.getRecPSDDrugID(),"100852");
		Assert.assertEquals(doc.getRecPSDDrugType(),"GFC");
		Assert.assertEquals(doc.getRecDoseKeySize(),"1");
		//RxDoseKey
		Assert.assertEquals(doc.getRecRxDoseKeyAttrValue("ROUTE_ID"),"103");
		Assert.assertEquals(doc.getRecRxDoseKeyAttrValue("ROUTE_ID_TYPE"),"HL7");
		Assert.assertEquals(doc.getRecRxDoseKeyAttrValue("ROUTE_NAME"),"Swallow, oral");
		Assert.assertEquals(doc.getRecRxDoseKeyAttrValue("DOSE_TYPE_ID"),"105");
		Assert.assertEquals(doc.getRecRxDoseKeyAttrValue("DOSE_TYPE_NAME"),"Maintenance");
		Assert.assertEquals(doc.getRecRxDoseKeyAttrValue("INDICATION_ID"),"949");
		Assert.assertEquals(doc.getRecRxDoseKeyAttrValue("INDICATION_ID_TYPE"),"TH");
		Assert.assertEquals(doc.getRecRxDoseKeyAttrValue("INDICATION_NAME"),"Bacterial infectious disease");
		Assert.assertEquals(doc.getRecRxDoseKeyAttrValue("SNOMED_CONCEPT_ID"),"87628006");
		//RecmndDosingUnits
		Assert.assertEquals(doc.getRecmndDosingUnitsAttrValue("DOSE_UNIT"),"MG");
		Assert.assertEquals(doc.getRecmndDosingUnitsAttrValue("NCPDP_FLAG"),"FALSE");
		Assert.assertEquals(doc.getRecmndDosingUnitsAttrValue("PERIOD_INTERVAL_UNIT"),"HR");
		// GeneralDoseParms
		Assert.assertEquals(doc.getRecmndGeneralDoseParmsAttrValue("DOSING_PATH"),"General");
		Assert.assertEquals(doc.getRecmndGeneralDoseParmsAttrValue("DOSING_METHOD"),"Flat");
		Assert.assertEquals(doc.getRecmndGeneralDoseParmsAttrValue("PRN"),"FALSE");
		Assert.assertEquals(doc.getRecmndGeneralDoseParmsAttrValue("NTI"),"FALSE");
		Assert.assertEquals(doc.getRecmndGeneralDoseParmsAttrValue("THERAPY_DURATION_MIN"),"10");
		Assert.assertEquals(doc.getRecmndGeneralDoseParmsAttrValue("THERAPY_DURATION_MAX"),"10");
		Assert.assertEquals(doc.getRecmndGeneralDoseParmsAttrValue("THERAPY_DURATION_UNIT"),"Day");
		Assert.assertEquals(doc.getRecmndGeneralDoseParmsAttrValue("GENPARMID"),"CMS2353244");
		// DoseModifierDescriptor
		Assert.assertEquals(doc.getRecDoseModifierDescriptorAttrValue("DOSE_MODIFIER_TYPE"),"Normal");
		Assert.assertEquals(doc.getRecDoseModifierDescriptorAttrValue("CONTRAINDICATED"),"FALSE");
		Assert.assertEquals(doc.getRecDoseModifierDescriptorAttrValue("NO_DOSE"),"FALSE");
		//DoseRecmnd
		Assert.assertEquals(doc.getDoseRecmndAttrValue("DOSE"),"500");
		Assert.assertEquals(doc.getDoseRecmndAttrValue("INTERVAL"),"12");
	}
	
	/**
	 * trying to force renal dose - CMS2353244
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testRenalRec() throws Exception {
		System.out.println("In method 'testRenalRec'");
		
		PSDDoc doc = getPSDResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
				"   <PSDRecommendationRequest>" + 
				"      <Patient GENDER=\"MALE\" AGE_IN_DAYS=\"5840\" WEIGHT=\"70\" HEIGHT=\"120\" CLINICIAN_CRCL=\"1\" />  " + 
				"      <RequestRecommendationRxList SIZE=\"1\">" + 
				"         <RequestRecommendationRx>" + 
				"            <PSDDrug ID=\"100852\" TYPE=\"GFC\"/>" + 
				"            <RxDoseKey ROUTE_ID=\"103\" ROUTE_ID_TYPE=\"HL7\" DOSE_TYPE_ID=\"105\" INDICATION_ID=\"949\" INDICATION_ID_TYPE=\"TH\"/>" + 
				"         </RequestRecommendationRx>" + 
				"      </RequestRecommendationRxList>" + 
				"      <DosingFilters INDICATION_NOT_SPECIFIED=\"NORESTRICTION\" NO_INDICATION_MATCH=\"IGNOREIND\" NORMAL_RESULTS_NO_RENAL_HEPATIC=\"TRUE\" RETURN_DOSE_KEYS=\"FALSE\"/>" + 
				"   </PSDRecommendationRequest>" + 
				"");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getRecResponseListSize(),"1");
		Assert.assertEquals(doc.getRecPSDDrugID(),"100852");
		Assert.assertEquals(doc.getRecPSDDrugType(),"GFC");
		Assert.assertEquals(doc.getRecDoseKeySize(),"1");
		//RxDoseKey
		Assert.assertEquals(doc.getRecRxDoseKeyAttrValue("ROUTE_ID"),"103");
		Assert.assertEquals(doc.getRecRxDoseKeyAttrValue("ROUTE_ID_TYPE"),"HL7");
		Assert.assertEquals(doc.getRecRxDoseKeyAttrValue("ROUTE_NAME"),"Swallow, oral");
		Assert.assertEquals(doc.getRecRxDoseKeyAttrValue("DOSE_TYPE_ID"),"105");
		Assert.assertEquals(doc.getRecRxDoseKeyAttrValue("DOSE_TYPE_NAME"),"Maintenance");
		Assert.assertEquals(doc.getRecRxDoseKeyAttrValue("INDICATION_ID"),"949");
		Assert.assertEquals(doc.getRecRxDoseKeyAttrValue("INDICATION_ID_TYPE"),"TH");
		Assert.assertEquals(doc.getRecRxDoseKeyAttrValue("INDICATION_NAME"),"Bacterial infectious disease");
		Assert.assertEquals(doc.getRecRxDoseKeyAttrValue("SNOMED_CONCEPT_ID"),"87628006");
		//RecmndDosingUnits
		Assert.assertEquals(doc.getRecmndDosingUnitsAttrValue("DOSE_UNIT"),"MG");
		Assert.assertEquals(doc.getRecmndDosingUnitsAttrValue("NCPDP_FLAG"),"FALSE");
		Assert.assertEquals(doc.getRecmndDosingUnitsAttrValue("PERIOD_INTERVAL_UNIT"),"HR");
		// GeneralDoseParms
		Assert.assertEquals(doc.getRecmndGeneralDoseParmsAttrValue("DOSING_PATH"),"General");
		Assert.assertEquals(doc.getRecmndGeneralDoseParmsAttrValue("DOSING_METHOD"),"Flat");
		Assert.assertEquals(doc.getRecmndGeneralDoseParmsAttrValue("PRN"),"FALSE");
		Assert.assertEquals(doc.getRecmndGeneralDoseParmsAttrValue("NTI"),"FALSE");
		Assert.assertEquals(doc.getRecmndGeneralDoseParmsAttrValue("THERAPY_DURATION_MIN"),"10");
		Assert.assertEquals(doc.getRecmndGeneralDoseParmsAttrValue("THERAPY_DURATION_MAX"),"10");
		Assert.assertEquals(doc.getRecmndGeneralDoseParmsAttrValue("THERAPY_DURATION_UNIT"),"Day");
		Assert.assertEquals(doc.getRecmndGeneralDoseParmsAttrValue("GENPARMID"),"CMS2353244");
		// DoseModifierDescriptor
		Assert.assertEquals(doc.getRecDoseModifierDescriptorAttrValue("DOSE_MODIFIER_TYPE"),"Renal");
		Assert.assertEquals(doc.getRecDoseModifierDescriptorAttrValue("RENAL_MODIFIER_TYPE"),"Creatinine clearance");
		Assert.assertEquals(doc.getRecDoseModifierDescriptorAttrValue("RENAL_RANGE_MIN"),"0");
		Assert.assertEquals(doc.getRecDoseModifierDescriptorAttrValue("RENAL_RANGE_MAX"),"29.99");
		Assert.assertEquals(doc.getRecDoseModifierDescriptorAttrValue("RENAL_RANGE_UNIT"),"mL/min");
		Assert.assertEquals(doc.getRecDoseModifierDescriptorAttrValue("CONTRAINDICATED"),"FALSE");
		Assert.assertEquals(doc.getRecDoseModifierDescriptorAttrValue("NO_DOSE"),"FALSE");
		//DoseRecmnd
		Assert.assertEquals(doc.getDoseRecmndAttrValue("DOSE"),"250");
		Assert.assertEquals(doc.getDoseRecmndAttrValue("INTERVAL"),"12");
	}

	/**
	 * trying to force hepatic mod dose - CMS2291484
	 * @throws Exception
	 */
	@Test 
	public void testHepaticRec() throws Exception {
		System.out.println("In method 'testHepaticRec'");
		
		PSDDoc doc = getPSDResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
				"   <PSDRecommendationRequest>" + 
				"      <Patient GENDER=\"MALE\" AGE_IN_DAYS=\"22000\" WEIGHT=\"100\" HEIGHT=\"160\" HEPATIC_STATUS_ID='10' />  " + 
				"      <RequestRecommendationRxList SIZE=\"1\">" + 
				"         <RequestRecommendationRx>" + 
				"            <PSDDrug ID=\"110963\" TYPE=\"GFC\"/>" + 
				"            <RxDoseKey ROUTE_ID=\"103\" ROUTE_ID_TYPE=\"HL7\" DOSE_TYPE_ID=\"105\" INDICATION_ID=\"104\" INDICATION_ID_TYPE=\"TH\"/>" + 
				"         </RequestRecommendationRx>" + 
				"      </RequestRecommendationRxList>" + 
				"      <DosingFilters INDICATION_NOT_SPECIFIED=\"NORESTRICTION\" NO_INDICATION_MATCH=\"IGNOREIND\" NORMAL_RESULTS_NO_RENAL_HEPATIC=\"TRUE\" RETURN_DOSE_KEYS=\"FALSE\"/>" + 
				"   </PSDRecommendationRequest>" + 
				"");
		Assert.assertEquals("0", doc.getErrorListSize());
		Assert.assertEquals("1", doc.getRecResponseListSize());
		Assert.assertEquals("110963", doc.getRecPSDDrugID());
		Assert.assertEquals("GFC", doc.getRecPSDDrugType());
		Assert.assertEquals("1", doc.getRecDoseKeySize());
		//RxDoseKey
		Assert.assertEquals("103", doc.getRecRxDoseKeyAttrValue("ROUTE_ID"));
		Assert.assertEquals("HL7", doc.getRecRxDoseKeyAttrValue("ROUTE_ID_TYPE"));
		Assert.assertEquals("Swallow, oral", doc.getRecRxDoseKeyAttrValue("ROUTE_NAME"));
		Assert.assertEquals("105", doc.getRecRxDoseKeyAttrValue("DOSE_TYPE_ID"));
		Assert.assertEquals("Maintenance", doc.getRecRxDoseKeyAttrValue("DOSE_TYPE_NAME"));
		Assert.assertEquals("104", doc.getRecRxDoseKeyAttrValue("INDICATION_ID"));
		Assert.assertEquals("TH", doc.getRecRxDoseKeyAttrValue("INDICATION_ID_TYPE"));
		Assert.assertEquals("Depressive disorder", doc.getRecRxDoseKeyAttrValue("INDICATION_NAME"));
		Assert.assertEquals("35489007", doc.getRecRxDoseKeyAttrValue("SNOMED_CONCEPT_ID"));
		//RecmndDosingUnits
		Assert.assertEquals("MG", doc.getRecmndDosingUnitsAttrValue("DOSE_UNIT"));
		Assert.assertEquals("FALSE", doc.getRecmndDosingUnitsAttrValue("NCPDP_FLAG"));
		Assert.assertEquals("HR", doc.getRecmndDosingUnitsAttrValue("PERIOD_INTERVAL_UNIT"));
		// GeneralDoseParms
		Assert.assertEquals("General", doc.getRecmndGeneralDoseParmsAttrValue("DOSING_PATH"));
		Assert.assertEquals("Flat", doc.getRecmndGeneralDoseParmsAttrValue("DOSING_METHOD"));
		Assert.assertEquals("FALSE", doc.getRecmndGeneralDoseParmsAttrValue("PRN"));
		Assert.assertEquals("FALSE", doc.getRecmndGeneralDoseParmsAttrValue("NTI"));
		Assert.assertEquals("CMS2291484", doc.getRecmndGeneralDoseParmsAttrValue("GENPARMID"));
		// DoseModifierDescriptor
		Assert.assertEquals("Hepatic", doc.getRecDoseModifierDescriptorAttrValue("DOSE_MODIFIER_TYPE"));
		Assert.assertEquals("FALSE", doc.getRecDoseModifierDescriptorAttrValue("CONTRAINDICATED"));
		Assert.assertEquals("FALSE", doc.getRecDoseModifierDescriptorAttrValue("NO_DOSE"));
		//DoseRecmnd
		Assert.assertTrue(doc.getAllDoseRecmndDoseAndIntervalValues("150","48"));
	}
	

}
