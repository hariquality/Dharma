package com.truven.ids.application.cko.uitest.regression.pageobjects;

import java.util.Iterator;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;


/**
 * ImagesImprintsDoc contains Images and Imprints specific methods.
 * @author APeavy
 * 
 */
public class ImagesImprintsDoc extends BaseDoc {

	public ImagesImprintsDoc(Document inputDoc) {
		super(inputDoc);
	}

	public String getDrugListSize() {
		return doc.getRootElement()
				.getChild("DrugList")
				.getAttributeValue("SIZE");
	}

	public String getFirstDrugCode() {
		return doc.getRootElement()
				.getChild("DrugList")
				.getChild("Drug")
				.getAttributeValue("CODE");
	}

	public String getFirstShape() {
		return doc.getRootElement()
				.getChild("DrugList")
				.getChild("Drug")
				.getChild("PhysicalPropertySetList")
				.getChild("PhysicalPropertySet")
				.getAttributeValue("SHAPE");
	}

	public String getFirstPattern() {
		return doc.getRootElement()
				.getChild("DrugList")
				.getChild("Drug")
				.getChild("PhysicalPropertySetList")
				.getChild("PhysicalPropertySet")
				.getAttributeValue("PATTERN");
	}

	public String getFirstImprintCodes() {
		return doc.getRootElement()
				.getChild("DrugList")
				.getChild("Drug")
				.getChild("PhysicalPropertySetList")
				.getChild("PhysicalPropertySet")
				.getAttributeValue("IMPRINT_CODES");
	}

	public String getFirstPrimaryColor() {
		return doc.getRootElement()
				.getChild("DrugList")
				.getChild("Drug")
				.getChild("PhysicalPropertySetList")
				.getChild("PhysicalPropertySet")
				.getAttributeValue("PRIMARY_COLOR");
	}

	public String getFirstSecondaryColor() {
		return doc.getRootElement()
				.getChild("DrugList")
				.getChild("Drug")
				.getChild("PhysicalPropertySetList")
				.getChild("PhysicalPropertySet")
				.getAttributeValue("SECONDARY_COLOR");
	}

	public String getFirstTertiaryColor() {
		return doc.getRootElement()
				.getChild("DrugList")
				.getChild("Drug")
				.getChild("PhysicalPropertySetList")
				.getChild("PhysicalPropertySet")
				.getAttributeValue("TERTIARY_COLOR");
	}

	public Boolean isPhraseInErrorElement(String phrase) {
		if (doc.getRootElement()
				.getChild("ErrorList")
				.getChild("Error")
				.getAttributeValue("ERROR_TEXT").contains(phrase)) {
			return true;
		} else return false;
	}

	public String getFirstStatus() {
		return doc.getRootElement()
				.getChild("DrugList")
				.getChild("Drug")
				.getChild("PhysicalPropertySetList")
				.getChild("PhysicalPropertySet")
				.getAttributeValue("STATUS");
	}

	public String getFirstFlavor() {
		return doc.getRootElement()
				.getChild("DrugList")
				.getChild("Drug")
				.getChild("PhysicalPropertySetList")
				.getChild("PhysicalPropertySet")
				.getAttributeValue("FLAVOR");
	}

	public String getFirstImprintDescription() {
		return doc.getRootElement()
				.getChild("DrugList")
				.getChild("Drug")
				.getChild("PhysicalPropertySetList")
				.getChild("PhysicalPropertySet")
				.getAttributeValue("IMPRINT_DESCRIPTION");
	}

	public boolean getDrugcodes(String value) {

		int flag=0;
		List<?> drugcodes =doc.getRootElement()
				.getChild("DrugList")
				.getChildren("Drug");

		int i=drugcodes.size();
		if (i > 0) {
			Iterator<?> w = drugcodes.iterator();
			while (w.hasNext()) {
				Element drugs = (Element) w.next();
				if ((drugs.getAttributeValue("CODE").equalsIgnoreCase(value))){
					System.out.println("success");
					System.out.println("response Value" +(drugs.getAttributeValue("CODE")));
					flag = 1;
					break;
				} else {
					System.out.println("fail");
					System.out.println("response Value" +(drugs.getAttributeValue("CODE")));

				}
			}
		}
		if (flag == 1)
			return true;
		else
			return false;
	}
}
