package com.truven.ids.application.cko.uitest.local.mas;

import static org.testng.Assert.assertTrue;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.MasDoc;
import com.truven.ids.application.cko.uitest.regression.pageobjects.MasValidationDoc;

/**
 * MAS Validationfunctional tests
 * 
 * @author APeavy
 * 
 */
public class TestMasValidationLocal extends CKOBaseTest  {

	/* TC350995, TC350996, TC350999
	 * 
	 * Verify whether warning is displayed when requested REGISTRY type is not available in Local Schema
	 * Verify whether warning displayed when requested REGISTRY code is not available in Local Schema
	 * REGISTRY_TYPE='ZZZ' not available in local schema
	 * @throws Exception
	 */
	@Test
	public void testWithValuesNotFoundforregistry() throws Exception {
		MasValidationDoc doc = getMasValidationResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
				"<MASValidationRequest REGION='ES'>" + 
				"� <NewDrugList SIZE='16'>" + 
				"� � <Drug CODE='4595-8688-68' TYPE='Registry' REGISTRY_TYPE='ZZZ'/>" + 
				"	 <Drug CODE='4595-8688-68' TYPE='Registry' REGISTRY_TYPE='AIC'/>" +
				"� �  � </NewDrugList>" + 
				"� � <OrderList SIZE='4'>" + 
				"� � <Order ID='123456789'>" + 
				"� � � <TimeStampList SIZE='2'>" + 
				"� � � � <TimeStamp TYPE='BEGIN' YEAR='2004' MONTH='11' DAY='5' HOUR='13' MINUTE='18' SECOND='20'/>" + 
				"� � � � <TimeStamp TYPE=\"END\" YEAR='2005' MONTH='12' DAY='10' HOUR='14' MINUTE='30' SECOND='10'/>" + 
				"� � � </TimeStampList>" + 
				"� � </Order>" + 
				"� � <Order ID='BADORDER'/>" + 
				"� </OrderList>" + 
				"</MASValidationRequest>" + 
				"");
		Assert.assertEquals(doc.getSummaryWarningTotal(),"2","Summary WARNING_TOTAL");
		Assert.assertTrue(doc.getWarningTextseq("Drug-ZZZ:4595-8688-68 Not in the Micromedex Screening Database: ZZZ:4595-8688-68"));
		Assert.assertTrue(doc.getWarningTextseq("Drug-AIC:4595-8688-68 Not in the Micromedex Screening Database: AIC:4595-8688-68"));
		//Assert.assertEquals(doc.getWarningText(), "Drug-ZZZ:4595-8688-68 Not in the Micromedex Screening Database: ZZZ:4595-8688-68","WARNING TEXT");
	}
	
	/* TC351000
	 * 
	 * Verify whether warning displayed when requested NDC type not is available in US Schema
	 * 
	 * @throws Exception
	 */
	@Test
	public void testerrmsgforNDConlocal() throws Exception {
		MasValidationDoc doc = getMasValidationResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
				"<MASValidationRequest REGION='IT'>" + 
				"� <CurrentDrugList SIZE='16'>" + 
				"� � <Drug CODE=\"00000-3109-70\" TYPE='NDC' ORDER_ID='123456789'/>" + 
				"</CurrentDrugList>" + 
				"� � <OrderList SIZE='4'>" + 
				"� � <Order ID='123456789'>" + 
				"� � � <TimeStampList SIZE='2'>" + 
				"� � � � <TimeStamp TYPE='BEGIN' YEAR='2004' MONTH='11' DAY='5' HOUR='13' MINUTE='18' SECOND='20'/>\r\n" + 
				"� � � � <TimeStamp TYPE=\"END\" YEAR='2005' MONTH='12' DAY='10' HOUR='14' MINUTE='30' SECOND='10'/>\r\n" + 
				"� � � </TimeStampList>" + 
				"� � </Order>" + 
				"� � <Order ID='BADORDER'/>" + 
				"� </OrderList>" + 
				"</MASValidationRequest>");
		Assert.assertEquals(doc.getSummaryWarningTotal(),"1","Summary WARNING_TOTAL");
		Assert.assertEquals(doc.getWarningText(), "Drug: 00000-3109-70 Not in the Micromedex Screening Database: 00000-3109-70","WARNING TEXT");
	}
	
	/* TC351002
	 * 
	 * Verify whether warning displayed when requested GCR/GFC type is not available in neither Local or US Schema
	 * 
	 * @throws Exception
	 */
	@Test
	public void testerrmsgforgcrgfconlocal() throws Exception {
		MasValidationDoc doc = getMasValidationResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
				"<MASValidationRequest REGION='ES'>" + 
				"� <CurrentDrugList SIZE='3'>" + 
				"� � <Drug CODE='53746-0670-01' TYPE='NDC' ORDER_ID='123-AA'/>" + 
				"� </CurrentDrugList>" + 
				"� <NewDrugList SIZE='16'>" + 
				"� � <Drug CODE='489712' TYPE='GCR' ORDER_ID='123456789'/>" + 
				"� � <Drug CODE='50268-0051-11' TYPE='NDC'/>" + 
				"� � <Drug CODE='100001' TYPE='GFC'/>" + 
				"� � <Drug CODE='23RT5' TYPE='Registry' REGISTRY_TYPE='GTIN' ORDER_ID='BADORDER'/>" + 
				" � </NewDrugList>" + 
				"� <AllergenList SIZE='4'>" + 
				"� � <Allergen CODE='7700263' TYPE='MDX_ALG'/>" + 
				"� � <Allergen CODE='42291-0102-90' TYPE='NDC'/>" + 
				"� </AllergenList>" + 
				"� <IndicationList SIZE='3'>" + 
				"� � <Indication CODE='011.30' TYPE='ICD_9'/>" + 
				"� � <Indication CODE='1676' TYPE='MDX_CONCEPT'/>" + 
				"� </IndicationList>" + 
				"� <OrderList SIZE='4'>" + 
				"� � <Order ID='123456789'>" + 
				"� � � <TimeStampList SIZE='2'>" + 
				"� � � � <TimeStamp TYPE='BEGIN' YEAR='2004' MONTH='11' DAY='5' HOUR='13' MINUTE='18' SECOND='20'/>" + 
				"� � � � <TimeStamp TYPE=\"END\" YEAR='2005' MONTH='12' DAY='10' HOUR='14' MINUTE='30' SECOND='10'/>" + 
				"� � � </TimeStampList>" + 
				"� � </Order>" + 
				"� � <Order ID='BADORDER'/>" + 
				"� </OrderList>" + 
				"</MASValidationRequest>");
		Assert.assertEquals(doc.getSummaryWarningTotal(),"3","Summary WARNING_TOTAL");
		Assert.assertTrue(doc.getWarningTextseq("Drug: 489712 Not in the Micromedex Screening Database: 489712"));
		Assert.assertTrue(doc.getWarningTextseq("Drug: 100001 Not in the Micromedex Screening Database: 100001"));
		//Assert.assertTrue(true, );
		//Assert.assertTrue(true, "");
		//Assert.asserttrue(doc.getWarningTextseq("Drug: 489712 Not in the Micromedex Screening Database: 489712"), "Drug: 489712 Not in the Micromedex Screening Database: 489712","WARNING TEXT");
		//Assert.assertEquals(doc.getWarningTextseq("Drug: 100001 Not in the Micromedex Screening Database: 100001"), "Drug: 100001 Not in the Micromedex Screening Database: 100001","WARNING TEXT");
		
	}
	
	/* TC351003
	 * 
	 * Verify whether the REGION and REGISTRY_TYPE is part of the result set for local MAS validation. 
	 * 
	 * @throws Exception
	 */
	@Test
	public void testerrmsgforregregistrytypelocal() throws Exception {
		MasValidationDoc doc = getMasValidationResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
				"<MASValidationRequest REGION='ES'>" + 
				"� <NewDrugList SIZE='16'>" + 
				"� � <Drug CODE='4595-8688-68' TYPE='Registry' REGISTRY_TYPE='AIC'/>" + 
				"� �  � </NewDrugList>" + 
				"� � <OrderList SIZE='4'>" + 
				"� � <Order ID='123456789'>" + 
				"� � � <TimeStampList SIZE='2'>" + 
				"� � � � <TimeStamp TYPE='BEGIN' YEAR='2004' MONTH='11' DAY='5' HOUR='13' MINUTE='18' SECOND='20'/>" + 
				"� � � � <TimeStamp TYPE=\"END\" YEAR='2005' MONTH='12' DAY='10' HOUR='14' MINUTE='30' SECOND='10'/>" + 
				"� � � </TimeStampList>" + 
				"� � </Order>" + 
				"� � <Order ID='BADORDER'/>" + 
				"� </OrderList>" + 
				"</MASValidationRequest>");
		Assert.assertEquals(doc.getSummaryWarningTotal(),"1","Summary WARNING_TOTAL");
		Assert.assertEquals(doc.getWarningText(), "Drug-AIC:4595-8688-68 Not in the Micromedex Screening Database: AIC:4595-8688-68","WARNING TEXT");
		Assert.assertTrue(doc.getvalidationWarningRegion("ES"));
	}

	/* TC351004
	 * 
	 * Verify whether Registry to be accepted in allergies section similar to NDC
	 * 
	 * @throws Exception
	 */
	@Test
	public void testerrmsgforallergenregistrytypesearch() throws Exception {
		MasValidationDoc doc = getMasValidationResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
				"<MASValidationRequest REGION='ES'>" + 
				"� <CurrentDrugList SIZE='3'>" + 
				"� � <Drug CODE='53746-0670-01' TYPE='NDC' ORDER_ID='123-AA'/>" + 
				"� </CurrentDrugList>" + 
				"� <NewDrugList SIZE='16'>" + 
				"� � <Drug CODE='489711' TYPE='GCR' ORDER_ID='123456789'/>" + 
				"� � <Drug CODE='50268-0051-11' TYPE='NDC'/>" + 
				"� � � </NewDrugList>" + 
				"� <AllergenList SIZE='4'>" + 
				"� � <Allergen CODE='77002635' TYPE='MDX_ALG'/>" + 
				"� � <Allergen CODE='23RT56' TYPE='Registry' REGISTRY_TYPE='GTIN' ORDER_ID='BADORDER'/>" + 
				"� </AllergenList>" + 
				"� <IndicationList SIZE='3'>" + 
				"� � <Indication CODE='011.30' TYPE='ICD_9'/>" + 
				"� � <Indication CODE='1676' TYPE='MDX_CONCEPT'/>" + 
				"� </IndicationList>" + 
				"� <OrderList SIZE='4'>" + 
				"� � <Order ID='123456789'>" + 
				"� � � <TimeStampList SIZE='2'>" + 
				"� � � � <TimeStamp TYPE='BEGIN' YEAR='2004' MONTH='11' DAY='5' HOUR='13' MINUTE='18' SECOND='20'/>" + 
				"� � � � <TimeStamp TYPE=\"END\" YEAR='2005' MONTH='12' DAY='10' HOUR='14' MINUTE='30' SECOND='10'/>" + 
				"� � � </TimeStampList>" + 
				"� � </Order>" + 
				"� � <Order ID='BADORDER'/>" + 
				"� </OrderList>" + 
				"</MASValidationRequest>");
		Assert.assertEquals(doc.getSummaryWarningTotal(),"3","Summary WARNING_TOTAL");
		Assert.assertTrue(doc.getWarningTextseq("Allergen-GTIN:23RT56 Not in the Micromedex Screening Database: GTIN:23RT56"));
	}
	
	/* TC351006
	 * 
	 * Verify whether the GFC/GCR existing in US schema is searched successfully in local schema
	 * 
	 * @throws Exception
	 */
	@Test
	public void testmasvalforexistinggcrgfc() throws Exception {
		MasValidationDoc doc = getMasValidationResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
				"<MASValidationRequest REGION='ES'>" + 
				"� <NewDrugList SIZE='2'>" + 
				"� � <Drug CODE='932214' TYPE='GCR' ORDER_ID='123456789'/>" + 
				"� � <Drug CODE='100002' TYPE='GFC'/>" + 
				"� � � </NewDrugList>" + 
				"� <AllergenList SIZE='2'>" + 
				"� � <Allergen CODE='7703564' TYPE='MDX_ALG'/>" + 
				"� </AllergenList>" + 
				"� <IndicationList SIZE='2'>" + 
				"� � <Indication CODE='011.30' TYPE='ICD_9'/>" + 
				"� � <Indication CODE='1676' TYPE='MDX_CONCEPT'/>" + 
				"� </IndicationList>" + 
				"� <OrderList SIZE='4'>" + 
				"� � <Order ID='123456789'>" + 
				"� � � <TimeStampList SIZE='2'>" + 
				"� � � � <TimeStamp TYPE='BEGIN' YEAR='2004' MONTH='11' DAY='5' HOUR='13' MINUTE='18' SECOND='20'/>" + 
				"� � � � <TimeStamp TYPE=\"END\" YEAR='2005' MONTH='12' DAY='10' HOUR='14' MINUTE='30' SECOND='10'/>" + 
				"� � � </TimeStampList>" + 
				"� � </Order>" + 
				"� � <Order ID='BADORDER'/>" + 
				"� </OrderList>" + 
				"</MASValidationRequest>" + 
				"");
		Assert.assertEquals(doc.getSummaryWarningTotal(),"0","Summary WARNING_TOTAL");
	}
	
	/* TC351001
	 * 
	 * Verify whether warning displayed when requested ndc code type is available in US Schema
	 * 
	 * @throws Exception
	 */
	@Test
	public void testerrmsgforNDConUS() throws Exception {
		MasValidationDoc doc = getMasValidationResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
				"<MASValidationRequest REGION='IT'>" + 
				"� <CurrentDrugList SIZE='16'>" + 
				"� � <Drug CODE=\"00002-1691-16\" TYPE='NDC' ORDER_ID='123456789'/>" + 
				"</CurrentDrugList>" + 
				"� � <OrderList SIZE='4'>" + 
				"� � <Order ID='123456789'>" + 
				"� � � <TimeStampList SIZE='2'>" + 
				"� � � � <TimeStamp TYPE='BEGIN' YEAR='2004' MONTH='11' DAY='5' HOUR='13' MINUTE='18' SECOND='20'/>\r\n" + 
				"� � � � <TimeStamp TYPE=\"END\" YEAR='2005' MONTH='12' DAY='10' HOUR='14' MINUTE='30' SECOND='10'/>\r\n" + 
				"� � � </TimeStampList>" + 
				"� � </Order>" + 
				"� � <Order ID='BADORDER'/>" + 
				"� </OrderList>" + 
				"</MASValidationRequest>");
		Assert.assertEquals(doc.getSummaryWarningTotal(),"0","Summary WARNING_TOTAL");
		//Assert.assertEquals(doc.getWarningText(), "Drug-AIC:4595-8688-68 Not in the Micromedex Screening Database: AIC:4595-8688-68","WARNING TEXT");
	}
	
	/* TC350998, TC349743
	 * 
	 * Verify whether warning displayed when requested REGISTRY type in US Region 
	 * 
	 * @throws Exception
	 */
	@Test
	public void testerrmsgforRegistryinUS() throws Exception {
		MasValidationDoc doc = getMasValidationResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
				"<MASValidationRequest >" + 
				"� <NewDrugList SIZE='1'>" + 
				"� � <Drug CODE='038529069' TYPE='Registry' REGISTRY_TYPE='AIC'/>" + 
				"� �� �  � </NewDrugList>" + 
				"� � <OrderList SIZE='1'>" + 
				"� � <Order ID='123456789'>" + 
				"� � � <TimeStampList SIZE='2'>" + 
				"� � � � <TimeStamp TYPE='BEGIN' YEAR='2004' MONTH='11' DAY='5' HOUR='13' MINUTE='18' SECOND='20'/>" + 
				"� � � � <TimeStamp TYPE=\"END\" YEAR='2005' MONTH='12' DAY='10' HOUR='14' MINUTE='30' SECOND='10'/>" + 
				"� � � </TimeStampList>" + 
				"� � </Order>" + 
				"� � <Order ID='BADORDER'/>" + 
				"� </OrderList>" + 
				"</MASValidationRequest>");
		Assert.assertEquals(doc.getSummaryWarningTotal(),"0","Summary WARNING_TOTAL");
		Assert.assertEquals(doc.getErrorTextValidation(), "Invalid drug identifier type given: valid values are NDC, GFC, or GCR.", "ERROR TEXT");
	}
	
	/* TC350997
	 * 
	 * Verify whether warning displayed when requested REGISTRY type is not belongs current region
	 * 
	 * @throws Exception
	 */
	@Test
	public void testerrmsgforRegistryinlocal() throws Exception {
		MasValidationDoc doc = getMasValidationResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
				"<MASValidationRequest REGION='ES'>" + 
				"� <NewDrugList SIZE='16'>" + 
				"� � <Drug CODE='038529069' TYPE='Registry' REGISTRY_TYPE='AIC'/>" + 
				"� �� �  � </NewDrugList>" + 
				"</MASValidationRequest>");
		Assert.assertEquals(doc.getSummaryWarningTotal(),"1","Summary WARNING_TOTAL");
		Assert.assertEquals(doc.getWarningText(), "Drug-AIC:038529069 Not in the Micromedex Screening Database: AIC:038529069", "WARNING TEXT");
	}
	
	/* TC351007
	 * 
	 * Verify whether Invalid region error displayed when requested by not valid region ID 
	 * 
	 * @throws Exception
	 */
	@Test
	public void testerrmsgforinvalidregion() throws Exception {
		MasValidationDoc doc = getMasValidationResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
				"<MASValidationRequest REGION='zz'>" + 
				"� <NewDrugList SIZE='16'>" + 
				"� � <Drug CODE='4595-8688-68' TYPE='Registry' REGISTRY_TYPE='AIC'/>" + 
				"� �  � </NewDrugList>" + 
				"� � <OrderList SIZE='4'>" + 
				"� � <Order ID='123456789'>" + 
				"� � � <TimeStampList SIZE='2'>" + 
				"� � � � <TimeStamp TYPE='BEGIN' YEAR='2004' MONTH='11' DAY='5' HOUR='13' MINUTE='18' SECOND='20'/>" + 
				"� � � � <TimeStamp TYPE=\"END\" YEAR='2005' MONTH='12' DAY='10' HOUR='14' MINUTE='30' SECOND='10'/>" + 
				"� � � </TimeStampList>" + 
				"� � </Order>" + 
				"� � <Order ID='BADORDER'/>" + 
				"� </OrderList>" + 
				"</MASValidationRequest>");
		Assert.assertEquals(doc.getSummaryWarningTotal(),"0","Summary WARNING_TOTAL");
		Assert.assertEquals(doc.getErrorTextValidation(), "Invalid Country ISO Code in region field given", "ERROR TEXT");
	}
	
	/* TC351009
	 * 
	 * Verify whether error displays when registry type requested in indication list
	 * 
	 * @throws Exception
	 */
	@Test
	public void testerrmsgforregistryinindication() throws Exception {
		MasValidationDoc doc = getMasValidationResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
				"<MASValidationRequest REGION='ES'>" + 
				"� <IndicationList SIZE='16'>" + 
				"� � <Indication CODE='4595-8688-68' TYPE='Registry' REGISTRY_TYPE='AIC'/>" + 
				"� �  � </IndicationList>" + 
				"� � <OrderList SIZE='4'>" + 
				"� � <Order ID='123456789'>" + 
				"� � � <TimeStampList SIZE='2'>" + 
				"� � � � <TimeStamp TYPE='BEGIN' YEAR='2004' MONTH='11' DAY='5' HOUR='13' MINUTE='18' SECOND='20'/>" + 
				"� � � � <TimeStamp TYPE=\"END\" YEAR='2005' MONTH='12' DAY='10' HOUR='14' MINUTE='30' SECOND='10'/>" + 
				"� � � </TimeStampList>" + 
				"� � </Order>" + 
				"� � <Order ID='BADORDER'/>" + 
				"� </OrderList>" + 
				"</MASValidationRequest>");
		Assert.assertEquals(doc.getSummaryWarningTotal(),"0","Summary WARNING_TOTAL");
		Assert.assertEquals(doc.getErrorTextValidation(), "Invalid indication identifier type given: valid values are ICD_9, ICD_10 or MDX_CONCEPT.", "ERROR TEXT");
	}
	
	/* TC351008
	 * 
	 * Verify validation response for US drugs with Region is set as 'US' or without region
	 * 
	 * @throws Exception
	 */
	@Test
	public void testmasforregionus() throws Exception {
		MasValidationDoc doc = getMasValidationResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
				"<MASValidationRequest REGION='US'>" + 
				"� <CurrentDrugList SIZE='16'>" + 
				"� � <Drug CODE=\"00002-1691-16\" TYPE='NDC' ORDER_ID='123456789'/>" + 
				"</CurrentDrugList>" + 
				"� � <OrderList SIZE='4'>" + 
				"� � <Order ID='123456789'>" + 
				"� � � <TimeStampList SIZE='2'>" + 
				"� � � � <TimeStamp TYPE='BEGIN' YEAR='2004' MONTH='11' DAY='5' HOUR='13' MINUTE='18' SECOND='20'/>\r\n" + 
				"� � � � <TimeStamp TYPE=\"END\" YEAR='2005' MONTH='12' DAY='10' HOUR='14' MINUTE='30' SECOND='10'/>\r\n" + 
				"� � � </TimeStampList>" + 
				"� � </Order>" + 
				"� � <Order ID='BADORDER'/>" + 
				"� </OrderList>" + 
				"</MASValidationRequest>");
		Assert.assertEquals(doc.getSummaryWarningTotal(),"0","Summary WARNING_TOTAL");
	
}
}
