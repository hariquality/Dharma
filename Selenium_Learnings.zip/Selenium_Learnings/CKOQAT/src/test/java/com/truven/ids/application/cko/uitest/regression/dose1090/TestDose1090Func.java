package com.truven.ids.application.cko.uitest.regression.dose1090;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.Dose1090Doc;

/**
 * Dose1090 functional tests
 * 
 * @author APeavy
 * 
 */
public class TestDose1090Func extends CKOBaseTest  {

	/**
	 * TC186956 TC186971 TC186980 TC186993 TC187009
	 * Happy path test for EA
	 * @throws Exception
	 */
	@Test
	public void testUnitEA() throws Exception {
		System.out.println("In method 'testUnitEA'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"17714-0009-36\" TYPE=\"NDC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\"1\" PERIOD_AMOUNT=\"1\" DURATION=\"1\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDrugListSize(),"1");
		Assert.assertEquals(doc.getFirstDrugCode(),"17714-0009-36");
		Assert.assertEquals(doc.getFirstDrugIndivRangeText(),"Value is within range");
		Assert.assertEquals(doc.getFirstDrugPeriodRangeText(),"Value is within range");
		Assert.assertEquals(doc.getFirstDrugDurationRangeText(),"Value is within range");
	}
	
	/**
	 * TC186957 TC186970 TC186979 TC186992 TC187008
	 * Happy path test for ML
	 * @throws Exception
	 */
	@Test
	public void testUnitML() throws Exception {
		System.out.println("In method 'testUnitML'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"100005\" TYPE=\"GFC\" UNIT=\"ML\" INDIVIDUAL_AMOUNT=\"20\" PERIOD_AMOUNT=\"1\" DURATION=\"1\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("0", doc.getErrorListSize());
		Assert.assertEquals("1", doc.getDrugListSize());
		Assert.assertEquals("100005", doc.getFirstDrugCode());
		Assert.assertEquals("Value is within range", doc.getFirstDrugIndivRangeText());
		Assert.assertEquals("Value is within range", doc.getFirstDrugPeriodRangeText());
		Assert.assertEquals("Value is within range", doc.getFirstDrugDurationRangeText());
	}
	
	/**
	 * TC186969 TC186978 TC186987 TC186991 TC187007
	 * Happy path test for GM
	 * @throws Exception
	 */
	@Test
	public void testUnitGM() throws Exception {
		System.out.println("In method 'testUnitGM'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1965\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"103067\" TYPE=\"GFC\" UNIT=\"GM\" INDIVIDUAL_AMOUNT=\"2\" PERIOD_AMOUNT=\"6\" DURATION=\"10\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("0", doc.getErrorListSize());
		Assert.assertEquals("1", doc.getDrugListSize());
		Assert.assertEquals("103067", doc.getFirstDrugCode());
		Assert.assertEquals("Value is within range", doc.getFirstDrugIndivRangeText());
		Assert.assertEquals("Value is within range", doc.getFirstDrugPeriodRangeText());
		Assert.assertEquals("Value is within range", doc.getFirstDrugDurationRangeText());
	}
	
	/**
	 * TC186972 TC186981 TC186989 TC187016
	 * Test that input values give high warning
	 * @throws Exception
	 */
	@Test
	public void testHighAll() throws Exception {
		System.out.println("In method 'testHighAll'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"17714-0009-36\" TYPE=\"NDC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\"9\" PERIOD_AMOUNT=\"100\" DURATION=\"500\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("0", doc.getErrorListSize());
		Assert.assertEquals("1", doc.getDrugListSize());
		Assert.assertEquals("17714-0009-36", doc.getFirstDrugCode());
		Assert.assertEquals("Value is above maximum", doc.getFirstDrugDurationRangeText());
		Assert.assertEquals("Value is above maximum", doc.getFirstDrugIndivRangeText());
		Assert.assertEquals("Value is above maximum", doc.getFirstDrugPeriodRangeText());
	}
	
	/**
	 * TC186973 TC186982 TC186988 TC187023
	 * Test that all input values give low warning
	 * @throws Exception
	 */
	@Test
	public void testLowAll() throws Exception {
		System.out.println("In method 'testLowAll'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"100002\" TYPE=\"GFC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\".5\" PERIOD_AMOUNT=\"1\" DURATION=\".5\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("0", doc.getErrorListSize());
		Assert.assertEquals("1", doc.getDrugListSize());
		Assert.assertEquals("100002", doc.getFirstDrugCode());
		Assert.assertEquals("Value is below minimum", doc.getFirstDrugIndivRangeText());
		Assert.assertEquals("Value is below minimum", doc.getFirstDrugPeriodRangeText());
		Assert.assertEquals("Value is below minimum", doc.getFirstDrugDurationRangeText());
	}
	
	/**
	 * Verify Age input is used to get proper record.
	 * 5ml is OK for an 4yo, but low for an adult 
	 * @throws Exception
	 */
	@Test
	public void testAgeInput() throws Exception {
		System.out.println("In method 'testAgeInput'");
		System.out.println("4 yo bdate:'" + getDose1090DateAttributesForGivenAgeInYears(4));
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient " + getDose1090DateAttributesForGivenAgeInYears(4) + " GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"100005\" TYPE=\"GFC\" UNIT=\"ML\" INDIVIDUAL_AMOUNT=\"5\" PERIOD_AMOUNT=\"1\" DURATION=\"10\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("0", doc.getErrorListSize());
		Assert.assertEquals("1", doc.getDrugListSize());
		Assert.assertEquals("100005", doc.getFirstDrugCode());
		Assert.assertEquals("Value is within range", doc.getFirstDrugIndivRangeText());
		Assert.assertEquals("Value is within range", doc.getFirstDrugPeriodRangeText());
		Assert.assertEquals("Value is within range", doc.getFirstDrugDurationRangeText());
	}
	
	/**
	 * TC186958
	 * Verify no gender input defaults to FEMALE.
	 * @throws Exception
	 */
	@Test
	public void testDefaultGender() throws Exception {
		System.out.println("In method 'testDefaultGender'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient " + getDose1090DateAttributesForGivenAgeInYears(25) + " LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"100002\" TYPE=\"GFC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\"1\" PERIOD_AMOUNT=\"1\" DURATION=\"1\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		// this test case fails.  There may be a legitimate
		// defect in that dose1090 records for gender F are
		// not being returned.
		// 4/7/2016 - DE51529 - PM is checking if Dose1090 is being used by customers.
		Assert.assertEquals("0", doc.getErrorListSize());
		Assert.assertEquals("1", doc.getDrugListSize());
		Assert.assertEquals("100002", doc.getFirstDrugCode());
	}

	/**
	 * TC186999 TC187001 TC187003 TC187006 TC187017 TC187018 TC187019
	 * Test each input individually for high response
	 * @throws Exception
	 */
	@Test
	public void testHighEachIndividually() throws Exception {
		System.out.println("In method 'testHighEachIndividually'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"17714-0009-36\" TYPE=\"NDC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\"9\" PERIOD_AMOUNT=\"5\" DURATION=\"5\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("0", doc.getErrorListSize());
		Assert.assertEquals("1", doc.getDrugListSize());
		Assert.assertEquals("17714-0009-36", doc.getFirstDrugCode());
		Assert.assertEquals("Value is above maximum", doc.getFirstDrugIndivRangeText());
		Assert.assertEquals("Value is within range", doc.getFirstDrugPeriodRangeText());
		Assert.assertEquals("Value is within range", doc.getFirstDrugDurationRangeText());
		
		doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"17714-0009-36\" TYPE=\"NDC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\"3\" PERIOD_AMOUNT=\"100\" DURATION=\"5\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("0", doc.getErrorListSize());
		Assert.assertEquals("1", doc.getDrugListSize());
		Assert.assertEquals("17714-0009-36", doc.getFirstDrugCode());
		Assert.assertEquals("Value is within range", doc.getFirstDrugIndivRangeText());
		Assert.assertEquals("Value is above maximum", doc.getFirstDrugPeriodRangeText());
		Assert.assertEquals("Value is within range", doc.getFirstDrugDurationRangeText());
		
		doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"17714-0009-36\" TYPE=\"NDC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\"3\" PERIOD_AMOUNT=\"20\" DURATION=\"1000\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("0", doc.getErrorListSize());
		Assert.assertEquals("1", doc.getDrugListSize());
		Assert.assertEquals("17714-0009-36", doc.getFirstDrugCode());
		Assert.assertEquals("Value is within range", doc.getFirstDrugIndivRangeText());
		Assert.assertEquals("Value is within range", doc.getFirstDrugPeriodRangeText());
		Assert.assertEquals("Value is above maximum", doc.getFirstDrugDurationRangeText());
	}
	
	/**
	 * TC187000 TC187002 TC187004 TC187005 TC187020 TC187021 TC187022
	 * Test each input individually for low response
	 * @throws Exception
	 */
	@Test
	public void testLowEachIndividually() throws Exception {
		System.out.println("In method 'testLowEachIndividually'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"100002\" TYPE=\"GFC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\".5\" PERIOD_AMOUNT=\"4\" DURATION=\"4\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("0", doc.getErrorListSize());
		Assert.assertEquals("1", doc.getDrugListSize());
		Assert.assertEquals("100002", doc.getFirstDrugCode());
		Assert.assertEquals("Value is below minimum", doc.getFirstDrugIndivRangeText());
		Assert.assertEquals("Value is within range", doc.getFirstDrugPeriodRangeText());
		Assert.assertEquals("Value is within range", doc.getFirstDrugDurationRangeText());
		
		doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"100002\" TYPE=\"GFC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\"4\" PERIOD_AMOUNT=\".1\" DURATION=\"4\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("0", doc.getErrorListSize());
		Assert.assertEquals("1", doc.getDrugListSize());
		Assert.assertEquals("100002", doc.getFirstDrugCode());
		Assert.assertEquals("Value is within range", doc.getFirstDrugIndivRangeText());
		Assert.assertEquals("Value is below minimum", doc.getFirstDrugPeriodRangeText());
		Assert.assertEquals("Value is within range", doc.getFirstDrugDurationRangeText());
		
		doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"100002\" TYPE=\"GFC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\"4\" PERIOD_AMOUNT=\"4\" DURATION=\".5\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("0", doc.getErrorListSize());
		Assert.assertEquals("1", doc.getDrugListSize());
		Assert.assertEquals("100002", doc.getFirstDrugCode());
		Assert.assertEquals("Value is within range", doc.getFirstDrugIndivRangeText());
		Assert.assertEquals("Value is within range", doc.getFirstDrugPeriodRangeText());
		Assert.assertEquals("Value is below minimum", doc.getFirstDrugDurationRangeText());

	}
	


}
