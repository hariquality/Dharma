package com.truven.ids.application.cko.uitest.regression.drugpoints;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.DrugPointsDoc;

/**
 * 
 * 
 * @author BHreen
 * 
 */
public class TestDrugPointsException extends CKOBaseTest  {



	/**
	 * 
	 * TC187358
	 */

	@Test 
	public void testInvalidNDC() throws Exception {
		System.out.println("In method 'testInvalidNDC'");
		DrugPointsDoc doc = getDrugPointsResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugPointsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"12345-6789-01\" TYPE=\"NDC\" />"
				+ "</NewDrugList>"
				+ "</DrugPointsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1");  // Assert.assert error
		Assert.assertTrue(doc.isPhraseInErrorElement("No data exists for the given drug identifier."),
				"No data exists for the given drug identifier.' not found in text element");  //Assert.assert phrase in the text element
	}


	/**
	 * 
	 * TC187359
	 */

	@Test 
	public void testInvalidGFC() throws Exception {
		System.out.println("In method 'testInvalidGFC'");
		DrugPointsDoc doc = getDrugPointsResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugPointsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"999999\" TYPE=\"GFC\" />"
				+ "</NewDrugList>"
				+ "</DrugPointsRequest>");
		Assert.assertEquals("1", doc.getErrorListSize());  // Assert.assert error
		Assert.assertTrue(doc.isPhraseInErrorElement("No data exists for the given drug identifier."),
				"No data exists for the given drug identifier.' not found in text element");  //Assert.assert phrase in the text element
	}


	/**
	 * 
	 * TC187360
	 */

	@Test 
	public void testInvalidGFCFormat() throws Exception {
		System.out.println("In method 'testInvalidGFCFormat'");
		DrugPointsDoc doc = getDrugPointsResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugPointsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"99-99-99\" TYPE=\"GFC\" />"
				+ "</NewDrugList>"
				+ "</DrugPointsRequest>");
		Assert.assertEquals("1", doc.getErrorListSize());  // Assert.assert error
		Assert.assertTrue(doc.isPhraseInErrorElement("Invalid GFC format: valid format is 123456."),
				"Invalid GFC format: valid format is 123456.' not found in text element");  //Assert.assert phrase in the text element
	}


	/**
	 * 
	 * TC187361
	 */

	@Test 
	public void testInvalidNDCFormat() throws Exception {
		System.out.println("In method 'testInvalidNDCFormat'");
		DrugPointsDoc doc = getDrugPointsResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugPointsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"999999\" TYPE=\"NDC\" />"
				+ "</NewDrugList>"
				+ "</DrugPointsRequest>");
		Assert.assertEquals("1", doc.getErrorListSize());  // Assert.assert error
		Assert.assertTrue(doc.isPhraseInErrorElement("Invalid NDC format: valid format is 12345-6789-10."),
				"Invalid NDC format: valid format is 12345-6789-10.' not found in text element");  //Assert.assert phrase in the text element
	}

	/**
	 * 
	 * TC187362
	 */

	@Test 
	public void testWithoutNDCCode() throws Exception {
		System.out.println("In method 'testWithoutNDCCode'");
		DrugPointsDoc doc = getDrugPointsResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugPointsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"\" TYPE=\"NDC\" />"
				+ "</NewDrugList>"
				+ "</DrugPointsRequest>");
		Assert.assertEquals("1", doc.getErrorListSize());  // Assert.assert error
		Assert.assertTrue(doc.isPhraseInErrorElement("Invalid NDC format: valid format is 12345-6789-10."),
				"Invalid NDC format: valid format is 12345-6789-10.' not found in text element");  //Assert.assert phrase in the text element
	}


	/**
	 * 
	 * TC187363
	 */

	@Test 
	public void testInvalidGCFDrugIdentifierType() throws Exception {
		System.out.println("In method 'testInvalidGCFDrugIdentifierType'");
		DrugPointsDoc doc = getDrugPointsResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugPointsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"101296\" TYPE=\"ABC\" />"
				+ "</NewDrugList>"
				+ "</DrugPointsRequest>");
		Assert.assertEquals("1", doc.getErrorListSize());  // Assert.assert error
		Assert.assertTrue(doc.isPhraseInErrorElement("Invalid drug identifier type given: valid values are GFC or NDC."),
				"Invalid drug identifier type given: valid values are GFC or NDC.");  //Assert.assert phrase in the text element
	}
	/**
	 * 
	 * TC187364
	 */

	@Test 
	public void testGFCWithoutDrugIdentifierType() throws Exception {
		System.out.println("In method 'testInvalidGCFDrugIdentifierType'");
		DrugPointsDoc doc = getDrugPointsResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugPointsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"101296\" TYPE=\"\" />"
				+ "</NewDrugList>"
				+ "</DrugPointsRequest>");
		Assert.assertEquals("1", doc.getErrorListSize());  // Assert.assert error
		Assert.assertTrue(doc.isPhraseInErrorElement("Invalid drug identifier type given: valid values are GFC or NDC."),
				"Invalid drug identifier type given: valid values are GFC or NDC.");  //Assert.assert phrase in the text element
	}
}
