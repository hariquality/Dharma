package com.truven.ids.application.cko.cpsi.testsuite;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.cpsi.pageobjects.DrugPointsDoc;
import com.truven.ids.application.cko.uitest.CPSIBaseTest;

public class TestDrugPoints extends CPSIBaseTest{

	
	@Test 
	public void testDrugPointsRequest() throws Exception {
	   System.out.println("In method 'testDrugPointsRequest'");
	   DrugPointsDoc doc = getDrugPointsResultDoc("drug_points/DrugPointsRequest");
	   Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"DrugPointsResult",
          "Server not connected OR Response is not displayed");
	   Assert.assertTrue(doc.verifyDrugPointsTextContains("Paroxetine Hydrochloride"),"Expected Response is incorrect");
	  }
		
		
}
