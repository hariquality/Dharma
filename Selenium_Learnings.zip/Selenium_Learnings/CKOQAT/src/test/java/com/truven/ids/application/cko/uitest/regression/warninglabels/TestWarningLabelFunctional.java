package com.truven.ids.application.cko.uitest.regression.warninglabels;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.WarningLabelsDoc;

/**
 * Warning Labels Exception tests
 * 
 * @author APeavy
 * 
 */
public class TestWarningLabelFunctional extends CKOBaseTest  {

	/**
	 * TC186824
	 * Verifying request w/o language
	 * 
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testWithoutLanguage() throws Exception {
		WarningLabelsDoc doc = getWarningLabelsDoc("<?xml version=\"1.0\" ?>\r\n" + 
				"<WarningLabelsRequest VERSION=\"1.00\" GRAPHIC_CODE=\"Architext\" >" + 
				"  <Patient />" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"102367\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"</WarningLabelsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDrugListSize(),"1" );
		Assert.assertEquals(doc.getFirstDrugCode(),"102367");
		Assert.assertEquals(doc.getFirstDrugType(),"GFC");
		Assert.assertEquals(doc.getFirstWarningLabelText(),"DRINK PLENTY OF FLUIDS WHILE TAKING THIS MEDICATION");

	}
	
	/**
	 * TC186827
	 * Verifying request w/ NDC
	 * 
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testNDC() throws Exception {
		WarningLabelsDoc doc = getWarningLabelsDoc("<?xml version=\"1.0\" ?>\r\n" + 
				"<WarningLabelsRequest VERSION=\"1.00\" >" + 
				"  <Patient />" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"00026-8514-48\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"</WarningLabelsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDrugListSize(),"1");
		Assert.assertEquals(doc.getFirstWarningLabelsListSize(),"5");
		Assert.assertEquals(doc.getFirstDrugCode(),"00026-8514-48");
		Assert.assertEquals(doc.getFirstDrugType(),"NDC");
		Assert.assertEquals(doc.getFirstWarningLabelText(),"MAY CAUSE DIZZINESS");
		
	}
	
	/**
	 * TC186828
	 * Verifying request w/ GFC
	 * 
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testGFC() throws Exception {
		WarningLabelsDoc doc = getWarningLabelsDoc("<?xml version=\"1.0\" ?>\r\n" + 
				"<WarningLabelsRequest VERSION=\"1.00\" >" + 
				"  <Patient />" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"101296\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"</WarningLabelsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDrugListSize(),"1");
		Assert.assertEquals(doc.getFirstWarningLabelsListSize(),"4");
		Assert.assertEquals(doc.getFirstDrugCode(),"101296");
		Assert.assertEquals(doc.getFirstDrugType(),"GFC");
		Assert.assertEquals(doc.getFirstWarningLabelText(),"THIS DRUG ALONE OR WITH ALCOHOL MAY CAUSE DROWSINESS. USE CARE WHEN DRIVING OR OPERATING MACHINERY.");
		
	}
	
	/**
	 * TC186832 TC186833
	 * Verifying request w/ NDC and English and Spanish
	 * 
	 * PharmexPre-printed labels are the only ones
	 * that come up different between English and Spanish.
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testNDCEnglish() throws Exception {
		// get english
		WarningLabelsDoc doc = getWarningLabelsDoc("<?xml version=\"1.0\" ?>\r\n" + 
				"<WarningLabelsRequest VERSION=\"1.00\" GRAPHIC_CODE=\"PharmexPre-printed\">" + 
				"  <Patient LANGUAGE=\"English\" />" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"00026-8514-48\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"</WarningLabelsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDrugListSize(),"1");
		Assert.assertEquals(doc.getFirstWarningLabelsListSize(),"5");
		Assert.assertEquals(doc.getFirstDrugCode(),"00026-8514-48");
		Assert.assertEquals(doc.getFirstDrugType(),"NDC");
		Assert.assertEquals(doc.getFirstWarningLabelText(),"MAY CAUSE DIZZINESS");
		Assert.assertEquals(doc.getListOfExternalLabelIds(),"1-715|2-X||11-X|5-X|");
		// get spanish
		doc = getWarningLabelsDoc("<?xml version=\"1.0\" ?>\r\n" + 
				"<WarningLabelsRequest VERSION=\"1.00\" GRAPHIC_CODE=\"PharmexPre-printed\">" + 
				"  <Patient LANGUAGE=\"Spanish\" />" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"00026-8514-48\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"</WarningLabelsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDrugListSize(),"1");
		Assert.assertEquals(doc.getFirstWarningLabelsListSize(),"5" );
		Assert.assertEquals(doc.getFirstDrugCode(),"00026-8514-48");
		Assert.assertEquals(doc.getFirstDrugType(),"NDC");
		Assert.assertEquals(doc.getFirstWarningLabelText(),"MAY CAUSE DIZZINESS");
		Assert.assertEquals(doc.getListOfExternalLabelIds(),"1-715|HX-2||HX-11|HX-5|");
		
	}

	/**
	 * TC186834
	 * Verifying request w/ Architext
	 * 
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testArchitext() throws Exception {
		WarningLabelsDoc doc = getWarningLabelsDoc("<?xml version=\"1.0\" ?>\r\n" + 
				"<WarningLabelsRequest VERSION=\"1.00\" GRAPHIC_CODE=\"Architext\">" + 
				"  <Patient />" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"00026-8514-48\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"</WarningLabelsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0" );
		Assert.assertEquals(doc.getDrugListSize(),"1");
		Assert.assertEquals(doc.getFirstWarningLabelsListSize(),"5");
		Assert.assertEquals(doc.getFirstDrugCode(),"00026-8514-48");
		Assert.assertEquals(doc.getFirstDrugType(),"NDC");
		Assert.assertEquals( doc.getFirstWarningLabelText(),"MAY CAUSE DIZZINESS");
		Assert.assertEquals(doc.getListOfExternalLabelIds(),"|108/6c||136/88|196/c4|");
		
	}
	
	/**
	 * TC186835
	 * Verifying request w/ Intercon
	 * 
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testIntercon() throws Exception {
		WarningLabelsDoc doc = getWarningLabelsDoc("<?xml version=\"1.0\" ?>\r\n" + 
				"<WarningLabelsRequest VERSION=\"1.00\" GRAPHIC_CODE=\"Intercon\">" + 
				"  <Patient />" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"00026-8514-48\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"</WarningLabelsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDrugListSize(),"1");
		Assert.assertEquals(doc.getFirstWarningLabelsListSize(),"5");
		Assert.assertEquals(doc.getFirstDrugCode(),"00026-8514-48");
		Assert.assertEquals(doc.getFirstDrugType(),"NDC");
		Assert.assertEquals(doc.getFirstWarningLabelText(),"MAY CAUSE DIZZINESS");
		Assert.assertEquals(doc.getListOfExternalLabelIds(),"217/D9|108/6C|213/D5|136/88|196/C4|");
		
	}
	
	/**
	 * TC186837
	 * Verifying request w/ PharmexPre-printed
	 * 
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testPharmexPrePrinted() throws Exception {
		WarningLabelsDoc doc = getWarningLabelsDoc("<?xml version=\"1.0\" ?>\r\n" + 
				"<WarningLabelsRequest VERSION=\"1.00\" GRAPHIC_CODE=\"PharmexPre-printed\">" + 
				"  <Patient />" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"00026-8514-48\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"</WarningLabelsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDrugListSize(),"1");
		Assert.assertEquals(doc.getFirstWarningLabelsListSize(),"5");
		Assert.assertEquals(doc.getFirstDrugCode(),"00026-8514-48");
		Assert.assertEquals(doc.getFirstDrugType(),"NDC");
		Assert.assertEquals(doc.getFirstWarningLabelText(),"MAY CAUSE DIZZINESS");
		Assert.assertEquals(doc.getListOfExternalLabelIds(),"1-715|2-X||11-X|5-X|");
		
	}
	
	/**
	 * TC186838
	 * Verifying request w/ Multiple drug inputs (NDC and GFC)
	 * 
	 * 
	 * @throws Exception
	 */
	@Test
public void testMultipleDrugs() throws Exception {
		WarningLabelsDoc doc = getWarningLabelsDoc("<?xml version=\"1.0\" ?>\r\n" + 
				"<WarningLabelsRequest VERSION=\"1.00\" >" + 
				"  <Patient />" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"101296\" TYPE=\"GFC\" />" + 
				"    <Drug CODE=\"00026-8514-48\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"</WarningLabelsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDrugListSize(),"2");
		Assert.assertEquals(doc.getListOfDrugCodes(),"101296GFC|00026-8514-48NDC|");
		Assert.assertEquals(doc.getWarningLabelsListSizeForGivenDrugCode("101296"),"4");
		Assert.assertEquals(doc.getWarningLabelsListSizeForGivenDrugCode("00026-8514-48"),"5");
		
	}
	

}
