package com.truven.ids.application.cko.cpsi.testsuite;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.cpsi.pageobjects.IVScreeningDoc;
import com.truven.ids.application.cko.uitest.CPSIBaseTest;

public class TestIVScreening extends CPSIBaseTest{

 
	@Test 
	public void testIVScreeningRequest() throws Exception {
	   System.out.println("In method 'testDrugPointsRequest'");
	   IVScreeningDoc doc = getIVScreeningResultDoc("iv_screening/IVScreeningRequest");
	   Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"IVScreeningResult",
          "Server not connected OR Response is not displayed");
	   Assert.assertTrue(doc.verifyIvScreeningResponseContainsText("Powered by Trissel's"),"Expected Response is incorrect");
	   Assert.assertTrue(doc.verifyIvScreeningResponseContainsText("SUMMARY: PATIENT PROFILE"),"Expected Response is incorrect");
	  }
		
		
}
