package com.truven.ids.application.cko.uitest.local.lookup;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.LookupDoc;

public class TestLookupFuncLocal3 extends CKOBaseTest {

	/**
	 * Verify only the records having country_iso_code as "IT" are returned for
	 * LookupType = 'REGION_LOCALE_MAP' TC349768
	 */

	@Test
	public void testRegionLocalMap() throws Exception {
		System.out.println("In method 'testRegionLocalMap'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGION_LOCALE_MAP'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='country_iso_code' VALUE='IT'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "region|normalized_region|country_iso_code");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("country_iso_code", "IT"),
				"IT is not in country_iso_code field");

	}

	/**
	 * REGION_LOCALE_MAP search using "region " column TC349766
	 */

	@Test
	public void testRegionLocalMap1() throws Exception {
		System.out.println("In method 'testRegionLocalMap1'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGION_LOCALE_MAP'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='region' VALUE='Italy'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "region|normalized_region|country_iso_code");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("region", "Italy"), "Italy is not in region field");

	}

	/**
	 * REGION_LOCALE_MAP search using "normalized_region" column TC349767
	 */

	@Test
	public void testRegionLocalMap2() throws Exception {
		System.out.println("In method 'testRegionLocalMap2'");
		LookupDoc doc = getLookupResultDoc(
				"<?xml version='1.0' encoding='iso-8859-1'?>" + "<LUSRequest LookUpType='REGION_LOCALE_MAP'>"
						+ "<SearchParameterList SIZE='1'>" + "<SearchParameter NAME='normalized_region' VALUE='italy'/>"
						+ "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "region|normalized_region|country_iso_code");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("normalized_region", "italy"),
				"Italy is not in normalized_region field");
	}

	/**
	 * Verify whether all the data of "REGION_LOCALE_MAP" lookup is not displayed on
	 * providing incorrect region TC349818
	 */

	@Test
	public void testRegionLocalMap3() throws Exception {
		System.out.println("In method 'testRegionLocalMap3'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGION_LOCALE_MAP'>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "region|normalized_region|country_iso_code");
		Assert.assertEquals(doc.getLookUpRecordListSize(), "246");
	}

	/**
	 * TC349770---Verify whether the following error message "Invalid Search
	 * Parameter for REGION_LOCALE_MAP" is displayed on providing Invalid Search
	 * Parameter for REGION_LOCALE_MAP lookup
	 * 
	 */

	@Test
	public void testRegionLocalMap4() throws Exception {
		System.out.println("In method 'testRegionLocalMap4'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGION_LOCALE_MAP'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='From' VALUE='Table'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "1");
		Assert.assertEquals(doc.getErrorListErrorText(), "Invalid Search Parameter for REGION_LOCALE_MAP LookUp");
	}

	/**
	 * TC349816 ---- Verify whether the appropriate values based on the request are
	 * getting displayed for "REGION_LOCALE_MAP" lookup on using
	 * SearchParameterItemList and "AND" OPERATOR
	 * 
	 */

	@Test
	public void testRegionLocalMap5() throws Exception {
		System.out.println("In method 'testRegionLocalMap5'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGION_LOCALE_MAP'>" + "<SearchParameterList SIZE='4' OPERATOR='AND'>"
				+ "<SearchParameter NAME='region' VALUE='Spain'/>"
				+ "<SearchParameter NAME='normalized_region' VALUE='spain'/>"
				+ "<SearchParameter NAME='country_iso_code' VALUE='ES'/>" + "<SearchParameterItemList>"
				+ "<Item NAME='region' VALUE='Spain'/>" + "<Item NAME='normalized_region' VALUE='spain'/>"
				+ "<Item NAME='country_iso_code' VALUE='ES'/>" + "</SearchParameterItemList>" + "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "region|normalized_region|country_iso_code");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("country_iso_code", "ES"),
				"Spain is not in country_iso_code field");
	}

	/**
	 * TC349817(Need to implemented function) ---- Verify whether the appropriate
	 * values based on the request are getting displayed for "REGION_LOCALE_MAP"
	 * lookup on using SearchParameterItemList and "OR" OPERATOR *
	 */

	@Test
	public void testRegionLocalMap6() throws Exception {
		System.out.println("In method 'testRegionLocalMap6'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGION_LOCALE_MAP'>" + "<SearchParameterList SIZE='4' OPERATOR='OR'>"
				+ "<SearchParameter NAME='region' VALUE='Spain'/>"
				+ "<SearchParameter NAME='normalized_region' VALUE='belgium'/>"
				+ "<SearchParameter NAME='country_iso_code' VALUE='TH'/>" + "<SearchParameterItemList>"
				+ "<Item NAME='region' VALUE='Italy'/>" + "<Item NAME='normalized_region' VALUE='italy'/>"
				+ "<Item NAME='country_iso_code' VALUE='IT'/>" + "</SearchParameterItemList>" + "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "region|normalized_region|country_iso_code");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("region", "Spain"), "Spain is not in Region field");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("normalized_region", "belgium"),
				"belgium is not in normalized_region field");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("country_iso_code", "TH"),
				"TH is not in country_iso_code field");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("region", "Italy"), "Italy is not in Region field");

	}

	/**
	 * TC349815 ---- Verify whether the appropriate values based on the request are
	 * getting displayed for "REGION_LOCALE_MAP" lookup on using "OR" OPERATOR*
	 */

	@Test
	public void testRegionLocalMap7() throws Exception {
		System.out.println("In method 'testRegionLocalMap7'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGION_LOCALE_MAP'>" + "<SearchParameterList SIZE='3' OPERATOR='OR'>"
				+ "<SearchParameter NAME='region' VALUE='Italy'/>"
				+ "<SearchParameter NAME='normalized_region' VALUE='germany'/>"
				+ "<SearchParameter NAME='country_iso_code' VALUE='ES'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "region|normalized_region|country_iso_code");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("region", "Italy"), "Italy is not in Region field");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("normalized_region", "germany"),
				"germany is not in normalized_region field");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("country_iso_code", "ES"),
				"ES is not in country_iso_code field");

	}

	/**
	 * TC349814 ---- Verify whether the appropriate values based on the request are
	 * getting displayed for "REGION_LOCALE_MAP" lookup on using "AND" OPERATOR
	 */

	@Test
	public void testRegionLocalMap8() throws Exception {
		System.out.println("In method 'testRegionLocalMap8'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGION_LOCALE_MAP'>" + "<SearchParameterList SIZE='4' OPERATOR='AND'>"
				+ "<SearchParameter NAME='region' VALUE='Spain'/>"
				+ "<SearchParameter NAME='normalized_region' VALUE='spain'/>"
				+ "<SearchParameter NAME='country_iso_code' VALUE='ES'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "region|normalized_region|country_iso_code");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("region", "Spain"), "Spain is not in Region field");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("normalized_region", "spain"),
				"spain is not in normalized_region field");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("country_iso_code", "ES"),
				"ES is not in country_iso_code field");

	}

}
