package com.truven.ids.application.cko.uitest.regression.physiology;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.PhysiologyDoc;

/**
 * 
 * 
 * @author BHreen
 * 
 */
public class TestPhysiologyException extends CKOBaseTest  {

	/*
	 * PHYS001.xml 14620 days = 40 year old
	 * 
	 */

	@Test public void testInvalidType() throws Exception {
		System.out.println("In method 'testInvalidType'");
		PhysiologyDoc doc = getPhysiologyResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>" +
				"<PhysiologyCalculatorRequest TYPE='ASDF'>" +
				"<Patient GENDER='Male' " +   
				" AGE_IN_DAYS='6570'" +   
				" WEIGHT='21' HEIGHT='108'/>" +
				"</PhysiologyCalculatorRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1");
		Assert.assertTrue(doc.isPhraseInErrorElement("Invalid Patient Physiology Calculator Type: Valid Values are ALL, BSA, LBM, or IBW."),"'Invalid Patient Physiology Calculator Type: Valid Values are ALL, BSA, LBM, or IBW.' not found in message element");

	}

	/*
	 * PHYS006.xml 14620 days = 40 year old
	 * 
	 */

	@Test public void testMissingType() throws Exception {
		System.out.println("In method 'testMissingType'");
		PhysiologyDoc doc = getPhysiologyResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>" +
				"<PhysiologyCalculatorRequest TYPE=''>" +
				"<Patient GENDER='Male' " +        
				" AGE_IN_DAYS='6570'" +   
				" WEIGHT='21' HEIGHT='108'/>" +
				"</PhysiologyCalculatorRequest>");
		System.out.println("testMissingType doc:" + doc.toString());
		Assert.assertEquals(doc.getErrorListSize(),"1");
		Assert.assertTrue(doc.isPhraseInErrorElement("Invalid Patient Physiology Calculator Type: Valid Values are ALL, BSA, LBM, or IBW."),"Invalid Patient Physiology Calculator Type: Valid Values are ALL, BSA, LBM, or IBW.'not found in message element");

	}



}
