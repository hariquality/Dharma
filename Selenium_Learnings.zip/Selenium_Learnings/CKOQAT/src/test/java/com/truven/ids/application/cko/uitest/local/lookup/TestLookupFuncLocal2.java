package com.truven.ids.application.cko.uitest.local.lookup;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.LookupDoc;

public class TestLookupFuncLocal2 extends CKOBaseTest {

	/*
	 * 
	 * TC349762 GNGCRRT_LOCAL search using "GCRCode" column
	 */
	@Test
	public void testGngcrrtLocalGcrId() throws Exception {
		System.out.println("In method 'testGngcrrtLocalGcrId'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GNGCRRT_LOCAL' REGION='IT'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='GCRCode' VALUE='932874'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "GCRName|RouteName|GCRCode|RouteCode|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("GCRCode", "932874"),
				"932874 is not in GCRCode field");

	}

	/*
	 * 
	 * TC349761 GNGCRRT_LOCAL search using ""RouteName "" column
	 */
	@Test
	public void testGNGCRRTLocalRouteName() throws Exception {
		System.out.println("In method 'testGNGCRRTLocalRouteName'");
		LookupDoc doc = getLookupResultDoc(
				"<?xml version='1.0' encoding='iso-8859-1'?>" + "<LUSRequest LookUpType='GNGCRRT_LOCAL' REGION='ES'>"
						+ "<SearchParameterList SIZE='1'>" + "<SearchParameter NAME='RouteName' VALUE='Intravenous'/>"
						+ "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "GCRName|RouteName|GCRCode|RouteCode|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("RouteName", "Intravenous"),
				"Intravenous is not in RouteName field");

	}

	/*
	 * 
	 * TC349763 GNGCRRT_LOCAL search using ""RouteCode"" column
	 */
	@Test
	public void testGNGCRRTLocalRouteid() throws Exception {
		System.out.println("In method 'testGNGCRRTLocalRouteid'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GNGCRRT_LOCAL' REGION='ES'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='RouteCode' VALUE='214000'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "GCRName|RouteName|GCRCode|RouteCode|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("RouteCode", "214000"),
				"214000 is not in RouteCode field");

	}

	/*
	 * 
	 * TC349760 GNGCRRT_LOCAL search using ""gcrname "" column
	 */

	@Test
	public void testGNGCRRTLocalGCR() throws Exception {
		System.out.println("In method 'testGNGCRRTLocalGCR'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GNGCRRT_LOCAL' REGION='IT'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='GCRName' VALUE='damoctocog alfa pegol'/>" + "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "GCRName|RouteName|GCRCode|RouteCode|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("GCRName", "damoctocog alfa pegol"),
				"damoctocog alfa pegol is not in GCRName field");

	}

	/*
	 * 
	 * TC349769 GNGCRRT_LOCAL selected region content
	 */

	@Test
	public void testGNGCRRTLocal() throws Exception {
		System.out.println("In method 'testGNGCRRTLocal'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GNGCRRT_LOCAL' REGION='IT'>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "GCRName|RouteName|GCRCode|RouteCode|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldTextRegion("region", "IT"));
	}

	/*
	 * #TC349800 Verify whether Local and US Content are getting displayed for
	 * ""GNGCRRT_LOCAL"" lookup for the following search parameters using ""AND""
	 * Operator.
	 */

	@Test
	public void testGngcrrtLocalWithAND() throws Exception {
		System.out.println("In method 'testGngcrrtLocalWithAND'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GNGCRRT_LOCAL' REGION='ES'>"
				+ "<SearchParameterList SIZE='5' OPERATOR='AND'>" + "<SearchParameter NAME='RouteCode' VALUE='116010'/>"
				+ "<SearchParameter NAME='RouteName' VALUE='Intravenous'/>" + "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "GCRName|RouteName|GCRCode|RouteCode|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("RouteCode", "116010"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("RouteName", "Intravenous"));

	}

	/*
	 * #TC349799 Verify whether Local and US Content are getting displayed for
	 * ""GNGCRRT_LOCAL"" lookup for the following search parameters using ""OR""
	 * Operator.
	 */

	@Test
	public void testGngcrrtLocalWithOR() throws Exception {
		System.out.println("In method 'testGngcrrtLocalWithOR'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GNGCRRT_LOCAL' REGION='ES'>" + "<SearchParameterList SIZE='5' OPERATOR='OR'>"
				+ "<SearchParameter NAME='RouteCode' VALUE='116010'/>"
				+ "<SearchParameter NAME='RouteName' VALUE='Intravenous'/>" + "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "GCRName|RouteName|GCRCode|RouteCode|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("RouteCode", "116010"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("RouteName", "Intravenous"));

	}

	/*
	 * #TC349803 Verify whether the Local and US Content are not getting displayed
	 * on providing incorrect region for GNGCRRT_LOCAL lookup
	 */

	@Test
	public void testGngcrrtLocalWithInvalidRegion() throws Exception {
		System.out.println("In method 'testGngcrrtLocalWithInvalidRegion'");
		LookupDoc doc = getLookupResultDoc(
				"<?xml version='1.0' encoding='iso-8859-1'?>" + "<LUSRequest LookUpType='GNGCRRT_LOCAL' REGION='SS'>"
						+ "<SearchParameterList SIZE='5'>" + "<SearchParameter NAME='RouteCode' VALUE='116010'/>"
						+ "<SearchParameter NAME='RouteName' VALUE='Intravenous'/>" + "</SearchParameterList>"
						+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "1");
		Assert.assertEquals(doc.getErrorListErrorText(), "Invalid LookUp Type or REGION for Category");

	}

	/*
	 * #TC349765 Verify whether the following error message ""Invalid Search
	 * Parameter for GNGCRRT_LOCAL LookUp"" is displayed on providing Invalid Search
	 * Parameter for GNGCRRT_LOCAL lookup
	 */

	@Test
	public void testGngcrrtLocalWithInvalidParameter() throws Exception {
		System.out.println("In method 'testGngcrrtLocalWithInvalidParameter'");
		LookupDoc doc = getLookupResultDoc(
				"<?xml version='1.0' encoding='iso-8859-1'?>" + "<LUSRequest LookUpType='GNGCRRT_LOCAL' REGION='ES'>"
						+ "<SearchParameterList SIZE='5'>" + "<SearchParameter NAME='ABC' VALUE='XYZ'/>"
						+ "<SearchParameter NAME='RouteName' VALUE='Intravenous'/>" + "</SearchParameterList>"
						+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "1");
		Assert.assertEquals(doc.getErrorListErrorText(), "Invalid Search Parameter for GNGCRRT_LOCAL LookUp");

	}

	/*
	 * #TC349801,#TC349802 Verify whether Local and US Content are getting displayed
	 * for ""GNGCRRT_LOCAL"" lookup on search using search parameter item list and
	 * ""AND"" Operator
	 */

	@Test
	public void testGngcrrtLocalWithItemlistAND() throws Exception {
		System.out.println("In method 'testGngcrrtLocalWithItemlistAND'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GNGCRRT_LOCAL' REGION='ES'>"
				+ "<SearchParameterList SIZE='7' OPERATOR='AND'>" + "<SearchParameter NAME='region' VALUE='ES'/>"
				+ "<SearchParameterItemList>" + "<Item NAME='RouteCode' VALUE='111000'/>"
				+ "<Item NAME='RouteName' VALUE='Oral (systemic)'/>" + "</SearchParameterItemList>"
				+ "<SearchParameterItemList>" + "<Item NAME='GCRName' VALUE='acetylcysteine'/>"
				+ "<Item NAME='GCRCode' VALUE='4590'/>" + "</SearchParameterItemList>" + "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "GCRName|RouteName|GCRCode|RouteCode|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("region", "ES"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("RouteName", "Oral (systemic)"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("GCRCode", "4590"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("GCRName", "acetylcysteine"));

	}

	/*
	 * #TC349797 Verify whether the Local and US Content are getting displayed on
	 * providing incorrect region for GNGCRRT lookup
	 */

	@Test
	public void testGngcrrtWithInvalidRegion() throws Exception {
		System.out.println("In method 'testGngcrrtWithInvalidRegion'");
		LookupDoc doc = getLookupResultDoc(
				"<?xml version='1.0' encoding='iso-8859-1'?>" + "<LUSRequest LookUpType='GNGCRRT' REGION='SS'>"
						+ "<SearchParameterList SIZE='5'>" + "<SearchParameter NAME='RouteCode' VALUE='116010'/>"
						+ "<SearchParameter NAME='RouteName' VALUE='Intravenous'/>" + "</SearchParameterList>"
						+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("RouteName", "Intravenous"));

	}

	/*
	 * #TC349796,#TC349792 Verify whether the Local and US Content are getting
	 * displayed on providing region for GNGCRRT lookup
	 */

	@Test
	public void testGngcrrtWithRegion() throws Exception {
		System.out.println("In method 'testGngcrrtWithRegion'");
		LookupDoc doc = getLookupResultDoc(
				"<?xml version='1.0' encoding='iso-8859-1'?>" + "<LUSRequest LookUpType='GNGCRRT' REGION='ES'>"
						+ "<SearchParameterList SIZE='5'>" + "<SearchParameter NAME='RouteCode' VALUE='116010'/>"
						+ "<SearchParameter NAME='RouteName' VALUE='Intravenous'/>" + "</SearchParameterList>"
						+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertFalse(doc.verifyLookUpRecordsByFieldStartsWith("region", "ES"),
				"No Local content available; US data only availabale");

	}
	/*
	 * #TC349791,#TC349790,#TC349794 Verify whether US Content alone getting
	 * displayed for ""GNGCRRT"" lookup on search using search parameter,parameter
	 * item list
	 */

	@Test
	public void testGngcrrtWithItemlist() throws Exception {
		System.out.println("In method 'testGngcrrtWithItemlist'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GNGCRRT' REGION='ES'>" + "<SearchParameterList SIZE='7' OPERATOR='AND'>"
				+ "<SearchParameter NAME='GCRName' VALUE='Technetium Tc 99m'/>" + "<SearchParameterItemList>"
				+ "<Item NAME='RouteCode' VALUE='116010'/>" + "<Item NAME='RouteName' VALUE='Intravenous'/>"
				+ "</SearchParameterItemList>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "GCRName|RouteName|GCRCode|RouteCode");
		Assert.assertEquals(doc.getLookUpRecordListSize(), "21");
		Assert.assertFalse(doc.verifyLookUpRecordsByFieldStartsWith("region", "ES"),
				"No Local content available; US data only availabale");
	}

	/*
	 * TC349828 Verify whether all the records displayed for REGISTRYCODE_GFC_LOCAL
	 * only lookup.
	 */
	@Test
	public void testRegistrycodeGfcLocal() throws Exception {
		System.out.println("In method 'testRegistrycodeGfcLocal'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGISTRYCODE_GFC_LOCAL' REGION='ES'>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "registry_type|registry_code|ndc|gfc|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("registry_type", "NC"));
	}

	/*
	 * TC349829 Verify whether all the records displayed for REGISTRYCODE_GFC_LOCAL
	 * only lookup with Invalid Region.
	 */
	@Test
	public void testRegistrycodeGfcLocalWithInvalidRegion() throws Exception {
		System.out.println("In method 'testRegistrycodeGfcLocalWithInvalidRegion'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGISTRYCODE_GFC_LOCAL' REGION='ZS'>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "1");
		Assert.assertEquals(doc.getErrorListErrorText(), "Invalid LookUp Type or REGION for Category");
	}

	/*
	 * TC349825 TC349827 Verify whether local user able to view local and US lookup
	 * Records
	 */
	@Test
	public void testRegistrycodeGfcLocalContentValidation() throws Exception {
		System.out.println("In method 'testRegistrycodeGfcLocalContentValidation'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGISTRYCODE_GFC_LOCAL' REGION='ES'>"
				+ "<SearchParameterList SIZE='5' OPERATOR='OR'>" + "<SearchParameter NAME='gfc' VALUE='135368'/>"
				+ "<SearchParameter NAME='ndc' VALUE='00009-0844-01'/>" + "<SearchParameterItemList>"
				+ "<Item NAME='registry_type' VALUE='NC'/>" + "<Item NAME='registry_code' VALUE='607122'/>"
				+ "</SearchParameterItemList>" + "<SearchParameterItemList>"
				+ "<Item NAME='registry_type' VALUE='NC'/>" + "<Item NAME='registry_code' VALUE='607227'/>"
				+ "</SearchParameterItemList>" + "</SearchParameterList>" + "</LUSRequest>");
		System.out.println(doc);
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "registry_type|registry_code|ndc|gfc|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("ndc", "00009-0844-01"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("registry_type", "NC"));
	}

	/*
	 * TC349830 "Invalid LookUp Type/Region for Category"" is displayed for
	 * REGISTRYCODE_GFC_LOCAL request with multiple items
	 */
	@Test
	public void testRegistrycodeGfcLocalInvalidRegion() throws Exception {
		System.out.println("In method 'testRegistrycodeGfcLocalInvalidRegion'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGISTRYCODE_GFC_LOCAL' REGION='SS'>" + "<SearchParameterList SIZE='5'>"
				+ "<SearchParameterItemList>" + "<Item NAME='registry_type' VALUE='NC'/>"
				+ "<Item NAME='registry_code' VALUE='72653'/>" + "</SearchParameterItemList>" + "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "1");
		Assert.assertEquals(doc.getErrorListErrorText(), "Invalid LookUp Type or REGION for Category");
	}

	/*
	 * TC349836 Verify whether local user able to view local and US lookup Records
	 * with AND
	 */
	@Test
	public void testRegistrycodeGfcLocalAND() throws Exception {
		System.out.println("In method 'testRegistrycodeGfcLocalAND'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGISTRYCODE_GFC_LOCAL' REGION='ES'>"
				+ "<SearchParameterList SIZE='5' OPERATOR='AND'>" + "<SearchParameter NAME='gfc' VALUE='135675'/>"
				+ "<SearchParameterItemList>" + "<Item NAME='registry_type' VALUE='NC'/>"
				+ "<Item NAME='registry_code' VALUE='607148'/>" + "</SearchParameterItemList>" + "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "registry_type|registry_code|ndc|gfc|region");
		Assert.assertEquals(doc.getLookUpRecordListSize(), "1");
	}

	/* TC349826 Verify whether Invalid Search Parameter error displays */
	@Test
	public void testRegistrycodeGfcLocalInvalidSearch() throws Exception {
		System.out.println("In method 'testRegistrycodeGfcLocalInvalidSearch'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='REGISTRYCODE_GFC_LOCAL' REGION='ES'>"
				+ "<SearchParameterList SIZE='5' OPERATOR='AND'>" + "<SearchParameter NAME='ABC' VALUE='XYZ'/>"
				+ "<SearchParameterItemList>" + "<Item NAME='registry_type' VALUE='AIC'/>"
				+ "<Item NAME='registry_code' VALUE='84721'/>" + "</SearchParameterItemList>" + "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "1");
		Assert.assertEquals(doc.getErrorListErrorText(), "Invalid Search Parameter for REGISTRYCODE_GFC_LOCAL LookUp");
	}

}