package com.truven.ids.application.cko.cpsi.pageobjects;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class LookUpDoc extends CPSIBaseDoc{

	
	
	public LookUpDoc(JSONObject jsonObject) {
		super(jsonObject);
	}

	public String getLookUpRecordListSize() {
		return jo.getJSONObject("Response").getString("SIZE");
				
	}
	
	public Boolean verifyLookUpRecords(String expectedValue) {
	   JSONArray lookUpRecords = jo.getJSONObject("Response").
	         getJSONArray("LookUpRecordList");
	   
	   
	   // iterate through all returned records
	   
	   for (int i = 0; i < lookUpRecords.length(); i++ ) {
	    JSONObject jo1 = (JSONObject)lookUpRecords.get(i);
	    // split record
//	    String[] recordData = record.split("[|]");
	    
	    String recordData = jo1.getString("LookUpRecord");
	    if (recordData.contains(expectedValue)) {
	       return true;
	    }
	   }
	   return false;
	  }
	
	public Boolean verifyLookUpRecordsList(String[] expectedValue, boolean compareFullContent) {
	   
	   List<String> lookUpRecordList =new ArrayList<>();
    JSONArray lookUpRecords = jo.getJSONObject("Response").getJSONArray("LookUpRecordList");
    // iterate through all returned records
    for (int i = 0; i < lookUpRecords.length(); i++ ) {
     JSONObject jo1 = (JSONObject)lookUpRecords.get(i);
     lookUpRecordList.add(jo1.getString("LookUpRecord"));}
     if (compareFullContent){
    	 if(lookUpRecordList.equals(Arrays.asList(expectedValue))) {
    		 return true;
     }
    	 else{
    		 if(lookUpRecordList.contains(Arrays.asList(expectedValue))){
    			 return true; 
    		 }
    	 }
        
     }
    return false;
   }
	
	
	
	
}
