package com.truven.ids.application.cko.uitest.local.lookup;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.LookupDoc;

public class TestLookupFuncLocal extends CKOBaseTest {

	/*
	 * TC349837 Verify whether user able to filter lookup records which trade_name
	 * starting with DINAXIL
	 */
	@Test
	public void testTradeName() throws Exception {

		System.out.println("In method 'testTradeName'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME_LOCAL' REGION='IT'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='trade_name' VALUE='DINAXIL'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),
				"trade_name|route|form|strength|ndc|registry_type|registry_code|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("trade_name", "DINAXIL"),
				"DINAXIL is not in trade name field");
	}

	/*
	 * TC349838 Verify whether user able to filter lookup records which route value
	 * is Injection (systemic)
	 */
	@Test
	public void testTradeNameRoute() throws Exception {
		System.out.println("In method 'testTradeNameRoute'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME_LOCAL' REGION='IT'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='route' VALUE='Injection (systemic)'/>" + "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),
				"trade_name|route|form|strength|ndc|registry_type|registry_code|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("route", "Injection (systemic)"),
				"Injection (systemic) is not in route field");
	}

	/*
	 * TC349839 Verify whether user able to filter lookup records which form value is TABLET
	 */
	@Test
	public void testTradeNameForm() throws Exception {
		System.out.println("In method 'testTradeNameForm'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME_LOCAL' REGION='IT'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='form' VALUE='TABLET'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),
				"trade_name|route|form|strength|ndc|registry_type|registry_code|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("form", "TABLET"), "IMPLANT is not in form field");
	}

	/*
	 * TC349840 Verify whether user able to filter lookup records which form
	 * strength is 75 MG"
	 */
	@Test
	public void testTradeNameStength() throws Exception {
		System.out.println("In method 'testTradeNameStength'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME_LOCAL' REGION='ES'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='strength' VALUE='75 MG'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),
				"trade_name|route|form|strength|ndc|registry_type|registry_code|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("strength", "75 MG"),
				"75 MG is not in strength field");
	}

	/*
	 * TC349840 Verify whether user able to filter lookup records which ndc value is
	 * 00083-0188-37
	 */
	@Test
	public void testTradeNameNDC() throws Exception {
		System.out.println("In method 'testTradeNameNDC'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME_LOCAL' REGION='IT'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='ndc' VALUE='00083-0188-37'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),
				"trade_name|route|form|strength|ndc|registry_type|registry_code|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("ndc", "00083-0188-37"),
				"00083-0188-37 is not in ndc field00083-0188-37");

	}

	/*
	 * TC349842 Verify whether user able to filter lookup records which
	 * registry_type value is AIC
	 */

	@Test
	public void testTradeNameRegistryType() throws Exception {
		System.out.println("In method 'testTradeNameRegistryType'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME_LOCAL' REGION='ES'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='registry_type' VALUE='AIC'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),
				"trade_name|route|form|strength|ndc|registry_type|registry_code|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("registry_type", "AIC"),
				"AIC is not in registry_type field");
	}

	/*
	 * TC349842 Verify whether user able to filter lookup records which
	 * registry_code value is Italy - 123
	 */

	@Test
	public void testTradeNameRegistryCode() throws Exception {
		System.out.println("In method 'testTradeNameRegistryCode'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME_LOCAL' REGION='IT'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='registry_code' VALUE='Italy - 123'/>" + "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),
				"trade_name|route|form|strength|ndc|registry_type|registry_code|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("registry_code", "Italy - 123"),
				"Italy - 123 is not in registry_code field");
	}

	/*
	 * TC349849 Verify whether local user able to view local and US lookup Records
	 */
	@Test
	public void testLocalAndUSContent() throws Exception {
		System.out.println("In method 'testLocalAndUSContent'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME_LOCAL' REGION='ES'>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),
				"trade_name|route|form|strength|ndc|registry_type|registry_code|region");
	}

	/*
	 * TC349845 Verify whether Invalid Search Parameter error displays
	 */
	@Test
	public void testInvalidSearchParamenter() throws Exception {
		System.out.println("In method 'testInvalidSearchParamenterForLanguage'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME_LOCAL' REGION='IT'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='ABC' VALUE='XYZ'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "1");
		Assert.assertEquals(doc.getErrorListErrorText(), "Invalid Search Parameter for TRADE_NAME_LOCAL LookUp");
	}

	/*
	 * TC349849 Verify whether user able to filter TRADE_NAME_LOCAL only lookup with
	 * Region
	 */

	@Test
	public void testTradenameLocallookupWithoutParameter() throws Exception {
		System.out.println("In method 'testTradenameLocallookupWithoutParameter'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME_LOCAL' REGION='ES'>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),
				"trade_name|route|form|strength|ndc|registry_type|registry_code|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("trade_name", "AZILECT"),
				"AZILECT is not in trade name field");
	}

	/*
	 * TC349848 Verify whether user able to filter Trade_NAME lookup records with OR
	 * Operator
	 */

	@Test
	public void testTradenameWithOR() throws Exception {
		System.out.println("In method 'testTradenameWithOR'");
		LookupDoc doc = getLookupResultDoc(
				"<?xml version='1.0' encoding='iso-8859-1'?>" + "<LUSRequest LookUpType='TRADE_NAME_LOCAL' REGION='ES'>"
						+ "<SearchParameterList SIZE='5' OPERATOR='OR'>"
						+ "<SearchParameter NAME='trade_name' VALUE='AZILECT'/>"
						+ "<SearchParameter NAME='form' VALUE='TABLET'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),
				"trade_name|route|form|strength|ndc|registry_type|registry_code|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("trade_name", "AZILECT"),
				"AZILECT is not in trade name field");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("form", "TABLET"), "TABLET is not in form field");
	}

	/*
	 * TC349853 Verify whether user able to filter Trade_NAME lookup records with
	 * AND Operator
	 */

	@Test
	public void testTradenameWithAND() throws Exception {
		System.out.println("In method 'testTradenameWithAND'");
		LookupDoc doc = getLookupResultDoc(
				"<?xml version='1.0' encoding='iso-8859-1'?>" + "<LUSRequest LookUpType='TRADE_NAME_LOCAL' REGION='ES'>"
						+ "<SearchParameterList SIZE='5' OPERATOR='AND'>"
						+ "<SearchParameter NAME='trade_name' VALUE='AZILECT'/>"
						+ "<SearchParameter NAME='form' VALUE='TABLET'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),
				"trade_name|route|form|strength|ndc|registry_type|registry_code|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("trade_name", "AZILECT"),
				"AZILECT is not in trade name field");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("form", "TABLET"), "TABLET is not in form field");
		Assert.assertEquals(doc.getLookUpRecordListSize(), "5");
	}

	/*
	 * TC349827 Verify whether user able to filter Trade_NAME_LOCAL lookup records
	 * with multiple parameter
	 */
	@Test
	public void testTradenameLocalWithMultipleparameter() throws Exception {
		System.out.println("In method 'testTradenameWithMultipleparameter'");
		LookupDoc doc = getLookupResultDoc(
				"<?xml version='1.0' encoding='iso-8859-1'?>" + "<LUSRequest LookUpType='TRADE_NAME_LOCAL' REGION='ES'>"
						+ "<SearchParameterList SIZE='5'>" + "<SearchParameter NAME='trade_name' VALUE='BLASTON'/>"
						+ "<SearchParameter NAME='registry_type' VALUE='NC'/>"
						+ "<SearchParameter NAME='registry_code' VALUE='725118'/>" + "</SearchParameterList>"
						+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),
				"trade_name|route|form|strength|ndc|registry_type|registry_code|region");
		// Assert.assertEquals (doc.getLookUpRecordListSize(),"48");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldTextRegion("registry_type", "NC"));
	}

	/*
	 * Verify whether user able to filter Trade_NAME_LOCAL lookup records with
	 * multiple Items
	 */
	@Test
	public void testTradenameLocalWithMultipleItems() throws Exception {
		System.out.println("In method 'testTradenameLocalWithMultipleItems'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME_LOCAL' REGION='ES'>" + "<SearchParameterList SIZE='5'>"
				+ "<SearchParameter NAME='trade_name' VALUE='AZILECT'/>" + "<SearchParameterItemList>"
				+ "<Item NAME='strength' VALUE='75 MG'/>" + "<Item NAME='trade_name' VALUE='CLOPIDOGREL TEVA'/>"
				+ "</SearchParameterItemList>" + "<SearchParameterItemList>" + "<Item NAME='registry_type' VALUE='NC'/>"
				+ "<Item NAME='registry_code' VALUE='725118'/>" + "</SearchParameterItemList>"
				+ "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),
				"trade_name|route|form|strength|ndc|registry_type|registry_code|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("trade_name", "AZILECT"),
				"AZILECT is not in trade name field");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("strength", "75 MG"), "75 MG is not in strength field");

	}

	/*
	 * TC349852 Verify whether user able to filter TRADE_NAME_LOCAL only lookup with
	 * invalid Region
	 */

	@Test
	public void testTradenameWithInvalidRegion() throws Exception {
		System.out.println("In method 'testTradenameWithInvalidRegion'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME_LOCAL' REGION='SS'>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "1");
		Assert.assertEquals(doc.getErrorListErrorText(), "Invalid LookUp Type or REGION for Category");

	}

	/*
	 * TC349846 Verify whether user able to filter Trade_NAME lookup records with
	 * multiple parameter
	 */

	@Test
	public void testTradenameWithMultipleparameter() throws Exception {
		System.out.println("In method 'testTradenameWithMultipleparameter'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME'>" + "<SearchParameterList SIZE='5'>"
				+ "<SearchParameter NAME='trade_name' VALUE='BLASTON'/>"
				+ "<SearchParameter NAME='strength' VALUE='25 MG'/>"
				+ "<SearchParameter NAME='trade_name' VALUE='ACARBOSE'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "trade_name|route|form|strength|ndc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("trade_name", "ACARBOSE"));

	}

	/*
	 * TC349847 Verify whether user able to filter Trade_NAME_LOCAL lookup records
	 * with multiple Items
	 */
	@Test
	public void testTradenameWithMultipleItems() throws Exception {
		System.out.println("In method 'testTradenameWithMultipleItems'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME'>" + "<SearchParameterList SIZE='5'>"
				+ "<SearchParameter NAME='trade_name' VALUE='ACARBOSE'/>" + "<SearchParameterItemList>"
				+ "<Item NAME='strength' VALUE='20 MG'/>" + "<Item NAME='ndc' VALUE='51927-4830-00'/>"
				+ "</SearchParameterItemList>" + "<SearchParameterItemList>"
				+ "<Item NAME='route' VALUE='Oral (systemic)'/>" + "<Item NAME='form' VALUE='SOLUTION'/>"
				+ "</SearchParameterItemList>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "trade_name|route|form|strength|ndc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("trade_name", "ACARBOSE"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("route", "Oral (systemic)"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("form", "SOLUTION"));
	}

	/* 18 Verify whether all records displayed for Trade_NAME lookup */
	@Test
	public void testTradename() throws Exception {
		System.out.println("In method 'testTradename'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME'>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("trade_name", "ACARBOSE"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("route", "Oral (systemic)"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("form", "SOLUTION"));
	}

	/*
	 * 18 Verify whether all records displayed for Trade_NAME_Local lookup for
	 * selected region
	 */
	@Test
	public void testTradenameLocalwithRegion() throws Exception {
		System.out.println("In method 'testTradenameLocalwithRegion'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME_LOCAL' REGION='ES'>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),
				"trade_name|route|form|strength|ndc|registry_type|registry_code|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("trade_name", "AZILECT"),
				"AZILECT is not in trade name field");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("route", "Oral (systemic)"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("form", "SOLUTION"));
	}

	/*
	 * 19 Verify whether all domestic records displayed for Trade_NAME lookup with
	 * Region
	 */
	@Test
	public void testTradenamewithRegion() throws Exception {
		System.out.println("In method 'testTradenamewithRegion'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME' REGION='ES'>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("trade_name", "ACARBOSE"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("route", "Oral (systemic)"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("form", "SOLUTION"));
	}

	/*
	 * TC349756 #20 Verify whether the appropriate error message ""Invalid LookUp
	 * Type/Region for Category"" is displayed for TRADE_NAME_LOCAL lookup with
	 * multiple items
	 */
	@Test
	public void testTradenameMultipleItemsWithInvalidRegion() throws Exception {
		System.out.println("In method 'testTradenameMultipleItemsWithInvalidRegion'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME_LOCAL' REGION='QQ'>" + "<SearchParameterList SIZE='5'>"
				+ "<SearchParameter NAME='trade_name' VALUE='BLASTON'/>" + "<SearchParameterItemList>"
				+ "<Item NAME='strength' VALUE='20 MG'/>" + "<Item NAME='ndc' VALUE='51927-4830-00'/>"
				+ "</SearchParameterItemList>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "1");
		Assert.assertEquals(doc.getErrorListErrorText(), "Invalid LookUp Type or REGION for Category");
	}

	/*
	 * 
	 * TC349750 GENERIC_NAME_LOCAL search using ""gfc"" column
	 */

	@Test
	public void testGenericNameLocalGFC() throws Exception {
		System.out.println("In method 'testGenericNameLocalGFC'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME_LOCAL' REGION='ES'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='gfc' VALUE='135686'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "generic_name|route_name|form|strength|gfc|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("gfc", "135686"),
				"135686 is not in generic_name field");
	}

	/*
	 * TC349753 Verify whether all the local and US content are displayed for
	 * Generic_Name_lookUp
	 */
	@Test
	public void testGenericNameLocal() throws Exception {
		System.out.println("In method 'testGenericNameLocalGFC'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME_LOCAL' REGION='ES'>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "generic_name|route_name|form|strength|gfc|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldTextRegion("region", "ES"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("generic_name",
				"1,1,1,3,3-PENTAFLUOROPROPANE/NORFLURANE;BETAMETHASONE ACETATE/BETAMETHASONE SODIUM PHOSPHATE;ISOPROPYL ALCOHOL;POVIDONE IODINE"),
				"test");
	}

	/*
	 * #TC349784 Verify whether Local and US Content are getting displayed for
	 * ""GENERIC_NAME_LOCAL"" lookup for the following search parameters using
	 * ""OR"" Operator.
	 */

	@Test
	public void testGenericnameWithMultipleparameter() throws Exception {
		System.out.println("In method 'testGenericnameWithMultipleparameter'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME_LOCAL' REGION='ES'>" + "<SearchParameterList SIZE='5'>"
				+ "<SearchParameter NAME='generic_name' VALUE='DAMOCTOCOG ALFA PEGOL'/>"
				+ "<SearchParameter NAME='strength' VALUE='25 MG'/>"
				+ "<SearchParameter NAME='route_name' VALUE='Epidural'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "generic_name|route_name|form|strength|gfc|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("strength", "25 MG"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("route_name", "Epidural"));
	}

	/*
	 * TC349786 Verify whether Local and US Content are getting displayed for
	 * ""GENERIC_NAME_LOCAL"" lookup on search using search parameter item list
	 */
	@Test
	public void testGenericnameLocalWithMultipleItems() throws Exception {
		System.out.println("In method 'testGenericnameLocalWithMultipleItems'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME_LOCAL' REGION='ES'>" + "<SearchParameterList SIZE='5'>"
				+ "<SearchParameter NAME='strength' VALUE='60 MG'/>" + "<SearchParameterItemList>"
				+ "<Item NAME='generic_name' VALUE='APALUTAMIDE'/>" + "<Item NAME='gfc' VALUE='135368'/>"
				+ "</SearchParameterItemList>" + "<SearchParameterItemList>"
				+ "<Item NAME='route_name' VALUE='Epidural'/>" + "<Item NAME='form' VALUE='TABLET'/>"
				+ "</SearchParameterItemList>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "generic_name|route_name|form|strength|gfc|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("generic_name", "APALUTAMIDE"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("form", "TABLET"));
	}

	/*
	 * #TC349785 ""GENERIC_NAME_LOCAL"" lookup for the following search parameters
	 * using ""AND"" Operator.
	 */
	@Test
	public void testGenericnameWithAND() throws Exception {
		System.out.println("In method 'testGenericnameWithAND'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME_LOCAL' REGION='ES'>"
				+ "<SearchParameterList SIZE='5' OPERATOR='AND'>"
				+ "<SearchParameter NAME='generic_name' VALUE='CLOPIDOGREL HYDROGEN SULFATE'/>"
				+ "<SearchParameter NAME='route_name' VALUE='Oral (systemic)'/>" + "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "generic_name|route_name|form|strength|gfc|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("generic_name", "CLOPIDOGREL HYDROGEN SULFATE"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("route_name", "Oral (systemic)"));
	}

	/*
	 * TC349787 "GENERIC_NAME_LOCAL"" lookup on search using search parameter item
	 * list with AND
	 */
	@Test
	public void testGenericnameLocalWithMultipleItemsAND() throws Exception {
		System.out.println("In method 'testGenericnameLocalWithMultipleItemsAND'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME_LOCAL' REGION='ES'>"
				+ "<SearchParameterList SIZE='5' OPERATOR='AND'>"
				+ "<SearchParameter NAME='form' VALUE='TABLET'/>" + "<SearchParameterItemList>"
				+ "<Item NAME='generic_name' VALUE='CLOPIDOGREL HYDROGEN SULFATE'/>"
				+ "<Item NAME='route_name' VALUE='Oral (systemic)'/>" + "</SearchParameterItemList>"
				+ "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "generic_name|route_name|form|strength|gfc|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("generic_name", "CLOPIDOGREL HYDROGEN SULFATE"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("route_name", "Oral (systemic)"));
	}

	/* #TC349781 ""GENERIC_NAME"" lookup */
	@Test
	public void testGenericname() throws Exception {
		System.out.println("In method 'testGenericname'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME'>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "generic_name|route_name|form|strength|gfc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("route_name", "Oral (systemic)"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("form", "POWDER FOR SOLUTION"));
	}

	/*
	 * #TC349783 Verify whether US content are getting displayed for
	 * ""GENERIC_NAME"" lookup on providing incorrect Region.
	 */

	@Test
	public void testGenericnameWithInvalidRegion() throws Exception {
		System.out.println("In method 'testGenericnameWithInvalidRegion'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME' REGION='SS'>" + "<SearchParameterList SIZE='5' OPERATOR='AND'>"
				+ "<SearchParameter NAME='form' VALUE='POWDER FOR SOLUTION'/>" + "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "generic_name|route_name|form|strength|gfc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("form", "POWDER FOR SOLUTION"));
	}

	/*
	 * #TC349780 TC349778 Verify whether only the US Content are getting displayed
	 * for ""GENERIC_NAME"" lookup with region
	 */
	@Test
	public void testGenericnameWithNoLocalContent() throws Exception {
		System.out.println("In method 'testGenericnameWithNoLocalContent'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME' REGION='ES'>" + "<SearchParameterList SIZE='5' >"
				+ "<SearchParameterItemList>" + "<Item NAME='generic_name' VALUE='14C UREA'/>"
				+ "</SearchParameterItemList>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "generic_name|route_name|form|strength|gfc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("generic_name", "14C UREA"));
		Assert.assertFalse(doc.verifyLookUpRecordsByFieldStartsWith("region", "ES"),
				"No Local content available; US data only availabale");
	}

	/*
	 * #TC349779 Verify whether only the US Content are getting displayed for
	 * ""GENERIC_NAME"" lookup without region
	 */
	@Test
	public void testGenericnameWithoutregion() throws Exception {
		System.out.println("In method 'testGenericnameWithoutregion'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME'>" + "<SearchParameterList SIZE='5' OPERATOR='AND'>"
				+ "<SearchParameter NAME='form' VALUE='POWDER FOR SOLUTION'/>" + "<SearchParameterItemList>"
				+ "<Item NAME='route_name' VALUE='Intravenous'/>" + "</SearchParameterItemList>"
				+ "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "generic_name|route_name|form|strength|gfc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("route_name", "Intravenous"));
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("form", "POWDER FOR SOLUTION"));
	}

	/*
	 * #TC349782 Verify whether US content are getting displayed for
	 * ""GENERIC_NAME"" with Region.
	 */
	@Test
	public void testGenericnameWithRegion() throws Exception {
		System.out.println("In method 'testGenericnameWithInvalidRegion'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME' REGION='ES'>" + "<SearchParameterList SIZE='5' OPERATOR='AND'>"
				+ "<SearchParameter NAME='form' VALUE='POWDER FOR SOLUTION'/>" + "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "generic_name|route_name|form|strength|gfc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldText("form", "POWDER FOR SOLUTION"));
	}

	/*
	 * #TC349788 Verify whether the Local and US Content are not getting displayed
	 * on providing incorrect region for GENERIC_NAME_LOCAL lookup
	 */

	@Test
	public void testGenericnameLocalWithInvalidRegion() throws Exception {
		System.out.println("In method 'testGenericnameLocalWithInvalidRegion'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME_LOCAL' REGION='SS'>" + "<SearchParameterList SIZE='5'>"
				+ "<SearchParameter NAME='generic_name' VALUE='DAMOCTOCOG ALFA PEGOL'/>"
				+ "<SearchParameter NAME='strength' VALUE='25 MG'/>"
				+ "<SearchParameter NAME='route_name' VALUE='Epidural'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "1");
		Assert.assertEquals(doc.getErrorListErrorText(), "Invalid LookUp Type or REGION for Category");
	}

	/*
	 * #TC349757 Verify whether the following error message ""Invalid Search
	 * Parameter for GENERIC_NAME_LOCAL LookUp"" is displayed on providing Invalid
	 * Search Parameter for GENERIC_NAME_LOCAL lookup
	 */
	@Test
	public void testGenericnameLocalWithInvalidParameter() throws Exception {
		System.out.println("In method 'testGenericnameLocalWithInvalidRegion'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME_LOCAL' REGION='ES'>" + "<SearchParameterList SIZE='5'>"
				+ "<SearchParameter NAME='ABC' VALUE='XYZ'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "1");
		Assert.assertEquals(doc.getErrorListErrorText(), "Invalid Search Parameter for GENERIC_NAME_LOCAL LookUp");

	}

	/*
	 * TC349749 GENERIC_NAME_LOCAL search using ""generic_name"" column
	 */
	@Test
	public void testGenericName() throws Exception {
		System.out.println("In method 'testGenericName'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME_LOCAL' REGION='IT'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='generic_name' VALUE='RIFAMPIN'/>" + "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "generic_name|route_name|form|strength|gfc|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("generic_name", "RIFAMPIN"),
				"RIFAMPIN is not in generic_name field");
	}

	/*
	 * TC349752 GENERIC_NAME_LOCAL search using ""Form"" column
	 */
	@Test
	public void testGenericNameLocalForm() throws Exception {
		System.out.println("In method 'testGenericNameLocalForm'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME_LOCAL' REGION='IT'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='form' VALUE='CRYSTAL'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "generic_name|route_name|form|strength|gfc|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("form", "CRYSTAL"),
				"CRYSTAL is not in generic_name field");
	}

	/*
	 * TC349754 GENERIC_NAME_LOCAL search using ""route_name"" column
	 */
	@Test
	public void testGenericNameLocalRoute() throws Exception {
		System.out.println("In method 'testGenericNameLocalRoute'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME_LOCAL' REGION='ES'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='route_name' VALUE='Intravenous'/>" + "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "generic_name|route_name|form|strength|gfc|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("route_name", "Intravenous"),
				"Intravenous is not in generic_name field");
	}

	/*
	 * TC349751 GENERIC_NAME_LOCAL search using ""strength"" column
	 */
	@Test
	public void testGenericNameLocalStrength() throws Exception {
		System.out.println("In method 'testGenericNameLocalStrength'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME_LOCAL' REGION='ES'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='strength' VALUE='75 MG'/>" + "</SearchParameterList>" + "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(), "0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(), "generic_name|route_name|form|strength|gfc|region");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("strength", "75 MG"),
				"75 MG is not in generic_name field");
	}

}
