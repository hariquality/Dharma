package com.truven.ids.application.cko.uitest.regression.physiology;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.PhysiologyDoc;

/**
 * 
 * 
 * @author BHreen
 * 
 */
public class TestPhysiologyFunc2 extends CKOBaseTest  {

	/*
	 * PHYS016.xml Male - 5495 days = 15 year old - no message
	 * 
	 */

	@Test public void testMaleTypeIBW15YearOld() throws Exception {
		System.out.println("In method 'testMaleTypeIBW15YearOld'");
		PhysiologyDoc doc = getPhysiologyResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>" +
				"<PhysiologyCalculatorRequest TYPE='IBW'>" +
				"<Patient GENDER='MALE' " +
				" AGE_IN_DAYS='5495'" +     
				" WEIGHT='69' HEIGHT='165'/>" +
				"</PhysiologyCalculatorRequest>");	
		Assert.assertEquals(doc.getPhysiologyCalculatorListSize(),"1");
		Assert.assertEquals(doc.getCalcValueByType("IBW"),"50.261");


	}
	
	/*
	 * PHYS017.xml Female - 1096 days = 3 year old - no message
	 * 
	 */
	
	@Test public void testFemaleTypeIBW3YearOld() throws Exception {
		System.out.println("In method 'testFemaleTypeIBW3YearOld'");
		PhysiologyDoc doc = getPhysiologyResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>" +
				"<PhysiologyCalculatorRequest TYPE='IBW'>" +
				"<Patient GENDER='FEMALE' " +
				" AGE_IN_DAYS='1096'" +     
				" WEIGHT='13' HEIGHT='90'/>" +
				"</PhysiologyCalculatorRequest>");	
		Assert.assertEquals(doc.getPhysiologyCalculatorListSize(),"1");
		Assert.assertEquals(doc.getCalcValueByType("IBW"),"13");
		
	}
	
	/*
	 * PHYS018.xml Female - 2191 days = 6 year old - no message
	 * 
	 */
	
	@Test public void testFemaleTypeIBW6YearOld() throws Exception {
		System.out.println("In method 'testFemaleTypeIBW6YearOld'");
		PhysiologyDoc doc = getPhysiologyResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>" +
				"<PhysiologyCalculatorRequest TYPE='IBW'>" +
				"<Patient GENDER='FEMALE' " +
				" AGE_IN_DAYS='2191'" +     
				" WEIGHT='21' HEIGHT='108'/>" +
				"</PhysiologyCalculatorRequest>");	
		Assert.assertEquals(doc.getPhysiologyCalculatorListSize(),"1");
		Assert.assertEquals(doc.getCalcValueByType("IBW"),"19.246");
		
	}
	
	/*
	 * PHYS019.xml Male - 160 days = 0 year old 
	 * 
	 */
	
	@Test public void testFemaleTypeIBW0YearOld() throws Exception {
		System.out.println("In method 'testFemaleTypeIBW0YearOld'");
		PhysiologyDoc doc = getPhysiologyResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>" +
				"<PhysiologyCalculatorRequest TYPE='IBW'>" +
				"<Patient GENDER='FEMALE' " +
				" AGE_IN_DAYS='160'" +     
				" WEIGHT='5.20' HEIGHT='55'/>" +
				"</PhysiologyCalculatorRequest>");	
		Assert.assertEquals(doc.getPhysiologyCalculatorListSize(),"1");
		Assert.assertEquals(doc.getCalcValueByType("IBW"),"5.2");
		Assert.assertEquals(doc.getMessageListSize(),"2");
		Assert.assertEquals(doc.getPhraseInMessageElement(),"Patient's Weight of 5.2 kg is outside normal range for patient's age and gender of 5.694 to 8.38 kg.|Patient's Height of 55 cm is outside normal range for patient's age and gender of 60.216 to 68.523 cm.|");
		
		
	}
	
	/*
	 * PHYS020.xml Female - 6590 days = 18 year old 
	 * 
	 */
	
	@Test public void testFemaleTypeLBM18YearOld() throws Exception {
		System.out.println("In method 'testFemaleTypeLBM18YearOld'");
		PhysiologyDoc doc = getPhysiologyResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>" +
				"<PhysiologyCalculatorRequest TYPE='LBM'>" +
				"<Patient GENDER='FEMALE' " +
				" AGE_IN_DAYS='6590'" +     
				" WEIGHT='87' HEIGHT='157'/>" +
				"</PhysiologyCalculatorRequest>");	
		Assert.assertEquals(doc.getPhysiologyCalculatorListSize(),"1");
		Assert.assertEquals(doc.getCalcValueByType("LBM"),"47.643");
		Assert.assertEquals(doc.getMessageListSize(),"1");
		Assert.assertEquals(doc.getPhraseInMessageElement(),"Patient's Weight of 87 kg is outside normal range for patient's age and gender of 45.36 to 81.918 kg.|");
		
	}
	
	/*
	 * PHYS021.xml Male - 23015 days = 63 year old - no message
	 * 
	 */
	
	@Test public void testMaleTypeLBM63YearOld() throws Exception {
		System.out.println("In method 'testMaleTypeLBM63YearOld'");
		PhysiologyDoc doc = getPhysiologyResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>" +
				"<PhysiologyCalculatorRequest TYPE='LBM'>" +
				"<Patient GENDER='MALE' " +
				" AGE_IN_DAYS='23015'" +     
				" WEIGHT='118' HEIGHT='183'/>" +
				"</PhysiologyCalculatorRequest>");	
		Assert.assertEquals(doc.getPhysiologyCalculatorListSize(),"1");
		Assert.assertEquals(doc.getCalcValueByType("LBM"),"76.58");

		
	}
	
	/*
	 * PHYS022.xml Female - 6955 days = 19 year old - no message
	 * 
	 */
	
	@Test public void testFemaleTypeLBM19YearOld() throws Exception {
		System.out.println("In method 'testFemaleTypeLBM19YearOld'");
		PhysiologyDoc doc = getPhysiologyResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>" +
				"<PhysiologyCalculatorRequest TYPE='LBM'>" +
				"<Patient GENDER='FEMALE' " +
				" AGE_IN_DAYS='6955'" +     
				" WEIGHT='10' HEIGHT='167'/>" +
				"</PhysiologyCalculatorRequest>");	
		Assert.assertEquals(doc.getPhysiologyCalculatorListSize(),"1");
		Assert.assertEquals(doc.getCalcValueByType("LBM"),"10");
		Assert.assertEquals(doc.getMessageListSize(),"1");
		Assert.assertEquals(doc.getPhraseInMessageElement(),"Patient's Weight of 10 kg is outside normal range for patient's age and gender of 45.97 to 82.93 kg.|");
	}

}