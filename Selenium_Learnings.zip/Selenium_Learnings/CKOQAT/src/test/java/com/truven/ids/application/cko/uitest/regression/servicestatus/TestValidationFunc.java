package com.truven.ids.application.cko.uitest.regression.servicestatus;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.ValidationDoc;

/**
 * Validation functional tests
 * 
 * @author APeavy
 * 
 */
public class TestValidationFunc extends CKOBaseTest  {
	
	/**
	 * TC187326
	 * Verify a 'current' drug is validated for IV but not the other services
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testInvalidIVDrugGFC() throws Exception {
		ValidationDoc doc = getValidationDoc("<?xml version=\"1.0\" ?>" + 
				"<ValidationRequest PSD=\"YES\" DOSE1090=\"YES\" WARNINGLABELS=\"YES\" DRUGNOTES=\"YES\" IVSCREENING=\"YES\" DRUGPOINTS=\"YES\" IMAGESIMPRINTS=\"YES\">" + 
				"  <CurrentDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"114554\" TYPE=\"GFC\" />" + 
				"    <!--  114554 purposely used as it will come back invalid for IV -->" + 
				"  </CurrentDrugList>" + 
				"</ValidationRequest>" );
		Assert.assertEquals(doc.getErrorListSize(),"0"); 
		Assert.assertEquals(doc.getNewDrugListSize(),"0"); 
		Assert.assertEquals(doc.getCurrentDrugListSize(),"1"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("114554", "DOSE1090"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("114554", "WARNINGLABELS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("114554", "DRUGNOTES"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("114554", "IVSCREENING"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("114554", "DRUGPOINTS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("114554", "IMAGESIMPRINTS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("114554", "PSD"),"NOTAPPLICABLE"); 
		
	}
	
	/**
	 * TC187327
	 * Verify a 'new' drug is validated 
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testNewDrugGFC() throws Exception {
		ValidationDoc doc = getValidationDoc("<?xml version=\"1.0\" ?>" + 
				"<ValidationRequest PSD=\"YES\" DOSE1090=\"YES\" WARNINGLABELS=\"YES\" DRUGNOTES=\"YES\" IVSCREENING=\"YES\" DRUGPOINTS=\"YES\" IMAGESIMPRINTS=\"YES\">" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"114554\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"</ValidationRequest>" );
		Assert.assertEquals(doc.getErrorListSize(),"0"); 
		Assert.assertEquals(doc.getNewDrugListSize(),"1"); 
		Assert.assertEquals(doc.getCurrentDrugListSize(),"0"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "DOSE1090"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "WARNINGLABELS"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "DRUGNOTES"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "IVSCREENING"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "DRUGPOINTS"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "IMAGESIMPRINTS"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "PSD"),"VALID"); 
		
	}
	
	/**
	 * TC187328
	 * Verify a 'current' drug is validated for IV but not the other services
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testInvalidIVDrugNDC() throws Exception {
		ValidationDoc doc = getValidationDoc("<?xml version=\"1.0\" ?>" + 
				"<ValidationRequest PSD=\"YES\" DOSE1090=\"YES\" WARNINGLABELS=\"YES\" DRUGNOTES=\"YES\" IVSCREENING=\"YES\" DRUGPOINTS=\"YES\" IMAGESIMPRINTS=\"YES\">" + 
				"  <CurrentDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"00108-5012-20\" TYPE=\"NDC\" />" + 
				"    <!--  00108-5012-20 purposely used as it will come back invalid for IV -->" + 
				"  </CurrentDrugList>" + 
				"</ValidationRequest>" );
		Assert.assertEquals(doc.getErrorListSize(),"0"); 
		Assert.assertEquals(doc.getNewDrugListSize(),"0"); 
		Assert.assertEquals(doc.getCurrentDrugListSize(),"1"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "DOSE1090"), "NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "WARNINGLABELS"), "NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "DRUGNOTES"), "NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "IVSCREENING"), "INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "DRUGPOINTS"), "NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "IMAGESIMPRINTS"), "NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "PSD"), "NOTAPPLICABLE"); 
		
	}
	
	/**
	 * TC187329
	 * Verify a 'new' drug is validated 
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testNewDrugNDC() throws Exception {
		ValidationDoc doc = getValidationDoc("<?xml version=\"1.0\" ?>" + 
				"<ValidationRequest PSD=\"YES\" DOSE1090=\"YES\" WARNINGLABELS=\"YES\" DRUGNOTES=\"YES\" IVSCREENING=\"YES\" DRUGPOINTS=\"YES\" IMAGESIMPRINTS=\"YES\">" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"00108-5012-20\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"</ValidationRequest>" );
		Assert.assertEquals(doc.getErrorListSize(),"0"); 
		Assert.assertEquals(doc.getNewDrugListSize(),"1"); 
		Assert.assertEquals(doc.getCurrentDrugListSize(),"0"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("00108-5012-20", "DOSE1090"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("00108-5012-20", "WARNINGLABELS"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("00108-5012-20", "DRUGNOTES"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("00108-5012-20", "IVSCREENING"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("00108-5012-20", "DRUGPOINTS"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("00108-5012-20", "IMAGESIMPRINTS"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("00108-5012-20", "PSD"),"VALID"); 
		
	}
	
	/**
	 * TC187330
	 * Verify a GFC and NDC is validated 
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testGFCAndNDC() throws Exception {
		ValidationDoc doc = getValidationDoc("<?xml version=\"1.0\" ?>" + 
				"<ValidationRequest PSD=\"YES\" DOSE1090=\"YES\" WARNINGLABELS=\"YES\" DRUGNOTES=\"YES\" IVSCREENING=\"YES\" DRUGPOINTS=\"YES\" IMAGESIMPRINTS=\"YES\">" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"00108-5012-20\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"114554\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"</ValidationRequest>" );
		Assert.assertEquals(doc.getErrorListSize(),"0"); 
		Assert.assertEquals(doc.getNewDrugListSize(),"2"); 
		Assert.assertEquals(doc.getCurrentDrugListSize(),"0"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("00108-5012-20", "DOSE1090"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("00108-5012-20", "WARNINGLABELS"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("00108-5012-20", "DRUGNOTES"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("00108-5012-20", "IVSCREENING"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("00108-5012-20", "DRUGPOINTS"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("00108-5012-20", "IMAGESIMPRINTS"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("00108-5012-20", "PSD"),"VALID"); 
		
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "DOSE1090"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "WARNINGLABELS"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "DRUGNOTES"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "IVSCREENING"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "DRUGPOINTS"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "IMAGESIMPRINTS"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "PSD"),"VALID"); 
		
	}
	
	/**
	 * TC187331
	 * Verify a GFC and NDC in Current is validated 
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testCurrentGFCAndNDC() throws Exception {
		ValidationDoc doc = getValidationDoc("<?xml version=\"1.0\" ?>" + 
				"<ValidationRequest PSD=\"YES\" DOSE1090=\"YES\" WARNINGLABELS=\"YES\" DRUGNOTES=\"YES\" IVSCREENING=\"YES\" DRUGPOINTS=\"YES\" IMAGESIMPRINTS=\"YES\">" + 
				"  <CurrentDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"00108-5012-20\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"114554\" TYPE=\"GFC\" />" + 
				"  </CurrentDrugList>" + 
				"</ValidationRequest>" );
		Assert.assertEquals(doc.getErrorListSize(),"0"); 
		Assert.assertEquals(doc.getNewDrugListSize(),"0"); 
		Assert.assertEquals(doc.getCurrentDrugListSize(),"2"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "DOSE1090"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "WARNINGLABELS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "DRUGNOTES"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "IVSCREENING"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "DRUGPOINTS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "IMAGESIMPRINTS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "PSD"),"NOTAPPLICABLE"); 
		
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("114554", "DOSE1090"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("114554", "WARNINGLABELS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("114554", "DRUGNOTES"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("114554", "IVSCREENING"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("114554", "DRUGPOINTS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("114554", "IMAGESIMPRINTS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("114554", "PSD"),"NOTAPPLICABLE"); 
		
	}
	
	/**
	 * TC187332
	 * Verify a GFC and NDC in both New and Current 
	 * 
	 * @throws Exception
	 */
	@Test
	public void testCurrentAndNew() throws Exception {
		ValidationDoc doc = getValidationDoc("<?xml version=\"1.0\" ?>" + 
				"<ValidationRequest PSD=\"YES\" DOSE1090=\"YES\" WARNINGLABELS=\"YES\" DRUGNOTES=\"YES\" IVSCREENING=\"YES\" DRUGPOINTS=\"YES\" IMAGESIMPRINTS=\"YES\">" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"00182-1908-01\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"114554\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <CurrentDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"00108-5012-20\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"114555\" TYPE=\"GFC\" />" + 
				"  </CurrentDrugList>" + 
				"</ValidationRequest>" );
		Assert.assertEquals(doc.getErrorListSize(),"0"); 
		Assert.assertEquals(doc.getNewDrugListSize(),"2"); 
		Assert.assertEquals(doc.getCurrentDrugListSize(),"2"); 
		
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("00182-1908-01", "DOSE1090"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("00182-1908-01", "WARNINGLABELS"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("00182-1908-01", "DRUGNOTES"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("00182-1908-01", "IVSCREENING"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("00182-1908-01", "DRUGPOINTS"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("00182-1908-01", "IMAGESIMPRINTS"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("00182-1908-01", "PSD"),"VALID"); 

		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "DOSE1090"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "WARNINGLABELS"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "DRUGNOTES"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "IVSCREENING"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "DRUGPOINTS"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "IMAGESIMPRINTS"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "PSD"),"VALID"); 

		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "DOSE1090"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "WARNINGLABELS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "DRUGNOTES"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "IVSCREENING"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "DRUGPOINTS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "IMAGESIMPRINTS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "PSD"),"NOTAPPLICABLE"); 
		
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("114555", "DOSE1090"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("114555", "WARNINGLABELS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("114555", "DRUGNOTES"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("114555", "IVSCREENING"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("114555", "DRUGPOINTS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("114555", "IMAGESIMPRINTS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("114555", "PSD"),"NOTAPPLICABLE"); 
		
	}
	
	/**
	 * TC187333 TC187334
	 * Verify an unknown NDCs and GFCs gets validated correctly
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testUnknownGFCs() throws Exception {
		ValidationDoc doc = getValidationDoc("<?xml version=\"1.0\" ?>" + 
				"<ValidationRequest PSD=\"YES\" DOSE1090=\"YES\" WARNINGLABELS=\"YES\" DRUGNOTES=\"YES\" IVSCREENING=\"YES\" DRUGPOINTS=\"YES\" IMAGESIMPRINTS=\"YES\">" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"898989\" TYPE=\"GFC\" />" + 
				"    <Drug CODE=\"98765-1234-99\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"  <CurrentDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"989898\" TYPE=\"GFC\" />" + 
				"    <Drug CODE=\"88888-7777-66\" TYPE=\"NDC\" />" + 
				"  </CurrentDrugList>" + 
				"</ValidationRequest>" );
		Assert.assertEquals(doc.getErrorListSize(),"0"); 
		Assert.assertEquals(doc.getNewDrugListSize(),"2"); 
		Assert.assertEquals(doc.getCurrentDrugListSize(),"2"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("898989", "DOSE1090"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("898989", "WARNINGLABELS"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("898989", "DRUGNOTES"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("898989", "IVSCREENING"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("898989", "DRUGPOINTS"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("898989", "IMAGESIMPRINTS"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("898989", "PSD"),"INVALID"); 
		
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("98765-1234-99", "DOSE1090"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("98765-1234-99", "WARNINGLABELS"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("98765-1234-99", "DRUGNOTES"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("98765-1234-99", "IVSCREENING"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("98765-1234-99", "DRUGPOINTS"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("98765-1234-99", "IMAGESIMPRINTS"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("98765-1234-99", "PSD"),"INVALID"); 
		
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("989898", "DOSE1090"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("989898", "WARNINGLABELS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("989898", "DRUGNOTES"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("989898", "IVSCREENING"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("989898", "DRUGPOINTS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("989898", "IMAGESIMPRINTS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("989898", "PSD"),"NOTAPPLICABLE"); 
		
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("88888-7777-66", "DOSE1090"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("88888-7777-66", "WARNINGLABELS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("88888-7777-66", "DRUGNOTES"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("88888-7777-66", "IVSCREENING"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("88888-7777-66", "DRUGPOINTS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("88888-7777-66", "IMAGESIMPRINTS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("88888-7777-66", "PSD"),"NOTAPPLICABLE"); 
		
	}
	
	/**
	 * TC187335
	 * Verify an mix of known and unknown NDCs and GFCs 
	 * 
	 * @throws Exception
	 */
	@Test 
	public void testMix() throws Exception {
		ValidationDoc doc = getValidationDoc("<?xml version=\"1.0\" ?>" + 
				"<ValidationRequest PSD=\"YES\" DOSE1090=\"YES\" WARNINGLABELS=\"YES\" DRUGNOTES=\"YES\" IVSCREENING=\"YES\" DRUGPOINTS=\"YES\" IMAGESIMPRINTS=\"YES\">" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"114554\" TYPE=\"GFC\" />" + 
				"    <Drug CODE=\"98765-1234-99\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"  <CurrentDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"989898\" TYPE=\"GFC\" />" + 
				"    <Drug CODE=\"00108-5012-20\" TYPE=\"NDC\" />" + 
				"  </CurrentDrugList>" + 
				"</ValidationRequest>" );
		Assert.assertEquals(doc.getErrorListSize(),"0"); 
		Assert.assertEquals(doc.getNewDrugListSize(),"2"); 
		Assert.assertEquals(doc.getCurrentDrugListSize(),"2"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "DOSE1090"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "WARNINGLABELS"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "DRUGNOTES"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "IVSCREENING"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "DRUGPOINTS"),"VALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "IMAGESIMPRINTS"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("114554", "PSD"),"VALID"); 
		
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("98765-1234-99", "DOSE1090"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("98765-1234-99", "WARNINGLABELS"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("98765-1234-99", "DRUGNOTES"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("98765-1234-99", "IVSCREENING"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("98765-1234-99", "DRUGPOINTS"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("98765-1234-99", "IMAGESIMPRINTS"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInNew("98765-1234-99", "PSD"),"INVALID"); 
		
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("989898", "DOSE1090"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("989898", "WARNINGLABELS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("989898", "DRUGNOTES"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("989898", "IVSCREENING"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("989898", "DRUGPOINTS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("989898", "IMAGESIMPRINTS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("989898", "PSD"),"NOTAPPLICABLE"); 
		
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "DOSE1090"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "WARNINGLABELS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "DRUGNOTES"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "IVSCREENING"),"INVALID"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "DRUGPOINTS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "IMAGESIMPRINTS"),"NOTAPPLICABLE"); 
		Assert.assertEquals(doc.getResultForGivenAttributeInCurrent("00108-5012-20", "PSD"),"NOTAPPLICABLE"); 
		
	}
	
	
}
