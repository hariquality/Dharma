package com.truven.ids.application.cko.uitest.regression.imagesimprints;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.ImagesImprintsDoc;

/**
 * 
 * 
 * @author BHreen
 * 
 */
public class TestImagesImprintsException extends CKOBaseTest  {

	/*
	 * TC186916
	 */
@Test
	public void testShapeNotFound() throws Exception {
		System.out.println("In method 'testShapeNotFound'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsSearchRequest>"
				+ "<DrugSearchDescription SHAPE=\"ferbibble\" />"
				+ "</ImagesImprintsSearchRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1"); 
		Assert.assertTrue(doc.isPhraseInErrorElement("No Data Found for the given search values."),
				"No Data Found for the given search values.' not found in text element");  //assert phrase in the text element

	}
	
	/*
	 * TC186917
	 */
@Test	
	public void testPatternNotFound() throws Exception {
		System.out.println("In method 'testPatternNotFound'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsSearchRequest>"
				+ "<DrugSearchDescription PATTERN=\"ferbibble\" />"
				+ "</ImagesImprintsSearchRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1"); 
		Assert.assertTrue(doc.isPhraseInErrorElement("No Data Found for the given search values."),
				"No Data Found for the given search values.' not found in text element");  //assert phrase in the text element
		
	}

	/*
	 * TC186918
	 */
@Test
	public void testShapeAndPatternNotFound() throws Exception {
		System.out.println("In method 'testShapeAndPatternNotFound'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsSearchRequest>"
				+ "<DrugSearchDescription SHAPE=\"Egg-shape\" PATTERN=\"Banded\"/>"
				+ "</ImagesImprintsSearchRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1"); 
		Assert.assertTrue(doc.isPhraseInErrorElement("No Data Found for the given search values."),
				"No Data Found for the given search values.' not found in text element");  //assert phrase in the text element
		

	}
	
	/*
	 * TC186919
	 */
@Test
	public void testImprintNotFound() throws Exception {
		System.out.println("In method 'testImprintNotFound'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsSearchRequest>"
				+ "<DrugSearchDescription>"
				+ "<ImprintList SIZE=\"1\">"
				+ "<Imprint>ferbibble"
				+ "</Imprint>"
				+ "</ImprintList>"
				+ "</DrugSearchDescription>"
				+ "</ImagesImprintsSearchRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1"); 
		Assert.assertTrue(doc.isPhraseInErrorElement("No Data Found for the given search values."),
				"No Data Found for the given search values.' not found in text element");  //assert phrase in the text element	

	}
	
	/*
	 * TC186920
	 */
@Test	
	public void testMultipleImprintsNotFound() throws Exception {
		System.out.println("In method 'testMultipleImprintsNotFound'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsSearchRequest>"
				+ "<DrugSearchDescription>"
				+ "<ImprintList SIZE=\"1\">"
				+ "<Imprint>PCE"
				+ "</Imprint>"
				+ "<Imprint>ferbibble"
				+ "</Imprint>"
				+ "</ImprintList>"
				+ "</DrugSearchDescription>"
				+ "</ImagesImprintsSearchRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1"); 
		Assert.assertTrue(doc.isPhraseInErrorElement("No Data Found for the given search values."),
				"No Data Found for the given search values.' not found in text element");  //assert phrase in the text element		
		
	}

	
	/*
	 * TC186921
	 */
@Test
	public void testColorNotFound() throws Exception {
		System.out.println("In method 'testColorNotFound'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsSearchRequest>"
				+ "<DrugSearchDescription>"
				+ "<ColorList SIZE =\"1\">"
				+ "<Color>ferbibble"
				+ "</Color>"
				+ "</ColorList>"
				+ "</DrugSearchDescription>"
				+ "</ImagesImprintsSearchRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1"); 
		Assert.assertTrue(doc.isPhraseInErrorElement("No Data Found for the given search values."),
				"No Data Found for the given search values.' not found in text element");  //assert phrase in the text element
		
	}
	
	/*
	 * TC186922
	 */
	@Test
	public void testMultipleColorsNotFound() throws Exception {
		System.out.println("In method 'testMultipleColorsNotFound'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsSearchRequest>"
				+ "<DrugSearchDescription>"
				+ "<ColorList SIZE =\"1\">"
				+ "<Color>ferbibble"
				+ "</Color>"
				+ "<Color>Black"
				+ "</Color>"
				+ "</ColorList>"
				+ "</DrugSearchDescription>"
				+ "</ImagesImprintsSearchRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1"); 
		Assert.assertTrue(doc.isPhraseInErrorElement("No Data Found for the given search values."),
				"No Data Found for the given search values.' not found in text element");  //assert phrase in the text element
		
	}

	
	/*
	 * TC186931
	 */
	@Test
	public void testNDCRequestWithInvalidStatus() throws Exception {
		System.out.println("In method 'testNDCRequestWithInvalidStatus'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"54868-1501-00\" TYPE=\"NDC\" STATUS=\"ASDF\"/>"
				+ "</NewDrugList>"
				+ "</ImagesImprintsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1"); 
		Assert.assertTrue(doc.isPhraseInErrorElement("HcpsSearch Exception: Invalid status of 'ASDF' was given. Valid values are 'ACTIVE', 'INACTIVE' and 'IGNORED'."),
				"HcpsSearch Exception: Invalid status of 'ASDF' was given. Valid values are 'ACTIVE', 'INACTIVE' and 'IGNORED', not found in text element");  //assert phrase in the text element
		
	}
	
	/*
	 * TC186932
	 */
	@Test
	public void testGFCNotAValidSearchformat() throws Exception {
		System.out.println("In method 'testGFCNotAValidSearchformat'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"101296\" TYPE=\"GFC\" STATUS=\"ACTIVE\"/>"
				+ "</NewDrugList>"
				+ "</ImagesImprintsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1"); 
		Assert.assertTrue(doc.isPhraseInErrorElement("Invalid NDC format: valid format is 12345-6789-10."),
				"Invalid NDC format: valid format is 12345-6789-10.', not found in text element.");  //assert phrase in the text element
		
	}
	
	/*
	 * TC186933
	 */
	@Test
	public void testInvalidNDC() throws Exception {
		System.out.println("In method 'testInvalidNDC'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"123-456-789\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "</NewDrugList>"
				+ "</ImagesImprintsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1"); 
		Assert.assertTrue(doc.isPhraseInErrorElement("Invalid NDC format: valid format is 12345-6789-10."),
				"Invalid NDC format: valid format is 12345-6789-10.', not found in text element.");  //assert phrase in the text element
		
	}
	
	/*
	 * TC186934
	 */
	@Test
	public void testNDCWithStatusInactive() throws Exception {
		System.out.println("In method 'testNDCWithStatusInactive'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"00056-0169-70\" TYPE=\"NDC\" STATUS=\"INACTIVE\"/>"
				+ "</NewDrugList>"
				+ "</ImagesImprintsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"1"); 
		Assert.assertTrue(doc.isPhraseInErrorElement("HcpsSearch Exception: No data found for NDC '00056-0169-70' with a status of 'INACTIVE'"),
				"HcpsSearch Exception: No data found for NDC '00056-0169-70' with a status of 'INACTIVE'', not found in text element.");  //assert phrase in the text element
		
	}
	
	
	
}
