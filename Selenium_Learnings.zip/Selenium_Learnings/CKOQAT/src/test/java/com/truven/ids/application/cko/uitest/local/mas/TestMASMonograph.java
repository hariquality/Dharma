package com.truven.ids.application.cko.uitest.local.mas;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.MasDoc;
import com.truven.ids.application.cko.uitest.regression.pageobjects.MonographDoc;

public class TestMASMonograph extends CKOBaseTest{


	/**
	 * TC349703 ---Verify whether the US Monograph Document is retrieved with appropriate pregnancy content on searching using the corresponding Document ID
	 * 
	 */
	
	@Test
	public void testMasMonograph() throws Exception {
	MonographDoc mono = getMonographDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" +
			"<DocumentRequest>" +
			"  <DocumentList SIZE=\"1\">" +
			"    <Document ID=\"8000004\" TYPE=\"MONOGRAPH\" />" +
			"  </DocumentList>" +
			"</DocumentRequest>");
	Assert.assertEquals(mono.getDocumentID(),"8000004");
	Assert.assertTrue(mono.getDocumentText().contains("Advise patients that use is contraindicated in pregnant women. It should not be used by women who are pregnant or who intend to become pregnant during therapy or up to 3 years following the discontinuation of therapy."));
	Assert.assertEquals(mono.getErrorListSize(),"0");
	}
	
	/**
	 * TC349702 ---Verify whether the US Monograph Document is retrieved with appropriate Lactation content on searching using the corresponding Document ID 
	 * 
	 */
	
	@Test
	public void testMasMonograph1() throws Exception {
	MonographDoc mono = getMonographDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" +
			"<DocumentRequest>" +
			"  <DocumentList SIZE=\"1\">" +
			"    <Document ID=\"9000029\" TYPE=\"MONOGRAPH\" />" +
			"  </DocumentList>" +
			"</DocumentRequest>");
	Assert.assertEquals(mono.getDocumentID(),"9000029");
	Assert.assertTrue(mono.getDocumentText().contains("AMERICAN ACADEMY OF PEDIATRICS:</H3>NOT RATED<H3>WORLD HEALTH ORGANIZATION:</H3>NOT RATED<H3>PATIENT MANAGEMENT:</H3><P>Hemophilus B vaccine is not approved"));
	Assert.assertEquals(mono.getErrorListSize(),"0");
	}
	
	/**
	 * TC349701 --- Verify whether the US Monograph Document is retrieved with appropriate Drug Interaction content on searching using the corresponding Document ID 
	 * 
	 */
	
	@Test
	public void testMasMonograph2() throws Exception {
	MonographDoc mono = getMonographDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" +
			"<DocumentRequest>" +
			"  <DocumentList SIZE=\"1\">" +
			"    <Document ID=\"1210631\" TYPE=\"MONOGRAPH\" />" +
			"  </DocumentList>" +
			"</DocumentRequest>");
	Assert.assertEquals(mono.getDocumentID(),"1210631");
	Assert.assertTrue(mono.getDocumentText().contains("Concurrent use of WARFARIN and ANTIPLATELET AGENTS may result in increased risk of bleeding.<H3>Clinical Management:</H3><P>Coadministration of warfarin and antiplatelet agents may increase the risk of bleeding."));
	Assert.assertEquals(mono.getErrorListSize(),"0");
	}
	
	/**
	 * TC349706 --- Verify whether the Local Monograph Document is retrieved with appropriate pregnancy local content on searching using the corresponding Document ID 
	 * 
	 */
	
	@Test
	public void testMasMonograph3() throws Exception {
	MonographDoc mono = getMonographDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" +
			"<DocumentRequest>" +
			"  <DocumentList SIZE=\"1\">" +
			"    <Document ID=\"8020856\" TYPE=\"MONOGRAPH\" />" +
			"  </DocumentList>" +
			"</DocumentRequest>");
	Assert.assertEquals(mono.getDocumentID(),"8020856");
	Assert.assertTrue(mono.getDocumentText().contains("Prasugrel hydrobromide should only be used during pregnancy as long as the potential benefit to the mother justifies the potential risk to the fetus"));
	Assert.assertEquals(mono.getErrorListSize(),"0");
	}
	
	/**
	 * TC349705 ---Verify whether the Local Monograph Document is retrieved with appropriate lactation local content on searching using the corresponding Document ID 
	 * 
	 */
	
	@Test
	public void testMasMonograph4() throws Exception {
	MonographDoc mono = getMonographDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" +
			"<DocumentRequest>" +
			"  <DocumentList SIZE=\"1\">" +
			"    <Document ID=\"9020845\" TYPE=\"MONOGRAPH\" />" +
			"  </DocumentList>" +
			"</DocumentRequest>");
	Assert.assertEquals(mono.getDocumentID(),"9020845");
	Assert.assertTrue(mono.getDocumentText().contains("AMERICAN ACADEMY OF PEDIATRICS:</H3>NOT RATED<H3>WORLD HEALTH ORGANIZATION:</H3>NOT RATED<H3>PATIENT MANAGEMENT:</H3><P>Based on the potential for serious adverse reactions from"));
	Assert.assertEquals(mono.getErrorListSize(),"0");
	}
	
	/**
	 * TC349704 ---Verify whether the Local Monograph Document is retrieved with appropriate Drug Interaction content on searching using the corresponding Document ID 
	 * 
	 */
	
	@Test
	public void testMasMonograph5() throws Exception {
	MonographDoc mono = getMonographDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" +
			"<DocumentRequest>" +
			"  <DocumentList SIZE=\"1\">" +
			"    <Document ID=\"1212412\" TYPE=\"MONOGRAPH\" />" +
			"  </DocumentList>" +
			"</DocumentRequest>");
	Assert.assertEquals(mono.getDocumentID(),"1212412");
	Assert.assertTrue(mono.getDocumentText().contains("Concurrent use of APALUTAMIDE and OMBITASVIR may result in decreased ombitasvir exposure.<H3>Clinical Management:</H3><P>Use of ombitasvir is contraindicated with moderate or strong inducers of CYP3A"));
	Assert.assertEquals(mono.getErrorListSize(),"0");
	}
	
	/**
	 * TC349708 ---Verify whether the appropriate error message ""No data exist for this document ID"" is displayed on providing incorrect Document ID. 
	 * 
	 */
	
	@Test
	public void testMasMonograph6() throws Exception {
		MonographDoc mono = getMonographDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" +
		"<DocumentRequest>" +
		" <DocumentList SIZE='1'>" +
		" <Document ID='0000000' TYPE='MONOGRAPH' />" +
		" <Document ID='8000004' TYPE='MONOGRAPH' />" +
		" </DocumentList>" +
		"</DocumentRequest>");
		Assert.assertEquals(mono.getErrorText(),"No data exists for the given document id .","ERROR TEXT");
		}
	/**
	 * TC349707 --- Verify whether the US Monograph and Local Monograph Documents are retrieved with appropriate Drug Interaction, Lactation, Pregnancy content on search using corresponding Document Id's 
	 * 
	 */
	
	@Test
	public void testMasMonograph7() throws Exception {
	MonographDoc mono = getMonographDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" +
			"<DocumentRequest>" +
			"  <DocumentList SIZE=\"6\">" +
			"    <Document ID=\"1000132\" TYPE=\"MONOGRAPH\" />" +
			"    <Document ID=\"8000005\" TYPE=\"MONOGRAPH\" />" +
			"    <Document ID=\"9000031\" TYPE=\"MONOGRAPH\" />" +
			"    <Document ID=\"1212417\" TYPE=\"MONOGRAPH\" />" +
			"    <Document ID=\"8020830\" TYPE=\"MONOGRAPH\" />" +
			"    <Document ID=\"9020867\" TYPE=\"MONOGRAPH\" />" +
			"  </DocumentList>" +
			"</DocumentRequest>");
	Assert.assertEquals(mono.getDocumentListSize(),"6");
	Assert.assertTrue(mono.getDocumentText("AMERICAN ACADEMY OF PEDIATRICS:</H3>NOT RATED<H3>WORLD HEALTH ORGANIZATION:</H3>NOT RATED<H3>PATIENT MANAGEMENT:</H3><P>Due to the potential risk for serious adverse reactions"));
	Assert.assertTrue(mono.getDocumentId("9020867"));
	
	}
}
