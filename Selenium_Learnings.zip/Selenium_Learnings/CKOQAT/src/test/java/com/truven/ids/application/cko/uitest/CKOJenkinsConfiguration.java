package com.truven.ids.application.cko.uitest;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

public class CKOJenkinsConfiguration extends ExtentManager
{

   public static String targetServerForTHIDS_THIAS;
   
   public static String targetServerforCPSI;
      
   public static boolean JenkinsRun = false;
   
   public static String executeType = "";
   
   public static String executeEnv = "";
   
   static Properties props = new Properties();

   static InputStream input = null;

   @BeforeClass(alwaysRun=true)
   @Parameters(
   { "ExecuteInJenkins", "Execute", "ExecuteIn"})
   public static void runConfiguration(@Optional String ExecuteInJenkins,
                                      @Optional String Execute,
                                      @Optional String ExecuteIn)
   {
      try
      {
         input = new FileInputStream("./TargetURL.properties");
         props.load(input);
         executeType = Execute;
        
         if (ExecuteInJenkins.equalsIgnoreCase("Yes"))
         {
             JenkinsRun = true;
            String targetURLForJenkinsRun = getValueFromPropertiesFile(System.getenv("ExecuteIn"));
            executeEnv = System.getenv("ExecuteIn");
            System.out.println(targetURLForJenkinsRun);
            targetServerForTHIDS_THIAS = targetURLForJenkinsRun;
            targetServerforCPSI = targetURLForJenkinsRun;
         }
         else
         {
        	 String targetURLForLocalRun = getValueFromPropertiesFile(ExecuteIn);
             executeEnv = ExecuteIn;
             targetServerForTHIDS_THIAS = targetURLForLocalRun;
             targetServerforCPSI = targetURLForLocalRun;
         }
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
   }

   public static String getValueFromPropertiesFile(String valueName)
   {
      return props.getProperty(valueName);
   }

   public String getCKOTargetServerForTHIAS_THIDS()
   {
      return targetServerForTHIDS_THIAS;
   }

   public String getCKOTargetServerForCPSI()
   {
      return targetServerforCPSI;
   }

}
