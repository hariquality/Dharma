package com.truven.ids.application.cko.uitest.regression.pageobjects;

import java.util.Iterator;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;


/**
 * PSDDoc contains PSD specific methods.
 * @author APeavy
 * 
 */
public class PSDDoc extends BaseDoc {

	public PSDDoc(Document inputDoc) {
		super(inputDoc);
	}

	/**
	 * Return size attribue of Rec response list
	 * @return
	 */
	public String getRecResponseListSize() {
		return doc.getRootElement()
				.getChild("RxRecmndResponseList")
				.getAttributeValue("SIZE"); 
	}

	/**
	 * Returns Rec DOSING_PERFORMED attribute value.
	 * 
	 * @return
	 */
	public String getRecDosingPerformedAttr() {
		return doc.getRootElement()
				.getChild("RxRecmndResponseList")
				.getChild("RxRecmndResponse")
				.getAttributeValue("DOSING_PERFORMED"); 
	}

	/**
	 * Returns Rec PSDDrug ID.
	 * 
	 * @return
	 */
	public String getRecPSDDrugID() {
		return doc.getRootElement()
				.getChild("RxRecmndResponseList")
				.getChild("RxRecmndResponse")
				.getChild("PSDDrug")
				.getAttributeValue("ID"); 
	}

	/**
	 * Returns Rec PSDDrug TYPE.
	 * 
	 * @return
	 */
	public String getRecPSDDrugType() {
		return doc.getRootElement()
				.getChild("RxRecmndResponseList")
				.getChild("RxRecmndResponse")
				.getChild("PSDDrug")
				.getAttributeValue("TYPE"); 
	}

	/**
	 * Returns Rec DoseKeyRecmndResultList SIZE.
	 * 
	 * @return
	 */
	public String getRecDoseKeySize() {
		return doc.getRootElement()
				.getChild("RxRecmndResponseList")
				.getChild("RxRecmndResponse")
				.getChild("DoseKeyRecmndResultList")
				.getAttributeValue("SIZE"); 
	}

	/**
	 * Return attribute value for the Rec RxDoseKey element.
	 * 
	 * @param attrName
	 * @return
	 */
	public String getRecRxDoseKeyAttrValue(String attrName) {
		return doc.getRootElement()
				.getChild("RxRecmndResponseList")
				.getChild("RxRecmndResponse")
				.getChild("DoseKeyRecmndResultList")
				.getChild("DoseKeyRecmndResult")
				.getChild("RxDoseKey")
				.getAttributeValue(attrName); 
	}

	/**
	 * Return attribute value for the Rec RecmndDosingUnits element.
	 * 
	 * @param attrName
	 * @return
	 */
	public String getRecmndDosingUnitsAttrValue(String attrName) {
		return doc.getRootElement()
				.getChild("RxRecmndResponseList")
				.getChild("RxRecmndResponse")
				.getChild("DoseKeyRecmndResultList")
				.getChild("DoseKeyRecmndResult")
				.getChild("RecmndDosingUnits")
				.getAttributeValue(attrName); 
	}

	/**
	 * Return attribute value for the Rec GeneralDoseParms element.
	 * 
	 * @param attrName
	 * @return
	 */
	public String getRecmndGeneralDoseParmsAttrValue(String attrName) {
		return doc.getRootElement()
				.getChild("RxRecmndResponseList")
				.getChild("RxRecmndResponse")
				.getChild("DoseKeyRecmndResultList")
				.getChild("DoseKeyRecmndResult")
				.getChild("GeneralDoseParms")
				.getAttributeValue(attrName); 
	}

	/**
	 * Return attribute value for the Rec DoseModifierDescriptor element.
	 * 
	 * @param attrName
	 * @return
	 */
	public String getRecDoseModifierDescriptorAttrValue(String attrName) {
		return doc.getRootElement()
				.getChild("RxRecmndResponseList")
				.getChild("RxRecmndResponse")
				.getChild("DoseKeyRecmndResultList")
				.getChild("DoseKeyRecmndResult")
				.getChild("DoseModifierRecmndResultList")
				.getChild("DoseModifierRecmndResult")
				.getChild("DoseModifierDescriptor")
				.getAttributeValue(attrName); 
	}

	/**
	 * Return attribute value for the Rec DoseRecmnd element.
	 * 
	 * @param attrName
	 * @return
	 */
	public String getDoseRecmndAttrValue(String attrName) {
		return doc.getRootElement()
				.getChild("RxRecmndResponseList")
				.getChild("RxRecmndResponse")
				.getChild("DoseKeyRecmndResultList")
				.getChild("DoseKeyRecmndResult")
				.getChild("DoseModifierRecmndResultList")
				.getChild("DoseModifierRecmndResult")
				.getChild("DoseRecmndList")
				.getChild("DoseRecmnd")
				.getAttributeValue(attrName); 
	}


	public String getAllDoseRecmndDoseAndIntervalValues() {
		StringBuffer delimitedDoses = new StringBuffer();
		List<?> doses = doc.getRootElement()
				.getChild("RxRecmndResponseList")
				.getChild("RxRecmndResponse")
				.getChild("DoseKeyRecmndResultList")
				.getChild("DoseKeyRecmndResult")
				.getChild("DoseModifierRecmndResultList")
				.getChild("DoseModifierRecmndResult")
				.getChild("DoseRecmndList")
				.getChildren("DoseRecmnd");
		for (Object dose : doses) {
			delimitedDoses.append(((Element) dose).getAttributeValue("DOSE") + "|");
			delimitedDoses.append(((Element) dose).getAttributeValue("INTERVAL") + "|");
		}
		return delimitedDoses.toString();
	}

	/**
	 * Return size attribute of Screening response list
	 * @return
	 */
	public String getScrResponseListSize() {
		return doc.getRootElement()
				.getChild("RxScreeningResponseList")
				.getAttributeValue("SIZE"); 
	}

	/**
	 * Returns Scr DOSING_PERFORMED attribute value.
	 * 
	 * @return
	 */
	public String getScrDosingPerformedAttr() {
		return doc.getRootElement()
				.getChild("RxScreeningResponseList")
				.getChild("RxRecmndResponse")
				.getAttributeValue("DOSING_PERFORMED"); 
	}

	/**
	 * Returns Scr PSDDrug ID.
	 * 
	 * @return
	 */
	public String getScrPSDDrugID() {
		return doc.getRootElement()
				.getChild("RxScreeningResponseList")
				.getChild("RxScreeningResponse")
				.getChild("PSDDrug")
				.getAttributeValue("ID"); 
	}

	/**
	 * Returns Scr PSDDrug TYPE.
	 * 
	 * @return
	 */
	public String getScrPSDDrugType() {
		return doc.getRootElement()
				.getChild("RxScreeningResponseList")
				.getChild("RxScreeningResponse")
				.getChild("PSDDrug")
				.getAttributeValue("TYPE"); 
	}

	/**
	 * Returns Scr DoseKeyRecmndResultList SIZE.
	 * 
	 * @return
	 */
	public String getScrDoseKeySize() {
		return doc.getRootElement()
				.getChild("RxScreeningResponseList")
				.getChild("RxScreeningResponse")
				.getChild("DoseKeyScreeningResultList")
				.getAttributeValue("SIZE"); 
	}

	/**
	 * Return attribute value for the Scr RxDoseKey element.
	 * 
	 * @param attrName
	 * @return
	 */
	public String getScrRxDoseKeyAttrValue(String attrName) {
		return doc.getRootElement()
				.getChild("RxScreeningResponseList")
				.getChild("RxScreeningResponse")
				.getChild("DoseKeyScreeningResultList")
				.getChild("DoseKeyScreeningResult")
				.getChild("RxDoseKey")
				.getAttributeValue(attrName); 
	}

	/**
	 * Return attribute value for the SCR ScrnDosingUnits element.
	 * 
	 * @param attrName
	 * @return
	 */
	public String getScrDosingUnitsAttrValue(String attrName) {
		return doc.getRootElement()
				.getChild("RxScreeningResponseList")
				.getChild("RxScreeningResponse")
				.getChild("DoseKeyScreeningResultList")
				.getChild("DoseKeyScreeningResult")
				.getChild("ScrnDosingUnits")
				.getAttributeValue(attrName); 
	}

	/**
	 * Return attribute value for the Scr GeneralDoseParms element.
	 * 
	 * @param attrName
	 * @return
	 */
	public String getScrGeneralDoseParmsAttrValue(String attrName) {
		return doc.getRootElement()
				.getChild("RxScreeningResponseList")
				.getChild("RxScreeningResponse")
				.getChild("DoseKeyScreeningResultList")
				.getChild("DoseKeyScreeningResult")
				.getChild("GeneralDoseParms")
				.getAttributeValue(attrName); 
	}

	/**
	 * Return attribute value for the Scr DoseModifierScreeningResult element.
	 * 
	 * @param attrName
	 * @return
	 */
	public String getScrDoseModifierScreeningResultAttrValue(String attrName) {
		return doc.getRootElement()
				.getChild("RxScreeningResponseList")
				.getChild("RxScreeningResponse")
				.getChild("DoseKeyScreeningResultList")
				.getChild("DoseKeyScreeningResult")
				.getChild("DoseModifierScreeningResultList")
				.getChild("DoseModifierScreeningResult")
				.getAttributeValue(attrName); 
	}

	/**
	 * Return attribute value for the Scr DoseModifierDescriptor element.
	 * 
	 * @param attrName
	 * @return
	 */
	public String getScrDoseModifierDescriptorAttrValue(String attrName) {
		return doc.getRootElement()
				.getChild("RxScreeningResponseList")
				.getChild("RxScreeningResponse")
				.getChild("DoseKeyScreeningResultList")
				.getChild("DoseKeyScreeningResult")
				.getChild("DoseModifierScreeningResultList")
				.getChild("DoseModifierScreeningResult")
				.getChild("DoseModifierDescriptor")
				.getAttributeValue(attrName); 
	}

	/**
	 * Return attribute value for the Scr ScreeningStatusFlags element.
	 * 
	 * @param attrName
	 * @return
	 */
	public String getScrScreeningStatusFlagsAttrValue(String attrName) {
		return doc.getRootElement()
				.getChild("RxScreeningResponseList")
				.getChild("RxScreeningResponse")
				.getChild("DoseKeyScreeningResultList")
				.getChild("DoseKeyScreeningResult")
				.getChild("DoseModifierScreeningResultList")
				.getChild("DoseModifierScreeningResult")
				.getChild("ScreeningStatusFlags")
				.getAttributeValue(attrName); 
	}

	/**
	 * Return attribute value for the Scr DoseModifierScreeningParms element.
	 * 
	 * @param attrName
	 * @return
	 */
	public String getScrDoseModifierScreeningParmsAttrValue(String attrName) {
		return doc.getRootElement()
				.getChild("RxScreeningResponseList")
				.getChild("RxScreeningResponse")
				.getChild("DoseKeyScreeningResultList")
				.getChild("DoseKeyScreeningResult")
				.getChild("DoseModifierScreeningResultList")
				.getChild("DoseModifierScreeningResult")
				.getChild("DoseModifierScreeningParms")
				.getAttributeValue(attrName); 
	}

	/**
	 * Return attribute value for the Scr DerivedPeriodData element.
	 * 
	 * @param attrName
	 * @return
	 */
	public String getScrDerivedPeriodDataAttrValue(String attrName) {
		return doc.getRootElement()
				.getChild("RxScreeningResponseList")
				.getChild("RxScreeningResponse")
				.getChild("DoseKeyScreeningResultList")
				.getChild("DoseKeyScreeningResult")
				.getChild("DoseModifierScreeningResultList")
				.getChild("DoseModifierScreeningResult")
				.getChild("DerivedPeriodData")
				.getAttributeValue(attrName); 
	}

	/**
	 * Get all PSDMessage texts for Scr errors
	 * @return
	 */
	public String getAllScrErrors() {
		StringBuffer scrErrors = new StringBuffer();
		List<?> psdMessages = doc.getRootElement()
				.getChild("RxScreeningResponseList")
				.getChild("RxScreeningResponse")
				.getChild("DoseKeyScreeningResultList")
				.getChild("DoseKeyScreeningResult")
				.getChild("DoseModifierScreeningResultList")
				.getChild("DoseModifierScreeningResult")
				.getChild("PSDErrorsMessages")
				.getChild("PSDMessageList")
				.getChildren("PSDMessage");
		for (Object psdMessage : psdMessages) {
			scrErrors.append(((Element) psdMessage).getAttributeValue("CATEGORY") + "|");
			scrErrors.append(((Element) psdMessage).getAttributeValue("MSG_TYPE") + "|");
			scrErrors.append(((Element) psdMessage).getAttributeValue("MSG_TEXT") + "|");
		}
		return scrErrors.toString();
	}

	public boolean getAllDoseRecmndDoseAndIntervalValues(String type,String value) {

		int flag=0;
		List<?> doses = doc.getRootElement()
				.getChild("RxRecmndResponseList")
				.getChild("RxRecmndResponse")
				.getChild("DoseKeyRecmndResultList")
				.getChild("DoseKeyRecmndResult")
				.getChild("DoseModifierRecmndResultList")
				.getChild("DoseModifierRecmndResult")
				.getChild("DoseRecmndList")
				.getChildren("DoseRecmnd");

		int i=doses.size();
		if (i > 0) {
			Iterator<?> w = doses.iterator();
			while (w.hasNext()) {
				Element summary = (Element) w.next();
				if ((summary.getAttributeValue("DOSE").equalsIgnoreCase(type))&&(summary.getAttributeValue("INTERVAL").equalsIgnoreCase(value))) {
					System.out.println("success");
					System.out.println("response Value" + (summary.getAttributeValue("DOSE"))+","+(summary.getAttributeValue("INTERVAL")));
					// w.next();
					flag = 1;
					break;
				} else {
					System.out.println("fail");
					System.out.println("response Value" + (summary.getAttributeValue("DOSE"))+","+(summary.getAttributeValue("INTERVAL")));			
				}
			}
		}
		if (flag == 1)
			return true;
		else
			return false;
	}
}




