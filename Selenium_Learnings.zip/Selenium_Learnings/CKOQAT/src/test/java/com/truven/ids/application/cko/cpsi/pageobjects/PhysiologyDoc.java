package com.truven.ids.application.cko.cpsi.pageobjects;


import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class PhysiologyDoc extends CPSIBaseDoc{

	
	
	public PhysiologyDoc(JSONObject jsonObject) {
		super(jsonObject);
	}

	public String getCalculatorResutlsSize() {
		return jo.getJSONObject("Response").getJSONObject("PhysiologyCalculatorResponseList").getString("SIZE");
				
	}
	
	public Boolean verifyPhysiologyMessage(String jsonObject, String jsonArray,String key,String expectedValue) {
	   
	   JSONArray drugsList = jo.getJSONObject("Response").
	         getJSONObject(jsonObject).getJSONArray(jsonArray);
	   // iterate through all returned records
	   
	   for (int i = 0; i < drugsList.length(); i++ ) {
	    JSONObject jo1 = (JSONObject)drugsList.get(i);

	    String imprintCode = jo1.getString(key);
	    
	    if (imprintCode.contains(expectedValue)) {
	       return true;
	    }
	   }
	   return false;
	  }
	
	
	
}
