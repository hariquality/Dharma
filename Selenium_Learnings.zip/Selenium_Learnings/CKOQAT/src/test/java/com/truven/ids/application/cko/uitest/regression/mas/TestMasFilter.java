package com.truven.ids.application.cko.uitest.regression.mas;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.MasDoc;

/**
 * MAS Filter tests
 * 
 * @author APeavy
 * 
 */
public class TestMasFilter extends CKOBaseTest  {

	
	/**
	 * TC186853 TC186854 TC186859 TC186860 TC186861 TC186862 TC186863
	 * Verify TypeFilter:  <TypeFilter NAME=\"DRUG\" />
	 * 
	 * @throws Exception
	 */
	@Test
	public void testTypeFilter() throws Exception {
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\"6/15/1971\" SMOKER=\"TRUE\" PREGNANT=\"TRUE\" LACTATING=\"TRUE\"/>" + 
				"  <NewDrugList SIZE=\"4\">" + 
				"    <Drug CODE=\"00182-1908-01\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"00108-5012-20\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"00056-0169-70\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"114423\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <AllergenList SIZE=\"1\">" + 
				"    <Allergen CODE=\"12843-0363-67\" TYPE=\"NDC\" />" + 
				"  </AllergenList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(), "45", "Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(), "45","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"9", "Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"), "3", "Number of Drug warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("FOOD"),"15","Number of Food warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("ETHANOL"), "3", "Number of Ethanol warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("LAB"), "4", "Number of Lab warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("TOBACCO"), "1","Number of Tobacco warnings" ); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DISEASE"), "8", "Number of Disease warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("ALLERGY"),"1","Number of Allergy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("PREGNANCY"), "5", "Number of Pregnancy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("LACTATION"), "5", "Number of Lactation warnings");
		
		// DRUG only
		doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\"6/15/1971\" SMOKER=\"TRUE\" PREGNANT=\"TRUE\" LACTATING=\"TRUE\"/>" + 
				"  <NewDrugList SIZE=\"4\">" + 
				"    <Drug CODE=\"00182-1908-01\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"00108-5012-20\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"00056-0169-70\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"114423\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <AllergenList SIZE=\"1\">" + 
				"    <Allergen CODE=\"12843-0363-67\" TYPE=\"NDC\" />" + 
				"  </AllergenList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"DRUG\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(), "3", "Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(), "3","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(), "1", "Type Summary"); // only one type (DRUG)
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"), "3", "Number of Drug warnings"); // only drug warnings

		// DISEASE, ALLERGY, PREGNANCY, LACTATION only
		doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\"6/15/1971\" SMOKER=\"TRUE\" PREGNANT=\"TRUE\" LACTATING=\"TRUE\"/>" + 
				"  <NewDrugList SIZE=\"4\">" + 
				"    <Drug CODE=\"00182-1908-01\" TYPE=\"NDC\" />" +  
				"    <Drug CODE=\"00108-5012-20\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"00056-0169-70\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"114423\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <AllergenList SIZE=\"1\">" + 
				"    <Allergen CODE=\"12843-0363-67\" TYPE=\"NDC\" />" + 
				"  </AllergenList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"DISEASE\" />" + 
				"    <TypeFilter NAME=\"ALLERGY\" />" + 
				"    <TypeFilter NAME=\"PREGNANCY\" />" + 
				"    <TypeFilter NAME=\"LACTATION\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(), "19", "Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"19", "Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"4", "Type Summary"); // only one type (DRUG)
		Assert.assertEquals(doc.getNumberOfWarningsByType("DISEASE"), "8", "Number of Disease warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("ALLERGY"), "1", "Number of Allergy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("PREGNANCY"), "5", "Number of Pregnancy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("LACTATION"), "5","Number of Lactation warnings");
		
	}
	
	/**
	 * TC186855 TC186856 TC186857 TC186858
	 * Verify Severity Filter:  example: SEVERITY="MINOR" />
	 * 
	 * @throws Exception
	 */
	@Test
	public void testSeverityFilter() throws Exception {
		System.out.println("===========  Start of 'MINOR' ==============");
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\"6/15/1971\" SMOKER=\"TRUE\" PREGNANT=\"TRUE\" LACTATING=\"TRUE\"/>" + 
				"  <NewDrugList SIZE=\"4\">" + 
				"    <Drug CODE=\"00182-1908-01\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"00108-5012-20\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"00056-0169-70\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"114423\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <AllergenList SIZE=\"1\">" + 
				"    <Allergen CODE=\"12843-0363-67\" TYPE=\"NDC\" />" + 
				"  </AllergenList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"MINOR\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"45","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(), "45", "Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"9", "Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"3", "Number of Drug warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("FOOD"), "15", "Number of Food warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("ETHANOL"), "3", "Number of Ethanol warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("LAB"),"4", "Number of Lab warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("TOBACCO"), "1","Number of Tobacco warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DISEASE"),"8", "Number of Disease warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("ALLERGY"), "1", "Number of Allergy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("PREGNANCY"),"5", "Number of Pregnancy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("LACTATION"), "5", "Number of Lactation warnings");

		System.out.println("===========  Start of 'MODERATE' ==============");
		doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\"6/15/1971\" SMOKER=\"TRUE\" PREGNANT=\"TRUE\" LACTATING=\"TRUE\"/>" + 
				"  <NewDrugList SIZE=\"4\">" + 
				"    <Drug CODE=\"00182-1908-01\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"00108-5012-20\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"00056-0169-70\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"114423\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <AllergenList SIZE=\"1\">" + 
				"    <Allergen CODE=\"12843-0363-67\" TYPE=\"NDC\" />" + 
				"  </AllergenList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"MODERATE\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"39", "Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"39", "Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(), "8", "Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"3", "Number of Drug warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("FOOD"),"15", "Number of Food warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("ETHANOL"), "3", "Number of Ethanol warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("TOBACCO"), "1", "Number of Tobacco warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DISEASE"),"8","Number of Disease warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("ALLERGY"), "1", "Number of Allergy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("PREGNANCY"),"5","Number of Pregnancy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("LACTATION"), "3", "Number of Lactation warnings");

		System.out.println("===========  Start of 'MAJOR' ==============");
		doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\"6/15/1971\" SMOKER=\"TRUE\" PREGNANT=\"TRUE\" LACTATING=\"TRUE\"/>" + 
				"  <NewDrugList SIZE=\"4\">" + 
				"    <Drug CODE=\"00182-1908-01\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"00108-5012-20\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"00056-0169-70\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"114423\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <AllergenList SIZE=\"1\">" + 
				"    <Allergen CODE=\"12843-0363-67\" TYPE=\"NDC\" />" + 
				"  </AllergenList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"MAJOR\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(), "16", "Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(), "16", "Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(), "7", "Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"), "1", "Number of Drug warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("FOOD"),"2", "Number of Food warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("TOBACCO"), "1", "Number of Tobacco warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DISEASE"),"8","Number of Disease warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("ALLERGY"), "1", "Number of Allergy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("PREGNANCY"), "1", "Number of Pregnancy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("LACTATION"),"2", "Number of Lactation warnings");

		System.out.println("===========  Start of 'CONTRAINDICATED' ==============");
		doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\"6/15/1971\" SMOKER=\"TRUE\" PREGNANT=\"TRUE\" LACTATING=\"TRUE\"/>" + 
				"  <NewDrugList SIZE=\"4\">" + 
				"    <Drug CODE=\"00182-1908-01\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"00108-5012-20\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"00056-0169-70\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"114423\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <AllergenList SIZE=\"1\">" + 
				"    <Allergen CODE=\"12843-0363-67\" TYPE=\"NDC\" />" + 
				"  </AllergenList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"CONTRAINDICATED\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(), "5", "Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(), "5", "Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(), "3", "Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DISEASE"), "3", "Number of Disease warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("ALLERGY"), "1", "Number of Allergy warnings"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("PREGNANCY"), "1", "Number of Pregnancy warnings"); 

	}
	
	/**
	 * TC186876 TC168677 TC168678
	 * documentation filter
	 * 
	 * @throws Exception
	 */
	@Test
	public void testDocumentationFilter() throws Exception {
		System.out.println("========== starting .testDocumentationFilter()");
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"CONSUMER\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"MALE\" BIRTH_DATE=\"" + 
				getBirthdateForGivenAgeInYears(50) +
				"\" SMOKER=\"FALSE\" PREGNANT=\"FALSE\" LACTATING=\"FALSE\"/>" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"100229\" TYPE=\"GFC\" />" + 
				"    <Drug CODE=\"00007-4471-20\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"FAIR\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		System.out.println("========== End of request .testDocumentationFilter()");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"7", "Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(), "7", "Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(), "4", "Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"), "1", "Number of DRUG warnings");
		Assert.assertEquals(doc.getNumberOfWarningsByType("FOOD"), "4","Number of FOOD warnings");
		Assert.assertEquals(doc.getNumberOfWarningsByType("ETHANOL"), "1", "Number of ETHANOL warnings");
		Assert.assertEquals(doc.getNumberOfWarningsByType("DISEASE"),"1", "Number of DISEASE warnings");
		
		doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"CONSUMER\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"MALE\" BIRTH_DATE=\"" + 
				getBirthdateForGivenAgeInYears(50) +
				"\" SMOKER=\"FALSE\" PREGNANT=\"FALSE\" LACTATING=\"FALSE\"/>" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"100229\" TYPE=\"GFC\" />" + 
				"    <Drug CODE=\"00007-4471-20\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"GOOD\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"3", "Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(), "3", "Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(), "2", "Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("FOOD"), "2","Number of FOOD warnings");
		Assert.assertEquals(doc.getNumberOfWarningsByType("DISEASE"),"1","Number of DISEASE warnings");

		doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"CONSUMER\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"MALE\" BIRTH_DATE=\"" + 
				getBirthdateForGivenAgeInYears(50) +
				"\" SMOKER=\"FALSE\" PREGNANT=\"FALSE\" LACTATING=\"FALSE\"/>" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"100229\" TYPE=\"GFC\" />" + 
				"    <Drug CODE=\"00007-4471-20\" TYPE=\"NDC\" />" + 
				"  </NewDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"EXCELLENT\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"ALL_TYPES\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(), "1", "Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(), "1", "Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(), "1", "Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DISEASE"), "1", "Number of DISEASE warnings");
	}

}
