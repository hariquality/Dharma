package com.truven.ids.application.cko.cpsi.testsuite;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.cpsi.pageobjects.MasDoc;
import com.truven.ids.application.cko.uitest.CPSIBaseTest;

public class TestMAS_Validation extends CPSIBaseTest{
	
	@Test 
	public void testMASProfileRequest() throws Exception {
	   System.out.println("In method 'testMASProfileRequest'");
	   MasDoc doc = getMASResultDoc("mas_services/MASProfileRequest");
	   Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"MasValidateResult",
                        "Server not connected OR Response is not displayed");
	   Assert.assertTrue(doc.verifyMAsResponseContains("Drug: 12345-6789-10 Not in the Micromedex Screening Database: 12345-6789-10"),"Expected Response is incorrect");
	  }
	
	
	@Test 
	public void testMASDrugScreeningRequest() throws Exception {
    System.out.println("In method 'testMASDrugScreeningRequest'");
    MasDoc doc = getMASResultDoc("mas_services/MASDrugScreeningRequest");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"MasResult",
                        "Server not connected OR Response is not displayed");
    Assert.assertTrue(
               doc.verifyMAsResponseContains("There may be a contraindication to the use of COUMADIN in patients with Tuberculosis."),"Expected Response is incorrect");
   }
		
	
	@Test 
	public void testMASMonographRequest() throws Exception {
    System.out.println("In method 'testMASDrugScreeningRequest'");
    MasDoc doc = getMASResultDoc("mas_services/MASMonographRequest");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"MasMonographResult",
                        "Server not connected OR Response is not displayed");
    Assert.assertTrue(
               doc.verifyMAS_Monograph_Text("Concurrent use of NSAIDS and THIAZIDE DIURETICS"),"Expected Response is incorrect");
   }
	
	
	@Test 
	public void testMASScreeningForAllergyRequest() throws Exception {
    System.out.println("In method 'testMASScreeningForAllergyRequest'");
    MasDoc doc = getMASResultDoc("mas_services/MasScreening_Request_1");
    Assert.assertEquals(doc.getErrorListSize(),"1","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"MasResult",
                        "Server not connected OR Response is not displayed");
    Assert.assertTrue(
               doc.verifyMAsResponseContains("It is recommended that you be consistent with how you take your theophylline"),"Expected Response is incorrect");
   }
	
	@Test 
	public void testMASScreeningForProfessional_Pregnant() throws Exception {
    System.out.println("In method 'testMASScreeningForProfessional'");
    MasDoc doc = getMASResultDoc("mas_services/MasScreening_Request_2");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"MasResult",
                        "Server not connected OR Response is not displayed");
    Assert.assertTrue(
               doc.verifyMAsResponseContains("BISACODYL and ALUMINUM, CALCIUM OR MAGNESIUM CONTAINING PRODUCTS "),"Expected Response is incorrect");
   }
	
	@Test 
	public void testMASScreeningForProfessional_Allergy() throws Exception {
    System.out.println("In method 'testMASScreeningForProfessional'");
    MasDoc doc = getMASResultDoc("mas_services/MasScreening_Request_3");
    Assert.assertEquals(doc.getErrorListSize(),"1","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"MasResult",
                        "Server not connected OR Response is not displayed");
    Assert.assertTrue(
               doc.verifyMAsResponseContains("Concurrent use of THEOPHYLLINE and FOOD"),"Expected Response is incorrect");
   }
	 
	
	@Test 
	public void testMASValidateRequestFor_NDC_Allergy_ICD9() throws Exception {
    System.out.println("In method 'testMASValidateRequestFor_InactiveNDC'");
    MasDoc doc = getMASResultDoc("mas_services/MasValidate_Request_1");
    Assert.assertEquals(doc.getErrorListSize(),"1","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"MasResult",
                        "Server not connected OR Response is not displayed");
    Assert.assertTrue(
               doc.verifyMAsResponseContains("Concurrent use of THEOPHYLLINE and FOOD"),"Expected Response is incorrect");
   }
	
	@Test 
	public void testMASValidateRequestFor_InactiveNDC() throws Exception {
    System.out.println("In method 'testMASValidateRequestFor_InactiveNDC'");
    MasDoc doc = getMASResultDoc("mas_services/MasValidate_Request_2");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"MasValidateResult",
                        "Server not connected OR Response is not displayed");
    Assert.assertTrue(
               doc.verifyMAsResponseContains("Drug: 12345-6789-10 Not in the Micromedex Screening Database: 12345-6789-10"),"Expected Response is incorrect");
   }
	
	
	@Test 
	public void testMASValidateRequestForGFC_Allergy_ICD9() throws Exception {
    System.out.println("In method 'testMASValidateRequestForGFC_Allergy_ICD9'");
    MasDoc doc = getMASResultDoc("mas_services/MasValidate_Request_3");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"MasValidateResult",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("WARNING_TOTAL"),"0","Server not connected OR Response is not displayed");
   }
	
	@Test 
	public void testMASValidateRequestForNDC_GFC() throws Exception {
    System.out.println("In method 'testMASValidateRequestForNDC_GFC'");
    MasDoc doc = getMASResultDoc("mas_services/MasValidate_Request_4");
    Assert.assertEquals(doc.getErrorListSize(),"1","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"MasResult",
                        "Server not connected OR Response is not displayed");
    Assert.assertTrue(
               doc.verifyMAsResponseContains("Concurrent use of THEOPHYLLINE and FOOD"),"Expected Response is incorrect");
   }
	
	@Test 
	public void testMASValidateRequestForNDC_Allergy_ICD9() throws Exception {
    System.out.println("In method 'testMASScreeningForProfessional'");
    MasDoc doc = getMASResultDoc("mas_services/MasValidate_Request_5");
    Assert.assertEquals(doc.getErrorListSize(),"1","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"MasResult",
                        "Server not connected OR Response is not displayed");
    Assert.assertTrue(
               doc.verifyMAsResponseContains("Concurrent use of THEOPHYLLINE and FOOD"),"Expected Response is incorrect");
   }
		
}
