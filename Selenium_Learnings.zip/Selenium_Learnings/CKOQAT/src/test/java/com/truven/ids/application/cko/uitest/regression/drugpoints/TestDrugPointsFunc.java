package com.truven.ids.application.cko.uitest.regression.drugpoints;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.DrugPointsDoc;

/**
 * 
 * 
 * @author BHreen
 * 
 */
public class TestDrugPointsFunc extends CKOBaseTest  {

	/**
	 * 
	 * TC187355
	 */
@Test
	public void testNDC() throws Exception {
		System.out.println("In method 'testNDC'");
		DrugPointsDoc doc = getDrugPointsResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugPointsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"00026-8514-48\" TYPE=\"NDC\" />"
				+ "</NewDrugList>"
				+ "</DrugPointsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");  // assert no errors
		Assert.assertEquals(doc.getDocumentListSize(),"1");  // assert 1 document
		Assert.assertEquals(doc.getDocumentDrugCodeAttribute(),"00026-8514-48");  // assert correct drug code
		Assert.assertTrue(doc.isPhraseInTextElement("CKO Drugpoints - Ciprofloxacin Hydrochlorid"),
				"Phase 'CKO Drugpoints - Ciprofloxacin Hydrochlorid' not found in text element.");  //assert phrase in text element

	}


	/**
	 * 
	 * TC187356
	 */
@Test
	public void testGFC() throws Exception {
		System.out.println("In method 'testGFC'");
		DrugPointsDoc doc = getDrugPointsResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugPointsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"101296\" TYPE=\"GFC\" />"
				+ "</NewDrugList>"
				+ "</DrugPointsRequest>");
		Assert.assertEquals("0", doc.getErrorListSize());  // assert no errors
		Assert.assertEquals("1", doc.getDocumentListSize());  // assert 1 document
		Assert.assertEquals("101296", doc.getDocumentDrugCodeAttribute());  // assert correct drug code
		Assert.assertTrue(doc.isPhraseInTextElement("CKO Drugpoints - Dronabinol"),
				"Phrase 'CKO Drugpoints - Dronabinol' not found in text element.");  //assert phrase in the title element
	}


	/**
	 * 
	 * TC187357 
	 */
@Test
	public void testGFCAndNDC() throws Exception {
		System.out.println("In method 'testGFCAndNDC'");
		DrugPointsDoc doc = getDrugPointsResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugPointsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"101296\" TYPE=\"GFC\" />"
				+ "<Drug CODE=\"00026-8514-48\" TYPE=\"NDC\" />"
				+ "</NewDrugList>"
				+ "</DrugPointsRequest>");
		Assert.assertEquals("0", doc.getErrorListSize());  // assert no errors
		Assert.assertEquals("2", doc.getDocumentListSize());  // assert 1 document
		Assert.assertEquals("101296|00026-8514-48|", doc.getDocumentDrugCodesAttribute());  // assert correct drug codes

	}


	/**
	 * 
	 * TC187365
	 */
@Test
	public void testGFCBlackBoxWarning() throws Exception {
		System.out.println("In method 'testGFCBlackBoxWarning'");
		DrugPointsDoc doc = getDrugPointsResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugPointsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"119179\" TYPE=\"GFC\" />"
				+ "</NewDrugList>"
				+ "</DrugPointsRequest>");
		Assert.assertEquals("0", doc.getErrorListSize());  // assert no errors
		Assert.assertEquals("1", doc.getDocumentListSize());  // assert 1 document
		Assert.assertEquals("119179", doc.getDocumentDrugCodeAttribute());  // assert correct drug code
		Assert.assertTrue(doc.isPhraseInTextElement("Black Box Warning"),
				"Phrase 'Black Box Warning' not found in text element."); //assert phrase in the text element

	}

	/**
	 * 
	 * TC187366
	 */
@Test
	public void testNDCBlackBoxWarning() throws Exception {
		System.out.println("In method 'testNDCBlackBoxWarning'");
		DrugPointsDoc doc = getDrugPointsResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugPointsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"00185-0550-30\" TYPE=\"NDC\" />"
				+ "</NewDrugList>"
				+ "</DrugPointsRequest>");
		Assert.assertEquals("0", doc.getErrorListSize());  // assert no errors
		Assert.assertEquals("1", doc.getDocumentListSize());  // assert 1 document
		Assert.assertEquals("00185-0550-30", doc.getDocumentDrugCodeAttribute());  // assert correct drug code
		Assert.assertTrue(doc.isPhraseInTextElement("Black Box Warning"),
				"Phrase 'Black Box Warning' not found in text element."); //assert phrase in the text element
	}
	/**
	 * 
	 * TC187367
	 */
@Test
	public void testNDCDoNotConfuse() throws Exception {
		System.out.println("In method 'testNDCDoNotConfuse'");
		DrugPointsDoc doc = getDrugPointsResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugPointsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"00115-3982-01\" TYPE=\"NDC\" />"
				+ "</NewDrugList>"
				+ "</DrugPointsRequest>");
		Assert.assertEquals("0", doc.getErrorListSize());  // assert no errors
		Assert.assertEquals("1", doc.getDocumentListSize());  // assert 1 document
		Assert.assertEquals("00115-3982-01", doc.getDocumentDrugCodeAttribute());  // assert correct drug code
		Assert.assertTrue(doc.isPhraseInTextElement("Do Not Confuse"),
				"Phrase 'Do Not Confuse' not found in text element.");  //assert phrase in the text element	
	}



}
