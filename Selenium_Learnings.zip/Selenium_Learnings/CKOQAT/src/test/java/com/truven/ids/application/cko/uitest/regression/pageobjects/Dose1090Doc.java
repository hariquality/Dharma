package com.truven.ids.application.cko.uitest.regression.pageobjects;

import org.jdom.Document;


/**
 * Dose1090Doc contains Dose1090 specific methods.
 * @author APeavy
 * 
 */
public class Dose1090Doc extends BaseDoc {
	
	public Dose1090Doc(Document inputDoc) {
		super(inputDoc);
	}

	public String getDrugListSize() {
		return doc.getRootElement()
				.getChild("DrugList")
				.getAttributeValue("SIZE");
	}

	public String getFirstDrugCode() {
		return doc.getRootElement()
				.getChild("DrugList")
				.getChild("Drug")
				.getAttributeValue("CODE");
	}

	public String getFirstDrugIndivRangeText() {
		return doc.getRootElement()
				.getChild("DrugList")
				.getChild("Drug")
				.getAttributeValue("INDIVIDUAL_RANGE_TEXT");
	}
	
	public String getFirstDrugPeriodRangeText() {
		return doc.getRootElement()
				.getChild("DrugList")
				.getChild("Drug")
				.getAttributeValue("PERIOD_RANGE_TEXT");
	}
	
	public String getFirstDrugDurationRangeText() {
		return doc.getRootElement()
				.getChild("DrugList")
				.getChild("Drug")
				.getAttributeValue("DURATION_RANGE_TEXT");
	}
	
}
