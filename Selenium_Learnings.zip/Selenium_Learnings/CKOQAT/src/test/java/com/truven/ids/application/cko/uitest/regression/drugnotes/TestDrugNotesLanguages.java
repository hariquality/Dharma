package com.truven.ids.application.cko.uitest.regression.drugnotes;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.DrugNotesDoc;

/**
 * 
 * 
 * @author BHreen
 * 
 */
public class TestDrugNotesLanguages extends CKOBaseTest  {

	
/**
 * Test English with NDC and all other languages with GFC as NDC is converted to GFC 
 * TC18704, TC187033
 */
	@Test
	public void testEnglish() throws Exception {
		System.out.println("In method 'testEnglishDrugNoteResponse'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"English\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"00087-0782-41\" TYPE=\"NDC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");  // assert no errors
		Assert.assertEquals(doc.getDocumentListSize(),"1");  // assert 1 document
		Assert.assertEquals(doc.getDocumentDrugCodeAttribute(),"00087-0782-41");  // assert correct drug code
		Assert.assertTrue(doc.isPhraseInTextElement("EN"),
				"EN' not found in text element.");  //assert phrase in the text element
	}
	
	/**
	 * 
	 * TC187041, TC187039, TC187034
	 */
	@Test
	public void testSpanish() throws Exception {
		System.out.println("In method 'testSpanishDrugNoteResponse'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"Spanish\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"118398\" TYPE=\"GFC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals("0", doc.getErrorListSize());  // assert no errors
		Assert.assertEquals("1", doc.getDocumentListSize());  // assert 1 document
		Assert.assertEquals("118398", doc.getDocumentDrugCodeAttribute());  // assert correct drug code
		Assert.assertTrue(doc.isPhraseInTextElement("ES"),
				"ES' not found in text element.");  //assert phrase in the text element
	}

	/**
	 * 
	 * TC187042`
	 */
	@Test
	public void testArabic() throws Exception {
		System.out.println("In method 'testArabicDrugNoteResponse'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"Arabic\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"118398\" TYPE=\"GFC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals("0", doc.getErrorListSize());  // assert no errors
		Assert.assertEquals("1", doc.getDocumentListSize());  // assert 1 document
		Assert.assertEquals("118398", doc.getDocumentDrugCodeAttribute());  // assert correct drug code
		Assert.assertTrue(doc.isPhraseInTextElement("ar-sa"),
				"ar-sa' not found in text element.");  //assert phrase in the text element
	}
	
	/**
	 * 
	 * TC187043
	 */
	@Test
	public void testChineseSimplified() throws Exception {
		System.out.println("In method 'testChineseSimplifiedDrugNoteResponse'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"Chinese-Simplified\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"118398\" TYPE=\"GFC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals("0", doc.getErrorListSize());  // assert no errors
		Assert.assertEquals("1", doc.getDocumentListSize());  // assert 1 document
		Assert.assertEquals("118398", doc.getDocumentDrugCodeAttribute());  // assert correct drug code
		Assert.assertTrue(doc.isPhraseInTextElement("zh-cn"),
				"zh-cn' not found in text element.");  //assert phrase in the text element
	}
	
	/**
	 * 
	 * TC187044
	 */
	@Test
	public void testChineseTraditional() throws Exception {
		System.out.println("In method 'testChineseTraditionalDrugNoteResponse'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"Chinese-Traditional\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"118398\" TYPE=\"GFC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals("0", doc.getErrorListSize());  // assert no errors
		Assert.assertEquals("1", doc.getDocumentListSize());  // assert 1 document
		Assert.assertEquals("118398", doc.getDocumentDrugCodeAttribute());  // assert correct drug code
		Assert.assertTrue(doc.isPhraseInTextElement("zh-tw"),
				"zh-tw' not found in text element.");  //assert phrase in the text element
	}
	
	/**
	 * 
	 * TC187045
	 */
	@Test
	public void testFrenchCanadian() throws Exception {
		System.out.println("In method 'testFrenchCandianDrugNoteResponse'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"French-Canadian\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"118398\" TYPE=\"GFC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals("0", doc.getErrorListSize());  // assert no errors
		Assert.assertEquals("1", doc.getDocumentListSize());  // assert 1 document
		Assert.assertEquals("118398", doc.getDocumentDrugCodeAttribute());  // assert correct drug code
		Assert.assertTrue(doc.isPhraseInTextElement("fr-ca"),
				"fr-ca' not found in text element.");  //assert phrase in the text element
	}
	
	/**
	 * 
	 * TC187046 TC187055 
	 */
	@Test
	public void testGerman() throws Exception {
		System.out.println("In method 'testGermanDrugNoteResponse'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"German\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"118398\" TYPE=\"GFC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals("0", doc.getErrorListSize());  // assert no errors
		Assert.assertEquals("1", doc.getDocumentListSize());  // assert 1 document
		Assert.assertEquals("118398", doc.getDocumentDrugCodeAttribute());  // assert correct drug code
		Assert.assertTrue(doc.isPhraseInTextElement("de-de"),
				"de-de' not found in text element.");  //assert phrase in the text element
	}
	
	/**
	 * 
	 * TC187047
	 */
	@Test
	public void testItalian() throws Exception {
		System.out.println("In method 'testItalianDrugNoteResponse'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"Italian\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"118398\" TYPE=\"GFC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals("0", doc.getErrorListSize());  // assert no errors
		Assert.assertEquals("1", doc.getDocumentListSize());  // assert 1 document
		Assert.assertEquals("118398", doc.getDocumentDrugCodeAttribute());  // assert correct drug code
		Assert.assertTrue(doc.isPhraseInTextElement("it-it"),
				"it-it' not found in text element.");  //assert phrase in the text element
	}

	
	/**
	 * 
	 * TC187048, TC187056
	 */
	@Test
	public void testJapanese() throws Exception {
		System.out.println("In method 'testJapaneseDrugNoteResponse'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"Japanese\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"118398\" TYPE=\"GFC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals("0", doc.getErrorListSize());  // assert no errors
		Assert.assertEquals("1", doc.getDocumentListSize());  // assert 1 document
		Assert.assertEquals("118398", doc.getDocumentDrugCodeAttribute());  // assert correct drug code
		Assert.assertTrue(doc.isPhraseInTextElement("ja-jp"),
				"ja-jp' not found in text element.");  //assert phrase in the text element
	}
	
	/**
	 * 
	 * TC187049
	 */
	@Test
	public void testKorean() throws Exception {
		System.out.println("In method 'testKoreanDrugNoteResponse'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"Korean\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"118398\" TYPE=\"GFC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals("0", doc.getErrorListSize());  // assert no errors
		Assert.assertEquals("1", doc.getDocumentListSize());  // assert 1 document
		Assert.assertEquals("118398", doc.getDocumentDrugCodeAttribute());  // assert correct drug code
		Assert.assertTrue(doc.isPhraseInTextElement("ko-kr"),
				"ko-kr' not found in text element.");  //assert phrase in the text element
	}
	
	/**
	 * 
	 * TC187050
	 */
	@Test
	public void testPolish() throws Exception {
		System.out.println("In method 'testPolishDrugNoteResponse'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"Polish\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"118398\" TYPE=\"GFC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals("0", doc.getErrorListSize());  // assert no errors
		Assert.assertEquals("1", doc.getDocumentListSize());  // assert 1 document
		Assert.assertEquals("118398", doc.getDocumentDrugCodeAttribute());  // assert correct drug code
		Assert.assertTrue(doc.isPhraseInTextElement("pl-pl"),
				"pl-pl' not found in text element.");  //assert phrase in the text element
	}
	
	/**
	 * 
	 * TC187051
	 */
	@Test
	public void testPortugueseBrazilian() throws Exception {
		System.out.println("In method 'testPortugueseBrazilianDrugNoteResponse'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"Portuguese-Brazilian\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"118398\" TYPE=\"GFC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals("0", doc.getErrorListSize());  // assert no errors
		Assert.assertEquals("1", doc.getDocumentListSize());  // assert 1 document
		Assert.assertEquals("118398", doc.getDocumentDrugCodeAttribute());  // assert correct drug code
		Assert.assertTrue(doc.isPhraseInTextElement("pt-br"),
				"pt-br' not found in text element.");  //assert phrase in the text element
	}
	
	/**
	 * 
	 * TC187052
	 */
	@Test
	public void testRussian() throws Exception {
		System.out.println("In method 'testRussianDrugNoteResponse'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"Russian\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"118398\" TYPE=\"GFC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals("0", doc.getErrorListSize());  // assert no errors
		Assert.assertEquals("1", doc.getDocumentListSize());  // assert 1 document
		Assert.assertEquals("118398", doc.getDocumentDrugCodeAttribute());  // assert correct drug code
		Assert.assertTrue(doc.isPhraseInTextElement("ru-ru"),
				"ru-ru' not found in text element.");  //assert phrase in the text element
	}
	
	/**
	 * 
	 * TC187053
	 */
	@Test
	public void testTurkish() throws Exception {
		System.out.println("In method 'testTurkishDrugNoteResponse'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"Turkish\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"118398\" TYPE=\"GFC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals("0", doc.getErrorListSize());  // assert no errors
		Assert.assertEquals("1", doc.getDocumentListSize());  // assert 1 document
		Assert.assertEquals("118398", doc.getDocumentDrugCodeAttribute());  // assert correct drug code
		Assert.assertTrue(doc.isPhraseInTextElement("tr-tr"),
				"tr-tr' not found in text element.");  //assert phrase in the text element
	}
	
	/**
	 * 
	 * TC187054
	 */
	@Test
	public void testVietnamese() throws Exception {
		System.out.println("In method 'testVietnameseDrugNoteResponse'");
		DrugNotesDoc doc = getDrugNoteResultDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
				+ "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"Vietnamese\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"118398\" TYPE=\"GFC\" />"
				+ "</NewDrugList>"
				+ "</DrugNotesRequest>");
		Assert.assertEquals("0", doc.getErrorListSize());  // assert no errors
		Assert.assertEquals("1", doc.getDocumentListSize());  // assert 1 document
		Assert.assertEquals("118398", doc.getDocumentDrugCodeAttribute());  // assert correct drug code
		Assert.assertTrue(doc.isPhraseInTextElement("vi-vn"),
				"vi-vn' not found in text element.");  //assert phrase in the text element
	}
	

}
