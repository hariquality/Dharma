package com.truven.ids.application.cko.uitest.regression.dose1090;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.Dose1090Doc;

/**
 * Dose1090 Exception tests
 * 
 * @author APeavy
 * 
 */
public class TestDose1090Exception extends CKOBaseTest  {

	/**
	 * TC186959
	 * Verify request without patient age returns error
	 */
	@Test
	public void testWithoutAge() {
		System.out.println("In method 'testWithoutAge'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" ?>"
				+ "<Dose1090Request>"
				+ "<Patient GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"100002\" TYPE=\"GFC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\"1\" PERIOD_AMOUNT=\"1\" DURATION=\"1\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals(doc.getDrugListSize(),"0");  // should be 0 drugs returned
		Assert.assertEquals(doc.getErrorListSize(),"1"); // should be 1 error
		Assert.assertEquals(doc.getErrorListErrorText(),"The Patient's Age must be from 0 - 130");
	}

	/**
	 * TC186960
	 * Verify request without drug code
	 */
	@Test
	public void testWithoutDrugIdentifier() {
		System.out.println("In method 'testWithoutDrugIdentifier'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" ?>"
				+ "<Dose1090Request>"
				+ "<Patient " + getDose1090DateAttributesForGivenAgeInYears(20) + " GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"\" TYPE=\"GFC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\"1\" PERIOD_AMOUNT=\"1\" DURATION=\"1\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("0", doc.getDrugListSize());  // should be 0 drugs returned
		Assert.assertEquals("1", doc.getErrorListSize()); // should be 1 error
		Assert.assertEquals("Invalid GFC format: valid format is 123456.", doc.getErrorListErrorText());
	}
	
	/**
	 * TC186961
	 * Verify request without drug ident type
	 */
	@Test
	public void testWithoutDrugIdentifierType() {
		System.out.println("In method 'testWithoutDrugIdentifierType'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" ?>"
				+ "<Dose1090Request>"
				+ "<Patient " + getDose1090DateAttributesForGivenAgeInYears(20) + " GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"100002\" TYPE=\"\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\"1\" PERIOD_AMOUNT=\"1\" DURATION=\"1\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("0", doc.getDrugListSize());  // should be 0 drugs returned
		Assert.assertEquals("1", doc.getErrorListSize()); // should be 1 error
		Assert.assertEquals("Invalid drug identifier type given: valid values are GFC or NDC.", doc.getErrorListErrorText());
	}
	
	/**
	 * TC186962
	 * Verify request without invalid format GFC
	 */
	@Test
	public void testInvalidFormatGFC() {
		System.out.println("In method 'testInvalidFormatGFC'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" ?>"
				+ "<Dose1090Request>"
				+ "<Patient " + getDose1090DateAttributesForGivenAgeInYears(20) + " GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"abcdef\" TYPE=\"GFC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\"1\" PERIOD_AMOUNT=\"1\" DURATION=\"1\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("0", doc.getDrugListSize());  // should be 0 drugs returned
		Assert.assertEquals("1", doc.getErrorListSize()); // should be 1 error
		Assert.assertEquals("Invalid GFC format: GFC must be numeric.", doc.getErrorListErrorText());
		
		doc = getDose1090ResultDoc("<?xml version=\"1.0\" ?>"
				+ "<Dose1090Request>"
				+ "<Patient " + getDose1090DateAttributesForGivenAgeInYears(20) + " GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"1234567\" TYPE=\"GFC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\"1\" PERIOD_AMOUNT=\"1\" DURATION=\"1\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("0", doc.getDrugListSize());  // should be 0 drugs returned
		Assert.assertEquals("1", doc.getErrorListSize()); // should be 1 error
		Assert.assertEquals("Invalid GFC format: valid format is 123456.", doc.getErrorListErrorText());
	}
	
	/**
	 * TC186963
	 * Verify invalid format for NDC
	 * @throws Exception
	 */
	@Test
	public void testNDCinvalidFormat() throws Exception {
		System.out.println("In method 'testNDCinvalidFormat'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"1234356-1-123\" TYPE=\"NDC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\"1\" PERIOD_AMOUNT=\"1\" DURATION=\"1\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("1", doc.getErrorListSize());
		Assert.assertEquals("0", doc.getDrugListSize());
		Assert.assertEquals("Invalid NDC format: valid format is 12345-6789-10.", doc.getErrorListErrorText());
	}
	
	/**
	 * TC186964
	 * Verify invalid drug type
	 * @throws Exception
	 */
	@Test
	public void testInvalidDrugType() throws Exception {
		System.out.println("In method 'testInvalidDrugType'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"100002\" TYPE=\"ABC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\"1\" PERIOD_AMOUNT=\"1\" DURATION=\"1\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("1", doc.getErrorListSize());
		Assert.assertEquals("0", doc.getDrugListSize());
		Assert.assertEquals("Invalid drug identifier type given: valid values are GFC or NDC.", doc.getErrorListErrorText());
	}
	
	/**
	 * TC186965
	 * Verify error for patient age < 0
	 * @throws Exception
	 */
	@Test
	public void testAgeLessThanZero() throws Exception {
		System.out.println("In method 'testAgeLessThanZero'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient " + getDose1090DateAttributesForGivenAgeInYears(-5) + " GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"100002\" TYPE=\"ABC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\"1\" PERIOD_AMOUNT=\"1\" DURATION=\"1\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("1", doc.getErrorListSize());
		Assert.assertEquals("0", doc.getDrugListSize());
		Assert.assertEquals("The Patient's Age must be from 0 - 130", doc.getErrorListErrorText());
	}
	
	/**
	 * TC186966
	 * Verify error for patient age < a dose1090 record's range
	 * @throws Exception
	 */
	@Test
	public void testLowAge() throws Exception {
		System.out.println("In method 'testLowAge'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient " + getDose1090DateAttributesForGivenAgeInYears(17) + " GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"102699\" TYPE=\"GFC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\"1\" PERIOD_AMOUNT=\"1\" DURATION=\"1\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("1", doc.getErrorListSize());
		Assert.assertEquals("0", doc.getDrugListSize());
		Assert.assertEquals("For the patient specified, no data is available for the given drug identifier.", doc.getErrorListErrorText());
	}
	
	/**
	 * TC186967
	 * Verify error for patient age > a dose1090 record's range
	 * @throws Exception
	 */
	@Test
	public void testHighAge() throws Exception {
		System.out.println("In method 'testHighAge'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient " + getDose1090DateAttributesForGivenAgeInYears(100) + " GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"115052\" TYPE=\"GFC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\"1\" PERIOD_AMOUNT=\"1\" DURATION=\"1\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("1", doc.getErrorListSize());
		Assert.assertEquals("0", doc.getDrugListSize());
		Assert.assertEquals("For the patient specified, no data is available for the given drug identifier.", doc.getErrorListErrorText());
	}
	
	/**
	 * TC186974 TC186983 TC186995 TC187011
	 * Verify error w/ invalid NCPDP unit
	 * @throws Exception
	 */
	@Test
	public void testInvalidNCPDPUnit() throws Exception {
		System.out.println("In method 'testInvalidNCPDPUnit'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"17714-0009-36\" TYPE=\"NDC\" UNIT=\"ZZ\" INDIVIDUAL_AMOUNT=\"1\" PERIOD_AMOUNT=\"1\" DURATION=\"1\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("1", doc.getErrorListSize());
		Assert.assertEquals("0", doc.getDrugListSize());
		Assert.assertEquals("Invalid NCPDP Unit: valid values are GM, ML, or EA.", doc.getErrorListErrorText());
	}
	
	/**
	 * TC186975
	 * indiv dose < 0
	 * @throws Exception
	 */
	@Test
	public void testUnitEA() throws Exception {
		System.out.println("In method 'testUnitEA'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"17714-0009-36\" TYPE=\"NDC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\"-5\" PERIOD_AMOUNT=\"1\" DURATION=\"1\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("1", doc.getErrorListSize());
		Assert.assertEquals("0", doc.getDrugListSize());
		Assert.assertEquals("Invalid Individual Dose: must be greater than or equal to zero.", doc.getErrorListErrorText());
	}
	
	/**
	 * TC186976 TC186985 TC186994 TC187010
	 * Verify error w/ missing NCPDP unit
	 * @throws Exception
	 */
	@Test
	public void testMissingNCPDPUnit() throws Exception {
		System.out.println("In method 'testMissingNCPDPUnit'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"17714-0009-36\" TYPE=\"NDC\" INDIVIDUAL_AMOUNT=\"1\" PERIOD_AMOUNT=\"1\" DURATION=\"1\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("1", doc.getErrorListSize());
		Assert.assertEquals("0", doc.getDrugListSize());
		Assert.assertEquals("No NCPDP unit was given.", doc.getErrorListErrorText());
	}
	
	/**
	 * TC186977 TC186986 TC186996 TC187012
	 * NCPDP unit mismatch
	 * @throws Exception
	 */
	@Test
	public void testUnitMismatch() throws Exception {
		System.out.println("In method 'testUnitMismatch'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"17714-0009-36\" TYPE=\"NDC\" UNIT=\"ML\" INDIVIDUAL_AMOUNT=\"1\" PERIOD_AMOUNT=\"1\" DURATION=\"1\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("1", doc.getErrorListSize());
		Assert.assertEquals("0", doc.getDrugListSize());
		Assert.assertEquals("Given NCPDP unit does not match NCPDP unit in data: cannot retrieve dosing information.", doc.getErrorListErrorText());
	}
	
	@Test
	public void testNDCnotKnown() {
		System.out.println("In method 'testNDCnotKnown'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"12345-6789-01\" TYPE=\"NDC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\"1\" PERIOD_AMOUNT=\"1\" DURATION=\"1\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("0", doc.getDrugListSize());  // should be 0 drugs returned
		Assert.assertEquals("1", doc.getErrorListSize()); // should be 1 error
		Assert.assertEquals("No data exists for the given drug identifier.", doc.getErrorListErrorText());
	}
	
	/**
	 * TC186984 TC186998 TC187015
	 * Test negative Period dose 
	 * @throws Exception
	 */
	@Test
	public void testNegativePeriodDose() throws Exception {
		System.out.println("In method 'testNegativePeriodDose'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"100002\" TYPE=\"GFC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\".5\" PERIOD_AMOUNT=\"-20\" DURATION=\".5\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("1", doc.getErrorListSize());
		Assert.assertEquals("0", doc.getDrugListSize());
		Assert.assertEquals("Invalid Period Dose: must be greater than or equal to zero.", doc.getErrorListErrorText());
	}
	
	/**
	 * TC186990 TC187013
	 * Test negative Duration  
	 * @throws Exception
	 */
	@Test
	public void testNegativeDuration() throws Exception {
		System.out.println("In method 'testNegativeDuration'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"100002\" TYPE=\"GFC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\".5\" PERIOD_AMOUNT=\"5\" DURATION=\"-2\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("1", doc.getErrorListSize());
		Assert.assertEquals("0", doc.getDrugListSize());
		Assert.assertEquals("Invalid Duration: must be greater than or equal to zero.", doc.getErrorListErrorText());
	}
	
	/**
	 * TC186997 TC187014
	 * Test negative Individual Dose
	 * @throws Exception
	 */
	@Test
	public void testNegativeIndividualDose() throws Exception {
		System.out.println("In method 'testNegativeIndividualDose'");
		Dose1090Doc doc = getDose1090ResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"100002\" TYPE=\"GFC\" UNIT=\"EA\" INDIVIDUAL_AMOUNT=\"-5\" PERIOD_AMOUNT=\"5\" DURATION=\".5\" />"
				+ "</NewDrugList>"
				+ "</Dose1090Request>");
		Assert.assertEquals("1", doc.getErrorListSize());
		Assert.assertEquals("0", doc.getDrugListSize());
		Assert.assertEquals("Invalid Individual Dose: must be greater than or equal to zero.", doc.getErrorListErrorText());
	}
	

}
