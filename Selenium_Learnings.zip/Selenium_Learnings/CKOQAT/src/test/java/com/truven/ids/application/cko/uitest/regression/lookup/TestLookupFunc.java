package com.truven.ids.application.cko.uitest.regression.lookup;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.LookupDoc;

/**
 * 
 * 
 * @author APeavy and BHreen
 * 
 */
public class TestLookupFunc extends CKOBaseTest  {

	/**
	 * 
	 * TC187126
	 */
@Test
	public void testTradeName() throws Exception {
		System.out.println("In method 'testTradeName'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='trade_name' VALUE='marin'/>"
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"trade_name|route|form|strength|ndc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("trade_name", "MARIN"),
				"MARIN is not in trade name field");
		

	}
	
	/**
	 * 
	 * TC187127
	 */
@Test
	public void testTradeNameRoute() throws Exception {
		System.out.println("In method 'testTradeNameRoute'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='route' VALUE='buccal'/>"
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"trade_name|route|form|strength|ndc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("route", "Buccal"),
				"Buccal is not in route field");
	

	}
	
	/**
	 * 
	 * TC187128
	 */
	@Test
	public void testTradeNameForm() throws Exception {
		System.out.println("In method 'testTradeNameForm'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='form' VALUE='implant'/>"
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"trade_name|route|form|strength|ndc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("form", "IMPLANT"),
				"IMPLANT is not in form field");
	
		
	}
	
	/**
	 * 
	 * TC187129
	 */
	@Test
	public void testTradeNameStength() throws Exception {
		System.out.println("In method 'testTradeNameStength'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='strength' VALUE='0.02'/>"
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"trade_name|route|form|strength|ndc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("strength", "0.02"),
				"0.02 is not in strength field");
		
	}
	
	/**
	 * 
	 * TC187130 
	 */
	@Test
	public void testTradeNameIncompleteNDC() throws Exception {
		System.out.println("In method 'testTradeNameIncompleteNDC'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='ndc' VALUE='00074-199'/>"
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"trade_name|route|form|strength|ndc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("ndc", "00074-199"),
				"00074-199 is not in ndc field");
		
	}
	
	/**
	 * 
	 * TC187131
	 */
	@Test
	public void testGenericName() throws Exception {
		System.out.println("In method 'testGenericName'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='generic_name' VALUE='dron'/>"
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"generic_name|route_name|form|strength|gfc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("generic_name", "DRON"),
				"dron is not in generic_name field");
		
	}
	
	/**
	 * 
	 * TC187132
	 */
	@Test
	public void testGenericNameRoute() throws Exception {
		System.out.println("In method 'testGenericNameRoute'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='route_name' VALUE='buccal'/>"
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"generic_name|route_name|form|strength|gfc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("route_name", "Buccal"),
				"buccal is not in route_name field");
		
	}
	
	/**
	 * 
	 * TC187133
	 */
	@Test
	public void testGenericNameForm() throws Exception {
		System.out.println("In method 'testGenericNameForm'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='form' VALUE='implant'/>"
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"generic_name|route_name|form|strength|gfc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("form", "IMPLANT"),
				"IMPLANT is not in form field");
		
	}
	
	/**
	 * 
	 * TC187134
	 */
	@Test
	public void testGenericNameStrength() throws Exception {
		System.out.println("In method 'testGenericNameStrength'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='strength' VALUE='0.02'/>"
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"generic_name|route_name|form|strength|gfc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("strength", "0.02"),
				"0.02 is not in strength field");
		
	}
	
	/**
	 * 
	 * TC187135
	 */
	@Test
	public void testGenericNameIncompleteGFC() throws Exception {
		System.out.println("In method 'testGenericNameIncompleteGFC'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GENERIC_NAME'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='gfc' VALUE='10129'/>"
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"generic_name|route_name|form|strength|gfc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("gfc", "10129"),
				"10129 is not in gfc field");
		
	}
	
	
	/**
  * 
  * TC332175
  */
 @Test
 public void testDrugCodeTypeLookUp() throws Exception {
  System.out.println("In method 'testDrugCodeTypeLookUp'");
  LookupDoc doc = getLookupResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
        "<LUSRequest LookUpType='DRUGCODESTYPELOOKUP'/>");
  Assert.assertEquals(doc.getSuccessValue(), "TRUE","LookUP service retuns False value");
  Assert.assertEquals(doc.getErrorListSize(),"0");
  Assert.assertEquals(doc.getLookUpRecordListHeader(),"source_code_type|target_code_type");
  Assert.assertEquals("2", doc.getLookUpRecordFieldCount());
 }
 
 /**
  * 
  * TC332175
  */
 @Test
 public void testDrugCodeLookUp() throws Exception {
  System.out.println("In method 'testDrugCodeLookUp'");
  LookupDoc doc = getLookupResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + 
        "<LUSRequest LookUpType='DRUGCODESLOOKUP'/>");
  Assert.assertEquals(doc.getSuccessValue(), "TRUE","LookUP service retuns False value");
  Assert.assertEquals(doc.getErrorListSize(),"0");
  Assert.assertEquals(doc.getLookUpRecordListHeader(),"source_code_type|source_code_value|target_code_type|target_code_value");
  Assert.assertEquals("4", doc.getLookUpRecordFieldCount());
 }
 
 /**
  * Validation for DrugCodeLookUpForTargetCodeType
  * 
  */
 @Test
 public void testDrugCodeLookUpForTargetCodeType() throws Exception {
    System.out.println("In method 'testDrugCodeLookUpForTargetCodeType'");
    LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
          + "<LUSRequest LookUpType='DRUGCODESLOOKUP'>"
          + "<SearchParameterList SIZE='1'>"
          + "<SearchParameter NAME='target_code_type' VALUE='GFC'/>"
          + "</SearchParameterList>"
          + "</LUSRequest>");
    Assert.assertEquals(doc.getSuccessValue(), "TRUE","LookUP service retuns False value");
    Assert.assertEquals(doc.getErrorListSize(),"0");
    Assert.assertEquals(doc.getLookUpRecordListHeader(),"source_code_type|source_code_value|target_code_type|target_code_value");
    Assert.assertEquals("4", doc.getLookUpRecordFieldCount());
    Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("target_code_type", "GFC"),"Target Code Type is Incorrect");
   }
 
 
 /**
  * Validation for DrugCodeLookUpForTargetCodeValue
  * 
  */
 @Test
 public void testDrugCodeLookUpForTargetCodeValue() throws Exception {
    System.out.println("In method 'testDrugCodeLookUpForTargetCodeValue'");
    LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
          + "<LUSRequest LookUpType='DRUGCODESLOOKUP'>"
          + "<SearchParameterList SIZE='1'>"
          + "<SearchParameter NAME='target_code_value' VALUE='10'/>"
          + "</SearchParameterList>"
          + "</LUSRequest>");
    Assert.assertEquals(doc.getSuccessValue(), "TRUE","LookUP service retuns False value");
    Assert.assertEquals(doc.getErrorListSize(),"0");
    Assert.assertEquals(doc.getLookUpRecordListHeader(),"source_code_type|source_code_value|target_code_type|target_code_value");
    Assert.assertEquals("4", doc.getLookUpRecordFieldCount());
    Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("target_code_value", "10"),"Codes starting with 10 is not in gfc field");
   }
 
 
 /**
  * Validation for DrugCodeLookUpForSourceCodeType
  * 
  */
 @Test
 public void testDrugCodeLookUpForSourceCodeType() throws Exception {
    System.out.println("In method 'testDrugCodeLookUpForSourceCodeType'");
    LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
          + "<LUSRequest LookUpType='DRUGCODESLOOKUP'>"
          + "<SearchParameterList SIZE='1'>"
          + "<SearchParameter NAME='source_code_type' VALUE='ATC'/>"
          + "</SearchParameterList>"
          + "</LUSRequest>");
    Assert.assertEquals(doc.getSuccessValue(), "TRUE","LookUP service retuns False value");
    Assert.assertEquals(doc.getErrorListSize(),"0");
    Assert.assertEquals(doc.getLookUpRecordListHeader(),"source_code_type|source_code_value|target_code_type|target_code_value");
    Assert.assertEquals("4", doc.getLookUpRecordFieldCount());
    Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("source_code_type", "ATC"),"Target Code Type is Incorrect");
   }
 
 
 /**
  * Validation for DrugCodeLookUpForSourceCodeValue
  * 
  */
 @Test
 public void testDrugCodeLookUpForSourceCodeValue() throws Exception {
    System.out.println("In method 'testDrugCodeLookUpForSourceCodeValue'");
    LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
          + "<LUSRequest LookUpType='DRUGCODESLOOKUP'>"
          + "<SearchParameterList SIZE='1'>"
          + "<SearchParameter NAME='source_code_value' VALUE='A'/>"
          + "</SearchParameterList>"
          + "</LUSRequest>");
    Assert.assertEquals(doc.getSuccessValue(), "TRUE","LookUP service retuns False value");
    Assert.assertEquals(doc.getErrorListSize(),"0");
    Assert.assertEquals(doc.getLookUpRecordListHeader(),"source_code_type|source_code_value|target_code_type|target_code_value");
    Assert.assertEquals("4", doc.getLookUpRecordFieldCount());
    Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("source_code_value", ""),"Error: Source codes starting with AB is not present in ATC field");
   }
	
	
}
