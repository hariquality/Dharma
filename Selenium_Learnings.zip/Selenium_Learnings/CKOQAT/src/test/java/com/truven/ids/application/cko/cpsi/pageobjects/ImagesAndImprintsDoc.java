package com.truven.ids.application.cko.cpsi.pageobjects;


import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class ImagesAndImprintsDoc extends CPSIBaseDoc{

	
	
	public ImagesAndImprintsDoc(JSONObject jsonObject) {
		super(jsonObject);
	}

	public String getImagesImprintDrugListSize() {
		return jo.getJSONObject("Response").getJSONObject("DrugList").getString("SIZE");
				
	}
	
	public Boolean verifyImprintCodePresentInDrug(String expectedValue) {
	   
	   JSONArray drugsList = jo.getJSONObject("Response").
	         getJSONObject("DrugList").getJSONArray("Drug");
	   // iterate through all returned records
	   
	   for (int i = 0; i < drugsList.length(); i++ ) {
	    JSONObject jo1 = (JSONObject)drugsList.get(i);


	    JSONArray physicalPropertySet = jo1.getJSONObject("PhysicalPropertySetList")
	          .getJSONArray("PhysicalPropertySet");
	    
	    String imprintCode = ((JSONObject)physicalPropertySet.get(0)).getString("IMPRINT_CODES");
	    
	    if (imprintCode.contains(expectedValue)) {
	       return true;
	    }
	   }
	   return false;
	  }
	
	
	
}
