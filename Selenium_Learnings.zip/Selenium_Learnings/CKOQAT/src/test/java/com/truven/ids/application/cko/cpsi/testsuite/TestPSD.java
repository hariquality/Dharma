package com.truven.ids.application.cko.cpsi.testsuite;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.cpsi.pageobjects.PSDDoc;
import com.truven.ids.application.cko.uitest.CPSIBaseTest;

public class TestPSD extends CPSIBaseTest{

 	@Test 
 	public void testPSD_withRX_DoseKey() throws Exception {
	   System.out.println("In method 'testPSD_withRX_DoseKey'");
	   PSDDoc doc = getPSDResultDoc("psd_dosing/PSDWithRxDoseKeyRequest");
	   Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
	   Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected OR Response is not displayed");
	   Assert.assertTrue(doc.verifyPSD_RxDoseKey("AvailableDoseKeyResponseList","DoseKeyResponse","SNOMED_CONCEPT_ID","35489007"),"Expected Warning messages is not displayed");
	  }
	
	@Test 
	public void testPSD_withOutRX_DoseKey() throws Exception {
    System.out.println("In method 'testPSD_withOutRX_DoseKey'");
    PSDDoc doc = getPSDResultDoc("psd_dosing/PSDWithRxDoseKeyRequest");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected OR Response is not displayed");
    Assert.assertTrue(doc.verifyPSD_RxDoseKey("AvailableDoseKeyResponseList","DoseKeyResponse","SNOMED_CONCEPT_ID","0"),"Expected Warning messages is not displayed");
   }
	
	
	@Test 
	public void testPSD_withOutRX_DoseKeyForGFC() throws Exception {
    System.out.println("In method 'testPSD_withRX_DoseKey'");
    PSDDoc doc = getPSDResultDoc("psd_dosing/PSDDoseKeys_Request");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected OR Response is not displayed");
    Assert.assertTrue(doc.verifyPSD_RxDoseKey("AvailableDoseKeyResponseList","DoseKeyResponse","SNOMED_CONCEPT_ID","69896004"),"Expected Warning messages is not displayed");
   }
	
 @Test 
 public void testPSD_ScreeningRequest() throws Exception {
    System.out.println("In method 'testPSD_ScreeningRequest'");
    PSDDoc doc = getPSDResultDoc("psd_screening/PSDScreeningRequest");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"PSDScreeningResult","Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getPSD_ScreeningValue(),"Cockcroft-Gault","Expected Screening Value is not displayed");
   }

 @Test 
 public void testPSD_ScreeningWithDosingFilter() throws Exception {
    System.out.println("In method 'testPSD_ScreeningWithDosingFilter'");
    PSDDoc doc = getPSDResultDoc("psd_screening/PSDScreening_Request_2");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"PSDScreeningResult","Server not connected OR Response is not displayed");
    Assert.assertTrue(doc.verifyPSD_Screening("MIN_RECOMMENDED_PERIOD_DOSE","20"),"Expected Screening Value is not displayed");
   }
 
 @Test 
 public void testPSD_ScreeningWithOutDosingFilter() throws Exception {
    System.out.println("In method 'testPSD_ScreeningWithDosingFilter'");
    PSDDoc doc = getPSDResultDoc("psd_screening/PSDScreening_Request_3");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"PSDScreeningResult",
                        "Server not connected OR Response is not displayed");
    Assert.assertTrue(doc.verifyPSD_Screening("DOSING_PATH","General"),"Expected Screening Value is not displayed");
   }
 
 
 @Test 
 public void testPSD_RecommendationRequest() throws Exception {
    System.out.println("In method 'testPSD_RecommendationRequest'");
    PSDDoc doc = getPSDResultDoc("psd_recommendation/PSDRecommendationRequest");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"PSDRecommendationResult",
                        "Server not connected OR Response is not displayed");
   }
 
 @Test 
 public void testPSD_RecommendationRequestWithClinician() throws Exception {
    System.out.println("In method 'testPSD_RecommendationRequestWithClinician'");
    PSDDoc doc = getPSDResultDoc("psd_recommendation/PSDRecommendation_Request_1");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"PSDRecommendationResult",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getPSD_ScreeningValue(),"","Expected Screening Value is not displayed");
   
   }
 
 
 @Test 
 public void testPSD_RecommendationRequestWithOutClinician() throws Exception {
    System.out.println("In method 'testPSD_RecommendationRequestWithOutClinician'");
    PSDDoc doc = getPSDResultDoc("psd_recommendation/PSDRecommendation_Request_2");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"PSDRecommendationResult",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getPSD_ScreeningValue(),"Cockcroft-Gault","Expected Screening Value is not displayed");
   }
 
 @Test 
 public void testPSD_RecommendationRequestWithNoDoseKey() throws Exception {
    System.out.println("In method 'testPSD_RecommendationRequestWithNoDoseKey'");
    PSDDoc doc = getPSDResultDoc("psd_recommendation/PSDRecommendation_Request_3");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseType(),"PSDRecommendationResult",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getPSD_ScreeningValue(),"Cockcroft-Gault","Expected Screening Value is not displayed");
   
   }
 
 
 
	
 
		
}
