package com.truven.ids.application.cko.cpsi.pageobjects;


import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class DrugNotesDoc extends CPSIBaseDoc{

	
	
	public DrugNotesDoc(JSONObject jsonObject) {
		super(jsonObject);
	}

	public String getDrugSize() {
		return jo.getJSONObject("Response").getJSONObject("DocumentList").getString("SIZE");
				
	}
	
	public Boolean verifyDrugNotesTextContains(String expectedValue) {
	   
	   JSONArray drugsList = jo.getJSONObject("Response").
	         getJSONObject("DocumentList").getJSONArray("Document");
	   // iterate through all returned records
	   
	   for (int i = 0; i < drugsList.length(); i++ ) {
	    JSONObject jo1 = (JSONObject)drugsList.get(i);

	    String imprintCode = jo1.getString("Text");
	    
	    if (imprintCode.contains(expectedValue)) {
	       return true;
	    }
	   }
	   return false;
	  }
	
	
	
}
