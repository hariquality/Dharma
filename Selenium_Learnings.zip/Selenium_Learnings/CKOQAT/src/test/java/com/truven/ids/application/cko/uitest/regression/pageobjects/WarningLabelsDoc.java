package com.truven.ids.application.cko.uitest.regression.pageobjects;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Document;
import org.jdom.Element;


/**
 * WarningLabelsDoc contains Warning Labels specific methods.
 * @author APeavy
 * 
 */
public class WarningLabelsDoc extends BaseDoc {
	
	public WarningLabelsDoc(Document inputDoc) {
		super(inputDoc);
	}

	public String getDrugListSize() {
		return doc.getRootElement()
				.getChild("DrugList")
				.getAttributeValue("SIZE");
	}

	public String getFirstWarningLabelsListSize() {
		return doc.getRootElement()
				.getChild("DrugList")
				.getChild("Drug")
				.getChild("WarningLabelsList")
				.getAttributeValue("SIZE");
	}
	
	public String getFirstDrugCode() {
		return doc.getRootElement()
				.getChild("DrugList")
				.getChild("Drug")
				.getAttributeValue("CODE");
	}
	
	public String getFirstDrugType() {
		return doc.getRootElement()
				.getChild("DrugList")
				.getChild("Drug")
				.getAttributeValue("TYPE");
	}
	
	public String getFirstWarningLabelText() {
		return doc.getRootElement()
				.getChild("DrugList")
				.getChild("Drug")
				.getChild("WarningLabelsList")
				.getChildText("WarningLabel");
	}
	
	public String getListOfExternalLabelIds() {
		StringBuilder labels = new StringBuilder(); 
		List<?> warningLabels = doc.getRootElement()
				.getChild("DrugList")
				.getChild("Drug")
				.getChild("WarningLabelsList")
				.getChildren("WarningLabel");
		for (Object warningLabel : warningLabels) {
			labels.append(((Element) warningLabel).getAttributeValue("EXTERNAL_LABEL_ID"));
			labels.append("|");
		}
		return labels.toString();
	}
	
	public String getListOfDrugCodes() {
		StringBuilder drugList = new StringBuilder();
		List<?> drugs = doc.getRootElement().getChild("DrugList").getChildren("Drug");
		for (Object drug : drugs) {
			drugList.append(((Element) drug).getAttributeValue("CODE"));
			drugList.append(((Element) drug).getAttributeValue("TYPE"));
			drugList.append("|");
		}
		return drugList.toString();
	}
	
	public String getWarningLabelsListSizeForGivenDrugCode(String code) {
		Map<String, String> drugMap = new HashMap<String, String>();
		drugMap.clear();
		List<?> drugs = doc.getRootElement().getChild("DrugList").getChildren("Drug");
		// populate map of drug code, size
		for (Object drug : drugs) {
			drugMap.put(((Element) drug).getAttributeValue("CODE"), 
					((Element) drug).getChild("WarningLabelsList").getAttributeValue("SIZE") );
		}
		return drugMap.get(code);
	}
	
	
}
