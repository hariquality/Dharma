package com.truven.ids.application.cko.uitest.regression.physiology;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.PhysiologyDoc;

/**
 * 
 * 
 * @author BHreen
 * 
 */
public class TestPhysiologyFunc extends CKOBaseTest  {

	/*
	 * PHYS008.xml Female - 6590 days = 18 year old
	 * 
	 */

	@Test public void testFemaleTypeAll18YearOld() throws Exception {
		System.out.println("In method 'testFemaleTypeAll18YearOld'");
		PhysiologyDoc doc = getPhysiologyResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>" +
				"<PhysiologyCalculatorRequest TYPE='ALL'>" +
				"<Patient GENDER='FEMALE' " +
				" AGE_IN_DAYS='6590'" +     
				" WEIGHT='87' HEIGHT='157'/>" +
				"</PhysiologyCalculatorRequest>");	
		Assert.assertEquals(doc.getPhysiologyCalculatorListSize(),"3");
		Assert.assertEquals(doc.getCalcValueByType("BSA"),"1.874");
		Assert.assertEquals(doc.getCalcValueByType("LBM"),"47.643");
		Assert.assertEquals(doc.getCalcValueByType("IBW"),"49.665");
		Assert.assertEquals(doc.getMessageListSize(),"1");
		Assert.assertEquals(doc.getPhraseInMessageElement(),"Patient's Weight of 87 kg is outside normal range for patient's age and gender of 45.36 to 81.918 kg.|");
	}

	/*
	 * PHYS009.xml Female - 6590 days = 18 year old
	 * 
	 */

	@Test public void testFemaleTypeBSA18YearOld() throws Exception {
		System.out.println("In method 'testFemaleTypeBSA18YearOld'");	
		PhysiologyDoc doc = getPhysiologyResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>" +
				"<PhysiologyCalculatorRequest TYPE='BSA'>" +
				"<Patient GENDER='FEMALE' " +
				" AGE_IN_DAYS='6570'" +        	          
				" WEIGHT='87.0' HEIGHT='157'/>" +
				"</PhysiologyCalculatorRequest>");	
		Assert.assertEquals(doc.getPhysiologyCalculatorListSize(),"1");
		Assert.assertEquals(doc.getCalcValueByType("BSA"),"1.874");
		Assert.assertEquals(doc.getMessageListSize(),"1");
		Assert.assertEquals(doc.getPhraseInMessageElement(),"Patient's Weight of 87 kg is outside normal range for patient's age and gender of 45.36 to 81.918 kg.|");
	}

	/*
	 * PHYS0010.xml Female - 6590 days = 18 year old
	 * 
	 */

	@Test public void testFemaleTypeIBW18YearOld() throws Exception {
		System.out.println("In method 'testFemaleTypeIBW18YearOld'");	
		PhysiologyDoc doc = getPhysiologyResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>" +
				"<PhysiologyCalculatorRequest TYPE='IBW'>" +
				"<Patient GENDER='FEMALE' " +
				" AGE_IN_DAYS='6590'" +        	          
				" WEIGHT='87.0' HEIGHT='157'/>" +
				"</PhysiologyCalculatorRequest>");	
		Assert.assertEquals(doc.getPhysiologyCalculatorListSize(),"1");
		Assert.assertEquals(doc.getCalcValueByType("IBW"),"49.665");
		Assert.assertEquals(doc.getMessageListSize(),"1");
		Assert.assertEquals(doc.getPhraseInMessageElement(),"Patient's Weight of 87 kg is outside normal range for patient's age and gender of 45.36 to 81.918 kg.|");

	}
	
	/*
	 * PHYS0011.xml Female - 35070 days = 96 year old - no message
	 * 
	 */

	@Test public void testFemaleTypeIBW96YearOld() throws Exception {
		System.out.println("In method 'testFemaleTypeIBW96YearOld'");	
		PhysiologyDoc doc = getPhysiologyResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>" +
				"<PhysiologyCalculatorRequest TYPE='IBW'>" +
				"<Patient GENDER='FEMALE' " +
				" AGE_IN_DAYS='35070'" +        	          
				" WEIGHT='45' HEIGHT='147'/>" +
				"</PhysiologyCalculatorRequest>");	
		Assert.assertEquals(doc.getPhysiologyCalculatorListSize(),"1");
		Assert.assertEquals(doc.getCalcValueByType("IBW"),"45");		

	}

	/*
	 * PHYS0012.xml Male - 23015 days = 63 year old - no message
	 * 
	 */

	@Test public void testMaleTypeIBW63YearOld() throws Exception {
		System.out.println("In method 'testMaleTypeIBW63YearOld'");	
		PhysiologyDoc doc = getPhysiologyResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>" +
				"<PhysiologyCalculatorRequest TYPE='IBW'>" +
				"<Patient GENDER='MALE' " +
				" AGE_IN_DAYS='23015'" +        	          
				" WEIGHT='118' HEIGHT='183'/>" +
				"</PhysiologyCalculatorRequest>");	
		Assert.assertEquals(doc.getPhysiologyCalculatorListSize(),"1");
		Assert.assertEquals(doc.getCalcValueByType("IBW"),"77.709");		

	}

	/*
	 * PHYS0013.xml Male - 35060 days = 96 year old 
	 * 
	 */

	@Test public void testMaleTypeIBW96YearOld() throws Exception {
		System.out.println("In method 'testMaleTypeIBW96YearOld'");	
		PhysiologyDoc doc = getPhysiologyResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>" +
				"<PhysiologyCalculatorRequest TYPE='IBW'>" +
				"<Patient GENDER='MALE' " +
				" AGE_IN_DAYS='35060'" +        	          
				" WEIGHT='50' HEIGHT='149'/>" +
				"</PhysiologyCalculatorRequest>");	
		Assert.assertEquals(doc.getPhysiologyCalculatorListSize(),"1");
		Assert.assertEquals(doc.getCalcValueByType("IBW"),"49.457");	
		Assert.assertEquals(doc.getMessageListSize(),"2");
		Assert.assertEquals(doc.getPhraseInMessageElement(),"Patient's Weight of 50 kg is outside normal range for patient's age and gender of 56.159 to 101.441 kg.|Patient's Height of 149 cm is outside normal range for patient's age and gender of 156.468 to 186.132 cm.|");


	}

	/*
	 * PHYS0014.xml Female - 6955 days = 19 year old 
	 * 
	 */

	@Test public void testFemaleTypeIBW19YearOld() throws Exception {
		System.out.println("In method 'testFemaleTypeIBW19YearOld'");	
		PhysiologyDoc doc = getPhysiologyResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>" +
				"<PhysiologyCalculatorRequest TYPE='IBW'>" +
				"<Patient GENDER='FEMALE' " +
				" AGE_IN_DAYS='6955'" +        	          
				" WEIGHT='10' HEIGHT='167'/>" +
				"</PhysiologyCalculatorRequest>");	
		Assert.assertEquals(doc.getPhysiologyCalculatorListSize(),"1");
		Assert.assertEquals(doc.getCalcValueByType("IBW"),"10");	
		Assert.assertEquals(doc.getMessageListSize(),"1");
		Assert.assertEquals(doc.getPhraseInMessageElement(),"Patient's Weight of 10 kg is outside normal range for patient's age and gender of 45.97 to 82.93 kg.|");

	}

	/*
	 * PHYS0015.xml Female - 5860 days = 16 year old 
	 * 
	 */

	@Test public void testFemaleTypeIBW16YearOld() throws Exception {
		System.out.println("In method 'testFemaleTypeIBW16YearOld'");	
		PhysiologyDoc doc = getPhysiologyResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>" +
				"<PhysiologyCalculatorRequest TYPE='IBW'>" +
				"<Patient GENDER='FEMALE' " +
				" AGE_IN_DAYS='5860'" +        	          
				" WEIGHT='68' HEIGHT='175'/>" +
				"</PhysiologyCalculatorRequest>");	
		Assert.assertEquals(doc.getPhysiologyCalculatorListSize(),"1");
		Assert.assertEquals(doc.getCalcValueByType("IBW"),"62.398");	
		Assert.assertEquals(doc.getMessageListSize(),"1");
		Assert.assertEquals(doc.getPhraseInMessageElement(),"Patient's Height of 175 cm is outside normal range for patient's age and gender of 151.942 to 173.551 cm.|");

	}

}
