package com.truven.ids.application.cko.uitest.regression.pageobjects;

import java.util.List;

import org.jdom.Document;
import org.jdom.Element;


/**
 * DrugNotesDoc to contain DrugNotes specific methods
 * @author APeavy
 * 
 */
public class DrugPointsDoc extends BaseDoc {

	public DrugPointsDoc(Document inputDoc) {
		super(inputDoc);
	}

	public String getDocumentListSize() {
		return doc.getRootElement()
				.getChild("DocumentList")
				.getAttributeValue("SIZE");
	}

	public String getDocumentDrugCodeAttribute() {
		return doc.getRootElement()
				.getChild("DocumentList")
				.getChild("Document")
				.getAttributeValue("DRUG_CODE");
	}
	
	public String getDocumentDrugCodesAttribute() {
		StringBuilder codes = new StringBuilder();
		List<?> dCodes = doc.getRootElement()
				.getChild("DocumentList")
				.getChildren("Document");
					for (Object dCode : dCodes){
						codes.append(((Element)dCode) .getAttributeValue("DRUG_CODE"));
						codes.append('|');
					}
						return codes.toString();
		}
	


	public Boolean isPhraseInTextElement(String phrase) {
		if (doc.getRootElement()
				.getChild("DocumentList")
				.getChild("Document")
				.getChildText("Text").contains(phrase)) {
			return true;
		} else return false;
	}



	public Boolean isPhraseInErrorElement(String phrase) {
		if (doc.getRootElement()
				.getChild("ErrorList")
				.getChild("Error")
				.getAttributeValue("ERROR_TEXT").contains(phrase)) {
			return true;
		} else return false;
	}

}
