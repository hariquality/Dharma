package com.truven.ids.application.cko.uitest.regression.pageobjects;

import java.util.Iterator;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.XMLOutputter;

/**
 * BasePage to contain common XML document methods
 * 
 * @author APeavy
 * 
 */
public class BaseDoc {

	Document doc;

	public BaseDoc(Document inputDoc) {
		doc = inputDoc;
	}

	public String getSuccessValue() {
		return doc.getRootElement().getAttributeValue("SUCCESS");
	}

	public String getErrorListSize() {
		if (doc.getRootElement().getChild("ErrorList") == null) {
			return "0";
		} else {
			System.out.println("Errors from the ErrorList:\n" + extractErrors());
			return doc.getRootElement().getChild("ErrorList").getAttributeValue("SIZE");

		}
	}

	public String getErrorListErrorText() {
		return doc.getRootElement().getChild("ErrorList").getChild("Error").getAttributeValue("ERROR_TEXT");
	}

	private String extractErrors() {
		StringBuilder sb = new StringBuilder();
		Iterator<?> itr = (doc.getRootElement().getChild("ErrorList").getChildren("Error")).iterator();
		while (itr.hasNext()) {
			Element error = (Element) itr.next();
			try {
				sb.append(XMLOutputter.class.newInstance().outputString(error));
			} catch (InstantiationException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
			sb.append("\n");
		}
		return sb.toString();

	}

}
