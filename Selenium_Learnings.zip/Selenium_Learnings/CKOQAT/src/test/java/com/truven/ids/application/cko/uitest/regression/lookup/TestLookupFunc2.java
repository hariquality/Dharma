package com.truven.ids.application.cko.uitest.regression.lookup;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.LookupDoc;

/**
 * 
 * 
 * @author APeavy and BHreen
 * 
 */
public class TestLookupFunc2 extends CKOBaseTest  {
	/**
	 * 
	 * TC187136
	 */
@Test
	public void testGFCNCPDPIncompleteGFC() throws Exception {
		System.out.println("In method 'testGFCNCPDPIncompleteGFC'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GFCNCPDP'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='gfc' VALUE='1032'/>"
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"gfc|ncpdp");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("gfc", "1032"),
				"1032 is not in gfc field");

	}

	/**
	 * 
	 * TC187137
	 */
@Test
	public void testGFCNCPDPValue() throws Exception {
		System.out.println("In method 'testGFCNCPDPValue'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='GFCNCPDP'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='ncpdp' VALUE='ML'/>"
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"gfc|ncpdp");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("ncpdp", "ML"),
				"ML is not in ncpdp field");

	}

	/**
	 * 
	 * TC187138
	 */
@Test
	public void testAllergyIncompleteTerm() throws Exception {
		System.out.println("In method 'testAllergyIncompleteTerm'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='ALLERGY'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='allergy_name' VALUE='acetamin'/>"
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"allergy_name|mdxalg");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("allergy_name", "ACETAMIN"),
				"acetamin is not in allergy_name field");

	}

	/**
	 * 
	 * TC187138
	 */
@Test
	public void testAllergyMDXALG() throws Exception {
		System.out.println("In method 'testAllergyIncompleteTerm'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='ALLERGY'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='mdxalg' VALUE='7700223'/>"
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"allergy_name|mdxalg");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("mdxalg", "7700223"),
				"7700223 is not in mdxalg field");

	}

	/**
	 * 
	 * TC187140
	 */
@Test
	public void testLookupLanguageRequest() throws Exception {
		System.out.println("In method 'testLookupLanguageRequest'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='LANGUAGE'>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"language_code|language_name");
		Assert.assertEquals (doc.getLookUpRecordListSize(),"2");
	}

	/**
	 * 
	 * TC187141
	 */

@Test
	public void testNDCCFGIncompleteNDC() throws Exception {
		System.out.println("In method 'testNDCCFGIncompleteNDC'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='NDCGFC'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='ndc' VALUE='00074-199'/>"
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"ndc|gfc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("ndc", "00074-199"),
				"00074-199 is not in ndc field");

	}

	/**
	 * 
	 * TC187142
	 */

@Test
	public void testNDCCFGIncompleteGFC() throws Exception {
		System.out.println("In method 'testNDCCFGIncompleteGFC'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='NDCGFC'>"
				+ "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='gfc' VALUE='10129'/>"
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"ndc|gfc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("gfc", "10129"),
				"10129 is not in gfc field");

	}

	/**
	 * 
	 * TC187143
	 */

@Test
	public void testTradeNameWithTwoQualifiers() throws Exception {
		System.out.println("In method 'testTradeNameWithTwoQualifiers'");
		LookupDoc doc = getLookupResultDoc("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME'>"
				+ "<SearchParameterList SIZE='2' OPERATOR='and'>"		
				+ "<SearchParameter NAME='trade_name' VALUE='marinol'/>"
				+ "<SearchParameter NAME='form' VALUE='capsule, liquid filled'/>"
				+ "</SearchParameterList>"
				+ "</LUSRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getLookUpRecordListHeader(),"trade_name|route|form|strength|ndc");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("trade_name", "MARINOL"),
				"marinol is not in trade_name field");
		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("form", "CAPSULE, LIQUID FILLED"),
				"CAPSULE, LIQUID FILLED is not in the form field");

	}


}
