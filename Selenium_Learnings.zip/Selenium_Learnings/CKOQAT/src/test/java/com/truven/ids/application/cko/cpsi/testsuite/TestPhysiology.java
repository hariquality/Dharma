package com.truven.ids.application.cko.cpsi.testsuite;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.cpsi.pageobjects.CrClDoc;
import com.truven.ids.application.cko.cpsi.pageobjects.PhysiologyDoc;
import com.truven.ids.application.cko.uitest.CPSIBaseTest;

public class TestPhysiology extends CPSIBaseTest{

	@Test 
	public void testPhysiologyForWithWarning() throws Exception {
	   System.out.println("In method 'testPhysiologyForWithWarning'");
	   PhysiologyDoc doc = getPhysiologyResultDoc("physiology_calc/PhysiologyCalcWithWarningRequest");
	   Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
	   Assert.assertTrue(doc.verifyPhysiologyMessage("PSDMessageList","PSDMessage","CATEGORY","WARNING"),"Expected Warning messages is not displayed");
	  }
	
 @Test 
 public void testPhysiologyForWithOutWarning() throws Exception {
    System.out.println("In method 'testPhysiologyForWithOutWarning'");
    CrClDoc doc = getCrclResultDoc("physiology_calc/PhysiologyCalcWithOutWarningRequest");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getResponseValueForAttribute("PSDMessageList"),"null","Warning displayed for valid input request");
   
   }
	
	@Test
	public void testPhysiologyForTypeAll() throws Exception {
    System.out.println("In method 'testPhysiologyForTypeAll'");
    PhysiologyDoc doc = getPhysiologyResultDoc("physiology_calc/PhysiologyCalculator_request_1");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getCalculatorResutlsSize(),"3","Expected PhysiologyCalculatorResponseList is incorrect");
   
   }
	
	@Test
	public void testPhysiologyForTypeBSA() throws Exception {
    System.out.println("In method 'testPhysiologyForTypeBSA'");
    PhysiologyDoc doc = getPhysiologyResultDoc("physiology_calc/PhysiologyCalculator_request_2");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertTrue(doc.verifyPhysiologyMessage("PhysiologyCalculatorResponseList","PhysiologyCalculatorResults","TYPE","BSA"),"Expected Warning messages is not displayed");
   
   }
	
	@Test 
	public void testPhysiologyForTypeLBM() throws Exception {
    System.out.println("In method 'testPhysiologyForTypeLBM'");
    PhysiologyDoc doc = getPhysiologyResultDoc("physiology_calc/PhysiologyCalculator_request_3");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertTrue(doc.verifyPhysiologyMessage("PhysiologyCalculatorResponseList","PhysiologyCalculatorResults","TYPE","LBM"),"Expected Warning messages is not displayed");
   
   }
	
	@Test 
	public void testPhysiologyForTypeIBW() throws Exception {
    System.out.println("In method 'testPhysiologyForTypeIBW'");
    PhysiologyDoc doc = getPhysiologyResultDoc("physiology_calc/PhysiologyCalculator_request_4");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertTrue(doc.verifyPhysiologyMessage("PhysiologyCalculatorResponseList","PhysiologyCalculatorResults","TYPE","IBW"),"Expected Warning messages is not displayed");
   
   }
	
	@Test 
	public void testPhysiologyForTypeALL() throws Exception {
    System.out.println("In method 'testPhysiologyForTypeALL'");
    PhysiologyDoc doc = getPhysiologyResultDoc("physiology_calc/PhysiologyCalculator_request_5");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
    Assert.assertEquals(doc.getCalculatorResutlsSize(),"3","Expected PhysiologyCalculatorResponseList is incorrect");
    Assert.assertTrue(doc.verifyPhysiologyMessage("PhysiologyCalculatorResponseList","PhysiologyCalculatorResults","TYPE","IBW"),"Expected Warning messages is not displayed");
   
   }
		
}
