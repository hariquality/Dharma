package com.truven.ids.application.cko.uitest.regression.imagesimprints;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.ImagesImprintsDoc;

/**
 * 
 * 
 * @author BHreen
 * 
 */
public class TestImagesImprintsFunc2 extends CKOBaseTest  {
	
	/*
	 * TC186926
	 */
@Test
	public void testNDCRequestWithNoStatus() throws Exception {
		System.out.println("In method 'testNDCRequestWithNoStatus'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"54868-1501-00\" TYPE=\"NDC\"/>"
				+ "</NewDrugList>"
				+ "</ImagesImprintsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDrugListSize(),"1");
		Assert.assertEquals(doc.getFirstDrugCode(),"54868-1501-00");
		Assert.assertEquals(doc.getFirstStatus(),"INACTIVE");
	}
	
	/*
	 * TC186927
	 */
	@Test
	public void testNDCRequestWithActiveStatus() throws Exception {
		System.out.println("In method 'testNDCRequestWithActiveStatus'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"00056-0169-70\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "</NewDrugList>"
				+ "</ImagesImprintsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDrugListSize(),"1");
		Assert.assertEquals(doc.getFirstDrugCode(),"00056-0169-70");
		Assert.assertEquals(doc.getFirstStatus(),"ACTIVE");
	}
	
	
	/*
	 * TC186928
	 */
	@Test
	public void testNDCRequestWithInactiveStatus() throws Exception {
		System.out.println("In method 'testNDCRequestWithNoStatus'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"54868-1501-00\" TYPE=\"NDC\" STATUS=\"INACTIVE\"/>"
				+ "</NewDrugList>"
				+ "</ImagesImprintsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDrugListSize(),"1");
		Assert.assertEquals(doc.getFirstDrugCode(),"54868-1501-00");
		Assert.assertEquals(doc.getFirstStatus(),"INACTIVE");
	}
	
	/*
	 * TC186929
	 */
	@Test
	public void testNDCRequestWithIGNOREDStatus() throws Exception {
		System.out.println("In method 'testNDCRequestWithNoStatus'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"54868-1501-00\" TYPE=\"NDC\" STATUS=\"IGNORED\"/>"
				+ "</NewDrugList>"
				+ "</ImagesImprintsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDrugListSize(),"1");
		Assert.assertEquals(doc.getFirstDrugCode(),"54868-1501-00");
		Assert.assertEquals(doc.getFirstStatus(),"INACTIVE");
	}
	
	/*
	 * TC186930
	 */
	
	@Test
	public void testMultipleNDCRequestWithNoStatus() throws Exception {
		System.out.println("In method 'testMultipleNDCRequestWithNoStatus'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"00051-0021-21\" TYPE=\"NDC\"/>"
				+ "<Drug CODE=\"00026-8514-48\" TYPE=\"NDC\"/>"
				+ "</NewDrugList>"
				+ "</ImagesImprintsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDrugListSize(),"2");
		Assert.assertEquals(doc.getFirstDrugCode(),"00051-0021-21");
		Assert.assertEquals(doc.getFirstStatus(),"INACTIVE");
	}
	
	/*
	 * TC186935
	 */
	
	@Test
	public void testFlavor() throws Exception {
		System.out.println("In method 'testFlavor'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"00029-6004-39\" TYPE=\"NDC\"/>"
				+ "</NewDrugList>"
				+ "</ImagesImprintsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDrugListSize(),"1");
		Assert.assertEquals(doc.getFirstDrugCode(),"00029-6004-39");
		Assert.assertEquals(doc.getFirstFlavor(),"Banana-Cherry Mint");
	}

	/*
	 * TC186936 - Wording in response
	 * &quot;Coumadin&quot; is over &quot;1&quot; and the score runs across the &quot;1&quot;.
	 */
	@Test
	public void testImprintDescription() throws Exception {
		System.out.println("In method 'testNDCWithStatusInactive'");
		ImagesImprintsDoc doc = getImagesImprintsResultDoc("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsRequest>"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"00056-0169-70\" TYPE=\"NDC\"/>"
				+ "</NewDrugList>"
				+ "</ImagesImprintsRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0");
		Assert.assertEquals(doc.getDrugListSize(),"1");
		Assert.assertEquals(doc.getFirstDrugCode(),"00056-0169-70");
		//Assert.assertEquals("&quot;Coumadin&quot; is over &quot;1&quot; and the score runs across the &quot;1&quot;.", doc.getFirstImprintDescription());
		Assert.assertTrue(doc.getFirstImprintDescription().contains("and the score runs across the"));
		
		
	}

}
