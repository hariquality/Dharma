package com.truven.ids.application.cko.uitest.regression.mas;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.MasDoc;

/**
 * MAS Order ID tests
 * 
 * @author APeavy
 * 
 */
public class TestMasOrder extends CKOBaseTest  {

	/**
	 * TC186881
	 * Verifying Order ID attributes associate to their given
	 * Drug items
	 * 
	 * @throws Exception
	 */
	@Test
	public void testOrderIDDrugAttribute() throws Exception {
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\""
				+ getBirthdateForGivenAgeInYears(40)
				+ "\" SMOKER=\"TRUE\" PREGNANT=\"TRUE\" LACTATING=\"TRUE\"/>" + 
				"  <CurrentDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"102472\" TYPE=\"GFC\" ORDER_ID=\"current\" />" + 
				"  </CurrentDrugList>" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"105848\" TYPE=\"GFC\" ORDER_ID=\"new1\" />" + 
				"    <Drug CODE=\"104050\" TYPE=\"GFC\" ORDER_ID=\"new2\" />" + 
				"  </NewDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"DRUG\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"3","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"3","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"1","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"3","Number of Drug warnings");
		Assert.assertEquals(doc.getOrderIdPairs(),"105848|new1|104050|new2|--105848|new1|102472|current|--104050|new2|102472|current|--");

	}
	
	/**
	 * TC186883
	 * Verifying Order ID's with a length of 0
	 * 
	 * @throws Exception
	 */
	@Test
	public void testZeroLengthOrderIds() throws Exception {
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\""
				+ getBirthdateForGivenAgeInYears(40)
				+ "\" SMOKER=\"TRUE\" PREGNANT=\"TRUE\" LACTATING=\"TRUE\"/>" + 
				"  <CurrentDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"102472\" TYPE=\"GFC\" ORDER_ID=\"\" />" + 
				"  </CurrentDrugList>" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"105848\" TYPE=\"GFC\" ORDER_ID=\"\" />" + 
				"    <Drug CODE=\"104050\" TYPE=\"GFC\" ORDER_ID=\"\" />" + 
				"  </NewDrugList>" + 
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"DRUG\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"3","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"3","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"1","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"3","Number of Drug warnings");
		Assert.assertEquals(doc.getOrderIdPairs(),"105848||104050||--105848||102472||--104050||102472||--");
		
	}
	
	/**
	 * TC186896
	 * Verifying 'noise reduction'
	 * 
	 * From ApTest/QC/Rally test case:
	 * From the Noise Reduction Tech Spec:
	 * Open issue #1 - Duplicate warning checking will use Order_Id 
	 * to determine if warnings are identical.  If two warnings 
	 * contain the same drugs but the Order_Id is different, 
	 * two warnings will be returned. 
	 * 
	 * @throws Exception
	 */
	@Test
	public void testOrderIdNoiseReduction() throws Exception {
		System.out.println("\r\n ======== testOrderIdNoiseReduction =========");
		// three diff drugs, no ORDER_ID - expect 2 warnings
		MasDoc doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\""
				+ getBirthdateForGivenAgeInYears(40)
				+ "\" SMOKER=\"TRUE\" PREGNANT=\"TRUE\" LACTATING=\"TRUE\"/>" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"105844\" TYPE=\"GFC\" />" + 
				"    <Drug CODE=\"105848\" TYPE=\"GFC\" />" + 
				"    <Drug CODE=\"104050\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" +
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"DRUG\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"2","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"2","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"1","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"2","Number of Drug warnings" );

		// three diff drugs, identical ORDER_IDs - expect 2 warnings
		doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\""
				+ getBirthdateForGivenAgeInYears(40)
				+ "\" SMOKER=\"TRUE\" PREGNANT=\"TRUE\" LACTATING=\"TRUE\"/>" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"105844\" TYPE=\"GFC\" ORDER_ID=\"ord\" />" + 
				"    <Drug CODE=\"105848\" TYPE=\"GFC\" ORDER_ID=\"ord\" />" + 
				"    <Drug CODE=\"104050\" TYPE=\"GFC\" ORDER_ID=\"ord\" />" + 
				"  </NewDrugList>" +
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"DRUG\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"2","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"2","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"1","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"2","Number of Drug warnings");
		
		// three diff drugs, unique ORDER_IDs - expect 2 warnings
		doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\""
				+ getBirthdateForGivenAgeInYears(40)
				+ "\" SMOKER=\"TRUE\" PREGNANT=\"TRUE\" LACTATING=\"TRUE\"/>" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"105844\" TYPE=\"GFC\" ORDER_ID=\"ord1\" />" + 
				"    <Drug CODE=\"105848\" TYPE=\"GFC\" ORDER_ID=\"ord2\" />" + 
				"    <Drug CODE=\"104050\" TYPE=\"GFC\" ORDER_ID=\"ord3\" />" + 
				"  </NewDrugList>" +
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"DRUG\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"2","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"2","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"1","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"2","Number of Drug warnings");
		
		// two diff drugs, one drug duplicated, identical ORDER_IDs - expect 1 warnings
		doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\""
				+ getBirthdateForGivenAgeInYears(40)
				+ "\" SMOKER=\"TRUE\" PREGNANT=\"TRUE\" LACTATING=\"TRUE\"/>" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"105844\" TYPE=\"GFC\" ORDER_ID=\"ord\"/>" + 
				"    <Drug CODE=\"105844\" TYPE=\"GFC\" ORDER_ID=\"ord\"/>" + 
				"    <Drug CODE=\"104050\" TYPE=\"GFC\" ORDER_ID=\"ord\"/>" + 
				"  </NewDrugList>" +
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"DRUG\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"1","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"1","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"1","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"1","Number of Drug warnings");
		
		// two diff drugs, one drug duplicated, unique ORDER_IDs - expect 2 warnings
		doc = getMasResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + 
				"  <Patient GENDER=\"FEMALE\" BIRTH_DATE=\""
				+ getBirthdateForGivenAgeInYears(40)
				+ "\" SMOKER=\"TRUE\" PREGNANT=\"TRUE\" LACTATING=\"TRUE\"/>" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"105844\" TYPE=\"GFC\" ORDER_ID=\"ord1\"/>" + 
				"    <Drug CODE=\"105844\" TYPE=\"GFC\" ORDER_ID=\"ord2\"/>" + 
				"    <Drug CODE=\"104050\" TYPE=\"GFC\" ORDER_ID=\"ord3\"/>" + 
				"  </NewDrugList>" +
				"  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">" + 
				"    <TypeFilter NAME=\"DRUG\" />" + 
				"  </Filter>" + 
				"</MasRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"0"); // no errors
		Assert.assertEquals(doc.getSummaryInteractionTotal(),"2","Total Interactions"); 
		Assert.assertEquals(doc.getSummaryWarningTotal(),"2","Total Warnings");
		Assert.assertEquals(doc.getInteractionsTypeSummarySize(),"1","Type Summary"); 
		Assert.assertEquals(doc.getNumberOfWarningsByType("DRUG"),"2","Number of Drug warnings");
		
	}
	
}
