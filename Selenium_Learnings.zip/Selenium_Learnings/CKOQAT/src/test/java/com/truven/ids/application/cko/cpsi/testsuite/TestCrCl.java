package com.truven.ids.application.cko.cpsi.testsuite;


import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.cpsi.pageobjects.CrClDoc;
import com.truven.ids.application.cko.uitest.CPSIBaseTest;

public class TestCrCl extends CPSIBaseTest{

 @Test(groups={"Smoke","Regression"})
	public void testCrclForWithOutWarning() throws Exception {
	   System.out.println("In method 'testCrclForWithOutWarning'");
	   CrClDoc doc = getCrclResultDoc("crcl_calc/CrCLCalcWithOutWarningRequest");
	   Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request" );
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE",
                        "Server not connected OR Response is not displayed");
	   Assert.assertEquals(doc.getResponseValueForAttribute("PSDMessageList"),"null","Warning displayed for valid input request");
	   Assert.assertEquals(doc.getResponseValueForAttribute("BSA"),"1.915","BSA value is incorrect, exceeds the given data");
	  }
	
 @Test
	public void testCrclForWithWarning() throws Exception {
    System.out.println("In method 'testCrclForWithWarning'");
    CrClDoc doc = getCrclResultDoc("crcl_calc/CrCLCalcWithWarningRequest");
    Assert.assertEquals(doc.getErrorListSize(),"0","ErrorList is present for Valid Request");
    Assert.assertEquals(doc.getResponseValueForAttribute("IS_SUCCESS"),"TRUE","Server not connected OR Response is not displayed");
    Assert.assertTrue(doc.verifyCrclMessage("WARNING"),"Expected Warning messages is not displayed");
   }
		
		
}
