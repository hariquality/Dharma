package com.truven.ids.application.cko.uitest.regression.servicestatus;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.ServiceStatusDoc;

/**
 * Service status functional tests
 * 
 * @author APeavy
 * 
 */
public class TestServiceStatus extends CKOBaseTest  {

	/**
	 * TC186
	 * 
	 * 
	 * @throws Exception
	 */
   
  @Test
 	public void testServiceStatusRequest() throws Exception {
 		ServiceStatusDoc doc = getServiceStatusResultDoc("<?xml version=\"1.0\" ?>" + 
 				"<ServiceStatusRequest VERSION='1.00' />" );
 		Assert.assertEquals(doc.getErrorListSize(),"0");
 		Assert.assertEquals(doc.getAllDataSetTypes(),"DOSE1090_DATA|LOOKUP_DATA|MAS_DATA|DRUGPOINTS_DATA|"
 				+ "DRUGNOTES_DATA|IVSCREENING_DATA|WARNINGLABELS_DATA|"
 				+ "IMAGESIMPRINTS_DATA|PSD_DATA|"); 
		
	}
	
	
}
