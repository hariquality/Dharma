package com.truven.ids.application.cko.uitest.regression.mas;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.truven.ids.application.cko.uitest.CKOBaseTest;
import com.truven.ids.application.cko.uitest.regression.pageobjects.MasValidationDoc;

/**
 * MAS Validationfunctional tests
 * 
 * @author APeavy
 * 
 */
public class TestMasValidation extends CKOBaseTest  {

	/**
	 * TC186898
	 * 
	 * @throws Exception
	 */
	@Test
	public void testWithValidValues() throws Exception {
		MasValidationDoc doc = getMasValidationResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MASValidationRequest VERSION=\"1.00\">" + 
				"  <CurrentDrugList SIZE=\"3\">" + 
				"    <Drug CODE=\"00026-8514-48\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"109798\" TYPE=\"GFC\" />" + 
				"    <Drug CODE=\"46910\" TYPE=\"GCR\" ROUTE=\"111000\" />" + 
				"  </CurrentDrugList>" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"00074-1990-10\" TYPE=\"NDC\" />" + 
				"    <Drug CODE=\"114182\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <AllergenList SIZE=\"2\">" + 
				"    <Allergen CODE=\"7700001\" TYPE=\"MDX_ALG\"/>" + 
				"    <Allergen CODE=\"00051-0023-21\" TYPE=\"NDC\"/>" + 
				"  </AllergenList>" + 
				"  <IndicationList SIZE=\"2\">" + 
				"    <Indication CODE=\"428.0\" TYPE=\"ICD_9\" />" + 
				"    <Indication CODE=\"493\" TYPE=\"MDX_CONCEPT\" />" + 
				"  </IndicationList>" + 
				"</MASValidationRequest>");
		Assert.assertEquals(doc.getSummaryWarningTotal(),"0","Summary WARNING_TOTAL");
		
	}
	
	/**
	 * TC186899
	 * 
	 * Verify with CODE values that won't be found in the data. 
	 * 
	 * @throws Exception
	 */
	@Test
	public void testWithValuesNotFound() throws Exception {
		MasValidationDoc doc = getMasValidationResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MASValidationRequest VERSION=\"1.00\">" + 
				"  <CurrentDrugList SIZE=\"3\">" + 
				"   <Drug CODE=\"12345-7898-76\" TYPE=\"NDC\" ORDER_ID=\"curr drug 1\" />" + 
				"   <Drug CODE=\"998877\" TYPE=\"GFC\" />" + 
				"   <Drug CODE=\"998877\" TYPE=\"GCR\" ROUTE=\"111000\" />" + 
				"  </CurrentDrugList>" + 
				"  <NewDrugList SIZE=\"2\">" + 
				"    <Drug CODE=\"98765-4321-98\" TYPE=\"NDC\" ORDER_ID=\"new drug 1\" />" + 
				"    <Drug CODE=\"989898\" TYPE=\"GFC\" />" + 
				"  </NewDrugList>" + 
				"  <AllergenList SIZE=\"2\">" + 
				"    <Allergen CODE=\"9999999\" TYPE=\"MDX_ALG\"/>" + 
				"    <Allergen CODE=\"88888-8888-88\" TYPE=\"NDC\"/>" + 
				"  </AllergenList>" + 
				"  <IndicationList SIZE=\"2\">" + 
				"    <Indication CODE=\"999.9\" TYPE=\"ICD_9\" />" + 
				"    <Indication CODE=\"999\" TYPE=\"MDX_CONCEPT\" />" + 
				"  </IndicationList>" + 
				"</MASValidationRequest>");
		Assert.assertEquals(doc.getSummaryWarningTotal(),"8","Summary WARNING_TOTAL");
	}
	
	/**
	 * TC186900
	 * Verify response when using invalid TYPE attributes
	 * 
	 * @throws Exception
	 */
	@Test
	public void testWithInvalidTypes() throws Exception {
		MasValidationDoc doc = getMasValidationResultDoc("<?xml version=\"1.0\" ?>" + 
				"<MASValidationRequest VERSION=\"1.00\">" + 
				"  <CurrentDrugList SIZE=\"1\">" + 
				"   <Drug CODE=\"12345-7898-76\" TYPE=\"ABC\" />" + 
				"  </CurrentDrugList>" + 
				"  <NewDrugList SIZE=\"1\">" + 
				"    <Drug CODE=\"989898\" TYPE=\"DEF\" />" + 
				"  </NewDrugList>" + 
				"  <AllergenList SIZE=\"1\">" + 
				"    <Allergen CODE=\"88888-8888-88\" TYPE=\"GHI\"/>" + 
				"  </AllergenList>" + 
				"  <IndicationList SIZE=\"1\">" + 
				"    <Indication CODE=\"abc\" TYPE=\"JKL\" />" + 
				"  </IndicationList>" + 
				"</MASValidationRequest>");
		Assert.assertEquals(doc.getErrorListSize(),"4","ErrorList SIZE");
	}
}
