package com.truven.ids.application.cko.cpsi.pageobjects;


import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class PSDDoc extends CPSIBaseDoc{

	
	
	public PSDDoc(JSONObject jsonObject) {
		super(jsonObject);
	}

	public String getPSD_ScreeningValue() {
		return jo.getJSONObject("Response").getJSONObject("PSDPatientDosingResponse").getString("CRCL_METHOD");
				
	}
	
	public Boolean verifyPSD_RxDoseKey(String jsonObject, String jsonArray,String key,String expectedValue) {
	   
	   JSONArray drugsList = jo.getJSONObject("Response").
	         getJSONObject(jsonObject).getJSONArray(jsonArray);
	   // iterate through all returned records
	   
	   for (int i = 0; i < drugsList.length(); i++ ) {
	    JSONObject jo1 = (JSONObject)drugsList.get(i);

	    String imprintCode = jo1.getJSONObject("RxDoseKey").getString(key);
	    
	    if (imprintCode.contains(expectedValue)) {
	       return true;
	    }
	   }
	   return false;
	  }
	
	
	
public Boolean verifyPSD_Screening(String key,String expectedValue) {
    
    JSONArray drugsList = jo.getJSONObject("Response").
          getJSONObject("RxScreeningResponseList").getJSONArray("RxScreeningResponse");
    // iterate through all returned records
    
    for (int i = 0; i < drugsList.length(); i++ ) {
     JSONObject jo1 = (JSONObject)drugsList.get(i);
     
     JSONArray drugsList1 = jo1.getJSONObject("DoseKeyScreeningResultList").
           getJSONArray("DoseKeyScreeningResult");
     
     for (int i1 = 0; i1 < drugsList1.length(); i1++ ) {
     JSONObject jo2 = (JSONObject)drugsList1.get(i1);
     
     if(key.equals("DOSING_PATH")) {
     if(jo2.getJSONObject("GeneralDoseParms").get(key).equals(expectedValue)) {
        return true;
     }}
     
     JSONArray drugsList2 = jo2.getJSONObject("DoseModifierScreeningResultList").
           getJSONArray("DoseModifierScreeningResult");
     for (int i11 = 0; i11 < drugsList2.length(); i11++ ) {
     JSONObject jo3 = (JSONObject)drugsList2.get(i11);

     String imprintCode = jo3.getJSONObject("DoseModifierScreeningParms").getString(key);
     
     if (imprintCode.contains(expectedValue)) {
        return true;
     }
    }
     }
    }
    return false;
   }
	
	
	
}
