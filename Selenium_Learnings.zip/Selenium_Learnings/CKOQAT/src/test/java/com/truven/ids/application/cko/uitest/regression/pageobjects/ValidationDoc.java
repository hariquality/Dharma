package com.truven.ids.application.cko.uitest.regression.pageobjects;

import java.util.List;

import org.jdom.Document;
import org.jdom.Element;

/**
 * ValidationDoc contains Validation specific methods.
 * 
 * @author APeavy
 * 
 */
public class ValidationDoc extends BaseDoc {

	public ValidationDoc(Document inputDoc) {
		super(inputDoc);
	}

	public String getCurrentDrugListSize() {
		if (doc.getRootElement().getChild("CurrentDrugList") == null) {
			return "0";
		} else {
			return doc.getRootElement().getChild("CurrentDrugList").getAttributeValue("SIZE");
		}
	}

	public String getNewDrugListSize() {
		if (doc.getRootElement().getChild("NewDrugList") == null) {
			return "0";
		} else {
			return doc.getRootElement().getChild("NewDrugList").getAttributeValue("SIZE");
		}
	}

	/**
	 * Gets the attribute for a given Current drug code.
	 * 
	 * @param drugCode
	 * @param attributeName
	 * @return
	 */
	public String getResultForGivenAttributeInCurrent(String drugCode, String attributeName) {
		List<?> currentDrugs = doc.getRootElement().getChild("CurrentDrugList").getChildren("Drug");
		String result = "";
		for (Object drug : currentDrugs) {
			if (((Element) drug).getAttributeValue("CODE").compareTo(drugCode) == 0) {
				result = ((Element) drug).getAttributeValue(attributeName);
				break;
			}
		}
		if (result != "") {
			return result;
		} else
			return "drug not found";
	}

	/**
	 * Gets the attribute for a given New drug code.
	 * 
	 * @param drugCode
	 * @param attributeName
	 * @return
	 */
	public String getResultForGivenAttributeInNew(String drugCode, String attributeName) {
		List<?> newDrugs = doc.getRootElement().getChild("NewDrugList").getChildren("Drug");
		String result = "";
		for (Object drug : newDrugs) {
			if (((Element) drug).getAttributeValue("CODE").compareTo(drugCode) == 0) {
				result = ((Element) drug).getAttributeValue(attributeName);
				break;
			}
		}
		if (result != "") {
			return result;
		} else
			return "drug not found";
	}

}
