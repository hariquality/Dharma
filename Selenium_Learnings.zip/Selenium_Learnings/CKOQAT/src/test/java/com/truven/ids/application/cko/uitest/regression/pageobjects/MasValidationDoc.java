package com.truven.ids.application.cko.uitest.regression.pageobjects;

import java.util.Iterator;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;

/**
 * MasValidationDoc contains MAS Validation specific methods.
 * 
 * @author APeavy
 * 
 */
public class MasValidationDoc extends BaseDoc {

	public MasValidationDoc(Document inputDoc) {
		super(inputDoc);
	}

	public String getSummaryWarningTotal() {
		return doc.getRootElement().getChild("Summary").getAttributeValue("WARNING_TOTAL");
	}

	public String getErrorListSize() {
		return doc.getRootElement().getChild("ErrorList").getAttributeValue("SIZE");
	}

	public String getWarningText() {
		return doc.getRootElement().getChild("WarningList").getChild("Warning").getChildText("WarningText");

	}

	public String getErrorTextValidation() {
		return doc.getRootElement().getChild("ErrorList").getChild("Error").getAttributeValue("ERROR_TEXT");

	}

	/*Method will iterate all resulted warnings text and return true if expected text present in warning Result */
	public Boolean getWarningTextseq(String inputText) {
		int i = 0;
		int flag = 0;
		List<?> warnings = doc.getRootElement().getChild("WarningList").getChildren("Warning");
		i = warnings.size();
		if (i > 0) {
			Iterator<?> w = warnings.iterator();
			while (w.hasNext()) {
				Element summary = (Element) w.next();
				if ((summary.getChildText("WarningText").equalsIgnoreCase(inputText))) {
					System.out.println("Match Found");
					System.out.println("response Value" + (summary.getChildText("WarningText")));
					System.out.println("Expected Value" + inputText);
					// w.next();
					flag = 1;
				} else {
					System.out.println("No Match");
					System.out.println("response Value : " + (summary.getChildText("WarningText")));
					System.out.println("Expected Value : " + inputText);
				}
			}
		}
		if (flag == 1)
			return true;
		else
			return false;
	}
	
	/*Method will iterate all resulted warnings and check region field in MAS screening Result */
	public Boolean getWarningRegion(String inputText) {
		int i = 0;
		int flag = 0;
		List<?> warnings = doc.getRootElement().getChild("WarningList").getChildren("Warning");
		i = warnings.size();
		Iterator<?> w = warnings.iterator();
		while (w.hasNext()) {
			Element totalwarnings = (Element) w.next();
			List<?> s = totalwarnings.getAttributes();
			i = s.size();
			if (i == 7) {
				System.out.println("Region : " + totalwarnings.getAttributeValue("REGION"));
				if (totalwarnings.getAttributeValue("REGION").equalsIgnoreCase(inputText)) {
					flag = 1;
				}
			}
		}
		if (flag == 1)
			return true;
		else
			return false;
	}
	
	/*Method will iterate all resulted warnings and check region field in Validation warning Result */
	public Boolean getvalidationWarningRegion(String inputText) {
		int i = 0;
		int flag = 0;
		List<?> warnings = doc.getRootElement().getChild("WarningList").getChildren("Warning");
		i = warnings.size();
		Iterator<?> w = warnings.iterator();
		while (w.hasNext()) {
			Element totalwarnings = (Element) w.next();
			List<?> s = totalwarnings.getAttributes();
			i = s.size();
			if (i == 2) {
				System.out.println("Region : " + totalwarnings.getAttributeValue("REGION"));
				if (totalwarnings.getAttributeValue("REGION").equalsIgnoreCase(inputText)) {
					flag = 1;
				}
			}
		}
		if (flag == 1)
			return true;
		else
			return false;
	}
}