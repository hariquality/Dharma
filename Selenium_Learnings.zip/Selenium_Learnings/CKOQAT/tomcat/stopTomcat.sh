#!/bin/sh 
## -------------------------------------------------------------
##
## Script:  stopTomcat.sh
## Author:  M.Mortensen
## Purpose: This script stops the Tomcat server. This
##          script must be located in $BUILD_HOME/tomcat
##
## -------------------------------------------------------------

## Grab the command line args and remember them for later
CMDARGS="$*"

## Source the common shell functions
. `dirname $0`/../bin/common.sh

USAGE_STATEMENT="Usage: $0 [--thcportset <A|B>] [-h|--help]"

## Determine port set to boot under if given, Toolkit defaults to A if not given
while [ $# -gt 0 ] 
do
  case "$1" in
    --thcportset)
      THC_PORT_SET=$2
      case "$THC_PORT_SET" in
        [AB]|[ab])
          THC_PORT_SET=`echo $THC_PORT_SET | tr '[a-b]' '[A-B]'`
          ;;
        *)
          echo $USAGE_STATEMENT
          exit 1
          ;;
      esac
      shift
      shift
      ;;
    -h|--help)
      SHOW_USAGE=true
      break
      ;;
    *) 
      break
      ;;
  esac
done

## Init the Build Toolkit
init_properties `dirname $0`/../bin

## If not in DEV mode and the user is not the runtime user then
## switch to that user and run this script again
if [ "$BUILD_MODE" != "DEV" ] ; then
  if [ "$USER" != "$TOMCAT_RUNTIME_UID" ] ; then
     echo "[INFO] Stopping Tomcat as $TOMCAT_RUNTIME_UID user"
     sudo -u $TOMCAT_RUNTIME_UID sh -c "$BUILD_HOME/tomcat/stopTomcat.sh $CMDARGS"
     exit 0
  fi
fi

## Verify some HOME properties
verify_home TOMCAT_HOME true
verify_home JAVA_HOME true
verify_home BUILD_HOME true


## If cygwin then convert to unix format paths
if $cygwin ; then
  TOMCAT_HOME=`cygpath --unix "$TOMCAT_HOME"`
  JAVA_HOME=`cygpath --unix "$JAVA_HOME"`
  BUILD_HOME=`cygpath --unix "$BUILD_HOME"`
fi


## Grab some file descriptors and LD_LIBRARY_PATH settings for solaris
set_ulimit
set_ld_library_path

# Setup the classpath
if $isunix ; then
  TOMCAT_CLASSPATH=${PATH_SEP}\
/production/ops/conf/other${PATH_SEP}\
/production/ops/conf/monitor${PATH_SEP}\
/production/ops/conf/patches${PATH_SEP}
fi

## Tomcat bootstrap loader items
if [ ! -f $TOMCAT_HOME/bin/bootstrap.jar ] || [ ! $TOMCAT_HOME/bin/bootstrap.jar ] ; then
  echo "[ERROR] Missing critical startup jars for Tomcat in $TOMCAT_HOME/bin"
  exit 1 
fi

TOMCAT_CLASSPATH=${TOMCAT_CLASSPATH}${PATH_SEP}\
${TOMCAT_HOME}/bin/bootstrap.jar${PATH_SEP}${TOMCAT_HOME}/bin/tomcat-juli.jar

## Java endorsed directory
JAVA_ENDORSED_DIRS=${TOMCAT_HOME}/endorsed
## verify_home JAVA_ENDORSED_DIRS true

## Tomcat (Catalina) base dir
TOMCAT_BASE=${BUILD_HOME}/tomcat

## Tomcat (Catalina) temp dir
TOMCAT_TMPDIR=${TOMCAT_BASE}/temp

## If cygwin then convert to windows format paths
if $cygwin ; then
  BUILD_HOME=`cygpath --windows "$BUILD_HOME"`
  TOMCAT_HOME=`cygpath --windows "$TOMCAT_HOME"`
  TOMCAT_BASE=`cygpath --windows "$TOMCAT_BASE"`
  TOMCAT_TMPDIR=`cygpath --windows "$TOMCAT_TMPDIR"`
  TOMCAT_CLASSPATH=`cygpath --windows --path "$TOMCAT_CLASSPATH"`
  JAVA_ENDORSED_DIRS=`cygpath --windows "$JAVA_ENDORSED_DIRS"`
fi


## Hot deployment can only happen on DEV
if [ "$BUILD_MODE" == "DEV" ] ; then
  TOMCAT_CONTEXT_RELOADABLE="true"
  TOMCAT_CONTEXT_ANTI_RESOURCE_LOCKING="true"
  TOMCAT_SERVER_HOST_AUTO_DEPLOY="true"
  
  TOMCAT_CONTEXT_RELOADABLE="false"
  TOMCAT_CONTEXT_ANTI_RESOURCE_LOCKING="false"
  TOMCAT_SERVER_HOST_AUTO_DEPLOY="false"  
  
else
  TOMCAT_CONTEXT_RELOADABLE="false"
  TOMCAT_CONTEXT_ANTI_RESOURCE_LOCKING="false"
  TOMCAT_SERVER_HOST_AUTO_DEPLOY="false"
fi


## Echo some data if in debug mode
if $SCRIPT_DEBUG ; then
  echo "[DEBUG] THIDS_PROPERTIES_FILE                 = $THIDS_PROPERTIES_FILE"
  echo "[DEBUG] BUILD_HOME                            = $BUILD_HOME"
  echo "[DEBUG] BUILD_MODE                            = $BUILD_MODE"
  echo "[DEBUG] DEPLOYMENT_MODE                       = $DEPLOYMENT_MODE"
  echo "[DEBUG] JAVA_HOME                             = $JAVA_HOME"
  echo "[DEBUG] TOMCAT_HOME                           = $TOMCAT_HOME"
  echo "[DEBUG] TOMCAT_JVM_ARGS                       = $TOMCAT_JVM_ARGS"
  echo "[DEBUG] TOMCAT_JVMROUTE                       = $TOMCAT_JVMROUTE"
  echo "[DEBUG] THC_PORT_SET                          = $THC_PORT_SET"
  echo "[DEBUG] TOMCAT_PORT                           = $TOMCAT_PORT"
  echo "[DEBUG] TOMCAT_AJP_PORT                       = $TOMCAT_AJP_PORT"
  echo "[DEBUG] TOMCAT_SHUTDOWN_PORT                  = $TOMCAT_SHUTDOWN_PORT"
  echo "[DEBUG] TOMCAT_CONTEXT_RELOADABLE             = $TOMCAT_CONTEXT_RELOADABLE"
  echo "[DEBUG] TOMCAT_CONTEXT_ANTI_RESOURCE_LOCKING  = $TOMCAT_CONTEXT_ANTI_RESOURCE_LOCKING"
  echo "[DEBUG] TOMCAT_SERVER_HOST_AUTO_DEPLOY        = $TOMCAT_SERVER_HOST_AUTO_DEPLOY"
  echo "[DEBUG] MULTICAST_BIND_ADDRESS                = $MULTICAST_BIND_ADDRESS"
  echo "[DEBUG] MANAGEMENT_EVENTBUS_MULTICAST_ADDRESS = $MANAGEMENT_EVENTBUS_MULTICAST_ADDRESS"
  echo "[DEBUG] MANAGEMENT_EVENTBUS_MULTICAST_PORT    = $MANAGEMENT_EVENTBUS_MULTICAST_PORT"
  echo "[DEBUG] MANAGEMENT_CMDLINE_PORT               = $MANAGEMENT_CMDLINE_PORT"
  echo "[DEBUG] MANAGEMENT_RMICONN_PORT               = $MANAGEMENT_RMICONN_PORT"
  echo "[DEBUG] MANAGEMENT_HTTPCONNECTOR_PORT         = $MANAGEMENT_HTTPCONNECTOR_PORT"
  echo "[DEBUG] THC_JDWP_DEBUG                        = $THC_JDWP_DEBUG"
  echo "[DEBUG] JDWP_PORT                             = $JDWP_PORT"
  echo "[DEBUG] TOMCAT_CLASSPATH                      = $TOMCAT_CLASSPATH"
  echo "[DEBUG] PATH                                  = $PATH"
  if $isunix ; then
  echo "[DEBUG] LD_LIBRARY_PATH                       = $LD_LIBRARY_PATH"
  fi
fi

if [ $SHOW_USAGE ] ; then
  echo ""
  echo $USAGE_STATEMENT  
  echo ""
  exit 0
fi

CLASSPATH="$TOMCAT_CLASSPATH"
export CLASSPATH

## Tomcat command - JDK 1.6/Tomcat 6.0
TOMCAT_CMD="$JAVA_HOME/bin/java $TOMCAT_JVM_ARGS \
-Deventbus.global.multicast.address=$MANAGEMENT_EVENTBUS_MULTICAST_ADDRESS \
-Deventbus.global.multicast.port=$MANAGEMENT_EVENTBUS_MULTICAST_PORT \
-Dthc.tomcat.ajp.port=$TOMCAT_AJP_PORT \
-Dthc.bindaddress.primary=$PRIMARY_BIND_ADDRESS \
-Dthc.tomcat.port=$TOMCAT_PORT \
-Dthc.tomcat.shutdown.port=$TOMCAT_SHUTDOWN_PORT \
-Dtomcat.replication.port=$TOMCAT_REPLICATION_PORT \
-Dthc.tomcat.jvmroute=$TOMCAT_JVMROUTE \
-Dthc.tomcat.context.reloadable=$TOMCAT_CONTEXT_RELOADABLE \
-Dthc.tomcat.context.antiResourceLocking=$TOMCAT_CONTEXT_ANTI_RESOURCE_LOCKING \
-Dthc.tomcat.server.host.autoDeploy=$TOMCAT_SERVER_HOST_AUTO_DEPLOY \
-Dcatalina.base=$TOMCAT_BASE \
-Dcatalina.home=$TOMCAT_HOME \
-Djava.io.tmpdir=$TOMCAT_TMPDIR \
org.apache.catalina.startup.Bootstrap stop"

echo "--- The Stop Command"
echo $TOMCAT_CMD
echo "---"

$TOMCAT_CMD

if [ $? != "0" ] ; then
  echo
  echo "The above Stop Command did not finish correctly."
  echo
  exit 1
fi

## Tomcat PID firl
TOMCAT_PID=${TOMCAT_BASE}/runtime.pid
if [ ! -f ${TOMCAT_PID} ] ; then
  echo "[ERROR]  PID file not found.  Looked for: ${TOMCAT_PID}"
  exit 1
fi
PID=`cat ${TOMCAT_PID}`

## Wait for Tomcat to stop
echo "Waiting for Tomcat process: $PID to terminate"
while true; do
   sleep 15
   TOMCAT_RUNNING=`ps -ef | grep " $PID " | grep -v grep`
   if [ "$TOMCAT_RUNNING" == "" ] ; then
      break
   fi
   kill -9 $PID
   break
done

## Remove the PID file
if [ -f ${TOMCAT_PID} ] ; then
  rm -f ${TOMCAT_PID}
fi

