#!/bin/sh 
## -------------------------------------------------------------
##
## Script:  startTomcat.sh
## Author:  M.Mortensen
## Purpose: This script bootstraps the Tomcat server. This
##          script must be located in $BUILD_HOME/tomcat
##
## -------------------------------------------------------------

## Source the common shell functions
. `dirname $0`/../bin/common.sh

## Grab the command line args and remember them for later
CMDARGS="$*"

## Init some properties
THC_JDWP_DEBUG=false
THC_OPTIT=false
THC_OPTIT_PROFILER=false
THC_OPTIT_PROFILER_NO_MEMORY=false
THC_OPTIT_CODE_COVERAGE=false
THC_OPTIT_THREAD_DEBUG=false

THC_JPROFILER=false

## Determine port set to boot under if given, Toolkit defaults to A if not given
while [ $# -gt 0 ] 
do
  case "$1" in
    --thcportset)
      THC_PORT_SET=$2
      case "$THC_PORT_SET" in
        [AB]|[ab])
          THC_PORT_SET=`echo $THC_PORT_SET | tr '[a-b]' '[A-B]'`
          ;;
      esac
      shift
      shift
      ;;
    --thcdebug)
      THC_JDWP_DEBUG=true
      shift
      ;;
    --jprofiler)
      THC_JPROFILER=true
      shift
      ;;
    --thcprofiler)
      THC_OPTIT=true
      THC_OPTIT_PROFILER=true
      shift
      ;;
    --thcprofilernomem)
      THC_OPTIT=true
      THC_OPTIT_PROFILER=true
      THC_OPTIT_PROFILER_NO_MEMORY=true
      shift
      ;;
    --thccodecoverage)
      THC_OPTIT=true
      THC_OPTIT_CODE_COVERAGE=true
      shift
      ;;
    --thcthreaddebug)
      THC_OPTIT=true
      THC_OPTIT_THREAD_DEBUG=true
      shift
      ;;
    -h|-help|--help)
      SHOW_USAGE=true
      break
      ;;
    *) 
      break
      ;;
  esac
done

## Init the Build Toolkit
init_properties `dirname $0`/../bin

## Setup customized paths for rapid development of SPA's
TOMCAT_EXTRA_PATHS=""
if [ "$BUILD_MODE" = "DEV" ] ; then
  app_name=${BUILD_HOME##*/}
  declare -l app_name
  app_name=${app_name}
  client_path="${BUILD_HOME}/src/webapp/${app_name}/webclnt"
  if $cygwin ; then
    client_path=`cygpath --windows --mixed "$client_path"`
  fi
  TOMCAT_EXTRA_PATHS="/webclnt=${client_path}"
fi

## If not in DEV mode and the user is not the runtime user then
## switch to that user and run this script again
if [ "$BUILD_MODE" != "DEV" ] ; then
  if [ "$USER" != "$TOMCAT_RUNTIME_UID" ] ; then
     echo "[INFO] Executing sudo to run Tomcat as $TOMCAT_RUNTIME_UID user"
     sudo -u $TOMCAT_RUNTIME_UID sh -c "$BUILD_HOME/tomcat/startTomcat.sh $CMDARGS"
     exit 0
  fi
fi

## Do some error checking for incompatible option combinations
if [ "$THC_JDWP_DEBUG" == "true" ] && [ "$THC_OPTIT" == "true" ] ; then
  echo "[ERROR] Cannot have JDWP debugging and Optimizeit at same time"
  exit 1
fi
if [ "$THC_OPTIT_PROFILER" == "true" ] && [ "$THC_OPTIT_CODE_COVERAGE" == "true" ] ; then
  echo "[ERROR] Cannot have Optimizeit profiler and code coverage at same time"
  exit 1
fi
if [ "$THC_OPTIT_PROFILER" == "true" ] && [ "$THC_OPTIT_THREAD_DEBUG" == "true" ] ; then
  echo "[ERROR] Cannot have Optimizeit profiler and thread debug at same time"
  exit 1
fi
if [ "$THC_OPTIT_THREAD_DEBUG" == "true" ] && [ "$THC_OPTIT_CODE_COVERAGE" == "true" ] ; then
  echo "[ERROR] Cannot have Optimizeit thread debug and code coverage at same time"
  exit 1
fi

## Verify some HOME properties
verify_home TOMCAT_HOME true
verify_home JAVA_HOME true
verify_home BUILD_HOME true
if $THC_OPTIT ; then
  verify_home OPTIT_HOME true
fi
if $THC_JPROFILER ; then
  verify_jprofiler
fi

## If cygwin then convert to unix format paths
if $cygwin ; then
  TOMCAT_HOME=`cygpath --unix "$TOMCAT_HOME"`
  JAVA_HOME=`cygpath --unix "$JAVA_HOME"`
  BUILD_HOME=`cygpath --unix "$BUILD_HOME"`
  if $THC_OPTIT ; then
    OPTIT_HOME=`cygpath --unix "$OPTIT_HOME"`
  fi
  if $THC_JPROFILER ; then
    JPROFILER_HOME=`cygpath --unix "$JPROFILER_HOME"`
  fi
fi

## If OptimizeIt needed then tack on the native libs
if $THC_OPTIT ; then
  if $isunix ; then
    LD_LIBRARY_PATH=${OPTIT_HOME}/lib${PATH_SEP}${LD_LIBRARY_PATH}
    export LD_LIBRARY_PATH
  else
    PATH=${OPTIT_HOME}/lib${PATH_SEP}${PATH}
  fi
fi

## If JProfiler needed then tack on the native libs
if $THC_JPROFILER ; then
  if $isunix ; then
    LD_LIBRARY_PATH=${JPROFILER_HOME}/lib${PATH_SEP}${LD_LIBRARY_PATH}
    export LD_LIBRARY_PATH
  else  
    PATH=${JPROFILER_HOME}${PATH_SEP}${PATH}
  fi
fi

## Grab some file descriptors and LD_LIBRARY_PATH settings for solaris
set_ulimit
set_ld_library_path

# Validate GLOBAL_PROPERTIES
verify_globalprops
  
# Setup the classpath
if $isunix ; then
  TOMCAT_CLASSPATH=${PATH_SEP}\
/production/ops/conf/properties${PATH_SEP}\
/production/ops/conf/other${PATH_SEP}\
/production/ops/conf/monitor${PATH_SEP}\
/production/ops/conf/patches${PATH_SEP}\
${GLOBAL_PROPERTIES}${PATH_SEP}
else  
  TOMCAT_CLASSPATH=${PATH_SEP}${GLOBAL_PROPERTIES}${PATH_SEP}
fi

## Tomcat bootstrap loader items
if [ ! -f $TOMCAT_HOME/bin/bootstrap.jar ] || [ ! $TOMCAT_HOME/bin/bootstrap.jar ] ; then
  echo "[ERROR] Missing critical startup jars for Tomcat in $TOMCAT_HOME/bin"
  exit 1 
fi

TOMCAT_CLASSPATH=${TOMCAT_CLASSPATH}${TOMCAT_HOME}/bin/bootstrap.jar${PATH_SEP}${TOMCAT_HOME}/bin/tomcat-juli.jar

## If the lib/other directory exists then add all jars to the classpath
if [ -d $BUILD_HOME/lib/other ] ; then
  OTHER_LIBS=$BUILD_HOME/lib/other/*.jar
  for i in ${OTHER_LIBS}
  do
    if [ "$i" != "${OTHER_LIBS}" ] ; then
      TOMCAT_CLASSPATH=${i}${PATH_SEP}${TOMCAT_CLASSPATH}
    fi
  done
fi

## If OptimizeIt then add it's jars to the classpath
if $THC_OPTIT ; then
  TOMCAT_CLASSPATH=${TOMCAT_CLASSPATH}${PATH_SEP}${OPTIT_HOME}/lib/optit.jar${PATH_SEP}
  OPTIT_BOOTCLASSPATH=${OPTIT_HOME}/lib/oibcp.jar
fi

## Build the JProfiler options
if $THC_JPROFILER ; then
  JPROF_AGENT="${JPROFILER_HOME}/agent.jar"
  echo "JPROF_AGENT: $JPROF_AGENT"
  if $cygwin ; then
    JPROF_AGENT=`cygpath --windows --path "$JPROF_AGENT"`
  fi
  echo "JPROF_AGENT: $JPROF_AGENT"
  JPROF_JVM_ARGS="-agentlib:jprofilerti=port=${JPROFILER_PORT} -Xbootclasspath/a:${JPROF_AGENT}"
fi

## Java endorsed directory
JAVA_ENDORSED_DIRS=${TOMCAT_LIB_ENDORSED}
## verify_home JAVA_ENDORSED_DIRS true

## Tomcat (Catalina) base dir
TOMCAT_BASE=${BUILD_HOME}/tomcat

## Tomcat (Catalina) temp dir
TOMCAT_TMPDIR=${TOMCAT_BASE}/temp

## Create some directories if non existent
if [ ! -d $TOMCAT_TMPDIR ] ; then
  mkdir $TOMCAT_TMPDIR
fi

## Copy tomcat-users.xml to $TOMCAT_TMPDIR. It will be touched there on start up
cp ${TOMCAT_BASE}/conf/tomcat-users.xml ${TOMCAT_TMPDIR}

if [ ! -d $TOMCAT_BASE/logs ] ; then
  mkdir $TOMCAT_BASE/logs
fi

## Remove expanded webapps so the war files are re-expanded cleanly
if $solaris ; then
	find ${BUILD_HOME}/tomcat/webapps/* -type d -exec rm -Rf {} \;
else
	find ${BUILD_HOME}/tomcat/webapps -maxdepth 1 -mindepth 1 -type d -exec rm -Rf {} \;
fi	

## Get the hostname and flip to upper case.  This is used to determine the 
## GB server key.
HOSTNAME_GIVEN=`hostname`
HOSTNAME_UPPER_CASE=`echo $HOSTNAME_GIVEN | tr '[a-z]' '[A-Z]'`

## If JDWP debug then tack debugger information onto JVM_ARGS
if $THC_JDWP_DEBUG ; then
  TOMCAT_JVM_ARGS="$TOMCAT_JVM_ARGS -Xint -Xdebug -Xrunjdwp:transport=dt_socket,address=$JDWP_PORT,server=y,suspend=n"
fi

## If cygwin then convert to windows format paths
if $cygwin ; then
  BUILD_HOME=`cygpath --windows "$BUILD_HOME"`
  TOMCAT_HOME=`cygpath --windows "$TOMCAT_HOME"`
  TOMCAT_BASE=`cygpath --windows "$TOMCAT_BASE"`
  TOMCAT_TMPDIR=`cygpath --windows "$TOMCAT_TMPDIR"`
  TOMCAT_CLASSPATH=`cygpath --windows --path "$TOMCAT_CLASSPATH"`
  JAVA_ENDORSED_DIRS=`cygpath --windows "$JAVA_ENDORSED_DIRS"`
  if $THC_OPTIT ; then
    OPTIT_HOME=`cygpath --windows "$OPTIT_HOME"`
    OPTIT_BOOTCLASSPATH=`cygpath --windows --path "$OPTIT_BOOTCLASSPATH"`
  fi
  if $THC_JPROFILER ; then
    JPROFILER_HOME=`cygpath --windows "$JPROFILER_HOME"`
  fi
fi

## Build the Optimizeit options
if $THC_OPTIT ; then  
  if [ -z "$OPTIT_LICENSE" ] ; then
    echo "[ERROR] OPTIT_LICENSE is required to be set in thids_properties.sh"
    echo "[ERROR] This is the Optimizeit license key on the CD"
    exit 1
  fi
  if $THC_OPTIT_PROFILER ; then
    OPTIT_JVM_ARGS="-DOILICENSE=$OPTIT_LICENSE -Xbootclasspath/a:${OPTIT_BOOTCLASSPATH} -Xboundthreads -DGCOPSIZE=8 -Xrunpri" 
    OPTIT_MAIN_CLASS="intuitive.audit.Audit" 
    OPTIT_ARGS="-port $OPTIT_PORT"
    
    if $THC_OPTIT_PROFILER_NO_MEMORY ; then      
      OPTIT_JVM_ARGS="-Xrunpri:dmp=1 $OPTIT_JVM_ARGS"
      OPTIT_ARGS="$OPTIT_ARGS -dmp"
    fi
  fi
  if $THC_OPTIT_CODE_COVERAGE ; then
    OPTIT_JVM_ARGS="-DOILICENSE=$OPTIT_LICENSE -Xbootclasspath/a:${OPTIT_BOOTCLASSPATH} -Xruncci:filters={patternList=(!com.thc.*),operation=AND}"    
    OPTIT_MAIN_CLASS="intuitive.audit.Cover"
    OPTIT_ARGS="-port $OPTIT_PORT"
  fi
  if $THC_OPTIT_THREAD_DEBUG ; then
    OPTIT_JVM_ARGS="-DOILICENSE=$OPTIT_LICENSE -Xbootclasspath/a:${OPTIT_BOOTCLASSPATH} -Xboundthreads -Xruntdi:port=$OPTIT_PORT"
    OPTIT_MAIN_CLASS=""
    OPTIT_ARGS=""
  fi
fi

## Some DEV specific testing
if [ "$BUILD_MODE" == "DEV" ] ; then
  ## Hot deployment can only happen on DEV
  TOMCAT_CONTEXT_RELOADABLE="true"
  TOMCAT_CONTEXT_ANTI_RESOURCE_LOCKING="true"
  TOMCAT_SERVER_HOST_AUTO_DEPLOY="true"
else
  TOMCAT_CONTEXT_RELOADABLE="false"
  TOMCAT_CONTEXT_ANTI_RESOURCE_LOCKING="false"
  TOMCAT_SERVER_HOST_AUTO_DEPLOY="false"
fi

## Check/set custom server config file  
TOMCAT_CFG_FILE_ARGS=""
if [ -f "${BUILD_HOME}/tomcat/conf/${BUILD_MODE}-server.xml" ] ; then
  TOMCAT_CFG_FILE_ARGS="-config conf/${BUILD_MODE}-server.xml"
fi

## Echo some data if in debug mode
if $SCRIPT_DEBUG ; then
  echo "[DEBUG] THIDS_PROPERTIES_FILE                 = $THIDS_PROPERTIES_FILE"
  echo "[DEBUG] GLOBAL_PROPERTIES                     = $GLOBAL_PROPERTIES"
  echo "[DEBUG] BUILD_HOME                            = $BUILD_HOME"
  echo "[DEBUG] BUILD_MODE                            = $BUILD_MODE"
  echo "[DEBUG] DEPLOYMENT_MODE                       = $DEPLOYMENT_MODE"
  echo "[DEBUG] JAVA_HOME                             = $JAVA_HOME"
  echo "[DEBUG] TOMCAT_HOME                           = $TOMCAT_HOME"
  echo "[DEBUG] TOMCAT_JVM_ARGS                       = $TOMCAT_JVM_ARGS"
  echo "[DEBUG] TOMCAT_JVMROUTE                       = $TOMCAT_JVMROUTE"
  echo "[DEBUG] THC_PORT_SET                          = $THC_PORT_SET"
  echo "[DEBUG] TOMCAT_PORT                           = $TOMCAT_PORT"
  echo "[DEBUG] TOMCAT_AJP_PORT                       = $TOMCAT_AJP_PORT"
  echo "[DEBUG] TOMCAT_SHUTDOWN_PORT                  = $TOMCAT_SHUTDOWN_PORT"
  echo "[DEBUG] TOMCAT_REPLICATION_PORT               = $TOMCAT_REPLICATION_PORT"
  echo "[DEBUG] TOMCAT_CONTEXT_RELOADABLE             = $TOMCAT_CONTEXT_RELOADABLE"
  echo "[DEBUG] TOMCAT_CONTEXT_ANTI_RESOURCE_LOCKING  = $TOMCAT_CONTEXT_ANTI_RESOURCE_LOCKING"
  echo "[DEBUG] TOMCAT_CFG_FILE_ARGS                  = $TOMCAT_CFG_FILE_ARGS"
  echo "[DEBUG] TOMCAT_SERVER_HOST_AUTO_DEPLOY        = $TOMCAT_SERVER_HOST_AUTO_DEPLOY"
  echo "[DEBUG] MULTICAST_BIND_ADDRESS                = $MULTICAST_BIND_ADDRESS"
  echo "[DEBUG] MANAGEMENT_EVENTBUS_MULTICAST_ADDRESS = $MANAGEMENT_EVENTBUS_MULTICAST_ADDRESS"
  echo "[DEBUG] MANAGEMENT_EVENTBUS_MULTICAST_PORT    = $MANAGEMENT_EVENTBUS_MULTICAST_PORT"
  echo "[DEBUG] MANAGEMENT_CMDLINE_PORT               = $MANAGEMENT_CMDLINE_PORT"
  echo "[DEBUG] MANAGEMENT_RMICONN_PORT               = $MANAGEMENT_RMICONN_PORT"
  echo "[DEBUG] MANAGEMENT_HTTPCONNECTOR_PORT         = $MANAGEMENT_HTTPCONNECTOR_PORT"
  echo "[DEBUG] THC_JDWP_DEBUG                        = $THC_JDWP_DEBUG"
  echo "[DEBUG] JDWP_PORT                             = $JDWP_PORT"
  echo "[DEBUG] THC_SFR_PORT                          = $THC_SFR_PORT"
  echo "[DEBUG] TOMCAT_CLASSPATH                      = $TOMCAT_CLASSPATH"
  echo "[DEBUG] TOMCAT_EXTRA_PATHS                    = $TOMCAT_EXTRA_PATHS"
  echo "[DEBUG] PATH                                  = $PATH"
  if $isunix ; then
  echo "[DEBUG] LD_LIBRARY_PATH                       = $LD_LIBRARY_PATH"
  fi
  if $THC_OPTIT ; then
  echo "[DEBUG] THC_OPTIT                             = $THC_OPTIT"
  echo "[DEBUG] THC_OPTIT_PROFILER                    = $THC_OPTIT_PROFILER"
  echo "[DEBUG] THC_OPTIT_PROFILER_NO_MEMORY          = $THC_OPTIT_PROFILER_NO_MEMORY"
  echo "[DEBUG] THC_OPTIT_CODE_COVERAGE               = $THC_OPTIT_CODE_COVERAGE"
  echo "[DEBUG] THC_OPTIT_THREAD_DEBUG                = $THC_OPTIT_THREAD_DEBUG"
  echo "[DEBUG] OPTIT_HOME                            = $OPTIT_HOME"
  echo "[DEBUG] OPTIT_LICENSE                         = $OPTIT_LICENSE"
  echo "[DEBUG] OPTIT_JVM_ARGS                        = $OPTIT_JVM_ARGS"
  echo "[DEBUG] OPTIT_ARGS                            = $OPTIT_ARGS"
  echo "[DEBUG] OPTIT_PORT                            = $OPTIT_PORT"
  fi
  if $THC_JPROFILER ; then
  echo "[DEBUG] THC_JPROFILER                         = $THC_JPROFILER"
  echo "[DEBUG] JPROFILER_HOME                        = $JPROFILER_HOME"
  echo "[DEBUG] JPROF_JVM_ARGS                        = $JPROF_JVM_ARGS"
  fi
fi

#need to export the classpath
CLASSPATH="$TOMCAT_CLASSPATH"
export CLASSPATH

## Tomcat command - JDK 1.6/Tomcat 6.0
TOMCAT_CMD="$JAVA_HOME/bin/java $TOMCAT_JVM_ARGS \
$OPTIT_JVM_ARGS \
-Dbuild.mode=$BUILD_MODE \
-Dbuild.home=$BUILD_HOME \
-Ddeployment.mode=$DEPLOYMENT_MODE \
$JVM_PERMGEN_ARGS \
-Dcontainer.mode=TOMCAT \
-Dthc.multicast.bindaddress=$MULTICAST_BIND_ADDRESS \
-Deventbus.global.multicast.address=$MANAGEMENT_EVENTBUS_MULTICAST_ADDRESS \
-Deventbus.global.multicast.port=$MANAGEMENT_EVENTBUS_MULTICAST_PORT \
-Dthc.management.commandline.port=$MANAGEMENT_CMDLINE_PORT \
-Dthc.management.rmiconnector.port=$MANAGEMENT_RMICONN_PORT \
-Dthc.management.httpconnector.port=$MANAGEMENT_HTTPCONNECTOR_PORT \
-Dthc.management.httpconnector.enabled=true \
-Dthc.bindaddress.primary=$PRIMARY_BIND_ADDRESS \
-Dthc.bindaddress.multicast=$MULTICAST_BIND_ADDRESS \
-Dthc.multicast.ttl=$IP_TTL \
-Dthc.multicast.address=$TOMCAT_MULTICAST_ADDRESS \
-Dthc.multicast.port=$TOMCAT_PORT \
-Dthc.naming.port=$MANAGEMENT_RMICONN_PORT \
-Dthc.service.host=localhost \
-Dthc.gb.server.key=DEFAULT${HOSTNAME_UPPER_CASE} \
-Dthc.domain.name=$THC_DOMAIN_NAME \
-Dthc.tomcat.jvmroute=$TOMCAT_JVMROUTE \
-Dthc.tomcat.port=$TOMCAT_PORT \
-Dthc.tomcat.ajp.port=$TOMCAT_AJP_PORT \
-Dthc.tomcat.shutdown.port=$TOMCAT_SHUTDOWN_PORT \
-Dtomcat.replication.port=$TOMCAT_REPLICATION_PORT \
-Dthc.tomcat.context.reloadable=$TOMCAT_CONTEXT_RELOADABLE \
-Dthc.tomcat.context.antiResourceLocking=$TOMCAT_CONTEXT_ANTI_RESOURCE_LOCKING \
-Dthc.tomcat.server.host.autoDeploy=$TOMCAT_SERVER_HOST_AUTO_DEPLOY \
-Djava.endorsed.dirs=$JAVA_ENDORSED_DIRS \
-Dcatalina.base=$TOMCAT_BASE \
-Dcatalina.home=$TOMCAT_HOME \
-Djava.io.tmpdir=$TOMCAT_TMPDIR \
-Djava.awt.headless=true \
-Dthc.sfr.port=$THC_SFR_PORT \
-Djava.naming.factory.initial=com.sun.jndi.rmi.registry.RegistryContextFactory \
-Djava.naming.provider.url=rmi://localhost:$MANAGEMENT_RMICONN_PORT \
-Dthc.list.buildmodes=\"$LIST_BUILDMODES\" \
-Djavax.net.ssl.trustStore=/production/ops/conf/security/client_public_keystore.jks \
-Djavax.net.ssl.keyStore=/production/ops/conf/security/client_public_keystore.jks \
$OPTIT_MAIN_CLASS $OPTIT_ARGS \
$JPROF_JVM_ARGS \
$PROJ_EXTRA_JVM_OPTS \
-Dthc.tomcat.extrapaths=$TOMCAT_EXTRA_PATHS \
org.apache.catalina.startup.Bootstrap $TOMCAT_CFG_FILE_ARGS start"

if [ $SHOW_USAGE ] ; then
  echo ""
  echo "THIDS Usage: $0 [THIDS options]"
  echo ""
  echo "THIDS options:"
  echo "  -h, --help                          Shows this help statement"
  echo "  --thcportset <A|B>                  Start under port set A or B"
  echo "  --thcdebug                          Start under the JDWP debugger"
  echo "  --thcprofiler                       Start with Optimizeit profiler"
  echo "  --thcprofilernomem                  Start with Optimizeit profiler without memory profiling"
  echo "  --thccodecoverage                   Start with Optimizeit code coverage"
  echo "  --thcthreaddebug                    Start with Optimizeit thread debugger"
  echo ""
  exit 0
fi

echo "---"
echo $TOMCAT_CMD
echo "---"

## Start tail in background
if [ "$BUILD_MODE" == "DEV" ] ; then
   TIME_STAMP=`date +%Y%m%d`-`date +%H%M%S`
   TOMCAT_LOG=$TOMCAT_BASE/logs/catalina-${TIME_STAMP}.log
   touch $TOMCAT_LOG
   if [ "$linux" == "false" ] ; then
      tail -f $TOMCAT_LOG &
   fi
   PID_TAIL=$!
   echo "[INFO]  PID_TAIL: $PID_TAIL"
else
   TOMCAT_LOG=$TOMCAT_BASE/logs/catalina.log
fi

## Start Tomcat in background
$TOMCAT_CMD \
  1>$TOMCAT_LOG \
  2>&1 &

## Echo the PID to a file for future reference so that stopTomcat
## knows what to do.
TOMCAT_PID=${TOMCAT_BASE}/runtime.pid
echo $! > ${TOMCAT_PID}
PID_TOMCAT=`cat ${TOMCAT_PID}`

echo "[INFO]  Servlet Engine running under PID: `cat ${TOMCAT_PID}`"
echo "[INFO]  The Servlet Engine log file is at $TOMCAT_LOG"
echo

## This function is called if user hits Control/C to kill Tomcat.
clean_up() {
   TOMCAT_RUNNING=`ps -ef | grep " $PID_TOMCAT " | grep -v grep`
   if [ "$TOMCAT_RUNNING" == "" ] ; then
      echo "Tomcat is not running..."
   else
      echo "Killing tomcat..."
      sh ${TOMCAT_BASE}/stopTomcat.sh   	
      echo "[INFO]  stopTomcat finished successfully"   	   	
   fi   	

   kill -9 $PID_TAIL

   echo "[INFO]  Servlet Engine has stopped running."
   exit 1
}

if [ "$BUILD_MODE" == "DEV" ] ; then
   trap clean_up 2
fi

if [ "$BUILD_MODE" == "DEV" ] ; then
   ## This loop handles graceful shutdown via the stop Tomcat script.
   while true; do
      TOMCAT_RUNNING=`ps -ef | grep " $PID_TOMCAT " | grep -v grep`
      if [ "$TOMCAT_RUNNING" == "" ] ; then
         break
      fi
      sleep 15
   done

   ## Finally, kill tail that was running in background
   echo "[INFO]  Servlet Engine has stopped running."
   kill -9 $PID_TAIL
fi

