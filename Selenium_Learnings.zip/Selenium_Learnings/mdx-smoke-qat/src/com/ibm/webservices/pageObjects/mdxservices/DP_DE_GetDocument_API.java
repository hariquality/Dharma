package com.ibm.webservices.pageObjects.mdxservices;


import java.util.HashMap;
import java.util.List;

import org.springframework.http.ResponseEntity;

import com.ibm.webservices.utils.JSON_Utilities;
import com.ibm.webservices.utils.MDXBaseTest;

import net.sf.json.JSONObject;

public class DP_DE_GetDocument_API extends JSON_Utilities{

   static MDXBaseTest baseTest = new MDXBaseTest();
   JSONObject getJSONObject ;
   
   HashMap<String, String> sectionWiseContent;
   HashMap<String, List<String>> sectionNamesinTopicsArray;
   static ResponseEntity<String> doc;
   
 
	/**
	 * Default constructor which invokes the parent class constructor to get the json object
	 * @param jsonObject = pass the json object (obtained from the request)
	 */
   public DP_DE_GetDocument_API(JSONObject jsonObject)
   {
      super(jsonObject);
      
   }
   
	
}
