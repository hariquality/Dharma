package com.ibm.webservices.pageObjects.mdxservices;

import com.ibm.webservices.utils.JSON_Utilities;
import com.ibm.webservices.utils.MDXBaseTest;

import net.sf.json.JSONObject;

public class CN_GetDocument_API extends JSON_Utilities
{

   static MDXBaseTest baseTest = new MDXBaseTest();



   /**
    * Default constructor which invokes the parent class constructor to get the
    * json object
    * 
    * @param jsonObject
    *           = pass the json object (obtained from the request)
    */
   public CN_GetDocument_API(JSONObject jsonObject)
   {
      super(jsonObject);

   }

   


}
