package com.ibm.webservices.pageObjects.infobutton;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;
import com.ibm.webservices.config.ExtentReporter;
import com.ibm.webservices.utils.InfoButtonBaseTest;

public class Infobutton_MDXPage extends InfoButtonBaseTest
{
   private final WebDriver driver;
   
   @FindBy(xpath = "//a[contains(text(),'Dosing Information')]")
   private WebElement dosingInfoLink;

   @FindBy(xpath = "/html/body/table[2]/tbody/tr[6]/td/table/tbody/tr[2]/th/div/a/span")
   private WebElement drugDexLink;
   
   Selenese utils = new Selenese();
   
   public Infobutton_MDXPage(WebDriver driver) throws IOException
   {
      this.driver = driver;
      PageFactory.initElements(this.driver, this);
      WebDriverWait wait = new WebDriverWait(this.driver, 20);

      try
      {
         wait.until(ExpectedConditions.visibilityOf(dosingInfoLink));
      }
      catch (Exception e)
      {
         ExtentReporter.FAIL("Infobutton_MDXPage",
                           "Dosing info link is not visible");
         log.error("Dosing info link is not visible in infobutton page");
      }
   }
   
   
   public void clickDosingInfo() throws IOException
   {
      dosingInfoLink.click();
      log.info("Dosing info clicked");
      drugDexLink.click();
      System.out.println(driver.getCurrentUrl());
      
      if(driver.getCurrentUrl().contains("micromedex2/librarian/"))
      {
         ExtentReporter.PASS("MicromedexLink","Micromedex link is successfully open");
         log.info("Micromedex link successfully opened from infobutton");
      }
      
      else
      {
         ExtentReporter.FAIL("Infobutton_HomePage",
                           "Create user for group link is not visible");
         log.error("Micromedex link not opened from infobutton");
      }
      driver.close();
   }
}
