package com.ibm.webservices.pageObjects.infobutton;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webservices.config.ExtentReporter;
import com.ibm.webservices.utils.InfoButtonBaseTest;

public class Infobutton_HomePage extends InfoButtonBaseTest
{
   private final WebDriver driver;
   
   @FindBy(xpath = "//*[@id='ci']/span/strong")
   private WebElement clinicalInfo;
   
   @FindBy(xpath = "//a[contains(text(),'Acetaminophen')]")
   private WebElement acetaminophenLink;
   
   @FindBy(xpath = "//a[contains(text(),'Carbamide Peroxide')]")
   private WebElement carbamidePeroxideLink;
   
   public Infobutton_HomePage(WebDriver driver) throws IOException
   {
      this.driver = driver;
      PageFactory.initElements(this.driver, this);
      WebDriverWait wait = new WebDriverWait(this.driver, 20);

      try
      {
         wait.until(ExpectedConditions.visibilityOf(clinicalInfo));
         
      }
      catch (Exception e)
      {
         ExtentReporter.FAIL(
                           "Infobutton_HomePage",
                           "Create user for group link is not visible");
         log.error("Create user for group link is not visible in user provisioning page");
      }
   }
   
   public Infobutton_MDXPage clickAcetaminophen() throws IOException
   {
      acetaminophenLink.click();
      ExtentReporter.PASS("Acetaminophen link clicked!", "Acetaminophen link is Clicked.");
      log.info("Acetaminophen clicked!");
      Infobutton_MDXPage mdxPage = PageFactory
            .initElements(driver, Infobutton_MDXPage.class);
      return mdxPage;
   }
   
   public void verifyICD10Drug() throws IOException 
   {
	   WebDriverWait wait = new WebDriverWait(driver, 20);
	   wait.until(ExpectedConditions.visibilityOf(carbamidePeroxideLink));
      if(carbamidePeroxideLink.isDisplayed())
      {
         ExtentReporter.PASS("Carbamide Peroxide", "Carbamide Peroxide is present as part of ICD 10 validation");
         log.info("Carbamide peroxide is present for ICD10 validation");
      }
      
      else
      {
         ExtentReporter.FAIL("ICD10 validation fail", "ICD10 validation fail - Carbamide Peroxide is not present in webpage");
         log.error("ICD 10 validation fail - Carbamide Peroxide not present");
      }
      
      driver.close();
   }


}
