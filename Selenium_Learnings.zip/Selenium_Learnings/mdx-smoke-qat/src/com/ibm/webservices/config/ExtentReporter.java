package com.ibm.webservices.config;

//OB: ExtentReports extent instance created here. That instance can be reachable by getReporter() method.

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.log4j.Logger;
import org.testng.Reporter;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Protocol;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentReporter
{
   ExtentReports extent;

   static String getExecutionType = "";

   static ExtentTest eachTest;

   ExtentTest eachNode;

   public static ExtentReporter extentInstance = null;

   protected Logger log = Logger.getLogger(ExtentReporter.class);

   protected static ExtentSparkReporter extentSparkInstance = null;

   public static ExtentReporter getInstance()
   {
      if (extentInstance == null)
         extentInstance = new ExtentReporter();
      return extentInstance;
   }

   public void getExtendReport() throws IOException
   {
      String environment =Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("Env");
      if (extent == null)
      {
         extent = new ExtentReports();
         DateTimeFormatter dtf = DateTimeFormatter
               .ofPattern("yyyy_MM_dd(HH-mm-ss)");
         LocalDateTime now = LocalDateTime.now();
         String outputFolderName = "WebServices_Reports";
         File outputReportFolder = new File(outputFolderName);
         if (!outputReportFolder.exists())
         {
            outputReportFolder.mkdir();
         }

         File outputFile = new File(outputFolderName + File.separator
               + "Report_" + dtf.format(now) + ".html");

         extentSparkInstance = new ExtentSparkReporter(outputFile);
         extentSparkInstance.config().setCSS("css-string");
         extentSparkInstance.config().setDocumentTitle("Smoke Test Report");
         extentSparkInstance.config().setEncoding("utf-8");
         extentSparkInstance.config().setJS("js-string");
         extentSparkInstance.config().setProtocol(Protocol.HTTP);
         extentSparkInstance.config()
               .setReportName("IBM Micromedex Applications WebServices Smoke Test Report");
         extentSparkInstance.config().setTheme(Theme.DARK);
         extentSparkInstance.config()
               .setTimeStampFormat("MMM dd, yyyy HH:mm:ss");
         extent.setSystemInfo("Environment", environment);
         extent.attachReporter(extentSparkInstance);
      }
   }

   public void createTest(String testname, String testDesciption)
   {
      eachTest = extent.createTest(testname, testDesciption);
      log.info("***********Started Executing TestCase: " + testname
            + "  ***********");
   }

   public static void PASS(String nodeName, String description)
   {
      eachTest.createNode(nodeName, description)
            .pass(MarkupHelper.createLabel(description, ExtentColor.GREEN));
   }

   public static void FAIL(String nodeName,
                    String description) 
   {
      eachTest.createNode(nodeName, description)
            .fail(MarkupHelper.createLabel(description, ExtentColor.RED));
   }


   public void SKIPPED(String description) 
   {
      eachTest.createNode(description, description)
            .pass(MarkupHelper.createLabel("SKIPPED", ExtentColor.ORANGE));
   }

   
   public void flush()
   {
      extent.flush();
   }

}
