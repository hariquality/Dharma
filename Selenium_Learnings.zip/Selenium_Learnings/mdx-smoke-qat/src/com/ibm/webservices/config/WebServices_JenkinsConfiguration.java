package com.ibm.webservices.config;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

public class WebServices_JenkinsConfiguration {
	public static String targetServerforCPSI;

	public static boolean JenkinsRun = false;

	public static String executeType = "";

	public static String executeEnv = "";

	public static String userCredentials = null;

	public static String encodedCredtials = null;

	static Properties props = new Properties();

	static InputStream input = null;

	@BeforeClass(alwaysRun = true)
	@Parameters({ "ExecuteInJenkins", "Env" })
	public static void runConfiguration(@Optional String ExecuteInJenkins, @Optional String Env) {
		try {
			input = new FileInputStream("./properties/WebServicesAppURLConfig.properties");
			props.load(input);
			executeEnv = Env;
			if (ExecuteInJenkins.equalsIgnoreCase("Yes")) {
				JenkinsRun = true;
				getValueFromPropertiesFile(System.getenv("Env"));
				executeEnv = System.getenv("Env");

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String getValueFromPropertiesFile(String valueName) {
		return props.getProperty(valueName);
	}

	public static String getUserNamePassword(String uName, String pWord) {
		return getValueFromPropertiesFile(uName) + ":" + getValueFromPropertiesFile(pWord);
	}

}
