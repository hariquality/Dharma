package com.ibm.webservices.testsuite;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.ibm.webservices.utils.CKOBaseTest;
import com.ibm.webservices.utils.XML_Utilities;
import com.ibm.webservices.utils.CommonUtils;

public class Test_CKO extends CKOBaseTest {

	/**
	 * Test English with NDC and all other languages with GFC as NDC is
	 * converted to GFC TC18704, TC187033
	 */
	@Test(groups = { "cko", "All" })
	public void testEnglish() throws Exception {
		extentReporter.createTest("testEnglish", "Testing English Drg Notes Response");
		System.out.println("In method 'testEnglishDrugNoteResponse'");
		XML_Utilities doc = readXMLResponse("<?xml version=\"1.0\" encoding=\"utf-8\"?>" + "<DrugNotesRequest>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"English\" />"
				+ "<NewDrugList SIZE=\"1\">" + "<Drug CODE=\"00087-0782-41\" TYPE=\"NDC\" />" + "</NewDrugList>"
				+ "</DrugNotesRequest>");
		CommonUtils.compareTextByEqual(doc.getErrorListSize(), "0", "List Size valiadtion");
		CommonUtils.compareTextByEqual(doc.getDocumentListSize("DocumentList", "SIZE"), "1",
				"Document Size valiadtion");
		CommonUtils.compareTextByEqual(doc.getDocumentDrugCodeAttribute("DocumentList", "Document", "DRUG_CODE"),
				"00087-0782-41", "Drug Code valiadtion");
	}

	/**
	 * TC186957 TC186970 TC186979 TC186992 TC187008 Happy path test for ML
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "cko", "All" })
	public void testUnitML() throws Exception {
		System.out.println("In method 'testUnitML'");
		extentReporter.createTest("testUnitML", "Testing Happy path test for ML");
		XML_Utilities doc = readXMLResponse("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + "<Dose1090Request>"
				+ "<Patient BD_MONTH=\"1\" BD_DAY=\"1\" BD_YEAR=\"1955\" GENDER=\"FEMALE\" LANGUAGE=\"E\" />"
				+ "<NewDrugList SIZE=\"1\">"
				+ "<Drug CODE=\"100005\" TYPE=\"GFC\" UNIT=\"ML\" INDIVIDUAL_AMOUNT=\"20\" PERIOD_AMOUNT=\"1\" DURATION=\"1\" />"
				+ "</NewDrugList>" + "</Dose1090Request>");
		CommonUtils.compareTextByEqual(doc.getErrorListSize(), "0", "List Size validation");
		CommonUtils.compareTextByEqual(doc.getDocumentListSize("DrugList", "SIZE"), "1", "Drug List Size validation");
		CommonUtils.compareTextByEqual(doc.getDocumentDrugCodeAttribute("DrugList", "Drug", "CODE"), "100005",
				"Drug Code validation");
		CommonUtils.compareTextByEqual(doc.getDocumentDrugCodeAttribute("DrugList", "Drug", "INDIVIDUAL_RANGE_TEXT"),
				"Value is within range", "Drug List validation");
		CommonUtils.compareTextByEqual(doc.getDocumentDrugCodeAttribute("DrugList", "Drug", "PERIOD_RANGE_TEXT"),
				"Value is within range", "Drug Period Range validation");
		CommonUtils.compareTextByEqual(doc.getDocumentDrugCodeAttribute("DrugList", "Drug", "DURATION_RANGE_TEXT"),
				"Value is within range", "Drug Duration Range validation");
	}

	/**
	 * 
	 * TC187355
	 */
	@Test(groups = { "cko", "All" })
	public void testNDC() throws Exception {
		System.out.println("In method 'testNDC'");
		extentReporter.createTest("testNDC", "Testing NDC");
		XML_Utilities doc = readXMLResponse(
				"<?xml version=\"1.0\" encoding=\"utf-8\"?>" + "<DrugPointsRequest>" + "<NewDrugList SIZE=\"1\">"
						+ "<Drug CODE=\"00026-8514-48\" TYPE=\"NDC\" />" + "</NewDrugList>" + "</DrugPointsRequest>");
		CommonUtils.compareTextByEqual(doc.getErrorListSize(), "0", "List Size validation");
		CommonUtils.compareTextByEqual(doc.getDocumentListSize("DocumentList", "SIZE"), "1",
				"Document Size validation");
		CommonUtils.compareTextByEqual(doc.getDocumentDrugCodeAttribute("DocumentList", "Document", "DRUG_CODE"),
				"00026-8514-48", "Drug Code validation");
	}

	/*
	 * TC186910
	 */
	@Test(groups = { "cko", "All" })
	public void testPatternBanded() throws Exception {
		System.out.println("In method 'testPatternBanded'");
		extentReporter.createTest("testPatternBanded", "Testing banded pattern");
		XML_Utilities doc = readXMLResponse("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
				+ "<ImagesImprintsSearchRequest>" + "<DrugSearchDescription PATTERN=\"Banded\" >"
				+ "<ImprintList SIZE=\"1\">" + "<Imprint>130" + "</Imprint>" + "</ImprintList>"
				+ "</DrugSearchDescription>" + "</ImagesImprintsSearchRequest>");

		CommonUtils.compareTextByEqual(doc.getErrorListSize(), "0", "List Size validation");
		CommonUtils.compareTextByEqual(doc.getDocumentListSize("DrugList", "SIZE"), "2", "Drug list Size validation");
		CommonUtils.compareTextByEqual(doc.getDocumentDrugCodeAttribute("DrugList", "Drug", "CODE"), "27437-0110-01",
				"Drug Code validation");

		CommonUtils.compareTextByEqual(
				doc.getFirstPattern("DrugList", "Drug", "PhysicalPropertySetList", "PhysicalPropertySet", "PATTERN"),
				"Banded", "Image pattern validation");
	}

	/**
	 * TC186795 Verify happy path with NDC
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "cko", "All" })
	public void testNDCs() throws Exception {
		System.out.println("In method 'testNDCs'");
		extentReporter.createTest("testNDCs", "Testing IV NDCs");
		XML_Utilities doc = readXMLResponse("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>" + "<IVScreeningRequest>"
				+ "  <NewDrugList SIZE=\"2\">" + "    <Drug CODE=\"00074-1027-02\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>"
				+ "    <Drug CODE=\"00074-1990-10\" TYPE=\"NDC\" STATUS=\"ACTIVE\"/>" + "  </NewDrugList>"
				+ "</IVScreeningRequest>");
		CommonUtils.compareTextByEqual(doc.getErrorListSize(), "0", "List Size validation");
		CommonUtils.compareTextByEqual(doc.getDocumentListSize("DocumentList", "SIZE"), "1",
				"Document list Size validation");

		Assert.assertTrue(doc.isPhraseInTextElement("<font face=\"Verdana\">Amikacin sulfate - Acyclovir sodium</font>",
				"DocumentList", "Document", "Text"));
	}

	/**
	 * 
	 * TC187126
	 */
	@Test(groups = { "cko", "All" })
	public void testTradeName() throws Exception {
		System.out.println("In method 'testTradeName'");
		extentReporter.createTest("testTradeName", "Testing trade name lookup");
		XML_Utilities doc = readXMLResponse("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<LUSRequest LookUpType='TRADE_NAME'>" + "<SearchParameterList SIZE='1'>"
				+ "<SearchParameter NAME='trade_name' VALUE='marin'/>" + "</SearchParameterList>" + "</LUSRequest>");
		CommonUtils.compareTextByEqual(doc.getErrorListSize(), "0", "List Size validation");
		CommonUtils.compareTextByEqual(doc.getDocumentListSize("LookUpRecordList", "HEADER"),
				"trade_name|route|form|strength|ndc", "Lookup Record list Size validation");

		Assert.assertTrue(doc.verifyLookUpRecordsByFieldStartsWith("trade_name", "MARIN"),
				"MARIN is not in trade name field");
	}

	/**
	 * TC186864 must be a male patient with an age that would be a 'possible
	 * child bearing' age I believe CKO's default is 16-60 years old.
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "cko", "All" })
	public void testNoPregLactWarningsWithMalePatient() throws Exception {
		System.out.println("In method 'testNoPregLactWarningsWithMalePatient'");
		extentReporter.createTest("testNoPregLactWarningsWithMalePatient",
				"Testing pregnanct lactation warning for male patient");
		XML_Utilities doc = readXMLResponse("<?xml version=\"1.0\" ?>"
				+ "<MasRequest CLASS=\"PROFESSIONAL\" VERSION=\"1.00\">" + "  <Patient GENDER=\"MALE\" BIRTH_DATE=\""
				+ getBirthdateForGivenAgeInYears(20) + "\" SMOKER=\"TRUE\" PREGNANT=\"FALSE\" LACTATING=\"FALSE\"/>"
				+ "  <NewDrugList SIZE=\"4\">" + "    <Drug CODE=\"00182-1908-01\" TYPE=\"NDC\" />"
				+ "    <Drug CODE=\"00108-5012-20\" TYPE=\"NDC\" />"
				+ "    <Drug CODE=\"00056-0169-70\" TYPE=\"NDC\" />" + "    <Drug CODE=\"114423\" TYPE=\"GFC\" />"
				+ "  </NewDrugList>" + "  <Filter DOCUMENTATION_RATING=\"ANY\" SEVERITY=\"ANY\">"
				+ "    <TypeFilter NAME=\"ALL_TYPES\" />" + "  </Filter>" + "</MasRequest>");
		CommonUtils.compareTextByEqual(doc.getErrorListSize(), "0", "List Size validation");
		CommonUtils.compareTextByEqual(doc.getDocumentListSize("Summary", "INTERACTION_TOTAL"), "34",
				"Total Interactions");
		CommonUtils.compareTextByEqual(doc.getDocumentListSize("Summary", "WARNING_TOTAL"), "34", "Total Warnings");
		CommonUtils.compareTextByEqual(
				doc.getDocumentDrugCodeAttribute("Summary", "InteractionTypeSummaryList", "SIZE"), "6", "Type Summary");

		CommonUtils.compareTextByEqual(doc.getNumberOfWarningsByType("DRUG"), "3", "Number of Drug warnings");
		CommonUtils.compareTextByEqual(doc.getNumberOfWarningsByType("FOOD"), "15", "Number of Food warnings");
		CommonUtils.compareTextByEqual(doc.getNumberOfWarningsByType("ETHANOL"), "3", "Number of Ethanol warnings");
		CommonUtils.compareTextByEqual(doc.getNumberOfWarningsByType("LAB"), "4", "Number of Lab warnings");
		CommonUtils.compareTextByEqual(doc.getNumberOfWarningsByType("TOBACCO"), "1", "Number of Tobacco warnings");
		CommonUtils.compareTextByEqual(doc.getNumberOfWarningsByType("DISEASE"), "8", "Number of Disease warnings");

	}

	@Test(groups = { "cko", "All" })
	public void testCrCl003() throws Exception {
		System.out.println("In method 'testCrCl003'");
		extentReporter.createTest("testCrCl003", "Testing PSD");
		XML_Utilities doc = readXMLResponse("<?xml version=\"1.0\" ?>" + "<CrClCalculatorRequest SCR=\"1.20\">"
				+ " <Patient GENDER=\"MALE\" HEIGHT=\"188\" WEIGHT=\"80\" AGE_IN_DAYS=\"6573\" />"
				+ "</CrClCalculatorRequest>");

		CommonUtils.compareTextByEqual(doc.getErrorListSize(), "0", "List Size validation");
		Assert.assertEquals(doc.getValueFromRoot("SUCCESS"), "TRUE");
		Assert.assertEquals(doc.getValueFromRoot("CRCL"), "109.67");
		Assert.assertEquals(doc.getValueFromRoot("MAX_CRCL"), "122");
		Assert.assertEquals(doc.getValueFromRoot("CALC_METHOD"), "Schwartz 1987");
		Assert.assertEquals(doc.getValueFromRoot("SCR"), "1.2");
		Assert.assertEquals(doc.getValueFromRoot("BSA"), "2.06");
		Assert.assertEquals(doc.getValueFromRoot("BSA_STATUS"), "C");
		Assert.assertEquals(doc.getValueFromRoot("IBW"), "70.816");
		Assert.assertEquals(doc.getValueFromPatient("WEIGHT5"), "53.227");
		Assert.assertEquals(doc.getValueFromPatient("WEIGHT95"), "93.92");
		Assert.assertEquals(doc.getValueFromPatient("HEIGHT5"), "164.242");
		Assert.assertEquals(doc.getValueFromPatient("HEIGHT95"), "188.236");
	}

	/**
	 * TC187326 Verify a 'current' drug is validated for IV but not the other
	 * services
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "cko", "All" })
	public void testInvalidIVDrugGFC() throws Exception {
		System.out.println("In method 'testCrCl003'");
		extentReporter.createTest("testCrCl003", "Testing PSD");
		XML_Utilities doc = readXMLResponse("<?xml version=\"1.0\" ?>"
				+ "<ValidationRequest PSD=\"YES\" DOSE1090=\"YES\" WARNINGLABELS=\"YES\" DRUGNOTES=\"YES\" IVSCREENING=\"YES\" DRUGPOINTS=\"YES\" IMAGESIMPRINTS=\"YES\">"
				+ "  <CurrentDrugList SIZE=\"1\">" + "    <Drug CODE=\"114554\" TYPE=\"GFC\" />"
				+ "    <!--  114554 purposely used as it will come back invalid for IV -->" + "  </CurrentDrugList>"
				+ "</ValidationRequest>");
		CommonUtils.compareTextByEqual(doc.getErrorListSize(), "0", "List Size validation");
		CommonUtils.compareTextByEqual(doc.getNewDrugListSize(), "0", "get new drug list size");
		CommonUtils.compareTextByEqual(doc.getCurrentDrugListSize(), "1", "get current drug list size");
		CommonUtils.compareTextByEqual(doc.getResultForGivenAttributeInCurrent("114554", "DOSE1090"), "NOTAPPLICABLE",
				"get result for given attribure in current");
		CommonUtils.compareTextByEqual(doc.getResultForGivenAttributeInCurrent("114554", "WARNINGLABELS"),
				"NOTAPPLICABLE", "get result for given attribure in current");
		CommonUtils.compareTextByEqual(doc.getResultForGivenAttributeInCurrent("114554", "DRUGNOTES"), "NOTAPPLICABLE",
				"get result for given attribure in current");
		CommonUtils.compareTextByEqual(doc.getResultForGivenAttributeInCurrent("114554", "IVSCREENING"), "INVALID",
				"get result for given attribure in current");
		CommonUtils.compareTextByEqual(doc.getResultForGivenAttributeInCurrent("114554", "DRUGPOINTS"), "NOTAPPLICABLE",
				"get result for given attribure in current");
		CommonUtils.compareTextByEqual(doc.getResultForGivenAttributeInCurrent("114554", "IMAGESIMPRINTS"),
				"NOTAPPLICABLE", "get result for given attribure in current");
		CommonUtils.compareTextByEqual(doc.getResultForGivenAttributeInCurrent("114554", "PSD"), "NOTAPPLICABLE",
				"get result for given attribure in current");

	}

	/*
	 * PHYS009.xml Female - 6590 days = 18 year old
	 * 
	 */

	@Test(groups = { "cko", "All" })
	public void testFemaleTypeBSA18YearOld() throws Exception {
		System.out.println("In method 'testFemaleTypeBSA18YearOld'");
		extentReporter.createTest("testFemaleTypeBSA18YearOld", "Testing Physiology");
		XML_Utilities doc = readXMLResponse("<?xml version='1.0' encoding='iso-8859-1'?>"
				+ "<PhysiologyCalculatorRequest TYPE='BSA'>" + "<Patient GENDER='FEMALE' " + " AGE_IN_DAYS='6570'"
				+ " WEIGHT='87.0' HEIGHT='157'/>" + "</PhysiologyCalculatorRequest>");
		CommonUtils.compareTextByEqual(doc.getDocumentListSize("PhysiologyCalculatorResponseList", "SIZE"), "1",
				"Physiology calculator response list");
		Assert.assertEquals(doc.getCalcValueByType("BSA"), "1.874");
		CommonUtils.compareTextByEqual(doc.getDocumentListSize("PSDMessageList", "SIZE"), "1", "Message list size");

		Assert.assertEquals(doc.getPhraseInMessageElement(),
				"Patient's Weight of 87 kg is outside normal range for patient's age and gender of 45.36 to 81.918 kg.|");
	}

	/**
	 * TC186824 Verifying request w/o language
	 * 
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "cko", "All" })
	public void testWithoutLanguage() throws Exception {
		System.out.println("In method 'testNDC'");
		extentReporter.createTest("testNDC", "Testing NDC");
		XML_Utilities doc = readXMLResponse(
				"<?xml version=\"1.0\" ?>\r\n" + "<WarningLabelsRequest VERSION=\"1.00\" GRAPHIC_CODE=\"Architext\" >"
						+ "  <Patient />" + "  <NewDrugList SIZE=\"1\">" + "    <Drug CODE=\"102367\" TYPE=\"GFC\" />"
						+ "  </NewDrugList>" + "</WarningLabelsRequest>");
		CommonUtils.compareTextByEqual(doc.getErrorListSize(), "0", "List Size validation");
		CommonUtils.compareTextByEqual(doc.getDocumentListSize("DrugList", "SIZE"), "1", "Drog List");
		CommonUtils.compareTextByEqual(doc.getDocumentDrugCodeAttribute("DrugList", "Drug", "CODE"), "102367",
				"First Drug Code");
		CommonUtils.compareTextByEqual(doc.getDocumentDrugCodeAttribute("DrugList", "Drug", "TYPE"), "GFC",
				"First Drug Type");
		CommonUtils.compareTextByEqual(
				doc.getFirstWarningLabelText("DrugList", "Drug", "WarningLabelsList", "WarningLabel"),
				"DRINK PLENTY OF FLUIDS WHILE TAKING THIS MEDICATION", "First warning label text");

	}

}
