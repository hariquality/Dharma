package com.ibm.webservices.testsuite;

import org.testng.annotations.Test;

import com.ibm.webservices.utils.CommonUtils;
import com.ibm.webservices.utils.JSON_Utilities;
import com.ibm.webservices.utils.MDXBaseTest;

public class Test_MDX_Services extends MDXBaseTest
{

   /**
    * Verifies the basic attributes like copyright, contentSetVersionHandle,
    * contentSetName
    * 
    * @throws Exception
    */

   @Test(groups =
   { "mdxservices", "All" })
   public void TC_01_DE_LIST_testBasicAttributes() throws Exception
   {
      extentReporter.createTest("TC_01_DE_LIST_testBasicAttributes",
                                "Testing Drug Evals List Api Response");
      JSON_Utilities doc = readJSONResponse("drugdexevals/documents/list", GET);
      CommonUtils.compareTextByEqual(doc.getAttribute("copyright"),
                                     "Copyright IBM Corporation 2020 Information is for End User's use only and "
                                           + "may not be sold, redistributed or otherwise used for commercial purposes.",
                                     "CopyRight message valiadtion");
      CommonUtils
            .compareTextByContains(doc.getAttribute("contentSetVersionHandle"),
                                   "31_",
                                   "Content set version handle validation");
      CommonUtils.compareTextByEqual(doc.getAttribute("contentSetName"),
                                     "DRUGDEXEVALS",
                                     "ContentSet Name validation");
   }

   /**
    * Verifies the basic attributes like copyright, contentSetVersionHandle,
    * contentSetName
    * 
    * @throws Exception
    */

   @Test(groups =
   { "mdxservices", "All" })
   public void TC_02_DP_LIST_testBasicAttributes() throws Exception
   {
      extentReporter.createTest("TC_02_DP_LIST_testBasicAttributes",
                                "Testing Drug POINTS List Api Response");
      JSON_Utilities doc = readJSONResponse("drugpoints/documents/list", GET);
      CommonUtils.compareTextByEqual(doc.getAttribute("copyright"),
                                     "Copyright IBM Corporation 2020 Information is for End User's use only and "
                                           + "may not be sold, redistributed or otherwise used for commercial purposes.",
                                     "CopyRight message valiadtion");
      CommonUtils
            .compareTextByContains(doc.getAttribute("contentSetVersionHandle"),
                                   "100_",
                                   "Content set version handle validation");
      CommonUtils.compareTextByEqual(doc.getAttribute("contentSetName"),
                                     "DRUGPOINTS",
                                     "ContentSet Name validation");
   }

   /**
    * DRUGPOINTS,100_ Verifies the basic attributes like copyright,
    * contentSetVersionHandle, contentSetName
    * 
    * @throws Exception
    */
   @Test(groups =
   { "mdxservices", "All" })
   public void TC_03_DE_GET_testBasicAttributes() throws Exception
   {
      extentReporter.createTest("TC_03_DE_GET_testBasicAttributes",
                                "Testing Drug Evals Get Api Response");
      JSON_Utilities doc = readJSONResponse("drugdexevals/documents/0001", GET);
      CommonUtils.compareTextByEqual(doc.getAttribute("copyright"),
                                     "Copyright IBM Corporation 2020 Information is for End User's use only and "
                                           + "may not be sold, redistributed or otherwise used for commercial purposes.",
                                     "CopyRight message valiadtion");
      CommonUtils
            .compareTextByContains(doc.getAttribute("contentSetVersionHandle"),
                                   "31_",
                                   "Content set version handle validation");
      CommonUtils.compareTextByEqual(doc.getAttribute("contentSetName"),
                                     "DRUGDEXEVALS",
                                     "ContentSet Name validation");
   }

   /**
    * Verifies the basic attributes like copyright, contentSetVersionHandle,
    * contentSetName
    * 
    * @throws Exception
    */
   @Test(groups =
   { "mdxservices", "All" })
   public void TC_04_DP_GET_testBasicAttributes() throws Exception
   {
      extentReporter.createTest("TC_04_DP_GET_testBasicAttributes",
                                "Testing Drug Points Get Api Response");
      JSON_Utilities doc = readJSONResponse("drugpoints/documents/265090", GET);
      CommonUtils.compareTextByEqual(doc.getAttribute("copyright"),
                                     "Copyright IBM Corporation 2020 Information is for End User's use only and "
                                           + "may not be sold, redistributed or otherwise used for commercial purposes.",
                                     "CopyRight message valiadtion");
      CommonUtils
            .compareTextByContains(doc.getAttribute("contentSetVersionHandle"),
                                   "100_",
                                   "Content set version handle validation");
      CommonUtils.compareTextByEqual(doc.getAttribute("contentSetName"),
                                     "DRUGPOINTS",
                                     "ContentSet Name validation");
   }

   /**
    * Verifies the basic attributes like copyright, contentSetVersionHandle,
    * contentSetName
    * 
    * @throws Exception
    */

   @Test(groups =
   { "mdxservices", "All" })
   public void TC_05_DC_LIST_testBasicAttributes() throws Exception
   {
      extentReporter.createTest("TC_05_DC_LIST_testBasicAttributesC",
                                "Testing Drug Consults List Api Response");
      JSON_Utilities doc = readJSONResponse("drugconsults/documents/list", GET);
      CommonUtils.compareTextByEqual(doc.getAttribute("copyright"),
                                     "Copyright IBM Corporation 2020 Information is for End User's use only and "
                                           + "may not be sold, redistributed or otherwise used for commercial purposes.",
                                     "CopyRight message valiadtion");
      CommonUtils
            .compareTextByContains(doc.getAttribute("contentSetVersionHandle"),
                                   "50_",
                                   "Content set version handle validation");
      CommonUtils.compareTextByEqual(doc.getAttribute("contentSetName"),
                                     "DRUGCONSULTS",
                                     "ContentSet Name validation");
   }

   /**
    * Verifies the basic attributes like copyright, contentSetVersionHandle,
    * contentSetName
    * 
    * @throws Exception
    */
   @Test(groups =
   { "mdxservices", "All" })
   public void TC_06_DC_GET_testBasicAttributes() throws Exception
   {
      extentReporter.createTest("TC_06_DC_GET_testBasicAttributes",
                                "Testing Drug Consults Get Api Response");
      JSON_Utilities doc = readJSONResponse("drugconsults/documents/1355", GET);
      CommonUtils.compareTextByEqual(doc.getAttribute("copyright"),
                                     "Copyright IBM Corporation 2020 Information is for End User's use only and "
                                           + "may not be sold, redistributed or otherwise used for commercial purposes.",
                                     "CopyRight message valiadtion");
      CommonUtils
            .compareTextByContains(doc.getAttribute("contentSetVersionHandle"),
                                   "50_",
                                   "Content set version handle validation");
      CommonUtils.compareTextByEqual(doc.getAttribute("contentSetName"),
                                     "DRUGCONSULTS",
                                     "ContentSet Name validation");
   }

   /**
    * Verifies the basic attributes like copyright, contentSetVersionHandle,
    * contentSetName
    * 
    * @throws Exception
    */
   @Test(groups =
   { "mdxservices", "All" })
   public void TC_07_DN_GET_testBasicAttributes() throws Exception
   {
      extentReporter.createTest("TC_07_DN_GET_testBasicAttributes",
                                "Testing Drug Notes Get Api Response");
      JSON_Utilities doc = readJSONResponse("drugnotes/documents/10001", GET);
      CommonUtils.compareTextByEqual(doc.getAttribute("copyright"),
                                     "Copyright IBM Corporation 2020 Information is for End User's use only and "
                                           + "may not be sold, redistributed or otherwise used for commercial purposes.",
                                     "CopyRight message valiadtion");
      CommonUtils
            .compareTextByContains(doc.getAttribute("contentSetVersionHandle"),
                                   "79_",
                                   "Content set version handle validation");
      CommonUtils.compareTextByEqual(doc.getAttribute("contentSetName"),
                                     "DRUGNOTES",
                                     "ContentSet Name validation");
   }

   /**
    * Verifies the basic attributes like copyright, contentSetVersionHandle,
    * contentSetName
    * 
    * @throws Exception
    */
   @Test(groups =
   { "mdxservices", "All" })
   public void TC_08_CN_GET_testBasicAttributes() throws Exception
   {
      extentReporter.createTest("TC_08_CN_GET_testBasicAttributes",
                                "Testing Care Notes Get Api Response");
      JSON_Utilities doc = readJSONResponse("carenotes/documents/101005", GET);
      CommonUtils.compareTextByEqual(doc.getAttribute("copyright"),
                                     "Copyright IBM Corporation 2020 Information is for End User's use only and "
                                           + "may not be sold, redistributed or otherwise used for commercial purposes.",
                                     "CopyRight message valiadtion");
      CommonUtils
            .compareTextByContains(doc.getAttribute("contentSetVersionHandle"),
                                   "78_",
                                   "Content set version handle validation");
      CommonUtils.compareTextByEqual(doc.getAttribute("contentSetName"),
                                     "CARENOTES",
                                     "ContentSet Name validation");
   }

}
