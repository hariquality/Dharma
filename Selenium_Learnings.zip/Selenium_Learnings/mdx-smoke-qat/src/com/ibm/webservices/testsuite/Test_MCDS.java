package com.ibm.webservices.testsuite;

import org.testng.annotations.Test;

import com.ibm.webservices.utils.CommonUtils;
import com.ibm.webservices.utils.JSON_Utilities;
import com.ibm.webservices.utils.MCDSBaseTest;

public class Test_MCDS extends MCDSBaseTest
{
 String testDataFilePath = "WebServices/MCDS/JSON/" ;
 
 @Test (groups ={"mcds","All"})
 public void TC_01_APPLE_Register() throws Exception{
    extentReporter.createTest("TC_01_APPLE_Register", "Testing Apple Register Api Response");
    JSON_Utilities doc = readJSONResponse(testDataFilePath+"TC_01_Apple_Register","register?test=true",CommonUtils.POST);
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Code"), "0","Code validation");
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Cause"), null,"Cause validation");
 }
  
  /**
   * Verifies the basic attributes like copyright, contentSetVersionHandle, contentSetName
   * @throws Exception
   */
  
 @Test (groups ={"mcds","All"})
  public void TC_02_APPLE_AboutValidation() throws Exception {
    extentReporter.createTest("TC_02_APPLE_AboutValidation", "Testing Apple About Api Response");
    JSON_Utilities doc = readJSONResponse("NA","about?test=true",CommonUtils.GET);
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("About","Application"), "MDX Subscription","Application Name validation");
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("About","Version"), "null","Version validation");
    }
 
 /**
  * Verifies the basic attributes like copyright, contentSetVersionHandle, contentSetName
  * @throws Exception
  */
 
@Test (groups ={"mcds","All"})
 public void TC_03_APPLE_ChangePasswordValidation() throws Exception {
   extentReporter.createTest("TC_03_APPLE_ChangePasswordValidation", "Testing Apple Change Password Api Response");
    JSON_Utilities doc = readJSONResponse(testDataFilePath+"TC_03_Apple_ChangePassword","changepassword?test=true",CommonUtils.POST);
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Code"), "0","Code validation");
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Cause"), null,"Cause validation");
   }

 

 
 @Test (groups ={"mcds","All"})
 public void TC_04_APPLE_ChangeEmail() throws Exception{
    extentReporter.createTest("TC_04_APPLE_ChangeEmail", "Testing Apple Change Email Api Response");
    JSON_Utilities doc = readJSONResponse(testDataFilePath+"TC_04_Apple_ChangeEmail","changeemail?test=true",CommonUtils.POST);
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Code"), "1","Code validation");
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Cause"), "Validation error. Invalid fields:  newEmail not a well-formed email address","Cause validation");
 }
 
 @Test (groups ={"mcds","All"})
 public void TC_05_APPLE_ChangeCredentials() throws Exception{
    extentReporter.createTest("TC_05_APPLE_ChangeCredentials", "Testing Apple Change Credentials Api Response");
    JSON_Utilities doc = readJSONResponse(testDataFilePath+"TC_05_Apple_ChangeCredentials","changecredentials?test=true",CommonUtils.POST);
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Code"), "1","Code validation");
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Cause"), "Validation error. Invalid fields:  newUserName length must be between 5 and 128","Cause validation");
 }
 
 @Test (groups ={"mcds","All"})
 public void TC_09_APPLE_RestorePassword() throws Exception{
    extentReporter.createTest("TC_09_APPLE_RestorePassword", "Testing Apple Restore Password Api Response");
    JSON_Utilities doc = readJSONResponse(testDataFilePath+"TC_09_APPLE_RestorePassword","restorepassword?test=true",CommonUtils.POST);
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Code"), "5","Code validation");
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Cause"), "Authorization failed","Cause validation");
 }
 
 @Test (groups ={"mcds","All"})
 public void TC_06_APPLE_ActivateFeature() throws Exception{
    extentReporter.createTest("TC_06_APPLE_ActivateFeature", "Testing Apple Activate Feature Api Response");
    JSON_Utilities doc = readJSONResponse(testDataFilePath+"TC_06_APPLE_ActivateFeature","activatefeature?test=true",CommonUtils.POST);
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Code"), "0","Code validation");
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Cause"), null,"Cause validation");
 }
 
 @Test (groups ={"mcds","All"})
 public void TC_07_APPLE_GetActiveFeatures() throws Exception{
    extentReporter.createTest("TC_07_APPLE_GetActiveFeatures", "Testing Apple Get active Features Api Response");
    JSON_Utilities doc = readJSONResponse(testDataFilePath+"TC_07_APPLE_GetActiveFeatures","getactivefeatures?test=true",CommonUtils.POST);
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Code"), "0","Code validation");
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Cause"), "micromedex_subscription","Cause validation");
 }
 
 @Test (groups ={"mcds","All"})
 public void TC_08_APPLE_UpdateAccount() throws Exception{
    extentReporter.createTest("TC_08_APPLE_UpdateAccount", "Testing Apple Update Account Features Api Response");
    JSON_Utilities doc = readJSONResponse(testDataFilePath+"TC_08_APPLE_UpdateAccount","updateaccount?test=true",CommonUtils.POST);
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Code"), "1","Code validation");
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Cause"), "Validation error. Invalid fields:  newEmail not a well-formed email address","Cause validation");
 }
 
 @Test (groups ={"mcds","All"})
 public void TC_01_ANDROID_Register() throws Exception{
    extentReporter.createTest("TC_01_ANDROID_Register", "Testing Android Register Api Response");
    JSON_Utilities doc = readJSONResponse(testDataFilePath+"TC_01_Android_Register","android/register?test=true",CommonUtils.POST);
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Code"), "0","Code validation");
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Cause"), null,"Cause validation");
 }
  
  /**
   * Verifies the basic attributes like copyright, contentSetVersionHandle, contentSetName
   * @throws Exception
   */
  
 @Test (groups ={"mcds","All"})
  public void TC_02_ANDROID_AboutValidation() throws Exception {
    extentReporter.createTest("TC_02_ANDROID_AboutValidation", "Testing Android About Api Response");
    JSON_Utilities doc = readJSONResponse("NA","about?test=true",CommonUtils.GET);
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("About","Application"), "MDX Subscription","Application Name validation");
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("About","Version"), "null","Version validation");
    }
 
 /**
  * Verifies the basic attributes like copyright, contentSetVersionHandle, contentSetName
  * @throws Exception
  */
 
@Test (groups ={"mcds","All"})
 public void TC_03_ANDROID_ChangePasswordValidation() throws Exception {
   extentReporter.createTest("TC_03_ANDROID_ChangePasswordValidation", "Testing Android Change Password Api Response");
    JSON_Utilities doc = readJSONResponse(testDataFilePath+"TC_03_Android_ChangePassword","android/changepassword?test=true",CommonUtils.POST);
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Code"), "0","Code validation");
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Cause"), null,"Cause validation");
   }

 

 
 @Test (groups ={"mcds","All"})
 public void TC_04_ANDROID_ChangeEmail() throws Exception{
    extentReporter.createTest("TC_04_ANDROID_ChangeEmail", "Testing Android Change Email Api Response");
    JSON_Utilities doc = readJSONResponse(testDataFilePath+"TC_04_Android_ChangeEmail","android/changeemail?test=true",CommonUtils.POST);
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Code"), "1","Code validation");
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Cause"), "Validation error. Invalid fields:  newEmail not a well-formed email address","Cause validation");
 }
 
 @Test (groups ={"mcds","All"})
 public void TC_05_ANDROID_ChangeCredentials() throws Exception{
    extentReporter.createTest("TC_05_ANDROID_ChangeCredentials", "Testing Android Change Credentials Api Response");
    JSON_Utilities doc = readJSONResponse(testDataFilePath+"TC_05_Android_ChangeCredentials","android/changecredentials?test=true",CommonUtils.POST);
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Code"), "1","Code validation");
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Cause"), "Validation error. Invalid fields:  newUserName length must be between 5 and 128","Cause validation");
 }
 
 @Test (groups ={"mcds","All"})
 public void TC_09_ANDROID_RestorePassword() throws Exception{
    extentReporter.createTest("TC_09_ANDROID_RestorePassword", "Testing Android Restore Password Api Response");
    JSON_Utilities doc = readJSONResponse(testDataFilePath+"TC_09_ANDROID_RestorePassword","android/restorepassword?test=true",CommonUtils.POST);
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Code"), "5","Code validation");
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Cause"), "Authorization failed","Cause validation");
 }
 
 @Test (groups ={"mcds","All"})
 public void TC_06_ANDROID_ActivateFeature() throws Exception{
    extentReporter.createTest("TC_06_ANDROID_ActivateFeature", "Testing Android Activate Feature Api Response");
    JSON_Utilities doc = readJSONResponse(testDataFilePath+"TC_06_ANDROID_ActivateFeature","android/activatefeature?test=true",CommonUtils.POST);
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Code"), "0","Code validation");
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Cause"), null,"Cause validation");
 }
 
 @Test (groups ={"mcds","All"})
 public void TC_07_ANDROID_GetActiveFeatures() throws Exception{
    extentReporter.createTest("TC_07_ANDROID_GetActiveFeatures", "Testing Android Get active Features Api Response");
    JSON_Utilities doc = readJSONResponse(testDataFilePath+"TC_07_ANDROID_GetActiveFeatures","android/getactivefeatures?test=true",CommonUtils.POST);
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Code"), "0","Code validation");
    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Cause"), "micromedex_subscription","Cause validation");
 }
 
 @Test (groups ={"mcds","All"})
 public void TC_08_ANDROID_UpdateAccount() throws Exception{
	   extentReporter.createTest("TC_08_ANDROID_UpdateAccount", "Testing Android Update Account Features Api Response");
	    JSON_Utilities doc = readJSONResponse(testDataFilePath+"TC_08_ANDROID_UpdateAccount","android/updateaccount?test=true",CommonUtils.POST);
	    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Code"), "1","Code validation");
	    CommonUtils.compareTextByEqual(doc.getAttributeValueFromJsonObject("Result","Cause"), "Validation error. Invalid fields:  newEmail not a well-formed email address","Cause validation");
	 }

  
}
