package com.ibm.webservices.testsuite;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.ibm.webservices.pageObjects.infobutton.Infobutton_HomePage;
import com.ibm.webservices.pageObjects.infobutton.Infobutton_MDXPage;
import com.ibm.webservices.utils.InfoButtonBaseTest;
import com.ibm.webservices.utils.XML_Utilities;

public class Test_InfoButton extends InfoButtonBaseTest {
	
	
	@Test(groups = { "infobutton", "All" })
	public void TC_01_VerifyHTMLResponse() throws Exception {
		extentReporter.createTest("TC_01_VerifyHTMLResponse", "Testing HTML Api Response");
		Infobutton_HomePage infobuttonHomePage = launchInfobuttonURL(
				"&mainSearchCriteria.v.dn=aspirin&holder.assignedEntity.n=702180001&holder.assignedEntity.certificateText=702180001&responseFormat=html");
		Infobutton_MDXPage mdxPage = infobuttonHomePage.clickAcetaminophen();
		mdxPage.clickDosingInfo();

	}

	@Test(groups = { "infobutton", "All" })
	public void TC_02_VerifyICD10CodeSearch() throws Exception {
		extentReporter.createTest("TC_02_VerifyICD10CodeSearch", "Testing ICD 10 Code Search");
		Infobutton_HomePage infobuttonHomePage = launchInfobuttonURL(
				"&mainSearchCriteria.v.dn=ear&mainSearchCriteria.v.c=2.16.840.1.113883.6.96&mainSearchCriteria.v.cs=2.16.840.1.113883.6.69&holder.assignedEntity.n=702180001&holder.assignedEntity.certificateText=702180001&responseFormat=htmlICD10-CM");
		infobuttonHomePage.verifyICD10Drug();
	}

	@Test(groups = { "infobutton", "All" })
	public void TC_03_VerifyXMLResponse() throws Exception {
		extentReporter.createTest("TC_03_VerifyXMLResponse", "Testing XML Api Response");
		XML_Utilities doc = readXMLResponse(
				"&mainSearchCriteria.v.dn=aspirin&holder.assignedEntity.n=702180001&holder.assignedEntity.certificateText=702180001&responseFormat=xml");
		Assert.assertEquals(doc.getDrugName(), "Acetaminophen");
	}

	@Test(groups = { "infobutton", "All" })
	public void TC_04_VerifyFilter_SectionSelection() throws Exception {
		extentReporter.createTest("TC_04_VerifyFilter_SectionSelection", "Testing filter based on section selection");
		XML_Utilities doc = readXMLResponse(
				"&mainSearchCriteria.v.dn=ear&mainSearchCriteria.v.c=2.16.840.1.113883.6.96&mainSearchCriteria.v.cs=2.16.840.1.113883.6.69&holder.assignedEntity.n=702180001&holder.assignedEntity.certificateText=702180001&modifier=Treatment&responseFormat=xml");
		Assert.assertEquals(doc.getDrugName(), "Carbamide Peroxide");
	}

	@Test(groups = { "infobutton", "All" })
	public void TC_05_VerifyDiseaseSearch() throws Exception {
		extentReporter.createTest("TC_05_VerifyDiseaseSearch", "Testing disease search");
		XML_Utilities doc = readXMLResponse(
				"&mainSearchCriteria.v.dn=lyme%20disease&mainSearchCriteria.v.c=2.16.840.1.113883.6.96&mainSearchCriteria.v.cs=2.16.840.1.113883.6.69&holder.assignedEntity.n=702180001&holder.assignedEntity.certificateText=702180001&responseFormat=xml");
		Assert.assertEquals(doc.getDrugName(), "Lyme disease - Acute");
	}

	@Test(groups = { "infobutton", "All" })
	public void TC_06_VerifyContextSearch() throws Exception {
		extentReporter.createTest("TC_06_VerifyContextSearch", "Testing context search");
		XML_Utilities doc = readXMLResponse(
				"&mainSearchCriteria.v.dn=Serum%20uric%20acid%20measurement&mainSearchCriteria.v.c=2.16.840.1.113883.6.1&mainSearchCriteria.v.cs=2.16.840.1.113883.6.69&holder.assignedEntity.n=702180001&holder.assignedEntity.certificateText=702180001&responseFormat=xml");
		Assert.assertEquals(doc.getDrugName(), "Serum uric acid measurement");
	}

	@Test(groups = { "infobutton", "All" })
	public void TC_07_VerifyDrugSearch() throws Exception {
		extentReporter.createTest("TC_07_VerifyDrugSearch", "Testing drug search");
		XML_Utilities doc = readXMLResponse(
				"&mainSearchCriteria.v.dn=aspirin&holder.assignedEntity.n=702180001&holder.assignedEntity.certificateText=702180001&responseFormat=xml");
		Assert.assertEquals(doc.getDrugName(), "Acetaminophen");
	}

}
