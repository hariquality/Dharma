package com.ibm.webservices.utils;

import java.util.Iterator;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.Namespace;

/**
 * BasePage to contain common XML document methods
 * 
 * @author APeavy
 * 
 */
public class XML_Utilities {

	Document doc;

	public XML_Utilities(Document inputDoc) {
		doc = inputDoc;
	}

	public String getSuccessValue() {
		return doc.getRootElement().getAttributeValue("SUCCESS");
	}

	public String getErrorListSize() {
		if (doc.getRootElement().getChild("ErrorList") == null) {
			return "0";
		} else {
			return doc.getRootElement().getChild("ErrorList").getAttributeValue("SIZE");

		}
	}

	public String getErrorListErrorText() {
		return doc.getRootElement().getChild("ErrorList").getChild("Error").getAttributeValue("ERROR_TEXT");
	}

	public String getDocumentListSize(String parent, String attribute) {
		return doc.getRootElement().getChild(parent).getAttributeValue(attribute);
	}

	public String getDocumentDrugCodeAttribute(String parent, String child, String attribute) {
		return doc.getRootElement().getChild(parent).getChild(child).getAttributeValue(attribute);
	}

	public String getFirstWarningLabelText(String parent, String child, String child1, String childText) {
		return doc.getRootElement().getChild(parent).getChild(child).getChild(child1).getChildText(childText);
	}

	public String getFirstPattern(String parent, String child, String child1, String child2, String attribute) {
		return doc.getRootElement().getChild(parent).getChild(child).getChild(child1).getChild(child2)
				.getAttributeValue(attribute);
	}

	public Boolean isPhraseInTextElement(String phrase, String parent, String child, String childText) {
		if (doc.getRootElement().getChild(parent).getChild(child).getChildText(childText).replaceAll("\\s+", " ")
				.contains(phrase)) {
			return true;
		} else
			return false;
	}

	public Boolean verifyLookUpRecordsByFieldStartsWith(String fieldName, String expectedValue) {
		int errorCount = 0;
		// get and split header
		String header = doc.getRootElement().getChild("LookUpRecordList").getAttributeValue("HEADER");
		String[] headers = header.split("[|]");
		// determine index for input fieldName
		int index = 0;
		for (int i = 0; i < headers.length; i++) {
			if (headers[i].contentEquals(fieldName)) {
				index = i;
				break;
			}
		}
		// get all records
		List<?> lookUpRecords = doc.getRootElement().getChild("LookUpRecordList").getChildren("LookUpRecord");
		// iterate through all returned records
		for (Object lookUpRecord : lookUpRecords) {
			String record = ((Element) lookUpRecord).getText();
			// split record
			String[] recordData = record.split("[|]");
			if (!recordData[index].startsWith(expectedValue)) {
				errorCount++;
			}
		}
		if (errorCount > 0) {
			return false;
		} else
			return true;
	}

	public String getNumberOfWarningsByType(String inputType) {
		String totalValue = null;
		List<?> warnings = doc.getRootElement().getChild("Summary").getChild("InteractionTypeSummaryList")
				.getChildren();
		Iterator<?> i = warnings.iterator();
		while (i.hasNext()) {
			Element summary = (Element) i.next();
			if (summary.getAttributeValue("TYPE").compareTo(inputType) == 0) {
				totalValue = summary.getAttributeValue("TOTAL");
				break;
			}
		}
		return totalValue;
	}

	public String getValueFromRoot(String attrName) {
		return doc.getRootElement().getAttributeValue(attrName);
	}

	public String getValueFromPatient(String attrName) {
		return doc.getRootElement().getChild("Patient").getAttributeValue(attrName);
	}

	public String getNewDrugListSize() {
		if (doc.getRootElement().getChild("NewDrugList") == null) {
			return "0";
		} else {
			return doc.getRootElement().getChild("NewDrugList").getAttributeValue("SIZE");
		}
	}

	public String getCurrentDrugListSize() {
		if (doc.getRootElement().getChild("CurrentDrugList") == null) {
			return "0";
		} else {
			return doc.getRootElement().getChild("CurrentDrugList").getAttributeValue("SIZE");
		}
	}

	/**
	 * Gets the attribute for a given Current drug code.
	 * 
	 * @param drugCode
	 * @param attributeName
	 * @return
	 */
	public String getResultForGivenAttributeInCurrent(String drugCode, String attributeName) {
		List<?> currentDrugs = doc.getRootElement().getChild("CurrentDrugList").getChildren("Drug");
		String result = "";
		for (Object drug : currentDrugs) {
			if (((Element) drug).getAttributeValue("CODE").compareTo(drugCode) == 0) {
				result = ((Element) drug).getAttributeValue(attributeName);
				break;
			}
		}
		if (result != "") {
			return result;
		} else
			return "drug not found";
	}

	public String getCalcValueByType(String calcType) {
		String totalValue = null;
		List<?> warnings = doc.getRootElement().getChild("PhysiologyCalculatorResponseList").getChildren();
		Iterator<?> i = warnings.iterator();
		while (i.hasNext()) {
			Element calcResponse = (Element) i.next();
			if (calcResponse.getAttributeValue("TYPE").compareTo(calcType) == 0) {
				totalValue = calcResponse.getAttributeValue("CALC_VALUE");
				break;
			}
		}
		return totalValue;
	}

	public String getPhraseInMessageElement() {
		StringBuilder messages = new StringBuilder();
		List<?> pSDMesssages = doc.getRootElement().getChild("PSDMessageList").getChildren("PSDMessage");
		for (Object pSDMessage : pSDMesssages) {
			messages.append(((Element) pSDMessage).getAttributeValue("MSG_TEXT"));
			messages.append("|");

		}
		return messages.toString();
	}

	public String getDrugName() {
		Namespace ns = Namespace.getNamespace("https://www.micromedexsolutions.com/infobutton/webtier/schemas");
		return doc.getRootElement().getChild("results", ns).getChild("contentDocument", ns).getChildText("title", ns);
	}

}
