package com.ibm.webservices.utils;

import static org.testng.Assert.fail;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.apache.log4j.Logger;
import org.jdom.Document;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.ibm.webapp.utils.Selenese;
import com.ibm.webservices.config.ExtentReporter;
import com.ibm.webservices.config.WebServices_JenkinsConfiguration;
import com.ibm.webservices.pageObjects.infobutton.Infobutton_HomePage;

import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * Creates convenience methods for driving CKO
 * 
 * @author Argon Team
 *
 */

public class InfoButtonBaseTest extends WebServices_JenkinsConfiguration {
	public WebDriver driver;

	protected Logger log = Logger.getLogger(InfoButtonBaseTest.class);

	protected static ExtentReporter extentReporter = ExtentReporter.getInstance();

	public XML_Utilities readXMLResponse(String request) {
		InputStream responseStream = sendRequestToIBServer(request);
		XML_Utilities docPage = new XML_Utilities(buildDoc(responseStream));
		return docPage;
	}

	private Document buildDoc(InputStream is) {
		Document doc = null;
		SAXBuilder builder = new SAXBuilder();
		try {
			doc = builder.build(is);
		} catch (JDOMException | IOException e) {
			e.printStackTrace();
		}
		// end output of xml for debugging
		return doc;
	}

	public String getXMLResponseAsString(String request) {
		InputStream responseStream = sendRequestToIBServer(request);

		// read responseStream into string result to return
		BufferedInputStream buf = new BufferedInputStream(responseStream);
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		int i = 0;
		while (i >= 0) {
			try {
				i = buf.read();
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (i != -1) {
				out.write(i);
			}
		}

		String response = out.toString();
		return response;
	}

	private InputStream sendRequestToIBServer(String reqString) {
		InputStream is = null;
		String urlValue = null;
		try {
			urlValue = "https://" + executeEnv + getValueFromPropertiesFile("info_button_url") + "?" + reqString;

			URL url = new URL(urlValue);
			URLConnection connection = url.openConnection();
			// connection.setRequestProperty("Content-Type", "text/html");
			connection.setDoOutput(true);

			OutputStream os = connection.getOutputStream();
			os.write(reqString.getBytes(), 0, reqString.getBytes().length);
			os.close();

			is = connection.getInputStream();
		} catch (Exception exception) {
			fail("caught exception in sendRequestToInfoButtonServer:" + exception.getMessage());
		}

		return is;
	}

	/**
	 * @param fileName
	 *            (xml input request)
	 * @return
	 * @throws IOException
	 */
	public String readXMLFile(String fileName) throws IOException {
		return new String(Files.readAllBytes(Paths.get("./xml/" + fileName + ".xml")));
	}

	public Infobutton_HomePage launchInfobuttonURL(String reqString) throws IOException, InterruptedException {
		Selenese.killBrowserDrivers("chrome");
		Thread.sleep(2000);
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		String url = "https://" + executeEnv + getValueFromPropertiesFile("info_button_url") + "?" + reqString;
		driver.get(url);
		return PageFactory.initElements(driver, Infobutton_HomePage.class);

	}

	@BeforeTest(alwaysRun = true)
	public void startReport() throws IOException {
		extentReporter.getExtendReport();
	}

	@AfterTest(alwaysRun = true)
	public void updateReport() {
		extentReporter.flush();
	}

}
