package com.ibm.webservices.utils;

import static org.testng.Assert.fail;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.jdom.Document;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

import com.ibm.webservices.config.ExtentReporter;
import com.ibm.webservices.config.WebServices_JenkinsConfiguration;


/**
 * Creates convenience methods for driving CKO
 * 
 * @author APeavy
 *
 */

public class CKOBaseTest extends WebServices_JenkinsConfiguration
{
   protected static ExtentReporter extentReporter = ExtentReporter.getInstance();
   public XML_Utilities readXMLResponse(String request)
   {
      InputStream responseStream = sendRequestToCKOServer(request);
      XML_Utilities docPage = new XML_Utilities(buildDoc(responseStream));
      return docPage;
   }

   private Document buildDoc(InputStream is)
   {
      Document doc = null;
      SAXBuilder builder = new SAXBuilder();
      try
      {
         doc = builder.build(is);
      }
      catch (JDOMException | IOException e)
      {
         e.printStackTrace();
      }

      // end output of xml for debugging
      return doc;
   }

   public String getXMLResponseAsString(String request)
   {
      InputStream responseStream = sendRequestToCKOServer(request);

      // read responseStream into string result to return
      BufferedInputStream buf = new BufferedInputStream(responseStream);
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      int i = 0;
      while (i >= 0)
      {
         try
         {
            i = buf.read();
         }
         catch (IOException e)
         {
            e.printStackTrace();
         }
         if (i != -1)
         {
            out.write(i);
         }
      }

      String response = out.toString();
      return response;
   }

   private InputStream sendRequestToCKOServer(String reqString)
   {
      InputStream is = null;
      String urlValue = null;
      try
      {
           urlValue =  "https://"+executeEnv+getValueFromPropertiesFile("cko_thids_url");;
         URL url = new URL(urlValue);
         URLConnection connection = url.openConnection();
         connection.setRequestProperty("Content-Type", "text/xml");
         connection.setDoOutput(true);

         OutputStream os = connection.getOutputStream();
         os.write(reqString.getBytes(), 0, reqString.getBytes().length);
         os.close();

         is = connection.getInputStream();
      }
      catch (Exception exception)
      {
         fail("caught exception in sendRequestToCKOServer:"
               + exception.getMessage());
      }

      return is;
   }

   /**
    * Returns a birthdate in the format of mm/dd/yyyy
    * 
    * @param inputAgeInYears
    * @return
    */
   public String getBirthdateForGivenAgeInYears(int inputAgeInYears)
   {
      Calendar calBirthdate = Calendar.getInstance();
      calBirthdate.add(Calendar.YEAR, 0 - inputAgeInYears);
      Date birthdate = calBirthdate.getTime();
      SimpleDateFormat format = new SimpleDateFormat("M/dd/yyyy");
      String returnBirthdate = format.format(birthdate);
      return returnBirthdate;
   }

   /**
    * Returns a birthday string represented in the Dose1090 format Also takes 2
    * days away to prevent GMT time-based systems from not recognizing intended
    * date. Format: BD_MONTH="1" BD_DAY="26" BD_YEAR="1955"
    * 
    * @param inputAgeInYears
    * @return
    */
   public String getDose1090DateAttributesForGivenAgeInYears(int inputAgeInYears)
   {
      Calendar bDay = Calendar.getInstance();
      bDay.add(Calendar.YEAR, -inputAgeInYears);
      String dose1090BirthDate = "BD_MONTH=\"" + (bDay.get(Calendar.MONTH) + 1)
            + "\" BD_DAY=\"" + (bDay.get(Calendar.DAY_OF_MONTH) - 2)
            + "\" BD_YEAR=\"" + bDay.get(Calendar.YEAR) + "\"";
      return dose1090BirthDate;
   }

   /**
    * @param fileName
    *           (xml input request)
    * @return
    * @throws IOException
    */
   public String readXMLFile(String fileName) throws IOException
   {
      return new String(Files
            .readAllBytes(Paths.get("./xml/" + fileName + ".xml")));
   }
}
