package com.ibm.webservices.utils;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.ibm.webservices.config.ExtentReporter;
import com.ibm.webservices.config.WebServices_JenkinsConfiguration;

import net.sf.json.JSONArray;
import net.sf.json.JSONException;
import net.sf.json.JSONObject;

/**
 * Creates convenience methods for driving CKO
 * 
 * @author APeavy
 *
 */

public class MCDSBaseTest extends WebServices_JenkinsConfiguration {
	protected static ExtentReporter extentReporter = ExtentReporter.getInstance();
	RestTemplate restTemplate = new RestTemplate();

	/**
	 * Sends request to MCDS server and forms the connection and returns the
	 * response stream
	 * 
	 * @param apiRequestFile:
	 *            Request body json file
	 * @param endPointURL
	 *            : End point URL
	 * @param reqType
	 *            : Type of request for example:GET,POST etc.
	 */
	public ResponseEntity<String> sendRequestToMCDSServer(String requestBodyFile, String endPointURL, String reqType)
			throws IOException {
		String urlValue;
		String inputRequest = null;
		ResponseEntity<String> loginResponse = null;
		try {
			if (!requestBodyFile.equalsIgnoreCase("NA")) {
				inputRequest = readJsonFile(requestBodyFile);
				isJSONValid(inputRequest);
			}
			urlValue = "https://" + executeEnv + getValueFromPropertiesFile("mcds_url");
			@SuppressWarnings("unused")
			URL url = new URL(urlValue + endPointURL);
			// set headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> entity = new HttpEntity<String>(inputRequest, headers);
			// send request and parse result
			if (reqType.equals("GET")) {
				loginResponse = restTemplate.exchange(urlValue + endPointURL, HttpMethod.GET, entity, String.class);
			} else if (reqType.equals("POST")) {
				loginResponse = restTemplate.exchange(urlValue + endPointURL, HttpMethod.POST, entity, String.class);
			}

		} catch (Exception exception) {
			HttpStatusCodeException httpClientErrorException = (HttpStatusCodeException) exception;
			return new ResponseEntity<String>("Exception Occured", httpClientErrorException.getStatusCode());

		}
		return loginResponse;
	}

	/**
	 * Method to get the JSON response as a String.
	 * 
	 * @param apiRequest
	 *            = enter the requestURL for the API
	 * @param requestType
	 *            = enter the request Type as GET, PUT,POST,DELETE
	 * @return
	 * @throws IOException
	 */
	public String getJSONResponse(String requestBodyFile, String endPointURL, String reqType) throws IOException {
		String responseMessage = null, errorMessage = null;
		ResponseEntity<String> response = sendRequestToMCDSServer(requestBodyFile, endPointURL, reqType);

		if (response != null && response.getStatusCode().equals(HttpStatus.OK)) {
			responseMessage = response.getBody();
		} else {
			switch (response.getStatusCodeValue()) {
			case 400:
				errorMessage = "Bad Request, the server could not understand the request due to invalid syntax.";
				break;
			case 401:
				errorMessage = "Authorization Error, Please check the credentials.";
				break;
			case 404:
				errorMessage = "The server can not find the requested resource.";
				break;
			case 500:
				errorMessage = "Internal Server Error";
				break;
			}
			ExtentReporter.FAIL("Response Code Validation", errorMessage + ":" + response.getStatusCode());
			assertEquals(response.getStatusCode(), "200", errorMessage);
		}
		return responseMessage;
	}

	/**
	 * @param fileName
	 *            (json input request)
	 * @return
	 * @throws IOException
	 */
	public String readJsonFile(String fileName) throws IOException {
		String fileData = null;
		try {
			fileData = new String(Files.readAllBytes(Paths.get("./TestData/" + fileName + ".json")));
		} catch (Exception e) {
			ExtentReporter.FAIL("File Not Found", "Please check the input file " + e.getMessage());
			throw new AssertionError("PLease check input file", e);
		}
		return fileData;
	}

	public void isJSONValid(String test) {
		String errorMessage1 = null;
		String errorMessage2 = null;
		try {
			JSONObject.fromObject(test);
		} catch (JSONException ex) {
			errorMessage1 = "Input JSON Object is not valid";
			ExtentReporter.FAIL("Input JSON Validation", errorMessage1);
			try {
				new JSONArray(test);
			} catch (JSONException ex1) {
				errorMessage2 = "Input JSON array is not valid";
				ExtentReporter.FAIL("Input JSON Validation", errorMessage2);
			}
		}

		if (errorMessage1 != null || errorMessage2 != null) {
			throw new AssertionError(" Incorrect input json format");
		}
	}

	@BeforeTest(alwaysRun = true)
	public void startReport() throws IOException {
		extentReporter.getExtendReport();
	}

	@AfterTest(alwaysRun = true)
	public void updateReport() {
		extentReporter.flush();
	}

	/**
	 * Base Method to read a json request and response
	 * 
	 * @param requestParametersinURL
	 *            = enter the requestURL for the API
	 * @param requestType
	 *            = enter the request Type as GET, PUT,POST,DELETE
	 * @return page api class objects
	 * @throws IOException
	 */
	public JSON_Utilities readJSONResponse(String requestBody, String requestParametersinURL, String requestType)
			throws IOException {
		String responseStream = getJSONResponse(requestBody, requestParametersinURL, requestType);
		JSON_Utilities jsonUtils = new JSON_Utilities(buildDoc(responseStream));
		return jsonUtils;
	}

	/**
	 * this method converts a json response(String) into JSON Object
	 * 
	 * @param JSONresponse
	 *            json Response obtained from request
	 * @return json object
	 */
	public JSONObject buildDoc(String JSONresponse) {
		JSONObject jo = JSONObject.fromObject(JSONresponse);
		return jo;
	}
}
