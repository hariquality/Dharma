package com.ibm.webservices.utils;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.ibm.webservices.config.ExtentReporter;
import com.ibm.webservices.config.WebServices_JenkinsConfiguration;

import net.sf.json.JSONArray;
import net.sf.json.JSONException;
import net.sf.json.JSONObject;

/**
 * This class contains the base methods to send the request to the server and
 * returns the response in string format This class returns json objects at the
 * page level, which will be helpful to create functional methods to test the
 * required api.
 * 
 * @author c400594
 */

public class MDXBaseTest extends WebServices_JenkinsConfiguration {
	protected static ExtentReporter extentReporter = ExtentReporter.getInstance();
	public String GET = "GET";
	public String PUT = "PUT";
	public String POST = "POST";
	public String DELETE = "DELETE";

	// regulatory authority details
	public String FDA = "FDA";
	public String EMA = "EMA";
	public String HC = "HC";
	public String FDA_EMA = "FDA/EMA";
	public String FDA_HC = "FDA/HC";
	public String EMA_HC = "EMA/HC";

	// api serviceName
	public static final String DE = "drugdexevals";
	public static final String DP = "drugpoints";
	public static final String DC = "drugconsults";
	public static final String DN = "drugnotes";
	public static final String CN = "carenotes";

	// excel constants
	public String fileName = "MDX_Services_TestData";
	public List<List<String>> _rowList = null;

	RestTemplate restTemplate = new RestTemplate();

	/**
	 * Base Method to read a json request and response
	 * 
	 * @param requestParametersinURL
	 *            = enter the requestURL for the API
	 * @param requestType
	 *            = enter the request Type as GET, PUT,POST,DELETE
	 * @return page api class objects
	 * @throws IOException
	 */
	public JSON_Utilities readJSONResponse(String requestParametersinURL, String requestType) throws IOException {
		String responseStream = getJSONResponseAsString(requestParametersinURL, requestType);
		JSON_Utilities jsonUtils = new JSON_Utilities(buildDoc(responseStream));
		return jsonUtils;
	}

	/**
	 * Sends request to MDX server to form the connection and returns the
	 * response stream
	 */
	public ResponseEntity<String> sendRequestToMDXServer(String apiRequest, String requestType) throws IOException {
		ResponseEntity<String> response = null;
		try {
			String urlValue;
			urlValue = "https://" + executeEnv + getValueFromPropertiesFile("mdx_services_url");
			HttpHeaders headers = new HttpHeaders();
			String encodedCredentials = "Basic "
					+ Base64.getEncoder().encodeToString((getValueFromPropertiesFile("mdxservices_username").trim()
							+ ":" + getValueFromPropertiesFile("mdxservices_password").trim()).getBytes());
			headers.set("Authorization", encodedCredentials);
			HttpEntity<String> requestEntity = new HttpEntity<>(headers);

			if (requestType.equals(GET)) {
				response = restTemplate.exchange(urlValue + apiRequest, HttpMethod.GET, requestEntity, String.class);
			} else if (requestType.equals(POST)) {
				response = restTemplate.exchange(urlValue + apiRequest, HttpMethod.POST, requestEntity, String.class);
			}

			else if (requestType.equals(PUT)) {
				response = restTemplate.exchange(urlValue + apiRequest, HttpMethod.PUT, requestEntity, String.class);
			}

			else {
				response = restTemplate.exchange(urlValue + apiRequest, HttpMethod.DELETE, requestEntity, String.class);
			}

		} catch (Exception exception) {
			HttpStatusCodeException httpClientErrorException = (HttpStatusCodeException) exception;
			return new ResponseEntity<String>("Exception Occured", httpClientErrorException.getStatusCode());

		}
		return response;
	}

	/**
	* 
	*/
	public String getStatusCodeFromResponse(ResponseEntity<String> doc) {

		return doc.getStatusCode().toString();

	}

	/**
	 * Method to get the JSON response as a String.
	 * 
	 * @param apiRequest
	 *            = enter the requestURL for the API
	 * @param requestType
	 *            = enter the request Type as GET, PUT,POST,DELETE
	 * @return
	 * @throws IOException
	 */
	public String getJSONResponseAsString(String apiRequest, String requestType) throws IOException {
		String responseMessage = null, errorMessage = null;
		ResponseEntity<String> response = sendRequestToMDXServer(apiRequest, requestType);

		if (response != null && response.getStatusCode().equals(HttpStatus.OK)) {
			responseMessage = response.getBody();
		} else {
			switch (response.getStatusCodeValue()) {
			case 400:
				errorMessage = "Bad Request, the server could not understand the request due to invalid syntax.";
				break;
			case 401:
				errorMessage = "Authorization Error, Please check the credentials.";
				break;
			case 404:
				errorMessage = "The server can not find the requested resource.";
				break;
			case 500:
				errorMessage = "Internal Server Error";
				break;
			}
			ExtentReporter.FAIL("Response Code Validation", errorMessage + ":" + response.getStatusCode());
			assertEquals(response.getStatusCode(), "200", errorMessage);
		}
		return responseMessage;
	}

	/**
	 * this method converts a json response(String) into JSON Object
	 * 
	 * @param JSONresponse
	 *            json Response obtained from request
	 * @return json object
	 */
	public JSONObject buildDoc(String JSONresponse) {
		JSONObject jo = JSONObject.fromObject(JSONresponse);
		return jo;
	}

	/**
	 * Sends request to CPSI server and forms the connection and returns the
	 * response stream
	 */
	public ResponseEntity<String> sendRequestToPostServerWithJsonBody(String apiRequestFile, String reqString)
			throws IOException {
		ResponseEntity<String> loginResponse = null;
		try {
			String inputRequest = readJsonFile(apiRequestFile);
			String urlValue;

			if (isJSONValid(inputRequest)) {
				urlValue = "https://" + executeEnv + getValueFromPropertiesFile("mdx_services_url");
				URL url = new URL(urlValue + reqString);
				System.out.println("url:" + url.toString());
				// set headers
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				HttpEntity<String> entity = new HttpEntity<String>(inputRequest, headers);

				// send request and parse result
				loginResponse = restTemplate.exchange(urlValue + reqString, HttpMethod.POST, entity, String.class);
			} else {
				System.out.println("Invalid JSON Request");
			}

		} catch (Exception exception) {
			HttpStatusCodeException httpClientErrorException = (HttpStatusCodeException) exception;
			return new ResponseEntity<String>("Exception Occured", httpClientErrorException.getStatusCode());

		}
		return loginResponse;
	}

	/**
	 * @param fileName
	 *            (json input request)
	 * @return
	 * @throws IOException
	 */
	public String readJsonFile(String fileName) throws IOException {
		return new String(Files.readAllBytes(Paths.get("./json/" + fileName + ".json")));
	}

	public static boolean isJSONValid(String test) {
		try {
			JSONObject.fromObject(test);
		} catch (JSONException ex) {

			try {
				new JSONArray(test);
			} catch (JSONException ex1) {
				return false;
			}
		}
		return true;
	}

	@BeforeTest(alwaysRun = true)
	public void startReport() throws IOException {
		extentReporter.getExtendReport();
	}

	@AfterTest(alwaysRun = true)
	public void updateReport() {
		extentReporter.flush();
	}

}
