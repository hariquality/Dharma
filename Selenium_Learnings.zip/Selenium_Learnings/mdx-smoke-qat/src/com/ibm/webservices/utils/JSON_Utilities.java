package com.ibm.webservices.utils;

import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * BasePage which contain common JSON methods, use this class methods the get any value from the required fields
 * @author HariHaran
 */
public class JSON_Utilities {

	protected JSONObject jo;
	protected Object jsonError;
	protected JSONArray jsonArray;
	
	public static String PASS = "Pass";
	public static String FAIL = "Fail";

   public JSON_Utilities(JSONObject jsonObject)
   {
      jo = jsonObject;
   }
   
   /** 
    * Use this method to get the field name from the JSON object
    * @param fieldName
    * @return value of the required field
    */
   public String getAttribute(String fieldName)
   {
      return jo.getString(fieldName);
   }

   /**
    * Use this method to get the field name from the JSON object
    * 
    * @param jsonObjectName = enter the JSON object name.
    * @param fieldName = enter the field name(attribute) for which the value is required.
    * @return value of the required field.
    */
   public String getAttributeValueFromJsonObject(String jsonObjectName,
                                            String fieldName)
   {
      return jo.getJSONObject(jsonObjectName).getString(fieldName);
   }
   
   /**
    * Use this method to get the field name from the JSON Array
    * 
    * @param jsonArrayName = enter the JSON Array name.
    * @param fieldName
    *           = enter the field name(attribute) for which the value is required.
    * @return value of the required field.
    */
   public String getAttributeValueFromJsonArray(String jsonArrayName,
                                                String fieldName)
   {
      JSONArray drugRecords = jo.getJSONArray(jsonArrayName);
      JSONObject jo1 = (JSONObject) drugRecords.get(0);
      return jo1.getString(fieldName);
   }
   
   /**
    * Use this method to get the field name from the JSON Array
    * 
    * @param jsonArrayName = enter the JSON Array name.
    * @param objectName
    *           = enter the field name(attribute) for which the json object is required.
    * @return json object of the required field.
    */
   public JSONObject getAttributeJsonObjectFromJsonArray(String jsonArrayName,
                                                String objectName)
   {
      JSONArray drugRecords = jo.getJSONArray(jsonArrayName);
      JSONObject jo1 = (JSONObject) drugRecords.get(0);
      JSONObject jo2 = jo1.getJSONObject(objectName);
      return jo2;
   }

   /**
    * 
    * @param jsonObjectName
    * @param jsonArrayName
    * @return
    */
   public JSONArray getJsonArrayFromJsonObject(String jsonObjectName,
                                               String jsonArrayName)
   {
      return jo.getJSONObject("recordSet").getJSONArray("records");
   }
   
   
   /**
    * 
    * @param parentjsonArrayName
    * @param arrayNumber
    * @param childjsonArrayName
    * @return
    */
   public JSONArray get_JsonArrayFrom_JsonArray(String parentjsonArrayName, int arrayNumber,String childjsonArrayName)
   {
      JSONObject ja =  (JSONObject) jo.getJSONArray(parentjsonArrayName).get(arrayNumber);
      return ja.getJSONArray(childjsonArrayName);
   }
   
   /**
    * Converts string value into Integer value
    * @param stringvalueTobeConverted = pass the string value to be converted
    * @returns the integer value
    */
   public int convertINT(String stringvalueTobeConverted)
   {
      return Integer.parseInt(stringvalueTobeConverted);
   }
   
   /**
    * Utility method Converts int value into string value
    * @param stringvalueTobeConverted = pass the int value to be converted
    * @returns the integer value
    */
   public String convertToString(int intvalueTobeConverted)
   {
      return String.valueOf(intvalueTobeConverted);
   }

   
   
   /**
    * Utility method to check if all elements in List B is present in List A
    * @param listA = store all the expected elements in this list.
    * @param listB = store the elements which is to be verified in ListA
    * @return false = if 
    */
   public boolean isexpectedValueNotPresentInList(List<String> listA, List<String> listB){
	   
	   for(String sectionValue:listB){
		    if(listA.contains(sectionValue))
		    	return false; 
	   }
	   return true;
   }
	
   

}
