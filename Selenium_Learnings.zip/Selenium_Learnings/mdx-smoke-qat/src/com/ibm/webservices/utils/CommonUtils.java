package com.ibm.webservices.utils;

import com.ibm.webservices.config.ExtentReporter;

public class CommonUtils extends ExtentReporter
{
   public static String GET ="GET";
   public static String PUT ="PUT";
   public static String POST ="POST";
   public static String DELETE ="DELETE";
   
   public static void compareTextByEqual(String actualValue,String ExpectedValue,String Description){
      if(actualValue.equalsIgnoreCase(ExpectedValue)){
         PASS(Description+" Successful", "ActualValue: "+actualValue+"equals Expected Value: "+ExpectedValue);
      }
      else{
         FAIL(Description+" Failed", "ActualValue: "+actualValue+"not equals Expected Value: "+ExpectedValue);
      }
   }
   
   public static void compareTextByContains(String actualValue,String ContainsValue,String Description){
      if(actualValue.contains(ContainsValue)){
         PASS(Description+" Successful", "ActualValue: "+actualValue+" contains Expected Value: "+ContainsValue);
      }
      else{
         FAIL(Description+" Failed", "ActualValue: "+actualValue+" not contains Expected Value: "+ContainsValue);
      }}
}
