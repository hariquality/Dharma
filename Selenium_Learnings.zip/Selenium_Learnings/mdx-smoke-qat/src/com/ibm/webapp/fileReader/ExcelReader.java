package com.ibm.webapp.fileReader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * Creates convenience methods for driving testData's
 * 
 * @author C400594 Hari
 *
 */

public class ExcelReader {

	private static FileInputStream fis;

	private static FileOutputStream outputStream;

	private static Workbook workBook;

	private static XSSFSheet currentSheet;

	/**
	 * Invoke this method to Open a excel file
	 * 
	 * @param fileName
	 * @param sheetName
	 */
	public static void openExcelSheet(String fileName, String sheetName) {
		try {
			fis = new FileInputStream(new File("./TestData/WebApp/" + fileName + ".xlsx"));// load
			workBook = new XSSFWorkbook(fis);// load workbook
			int index = workBook.getSheetIndex(sheetName);
			currentSheet = (XSSFSheet) workBook.getSheetAt(index);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Invoke this method to read TestData from excel
	 * 
	 * @param startFromColumn
	 * @param endWithColumn
	 * @return
	 * @throws IOException
	 */

	public static List<List<String>> readDataFromExcel(int startFromColumn, int endWithColumn) throws IOException {
		List<List<String>> rowListTerms = new ArrayList<List<String>>();
		String textFromCell = null;
		int i = 0, j = 0;
		try {
			int maxRowNum = currentSheet.getLastRowNum();// get line count
			// specify row,cell location and get the string value

			for (i = 1; i <= maxRowNum; i++) {
				XSSFRow row = currentSheet.getRow(i);
				List<String> columnValueList = new ArrayList<String>();
				for (j = startFromColumn; j <= endWithColumn; j++) {
					try {
						XSSFCell cellValue = row.getCell(j);
						switch (cellValue.getCellType()) {
						case STRING:
							textFromCell = cellValue.getStringCellValue();
							break;
						case BLANK:
							break;
						case _NONE:
							break;
						case NUMERIC:
							if ((cellValue.getNumericCellValue() + "").endsWith(".0")) {
								textFromCell = (int) cellValue.getNumericCellValue() + "";
								break;
							}
							textFromCell = cellValue.getNumericCellValue() + "";
							break;

						default:
							break;
						}
						columnValueList.add(textFromCell);

					} catch (Exception e) {
						e.printStackTrace();
						System.out.println("In Sheet " + currentSheet.getSheetName() + " cell (" + i + "," + j
								+ ") is empty or unreadable value is present");
					}
				}
				rowListTerms.add(columnValueList);
			}
			System.out.println("Number of TestData used  -->" + rowListTerms.size());

		} catch (Exception e) {
			System.out.println("Error when reading ROW:" + i + " and COLUMN:" + j);
			e.printStackTrace();
		} finally {
			fis.close();
		}
		return rowListTerms;
	}

	/**
	 * Invoke this method to Open a excel file
	 * 
	 * @param fileName
	 * @param sheetName
	 */
	public static void openExcelForReadWrite(String fileName, String sheetName) {
		try {
			fis = new FileInputStream(new File("./TestData/WebApp/" + fileName + ".xlsx"));// load
			workBook = new XSSFWorkbook(fis);// load workbook
			int index = workBook.getSheetIndex(sheetName);
			currentSheet = (XSSFSheet) workBook.getSheetAt(index);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Invoke this method to write testdata results PASS/FAIL
	 * 
	 * @param fileName
	 * @param textListToWrite
	 * @param columnIndexToWrite
	 * @throws IOException
	 */

	public static void writeResultsToExcel(String fileName, List<String> textListToWrite, int columnIndexToWrite)
			throws IOException {
		try {
			outputStream = new FileOutputStream("./TestData/" + fileName + ".xlsx");
			int maxRowNum = currentSheet.getLastRowNum();
			int finalColumnNumToWrite = columnIndexToWrite + 1;

			int k = 0;
			for (int i = 0; i < maxRowNum; i++) {
				XSSFRow row = currentSheet.getRow(i + 1);
				XSSFCell newCell = row.createCell(finalColumnNumToWrite);
				newCell.setCellValue(textListToWrite.get(k));
				k++;
			}
		} catch (Exception n) {
			n.printStackTrace();
		} finally {
			workBook.write(outputStream);
			outputStream.close();
		}
	}

	/**
	 * Invoke this method to read TestData from excel
	 * 
	 * @param startFromColumn
	 * @param endWithColumn
	 * @return
	 * @throws IOException
	 */

	public static List<List<String>> readDataFromExcel(int startFromColumn, int endWithColumn, int maxRowNumber)
			throws IOException {
		List<List<String>> rowListTerms = new ArrayList<List<String>>();
		String textFromCell = null;
		int i = 0, j = 0;
		try {
			for (i = 3; i <= maxRowNumber - 1; i++) {
				XSSFRow row = currentSheet.getRow(i);
				List<String> columnValueList = new ArrayList<String>();
				for (j = startFromColumn; j <= endWithColumn; j++) {
					try {
						XSSFCell cellValue = row.getCell(j);
						switch (cellValue.getCellType()) {
						case STRING:
							textFromCell = cellValue.getStringCellValue();
							break;
						case BLANK:
							break;
						case _NONE:
							break;
						case NUMERIC:
							if ((cellValue.getNumericCellValue() + "").endsWith(".0")) {
								textFromCell = (int) cellValue.getNumericCellValue() + "";
								break;
							}
							textFromCell = cellValue.getNumericCellValue() + "";
							break;

						default:
							break;
						}
						columnValueList.add(textFromCell);
					} catch (Exception e) {
						e.printStackTrace();
						System.out.println("In Sheet " + currentSheet.getSheetName() + " cell (" + i + "," + j + ") "
								+ "is empty or unreadable value is present");
					}
				}
				rowListTerms.add(columnValueList);
			}
			System.out.println("Number of TestData used  -->" + rowListTerms.size());

		} catch (Exception e) {
			System.out.println("Error when reading ROW:" + i + " and COLUMN:" + j);
			e.printStackTrace();
		} finally {
			fis.close();
		}
		return rowListTerms;
	}
}
