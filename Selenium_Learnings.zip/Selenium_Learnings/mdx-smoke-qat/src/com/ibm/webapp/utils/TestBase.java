package com.ibm.webapp.utils;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.ibm.webapp.config.ExtentReporter;
import com.ibm.webapp.config.JenkinsConfiguration;
import com.ibm.webapp.pageObjects.LoginPage;
import com.ibm.webapp.pageObjects.ToxandDrugProduct.TOD_SearchResultPage;
import com.ibm.webapp.pageObjects.healthcheck.HealthCheckApplicationPage;
import com.ibm.webapp.pageObjects.healthcheck.HealthCheckServicesPage;
import com.ibm.webapp.pageObjects.mdx.ChatBotEHRPage;
import com.ibm.webapp.pageObjects.sso.OpenAthens_LoginPage;
import com.ibm.webapp.pageObjects.top100hospitals.Top100Hospitals_HomePage;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestBase extends JenkinsConfiguration {

	public WebDriver driver;

	protected ExtentReporter extentReporter = ExtentReporter.getInstance();

	protected Logger log = Logger.getLogger(TestBase.class);

	public static String browser = null;
	public static String browserVersion = null;
	public static String environment = executionEnv;

	public static String getEnvironment() {
		return environment;
	}

	public static void setEnvironment() {
		TestBase.environment = executionEnv;
	}

	@BeforeClass(alwaysRun = true)
	@Parameters({ "ExecuteInJenkins", "isRemote", "browserName", "Env", "adminUser", "platformName", "browserVersion" })
	public void setupBrowser(@Optional String ExecuteInJenkins, @Optional String isRemote, @Optional String browserName,
			@Optional String Env, @Optional String adminUser, @Optional String platformName,
			@Optional String browserVersion) throws MalformedURLException {
		if (isRemote.equalsIgnoreCase("Y")) {
			try {
				Selenese.killBrowserDrivers(browserName);
				DesiredCapabilities caps = new DesiredCapabilities();
				caps.setCapability("browserName", browserName);
				caps.setCapability("version", browserVersion);
				caps.setCapability("platform", platformName);

				driver = new RemoteWebDriver(new URL("https://" + getValueFromPropertiesFile("sauceUser") + ":"
						+ getValueFromPropertiesFile("sauceKey") + "@ondemand.saucelabs.com/wd/hub"), caps);
			} catch (Exception e) {
				e.printStackTrace();
				log.error("Sauce Lab Configuration is incorrect");
			}
		} else {
			try {
				Selenese.killBrowserDrivers(browserName);
				Thread.sleep(2000);
				switch (browserName) {
				case "chrome":
					WebDriverManager.chromedriver().setup();
					driver = new ChromeDriver();
					clearCache();
					break;
				case "firefox":
					WebDriverManager.firefoxdriver().setup();
					driver = new FirefoxDriver();
					break;
				case "ie":
					WebDriverManager.iedriver().setup();
					driver = new InternetExplorerDriver();
					break;
				case "edge":
					WebDriverManager.edgedriver().setup();
					driver = new EdgeDriver();
					break;
				}
				browser = browserName;
				driver.manage().window().maximize();
			} catch (Exception e) {
				e.printStackTrace();
				log.error("Browser Not Launched Successfully");
			}
		}
	}

	static {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy hhmmss");
		System.setProperty("current.date", dateFormat.format(new Date()));
		String log4jConfigFile = "log4j.properties";
		PropertyConfigurator.configure(log4jConfigFile);
	}

	/*
	 * public void healthCheckAppLaunch() { driver.get("https://" + executionEnv
	 * + "." + getValueFromPropertiesFile("healthCheckURL")); }
	 */

	/**
	 * 
	 * @return
	 * @throws IOException
	 */
	public LoginPage launchApp() throws IOException {
		driver.get("https://" + executionEnv + "." + getValueFromPropertiesFile("appURL"));
		if (driver.getTitle().contains("Select a Product")) {
			driver.findElement(By.linkText("Log in")).click();
		}
		if (driver.getTitle().contains("Please Login")) {
			ExtentReporter.getInstance().PASS("Application URL LAunch.", "App URL launched Succesfully");
			log.info("Application is loaded Succesfully");
		} else {
			log.error("App URL launched Failed");
			ExtentReporter.getInstance().FAIL(driver, "Application URL LAunch.",
					"Application is not loaded Succesfully");
		}
		return PageFactory.initElements(driver, LoginPage.class);
	}

	/**
	 * 
	 * @return
	 * @throws IOException
	 * @throws InterruptedException 
	 */
	public Top100Hospitals_HomePage launchtop100App() throws IOException, InterruptedException {
		driver.get("https://" + executionEnv + "." + getValueFromPropertiesFile("top100URL"));
		if (driver.getTitle().contains("Watson Health 100 Top Hospitals:")) {
			ExtentReporter.getInstance().PASS("Top 100 Application URL LAunch.",
					"Top 100 App URL launched Succesfully");
			log.info("Top 100 Application is loaded Succesfully");
		} else {
			log.error("Top 100 App URL launched Failed");
			ExtentReporter.getInstance().FAIL(driver, "Top 100 Application URL LAunch.",
					"Top 100 Application is not loaded Succesfully");
		}
		return PageFactory.initElements(driver, Top100Hospitals_HomePage.class);
	}

	/**
	 * 
	 * Return HealthCheckApplicationPage
	 * 
	 * @throws InterruptedException
	 */

	public HealthCheckApplicationPage healthCheckAppLaunch() throws IOException {
		driver.get("https://" + executionEnv + "." + getValueFromPropertiesFile("healthCheckURLapplication"));
		return PageFactory.initElements(driver, HealthCheckApplicationPage.class);
	}

	/**
	 * 
	 * @Return HealthCheckServicesPage
	 * @throws InterruptedException
	 */
	public HealthCheckServicesPage healthCheckServiceLaunch() {
		driver.get("https://" + executionEnv + "." + getValueFromPropertiesFile("healthCheckURLservices"));
		return PageFactory.initElements(driver, HealthCheckServicesPage.class);
	}

	/**
	 * 
	 * @param searchTerm
	 * @param searchType
	 * @param caseNum
	 * @param pdxRefId
	 * @return
	 * @throws InterruptedException
	 */
	public TOD_SearchResultPage gotoTargetURLToxResultsPage(String CredentialType, String searchTerm, String searchType,
			String caseNum, String pdxRefId) throws InterruptedException {
		String finalToxResultsURL = null;
		String[] cred;
		if (JenkinsConfiguration.isAdminUser.equalsIgnoreCase("No")) {
			cred = JenkinsConfiguration.getValueFromPropertiesFile(CredentialType).split("/");
		} else {
			cred = JenkinsConfiguration.getValueFromPropertiesFile("adminuser").split("/");
		}

		if (searchType.equalsIgnoreCase("Default")) {
			finalToxResultsURL = "https://" + executionEnv + "." + getValueFromPropertiesFile("pdxSimulatorURL")
					+ "/micromedex2/librarian/pdxwssearch?" + "institution=MDX^" + cred[0] + "^" + cred[1]
					+ "&action=toxsearch&SearchTerm=" + searchTerm + "&caseNum=" + caseNum + "&pdxRefID=" + pdxRefId;
		} else {
			finalToxResultsURL = "https://" + executionEnv + "." + getValueFromPropertiesFile("pdxSimulatorURL")
					+ "/micromedex2/librarian/pdxwssearch?" + "institution=MDX^" + cred[0] + "^" + cred[1]
					+ "&action=toxsearch&SearchTerm=" + searchTerm + "&SearchType=" + searchType + "&caseNum=" + caseNum
					+ "&pdxRefID=" + pdxRefId;
		}
		driver.get(finalToxResultsURL);
		Thread.sleep(1000);
		extentReporter.PASS("PDXSimulator",
				"Navigation to TOX and DRUG Product page is succesful from PDX Simulator url");
		log.info("Navigation to TOX and DRUG Product page is succesful from PDX Simulator url");
		return PageFactory.initElements(driver, TOD_SearchResultPage.class);
	}

	/**
	 * Navigates directly to the 'micromedex2/librarian/watsonaccessui' url and
	 * returns a ChatBotEHRPage
	 * 
	 * @return Exception
	 */
	public ChatBotEHRPage goStraightToEHRwatsonaccessuiWithUserNamePasswordForFullWindow(String creds)
			throws Exception {

		try {
			driver.manage().deleteAllCookies();
			String[] cred;
			if (JenkinsConfiguration.isAdminUser.equalsIgnoreCase("No")) {
				cred = JenkinsConfiguration.getValueFromPropertiesFile(creds).split("/");
			} else {
				cred = JenkinsConfiguration.getValueFromPropertiesFile("adminuser").split("/");
			}
			driver.get("https://" + executionEnv + "." + getValueFromPropertiesFile("EHRFullWindow") + "?username="
					+ cred[0] + "&password=" + cred[0]);
			ExtentReporter.getInstance().PASS("EHR chatbot application URL Launch", "EHR URL launched Successfully");
			log.info("EHR ChatBot Application is loaded Succesfully");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			ExtentReporter.getInstance().FAIL(driver, "EHR chatbot application URL Launch",
					"EHR URL is not loaded Successfully");
			log.error("EHR URL is not loaded Successfully", e);
			e.printStackTrace();
		}
		ChatBotEHRPage page = PageFactory.initElements(driver, ChatBotEHRPage.class);
		return page;
	}

	/**
	 * Navigates directly to the 'micromedex2/librarian/watsonaccessui' url and
	 * returns a ChatBotEHRPage
	 * 
	 * @return Exception
	 */
	public ChatBotEHRPage goStraightToEHRwatsonaccessuiWithIP() throws Exception {

		try {
			driver.manage().deleteAllCookies();
			driver.get("https://" + executionEnv + "." + getValueFromPropertiesFile("EHRFullWindow"));
			ExtentReporter.getInstance().PASS(
					"EHR chatbot application URL Launch with IP authenticate for Small window",
					"EHR ChatBot Application is loaded Succesfully with IP authenticate");
			log.info("EHR ChatBot Application is loaded Succesfully with IP authenticate");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			ExtentReporter.getInstance().FAIL(driver,
					"EHR chatbot application URL Launch with IP authenticate for Small window",
					"EHR URL is not loaded Successfully");
			log.error("EHR ChatBot Application is loaded Succesfully with IP authenticate", e);
			e.printStackTrace();
		}
		ChatBotEHRPage page = PageFactory.initElements(driver, ChatBotEHRPage.class);
		return page;
	}

	public OpenAthens_LoginPage launchOpenAthens() throws IOException {
		driver.get("https://" + getValueFromPropertiesFile("OpenAthens_URL"));
		System.out.println(driver.getTitle());

		if (driver.getTitle().contains("OpenAthens / Sign in")) {
			ExtentReporter.getInstance().PASS("Open Athens Application URL LAunch.",
					"Open Athens URL launched Succesfully");
			log.info("Open Athens Application is loaded Succesfully");
		} else {
			log.error("Open Athens App URL launched Failed");
			ExtentReporter.getInstance().FAIL(driver, "Open Athens Application URL LAunch.",
					"Open Athens Application is not loaded Succesfully");
		}
		return PageFactory.initElements(driver, OpenAthens_LoginPage.class);
	}

	public void compareTextByEqual(String actualValue, String ExpectedValue, String Description) {
		if (actualValue.equalsIgnoreCase(ExpectedValue)) {
			extentReporter.PASS(Description + " Successful",
					"ActualValue: " + actualValue + "equals Expected Value: " + ExpectedValue);
		} else {
			extentReporter.FAIL(Description + " Failed",
					"ActualValue: " + actualValue + "not equals Expected Value: " + ExpectedValue);
		}
	}

	public void compareTextByContains(String actualValue, String ContainsValue, String Description) {
		if (actualValue.contains(ContainsValue)) {
			extentReporter.PASS(Description + " Successful",
					"ActualValue: " + actualValue + " contains Expected Value: " + ContainsValue);
		} else {
			extentReporter.FAIL(Description + " Failed",
					"ActualValue: " + actualValue + " not contains Expected Value: " + ContainsValue);
		}
	}

	public void compareListByContains(List<String> actualValue, String ContainsValue, String Description,
			boolean expectedResultValue) {

		if (expectedResultValue) {
			if (actualValue.contains(ContainsValue))
				extentReporter.PASS("Passed: " + Description);
			else
				extentReporter.FAIL("Failed: " + Description);
		} else {
			if (actualValue.contains(ContainsValue))
				extentReporter.FAIL("Failed: " + Description);
			else
				extentReporter.PASS("Passed: " + Description);
		}
	}

	@BeforeTest(alwaysRun = true)
	public void startReport() throws IOException {
		extentReporter.getExtendReport();
	}

	@AfterTest(alwaysRun = true)
	public void updateReport() {
		extentReporter.flush();
	}

	@AfterClass(alwaysRun = true)
	public void killBrowser() {
		driver.quit();
		Selenese.killBrowserDrivers(browser);
	}
	
	public void clearCache() throws InterruptedException {
		driver.get("chrome://settings/clearBrowserData");
		driver.findElement(By.xpath("//settings-ui")).sendKeys(Keys.ENTER);
		Thread.sleep(2000);
	}

}
