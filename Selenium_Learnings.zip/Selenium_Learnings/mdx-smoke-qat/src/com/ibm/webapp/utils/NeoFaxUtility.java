package com.ibm.webapp.utils;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.pageObjects.mdx.DC_PatientInformationPage;
import com.ibm.webapp.pageObjects.mdx.EnteralFormulaPage;

public class NeoFaxUtility extends Selenese {

	WebDriver driver;

	@FindBy(id = "searchTextBox")
	private WebElement searchBar_EF;

	@FindBy(xpath = "//input[@id='textInput']")
	private WebElement searchBar_DM;

	@FindBy(id = "searchTextBox")
	private WebElement searchBar_DC;

	@FindBy(xpath = "//li[@id='neonatalTab']")
	public WebElement tab_Neo_DM;

	@FindBy(xpath = "//li[@id='pediatricTab']")
	public WebElement tab_Ped_DM;

	@FindBy(xpath = "//li[@id='neonatalTab']/a")
	private WebElement tab_Neo_Colour_DM;

	@FindBy(xpath = "//li[@id='pediatricTab']/a")
	private WebElement tab_Ped_Colour_DM;

	// @FindBy(id = "neonatalTab")
	@FindBy(id = "neonatalTab")
	private WebElement tab_Neo_EF;

	// @FindBy(id = "pediatricsTab")
	@FindBy(id = "pediatricTab")
	private WebElement tab_Ped_EF;

	@FindBy(xpath = "//input[@type='button'][@title='Clear']")
	public WebElement btn_Clear;

	@FindBy(id = "enteralFormulaToolLink")
	private WebElement tab_EnteralFormula;

	@FindBy(id = "dosingCalculatorToolLink")
	private WebElement tab_DosingCalculator;

	/**
	 * Default Constructor for NeoFax Header class
	 */
	public NeoFaxUtility(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}

	/**
	 * Enter the drug name in the search bar.
	 * 
	 * @param userInput
	 *            = type atleast 1 char
	 * @throws IOException
	 */
	public void enterDrugName(String userInput, String module) throws IOException {
		WebElement element = null;
		switch (module) {
		case "EF":
			element = searchBar_EF;
			break;
		case "DM":
			element = searchBar_DM;
			break;
		case "DC":
			element = searchBar_DC;
		}
		element.clear();
		// click(driver, "NeoNatal/Pediatric", element);
		sendKeys(driver, "Search box", element, userInput);
	}

	/**
	 * Call this method to verify if Neonatal/Pediatrics tab is displayed
	 * 
	 * @param tabName
	 *            = enter Neo or Ped to validate the tab existence
	 * @throws IOException
	 * @returns true = if tab is displayed.
	 * @returns false = if tab is not displayed.
	 */
	public boolean isTabDisplayed(String tabName) throws IOException {
		try {
			if (tabName.equalsIgnoreCase("Neo")) {
				tab_Neo_EF.isDisplayed();
			} else {
				tab_Ped_EF.isDisplayed();
			}

			extentReport.PASS("Verification of Neonatal/Pediatrics tab is displayed", tabName + " is displayed");
			log.info(tabName + " is displayed");
			return true;
		}

		catch (NoSuchElementException e) {
			extentReport.FailWithException(driver, "Verification of Neonatal/Pediatrics tab is displayed",
					tabName + " is not displayed", e);
			logERROR(tabName + " is not displayed", e);
			return false;
		}
	}

	/**
	 * verifies if NeoNatal tab or Pediatric is selected and highlighted in
	 * color rgb(146, 79, 167)
	 * 
	 * @return true = if the expected tab is highlighted false = if the expected
	 *         tab is not highlighted.
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public boolean isTabHighlighted(String tabName, String module) throws InterruptedException, IOException {
		WebElement tab_Highlight = null;
		WebElement tab_Colour = null;
		String expectedValue = null;

		switch (module) {
		case "DM":
			if (tabName.equalsIgnoreCase("Neo")) {
				tab_Highlight = tab_Neo_DM;
				tab_Colour = tab_Neo_Colour_DM;
			} else {
				tab_Highlight = tab_Ped_DM;
				tab_Colour = tab_Ped_Colour_DM;
			}
			expectedValue = "selected";
			break;
		case "EF":
			if (tabName.equalsIgnoreCase("Neo")) {
				tab_Highlight = tab_Neo_EF;
				tab_Colour = tab_Neo_EF;
			} else {
				tab_Highlight = tab_Ped_EF;
				tab_Colour = tab_Ped_EF;
			}
			expectedValue = "activeMode";
		}
		Thread.sleep(1000);

		String tabActivate = tab_Highlight.getAttribute("class");
		String tabValue = tab_Colour.getCssValue("background-color");
		String[] actualTabColour = tabValue.split("\\(");
		if (tabActivate.equals(expectedValue) && actualTabColour[0].contains("rgb")
				&& actualTabColour[1].contains("146, 79, 167")) {

			extentReport.PASS("Verification of NeoNatal tab or Pediatric is selected and highlighted",
					tabName + " is selected and highlighted for " + module);
			log.info(tabName + " is selected and highlighted for " + module);
			return true;
		}
		extentReport.FAIL(driver, "Verification of NeoNatal tab or Pediatric is selected and highlighted",
				tabName + " is not selected and highlighted for " + module);
		logERROR(tabName + " is not selected and highlighted for " + module);
		return false;
	}

	/**
	 * Scrolls up the vertical scroll bar
	 * 
	 * @param y
	 *            - pass the values to scroll UP ex: 250
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public void scrollUp(int y) throws InterruptedException, IOException {
		try {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("scroll(0,-" + y + ")");
			Thread.sleep(500);
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Scrolls up vertical scroll bar", "Problem with vertical scrolling",
					e);
			logERROR("Problem with vertical scrolling", e);
		}
	}

	/**
	 * Based on the users Call this method to click on NeoFax/Pediatrics tab in
	 * Enteral Formula Page
	 * 
	 * @param tabName
	 *            = enter Neo or Ped to click the tab.
	 * @returns true = if tab is clicked.
	 * @returns false = if tab is not clicked.
	 * 
	 */
	public boolean clickTab(String tabName, String module) {
		try {
			WebElement element = null;
			switch (module) {
			case "EF":
				if (tabName.equalsIgnoreCase("neo"))
					element = tab_Neo_EF;
				else
					element = tab_Ped_EF;
				break;
			case "DM":
				if (tabName.equalsIgnoreCase("neo"))
					element = tab_Neo_DM;
				else
					element = tab_Ped_DM;
				break;
			}
			scrollUp(100);
			click(driver, tabName, element);

			return true;
		}

		catch (Exception e) {
			e.printStackTrace();
		}
		return false;

	}

	/**
	 * Scrolls down the vertical scroll bar
	 * 
	 * @param y
	 *            - pass the values to scroll UP ex: 250
	 * @throws InterruptedException
	 */
	public void scrollDown(int y) throws InterruptedException {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("scroll(0," + y + ")");
		Thread.sleep(500);
	}

	/**
	 * click the EnteralFormula tab
	 */
	public EnteralFormulaPage clickEF_tab() {

		try {
			waitForElementVisibility(driver, tab_EnteralFormula);
			click(driver, "Enteral formula tab", tab_EnteralFormula);
			return PageFactory.initElements(driver, EnteralFormulaPage.class);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * click the Dosing Calculator tab
	 */
	public DC_PatientInformationPage clickDC_tab() {

		try {

			// webDriverwait.until(ExpectedConditions.elementToBeClickable(tab_DosingCalculator));
			// scrollUp(200);
			click(driver, "Dosing calculator tab", tab_DosingCalculator);
			return PageFactory.initElements(driver, DC_PatientInformationPage.class);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
