package com.ibm.webapp.utils;

import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.config.ExtentReporter;

public class Selenese
{

   public static ExtentReporter extentReport;

   protected Logger log = Logger.getLogger(Selenese.class);

   /**
    * Constructor is used to get the extend reports instance, so that the same
    * instance can be used in other page classes.
    */
   public Selenese()
   {
      extentReport = ExtentReporter.getInstance();
   }

   /**
    * this method is used to enter the search-term value in the text-box.
    * 
    * @param driver
    *           = driver needs to be passed from the PageObjects Class
    * @param txtboxName
    *           = pass the textBoxName
    * @param ele
    *           = textBox WebElement to be passed from PageObjects Class
    * @param term
    *           = pass the searchTerm to be entered in textBox
    * @throws IOException
    */
   public void sendKeys(WebDriver driver,
                        String txtboxName,
                        WebElement ele,
                        String term) throws IOException
   {
      try
      {
         waitForElementVisibility(driver, ele);
         ele.sendKeys(term);
         extentReport.PASS(txtboxName, term + " entered in " + txtboxName);
         log.info(term + " entered in " + txtboxName);
      }

      catch (StaleElementReferenceException sere)
      {
         extentReport.FailWithException(driver,
                           txtboxName,
                           term + " NOT entered in " + txtboxName
                                 + "as Element is not available on the DOM ",
                           sere);
         logERROR(term + " NOT entered in " + txtboxName
               + "as Element is not available on the DOM");
      }

      catch (NoSuchElementException nse)
      {
         extentReport.FailWithException(driver,
                           txtboxName,
                           term + " NOT entered in " + txtboxName
                                 + "as Element is not available on the webpage ",
                           nse);
         logERROR(term + " NOT entered in " + txtboxName
               + "as Element is not available on the webpage");
      }

      catch (ElementNotVisibleException env)
      {
         extentReport.FailWithException(driver,
                           txtboxName,
                           term + " NOT entered in " + txtboxName
                                 + "as Element is not visible on the webpage ",
                           env);
         logERROR(term + " NOT entered in " + txtboxName
               + "as Element is not visible on the webpage");
      }

      catch (Exception e)
      {
         extentReport.FailWithException(driver,
                           txtboxName,
                           term + " NOT entered in " + txtboxName
                                 + "check for exception handling ",
                           e);
         logERROR(term + " NOT entered in " + txtboxName
               + "check for exception handling");
      }
   }

   /**
    * this method is used to enter the search-term value slowly in the text-box.
    * 
    * @param driver
    *           = driver needs to be passed from the PageObjects Class
    * @param txtboxName
    *           = pass the textBoxName from the PageObjects Class
    * @param ele
    *           = textBox WebElement to be passed from PageObjects Class
    * @param term
    *           = pass the searchTerm to be entered in textBox
    * @throws IOException
    */
   public void sendKeysSlow(WebDriver driver,
                            String txtboxName,
                            WebElement ele,
                            String term) throws IOException
   {
      try
      {
         waitForElementVisibility(driver, ele);
         int timelap = 250;
         for (int index = 0; index < term.length(); index++)
         {
            String singleLetter = term.substring(index, index + 1);
            Thread.sleep(timelap);
            if (Character.isWhitespace(singleLetter.charAt(0)))
               ele.sendKeys(Keys.SPACE);
            else
               ele.sendKeys(singleLetter);
         }
         extentReport.PASS(txtboxName, term + " entered in " + txtboxName);
         log.info(term + " entered in " + txtboxName);
      }

      catch (StaleElementReferenceException sere)
      {
         extentReport.FailWithException(driver,
                           txtboxName,
                           term + " NOT entered in " + txtboxName
                                 + " as  Element is not attached to DOM of the webpage ",
                           sere);
         logERROR(term + " NOT entered in " + txtboxName
               + " as  Element is not attached to DOM of the webpage.");
      }
      catch (NoSuchElementException nse)
      {
         extentReport.FailWithException(driver,
                           txtboxName,
                           term + " NOT entered in " + txtboxName
                                 + " as   Element is not available on the webpage ",
                           nse);
         logERROR(term + " NOT entered in " + txtboxName
               + " as   Element is not available on the webpage ");
      }
      catch (ElementNotVisibleException env)
      {
         extentReport.FailWithException(driver,
                           txtboxName,
                           term + " NOT entered in " + txtboxName
                                 + " as   Element is not visible on the webpage ",
                           env);
         logERROR(term + " NOT entered in " + txtboxName
               + " as   Element is not visible on the webpage ");
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver,
                           txtboxName,
                           term + " NOT entered in " + txtboxName
                                 + " as Something went wrong. ",
                           e);
         logERROR(term + " NOT entered in " + txtboxName
               + " as Something went wrong. ");
      }
   }

   /**
    * this method is used to click the element in the page.
    * 
    * @param driver
    *           = driver needs to be passed from the PageObjects Class
    * @param nodeDescription
    *           = pass the generic description about the element to be clicked.
    * @param ele
    *           = clickable WebElement to be passed from PageObjects Class
    * @throws IOException
    */
   public void click(WebDriver driver,
                     String nodeDescription,
                     WebElement ele) throws IOException
   {
      try
      {
         waitForElementToBeClickable(driver, ele);
         ele.click();
         extentReport.PASS(nodeDescription + " clicked!", "  Element Clicked.");
         log.info(nodeDescription + " clicked!");
      }
      catch (Exception e)
      {
         keyBoardClick(driver, nodeDescription, ele);
      }
   }

   /**
    * this method is used to click the element in the page by using the keyboard
    * press.
    * 
    * @param driver
    *           = driver needs to be passed from the PageObjects Class
    * @param nodeDescription
    *           = pass the generic description about the element to be clicked.
    * @param ele
    *           = click-able WebElement to be passed from PageObjects Class
    * @throws IOException
    */
   public void keyBoardClick(WebDriver driver,
                             String nodeDescription,
                             WebElement ele) throws IOException
   {
      try
      {
         ele.sendKeys(Keys.ENTER);
         extentReport.PASS(nodeDescription + " clicked!", "  Element Clicked.");
         log.info(nodeDescription + " clicked!");
      }
      catch (StaleElementReferenceException sere)
      {
         extentReport.FailWithException(driver,
                           nodeDescription + " NOT clicked!",
                           " is not attached to DOM of the webpage.",
                           sere);
         logERROR(nodeDescription + " is not attached to DOM of the webpage.");
      }
      catch (NoSuchElementException nse)
      {
         extentReport.FailWithException(driver,
                           nodeDescription + " NOT clicked!",
                           " is not available on the webpage ",
                           nse);
         logERROR(nodeDescription + " is not available on the webpage ");
      }
      catch (ElementNotVisibleException env)
      {
         extentReport.FailWithException(driver,
                           nodeDescription + " NOT clicked!",
                           " is not visible on the webpage ",
                           env);
         logERROR(nodeDescription + " is not visible on the webpage ");
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver,
                           nodeDescription + " NOT clicked!",
                           " Something went wrong  ",
                           e);
         logERROR(nodeDescription + "Something went wrong  ");
      }
   }

   public void JSExecutor(JavascriptExecutor jse, WebElement ele, String script)
   {
      jse.executeScript(script, ele);
   }

   /**
    * this method is used to compare two text values, gets the actual value from
    * the web page and compares it against the expected value.
    * 
    * @param driver
    *           = driver needs to be passed from the PageObjects Class
    * @param ele
    *           = text WebElement to be passed from PageObjects Class
    * @param expectedValue
    *           = enter the value to be compared.
    * @param compareType
    *           = pass the java conditions like equals, OR equalsIgnoreCase, OR
    *           contains
    * @return true = if the expected value = actual value
    * @return false = if the expected value != actual value
    * @throws IOException
    */
   public boolean compareText(WebDriver driver,
                              WebElement ele,
                              String expectedValue,
                              String compareType) throws IOException
   {
      boolean result = false;
      try
      {
         waitForElementVisibility(driver, ele);
         if (compareType.equalsIgnoreCase("equals"))
         {
            if (ele.getText().trim().equals(expectedValue))
            {
               result = true;
            }
         }

         else if (compareType.equalsIgnoreCase("equalsIgnoreCase"))
         {
            if (ele.getText().trim().equalsIgnoreCase(expectedValue))
            {
               result = true;
            }
         }

         else if (compareType.equalsIgnoreCase("contains"))
         {
            if (ele.getText().trim().contains(expectedValue))
            {
               result = true;
            }
         }

      }
      catch (StaleElementReferenceException sere)
      {
         extentReport.FailWithException(driver,
                           "Text Compare",
                           ele.getText()
                                 + " is not attached to DOM of the webpage. ",
                           sere);
         logERROR(ele.getText() + " is not attached to DOM of the webpage. ");
      }
      catch (NoSuchElementException nse)
      {
         extentReport.FailWithException(driver,
                           "Text Compare",
                           ele.getText() + "  is not available on the webpage ",
                           nse);
         logERROR(ele.getText() + " is not available on the webpage ");
      }
      catch (ElementNotVisibleException env)
      {
         extentReport.FailWithException(driver,
                           "Text Compare",
                           ele.getText() + " is not visible on the webpage ",
                           env);
         logERROR(ele.getText() + " is not visible on the webpage ");
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver,
                           "Text Compare",
                           ele.getText() + " -Something went wrong. ",
                           e);
         logERROR(ele.getText() + " Something went wrong. ");
      }
      return result;
   }

   /**
    * this method is used to check whether elements is visible on the page,
    * 
    * @param driver
    *           = driver needs to be passed from the PageObjects Class
    * @param nodeDescription
    *           = pass the generic description about the element to be clicked.
    * @param ele
    *           = WebElement to be passed from PageObjects Class
    * @throws IOException
    */
   public void isElementDisplayed(WebDriver driver,
                                  String nodeDescription,
                                  WebElement ele) throws IOException
   {
      try
      {
         waitForElementVisibility(driver, ele);
         if (ele.isDisplayed())
         {
            extentReport.PASS(nodeDescription, nodeDescription + " displayed!");
            log.info(nodeDescription + " displayed!");
         }
         else
         {
            extentReport.FAIL(driver,
                              nodeDescription,
                              nodeDescription + " NOT displayed!");
            logERROR(nodeDescription + " NOT displayed!");
         }
      }
      catch (StaleElementReferenceException sere)
      {
         extentReport.FailWithException(driver,
                           nodeDescription + "Element not displayed!",
                           "  Element is not attached to DOM of the webpage. ",
                           sere);
         logERROR(nodeDescription
               + "  Element is not attached to DOM of the webpage. ");
      }
      catch (NoSuchElementException nse)
      {
         extentReport.FailWithException(driver,
                           nodeDescription + "Element not displayed!",
                           "  Element  is not available on the webpage ",
                           nse);
         logERROR(nodeDescription
               + "  Element  is not available on the webpage. ");
      }
      catch (ElementNotVisibleException env)
      {
         extentReport.FailWithException(driver,
                           nodeDescription + "Element not displayed!",
                           "  Element is not visible on the webpage ",
                           env);
         logERROR(nodeDescription + "  Element is not visible on the webpage ");
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver,
                           nodeDescription + "Element not displayed!",
                           "  Element -Something went wrong. ",
                           e);
         logERROR(nodeDescription + "  Element -Something went wrong. ");
      }
   }

   /**
    * this method is used to check whether elements is not visible on the web
    * page,
    * 
    * @param driver
    *           = driver needs to be passed from the PageObjects Class
    * @param nodeDescription
    *           = pass the generic description about the element to be clicked.
    * @param ele
    *           = WebElement to be passed from PageObjects Class
    * @throws IOException
    */
   public boolean isElementNotDisplayed(WebDriver driver,
                                        String nodeDescription,
                                        WebElement ele) throws IOException
   {
      try
      {
         if (!ele.isDisplayed())
         {
            extentReport.PASS(nodeDescription,
                              nodeDescription + " NOT displayed!");
            logINFO(nodeDescription + " displayed!");
         }
         else
         {
            extentReport.FAIL(driver,
                              nodeDescription,
                              nodeDescription + " displayed in the webpage!");
            logERROR(nodeDescription + " displayed!");
         }
      }
      catch (StaleElementReferenceException sere)
      {
         extentReport.FailWithException(driver,
                           nodeDescription + "Element not displayed!",
                           "  Element is not attached to DOM of the webpage. ",
                           sere);
         logERROR(nodeDescription
               + "  Element is not attached to DOM of the webpage. ");
      }
      catch (NoSuchElementException nse)
      {
         extentReport.PASS(nodeDescription,
                           nodeDescription + " NOT displayed!");
         logINFO(nodeDescription
               + "  Element  is not available on the webpage. ");
      }
      catch (ElementNotVisibleException env)
      {
         extentReport.PASS(nodeDescription,
                           nodeDescription + " NOT displayed!");
         logINFO(nodeDescription
               + "  Element  is not available on the webpage. ");
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver,
                           nodeDescription + "Element not displayed!",
                           "  Element -Something went wrong. ",
                           e);
         logERROR(nodeDescription + "  Element -Something went wrong. ");
      }
      return false;
   }

   /**
    * this method is used to check whether elements is enabled on the web page,
    * 
    * @param driver
    *           = driver needs to be passed from the PageObjects Class
    * @param nodeDescription
    *           = pass the generic description about the element to be clicked.
    * @param ele
    *           = WebElement to be passed from PageObjects Class
    * @throws IOException
    */
   public boolean IsEnabled(WebDriver driver,
                            String nodeDescription,
                            WebElement ele) throws IOException
   {
      try
      {
         if (ele.isEnabled())
         {
            extentReport.PASS(nodeDescription,
                              nodeDescription + " is enabled!");
            log.info(nodeDescription + " is enabled!");
            return true;
         }
         else
         {
            extentReport.FAIL(driver,
                              nodeDescription,
                              nodeDescription + " is not enabled!");
            logERROR(nodeDescription + " is not enabled!");
         }
      }
      catch (StaleElementReferenceException sere)
      {
         extentReport.FailWithException(driver,
                           nodeDescription,
                           "  Element is not attached to DOM of the webpage. ",
                           sere);
         logERROR("  Element is not attached to DOM of the webpage. ", sere);
      }
      catch (NoSuchElementException nse)
      {
         extentReport.FailWithException(driver,
                           nodeDescription,
                           "  Element  is not available on the webpage ",
                           nse);
         logERROR("  Element  is not available on the webpage ", nse);
      }
      catch (ElementNotVisibleException env)
      {
         extentReport.FailWithException(driver,
                           nodeDescription,
                           "  Element is not visible on the webpage ",
                           env);
         logERROR("  Element is not visible on the webpage ", env);
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver,
                           nodeDescription,
                           "  Element" + " -Something went wrong. ",
                           e);
         logERROR("  Element" + " -Something went wrong. ", e);
      }
      return false;
   }

   /**
    * this method is used to check whether elements is not enabled on the web
    * page,
    * 
    * @param driver
    *           = driver needs to be passed from the PageObjects Class
    * @param nodeDescription
    *           = pass the generic description about the element to be clicked.
    * @param ele
    *           = WebElement to be passed from PageObjects Class
    * @throws IOException
    */
   public boolean IsNotEnabled(WebDriver driver,
                               String nodeDescription,
                               WebElement ele) throws IOException
   {
      try
      {
         if (!ele.isEnabled())
         {
            extentReport.PASS(nodeDescription,
                              nodeDescription + " is NOT enabled!");
            log.info(nodeDescription + " is NOT enabled!");
            return true;
         }
         else
         {
            extentReport.FAIL(driver,
                              nodeDescription,
                              nodeDescription + " is enabled!");
            logERROR(nodeDescription + " is enabled!");
         }
      }
      catch (StaleElementReferenceException sere)
      {
         extentReport.FailWithException(driver,
                           nodeDescription,
                           "  Element is not attached to DOM of the webpage. ",
                           sere);
         logERROR("  Element is not attached to DOM of the webpage. ", sere);
      }
      catch (NoSuchElementException nse)
      {
         extentReport.FailWithException(driver,
                           nodeDescription,
                           "  Element  is not available on the webpage ",
                           nse);
         logERROR("  Element  is not available on the webpage ", nse);
      }
      catch (ElementNotVisibleException env)
      {
         extentReport.FailWithException(driver,
                           nodeDescription,
                           "  Element is not visible on the webpage ",
                           env);
         logERROR("  Element is not visible on the webpage ", env);
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver,
                           nodeDescription,
                           "  Element" + " -Something went wrong. ",
                           e);
         logERROR("  Element" + " -Something went wrong. ", e);
      }
      return false;
   }

   public void executeJS(WebDriver driver, String script) throws IOException
   {
      try
      {
         JavascriptExecutor js = (JavascriptExecutor) driver;
         js.executeScript(script);
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver, "JS Scroll", "Scroll Failed", e);
         logERROR("Scroll Failed ", e);
      }
   }

   public void Scroll(WebDriver driver, String scrpt) throws IOException
   {
      try
      {
         JavascriptExecutor js = (JavascriptExecutor) driver;
         js.executeScript(scrpt);
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver, "JS Scroll", "Scroll Failed", e);
         logERROR("Scroll Failed ", e);
      }
   }

   public void IsAllCheckBoxUnchecked(WebDriver driver,
                                      String Description,
                                      List<WebElement> ele) throws IOException
   {
      try
      {
         boolean flag = true;
         for (WebElement el : ele)
         {
            if (el.isSelected())
            {
               flag = false;
               break;
            }
         }
         if (!flag)
         {
            extentReport.FAIL(driver,
                              Description,
                              " One or more Checkboxes aren't unchecked.");
            logERROR(" One or more Checkboxes aren't unchecked.");
         }
         else
         {
            extentReport.PASS(Description, " All/few  Checkboxes are checked.");
            log.info(" All/few  Checkboxes are checked.");
         }
      }
      catch (StaleElementReferenceException sere)
      {
         extentReport.FailWithException(driver,
                           Description,
                           "  Element is not attached to DOM of the webpage. ",
                           sere);
         logERROR("  Element is not attached to DOM of the webpage. ", sere);
      }
      catch (NoSuchElementException nse)
      {
         extentReport.FailWithException(driver,
                           Description,
                           "  Element  is not available on the webpage ",
                           nse);
         logERROR("  Element  is not available on the webpage ", nse);
      }
      catch (ElementNotVisibleException env)
      {
         extentReport.FailWithException(driver,
                           Description,
                           "  Element" + " is not visible on the webpage ",
                           env);
         logERROR("  Element" + " is not visible on the webpage ", env);
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver,
                           Description,
                           "  Element" + " -Something went wrong. ",
                           e);
         logERROR("  Element" + " -Something went wrong. ", e);
      }
   }

   public int extractNumbers(String term)
   {
      int x = -1;
      Pattern p = Pattern.compile("\\d+");
      Matcher m = p.matcher(term);
      if (m.find())
      {
         x = Integer.valueOf(m.group());
      }
      return x;
   }

   /**
    * use this method to get the attribute value from the element
    * 
    * @param driver
    * @param xpath
    * @param AttributeName
    * @return
    * @throws IOException
    */
   public String getAttribute(WebDriver driver,
                              WebElement xpath,
                              String AttributeName) throws IOException
   {
      String value = null;
      try
      {
         value = xpath.getAttribute(AttributeName);
         extentReport.PASS(AttributeName, AttributeName + " value is " + value);
         log.info(AttributeName + " value is " + value);
      }
      catch (Exception e)
      {
         extentReport.FAIL(driver,
                           "Something went wrong in getting attribute with an exception ",
                           e.getMessage());
         logERROR("Something went wrong in getting attribute with an exception ",
                  e);
      }
      return value;
   }

   /**
    * use this method to write failure case description in logs
    */
   public void logERROR(String errorMessage)
   {
      log.error(errorMessage);
      log.info("\n");
   }

   /**
    * use this method to write teststep flow description in logs
    */
   public void logINFO(String description)
   {
      log.info(description);
   }

   /**
    * use this method to write positive case description in logs
    */
   public void logPASS(String description)
   {
      log.info(description);
      log.info("\n");
   }

   /**
    * use this method to write failure case description along with the exception
    * in logs
    */
   public void logERROR(String errorMessage, Exception e)
   {
      log.error(errorMessage, e);
      log.info("\n");
   }

   /**
    * use this method to get the selected value from the dropdown
    */
   public String getDropDownSelectedValue(WebDriver driver,
                                          WebElement dropDownXpath) throws IOException
   {
      String value = null;
      try
      {
         Select select = new Select(dropDownXpath);
         value = select.getFirstSelectedOption().getText();
         extentReport.PASS("DropDown",
                           "Dropdown have default values as " + value);
         log.info("Dropdown have default values as " + value);
      }
      catch (NoSuchElementException nse)
      {
         extentReport.FailWithException(driver,
                           "Unable to retrieve selected drop down values",
                           "   Element is not available on the webpage ",
                           nse);
         logERROR("   Element is not available on the webpage ", nse);
      }
      catch (ElementNotVisibleException env)
      {
         extentReport.FailWithException(driver,
                           "Unable to retrieve selected drop down values",
                           "   Element is not visible on the webpage ",
                           env);
         logERROR("   Element is not visible on the webpage ", env);
      }
      catch (Exception e)
      {
         log.error("Getting dropdown selected values method failed");
         extentReport.FAIL(driver,
                           "getDropDownSelectedValue method failed with an exception ",
                           e.getMessage());
         logERROR("getDropDownSelectedValue method failed with an exception ",
                  e);
      }
      return value;
   }

   public void selectDropDownByVisibleText(WebDriver driver,
                                           WebElement dropDownXpath,
                                           String dropDownValue) throws IOException
   {
      try
      {
         Select select = new Select(dropDownXpath);
         select.selectByVisibleText(dropDownValue);
         extentReport.PASS("DropDown",
                           "Dropdown selects values " + dropDownValue);
         log.info("Dropdown have selects values " + dropDownValue);
      }
      catch (NoSuchElementException nse)
      {
         extentReport.FailWithException(driver,
                           "Unable to  select drop down values",
                           "   Element is not available on the webpage ",
                           nse);
         logERROR("   Element is not available on the webpage ", nse);
      }
      catch (ElementNotVisibleException env)
      {
         extentReport.FailWithException(driver,
                           "Unable to select drop down values",
                           "   Element is not visible on the webpage ",
                           env);
         logERROR("   Element is not visible on the webpage ", env);
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver,
                           dropDownValue,
                           " Value not selected in drop down",
                           e);
         logERROR(" Value not selected in drop down", e);
      }

   }

   public void selectDropDownByIndex(WebDriver driver,
                                     WebElement dropDownXpath,
                                     int dropDownValueCount) throws IOException
   {
      try
      {
         Select select = new Select(dropDownXpath);
         select.selectByIndex(dropDownValueCount);
         extentReport.PASS("DropDown",
                           "Dropdown selects values at position "
                                 + dropDownValueCount);
         log.info("Dropdown have selects values at position "
               + dropDownValueCount);
      }
      catch (NoSuchElementException nse)
      {
         extentReport.FailWithException(driver,
                           "Unable to  select drop down values",
                           "   Element is not available on the webpage ",
                           nse);
         logERROR("   Element is not available on the webpage ", nse);
      }
      catch (ElementNotVisibleException env)
      {
         extentReport.FailWithException(driver,
                           "Unable to select drop down values",
                           "   Element is not visible on the webpage ",
                           env);
         logERROR("   Element is not visible on the webpage ", env);
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver,
                           "Dropdown selects values at position "
                                 + dropDownValueCount,
                           " Value not selected in drop down",
                           e);
         logERROR(" Value not selected in drop down", e);
      }

   }

   public void selectDropDownByValue(WebDriver driver,
                                     WebElement dropDownXpath,
                                     String dropDownValue) throws IOException
   {
      try
      {
         Select select = new Select(dropDownXpath);
         select.selectByValue(dropDownValue);
         extentReport.PASS("DropDown",
                           "Dropdown selects values " + dropDownValue);
         log.info("Dropdown have selects values " + dropDownValue);
      }
      catch (NoSuchElementException nse)
      {
         extentReport.FailWithException(driver,
                           "Unable to  select drop down values",
                           "   Element is not available on the webpage ",
                           nse);
         logERROR("   Element is not available on the webpage ", nse);
      }
      catch (ElementNotVisibleException env)
      {
         extentReport.FailWithException(driver,
                           "Unable to select drop down values",
                           "   Element is not visible on the webpage ",
                           env);
         logERROR("   Element is not visible on the webpage ", env);
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver,
                           dropDownValue,
                           " Value not selected in drop down",
                           e);
         logERROR(" Value not selected in drop down", e);
      }

   }

   public void deSelectDropDownByValue(WebDriver driver,
                                       WebElement dropDownXpath,
                                       String dropDownValue) throws IOException
   {
      try
      {
         Select select = new Select(dropDownXpath);
         select.deselectByValue(dropDownValue);
         extentReport.PASS("DropDown",
                           "value deselected in dropdown is " + dropDownValue);
         log.info("value deselected in dropdown is " + dropDownValue);
      }
      catch (NoSuchElementException nse)
      {
         extentReport.FailWithException(driver,
                           "Unable to  deselect drop down values",
                           "   Element is not available on the webpage ",
                           nse);
         logERROR("   Element is not available on the webpage ", nse);
      }
      catch (ElementNotVisibleException env)
      {
         extentReport.FailWithException(driver,
                           "Unable to deselect drop down values",
                           "   Element is not visible on the webpage ",
                           env);
         logERROR("   Element is not visible on the webpage ", env);
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver,
                           dropDownValue,
                           " Value not deselected in drop down",
                           e);
         logERROR(" Value not deselected in drop down", e);
      }

   }

   public void deSelectDropDownByIndex(WebDriver driver,
                                       WebElement dropDownXpath,
                                       int dropDownValueCount) throws IOException
   {
      try
      {
         Select select = new Select(dropDownXpath);
         select.deselectByIndex(dropDownValueCount);
         extentReport.PASS("DropDown",
                           "Dropdown deselects values at position "
                                 + dropDownValueCount);
         log.info("Dropdown have deselects values at position "
               + dropDownValueCount);
      }
      catch (NoSuchElementException nse)
      {
         extentReport.FailWithException(driver,
                           "Unable to  deselect drop down values",
                           "   Element is not available on the webpage ",
                           nse);
         logERROR("   Element is not available on the webpage ", nse);
      }
      catch (ElementNotVisibleException env)
      {
         extentReport.FailWithException(driver,
                           "Unable to deselect drop down values",
                           "   Element is not visible on the webpage ",
                           env);
         logERROR("   Element is not visible on the webpage ", env);
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver,
                           "Dropdown deselects values at position "
                                 + dropDownValueCount,
                           " Value not deselected in drop down",
                           e);
         logERROR(" Value not deselected in drop down", e);
      }

   }

   public void deSelectDropDownByVisibleText(WebDriver driver,
                                             WebElement dropDownXpath,
                                             String dropDownValue) throws IOException
   {
      try
      {
         Select select = new Select(dropDownXpath);
         select.deselectByVisibleText(dropDownValue);
         extentReport.PASS("DropDown",
                           "value deselected in dropdown is " + dropDownValue);
         log.info("value deselected in dropdown is " + dropDownValue);
      }
      catch (NoSuchElementException nse)
      {
         extentReport.FailWithException(driver,
                           "Unable to  deselect drop down values",
                           "   Element is not available on the webpage ",
                           nse);
         logERROR("   Element is not available on the webpage ", nse);
      }
      catch (ElementNotVisibleException env)
      {
         extentReport.FailWithException(driver,
                           "Unable to deselect drop down values",
                           "   Element is not visible on the webpage ",
                           env);
         logERROR("   Element is not visible on the webpage ", env);
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver,
                           dropDownValue,
                           " Value not deselected in drop down",
                           e);
         logERROR(" Value not deselected in drop down", e);
      }

   }

   public void deSelectAllValuesInDropDown(WebDriver driver,
                                           WebElement dropDownXpath) throws IOException
   {
      try
      {
         Select select = new Select(dropDownXpath);
         select.deselectAll();
         extentReport.PASS("DropDown", "All Values deselects in dropdown");
         log.info("All Values deselects in dropdown ");
      }
      catch (NoSuchElementException nse)
      {
         extentReport.FailWithException(driver,
                           "Unable to  deselect drop down values",
                           "   Element is not available on the webpage ",
                           nse);
         logERROR("   Element is not available on the webpage ", nse);
      }
      catch (ElementNotVisibleException env)
      {
         extentReport.FailWithException(driver,
                           "Unable to deselect drop down values",
                           "   Element is not visible on the webpage ",
                           env);
         logERROR("   Element is not visible on the webpage ", env);
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver,
                           "Desecting dropdown failed",
                           " Value not deselected in drop down",
                           e);
         logERROR(" Value not deselected in drop down", e);
      }

   }

   public boolean isVerticalScrollBarPresent(WebDriver driver)
   {
      JavascriptExecutor javascript = (JavascriptExecutor) driver;
      if ((Boolean) javascript
            .executeScript("return document.documentElement.scrollHeight>document.documentElement.clientHeight;"))
      {
         return false;
      }
      return true;
   }

   //////////////

   public int getDropdownBoxSize(WebDriver driver,
                                 WebElement ObjectxPath,
                                 String message) throws Exception
   {
      try
      {
         Select select = new Select(ObjectxPath);
         extentReport.PASS(message,
                           message + " dropbox size is "
                                 + select.getOptions().size());
         log.info(message + " dropbox size is " + select.getOptions().size());
         return select.getOptions().size();
      }
      catch (Exception t)
      {
         extentReport.FailWithException(driver, message, message + " does not Exist", t);
         log.error(message + " does not Exist", t);
         t.printStackTrace();
         throw new Exception("Element Not Present");
      }
   }

   public void swithToWindowHandleWithTitle(WebDriver driver, String title)
   {
      Set<String> handles = driver.getWindowHandles();
      String[] browser = handles.toArray(new String[0]);
      System.out.println("Number of browsers opened are" + browser.length);
      System.out.println(driver.getTitle());
      for (int i = 0; i < handles.size(); i++)
      {
         driver.switchTo().window(browser[i]);
         if (driver.getTitle().equals(title))
         {
            driver.getWindowHandle();
            extentReport.PASS(title, "Window handled for " + title);
            log.info("Window handled for " + title);
            break;
         }
      }
   }

   public void waitForElementVisibility(WebDriver driver,
                                        WebElement element) throws IOException
   {
      try
      {
         WebDriverWait wait = new WebDriverWait(driver, 20);
         wait.until(ExpectedConditions.visibilityOf(element));
      }
      catch (TimeoutException te)
      {
         extentReport.FailWithException(driver,
                           "Visibility of Element",
                           "Element not visbile",
                           te);
         logERROR("Element not visbile", te);
      }
   }

   public void waitForElementToBeClickable(WebDriver driver,
                                           WebElement element) throws IOException
   {
      try
      {
         WebDriverWait wait = new WebDriverWait(driver, 20);
         waitForElementVisibility(driver, element);
         wait.until(ExpectedConditions.elementToBeClickable(element));
      }
      catch (TimeoutException te)
      {
         extentReport.FailWithException(driver,
                           "Visibility of Element",
                           "Element not visbile or not clickable",
                           te);
         logERROR("Element not visbile", te);
      }
   }

   public void waitForElementNotPresent(WebDriver driver,
                                        WebElement element) throws IOException
   {
      try
      {
         WebDriverWait wait = new WebDriverWait(driver, 20);
         wait.until(ExpectedConditions.invisibilityOf(element));
      }
      catch (TimeoutException te)
      {
         extentReport.FailWithException(driver,
                           "Visibility of Element",
                           "Element not visbile",
                           te);
         logERROR("Element not visbile", te);
      }
   }

   public void waitForElementClickable(WebDriver driver,
                                       WebElement element,
                                       int timeout) throws IOException
   {
      try
      {
         WebDriverWait wait = new WebDriverWait(driver, timeout);
         wait.until(ExpectedConditions.elementToBeClickable(element));
      }
      catch (NoSuchWindowException e)
      {
         extentReport.FailWithException(driver,
                           "Element Clickable",
                           "Element not Clickable",
                           e);
         logERROR("Element not Clickable", e);
      }
      catch (InvalidElementStateException e)
      {
         extentReport.FailWithException(driver,
                           "Element Clickable",
                           "Element not Clickable",
                           e);
         logERROR("Element not Clickable", e);
      }
      catch (TimeoutException te)
      {
         extentReport.FailWithException(driver,
                           "Element Clickable",
                           "Element not Clickable",
                           te);
         logERROR("Element not Clickable", te);
      }
      catch (NoSuchElementException e)
      {
         extentReport.FailWithException(driver,
                           "Element Clickable",
                           "Element not Clickable",
                           e);
         logERROR("Element not Clickable", e);
      }
      catch (WebDriverException we)
      {
         extentReport.FailWithException(driver,
                           "Element Clickable",
                           "Element not Clickable",
                           we);
         logERROR("Element not Clickable", we);
      }
   }

   public Alert waitforAlertPresent(WebDriver driver) throws InterruptedException
   {
      int i = 0;
      Alert alert = null;
      while (i++ < 30)
      {
         try
         {
            alert = driver.switchTo().alert();
            return alert;
         }
         catch (NoAlertPresentException e)
         {
            Thread.sleep(1000);
            continue;
         }
      }
      return alert;
   }

   public void JavaScriptExecutor_SetValue(WebDriver driver,
                                           WebElement ObjectxPath,
                                           String Value,
                                           String message) throws Exception
   {
      try
      {
         JavascriptExecutor executor = (JavascriptExecutor) driver;
         executor.executeScript("arguments[0].value='10';", ObjectxPath);
         extentReport.PASS(Value + " entered", message + " Clicked");
         log.info(message + " Clicked");
      }
      catch (Throwable t)
      {
         extentReport.FAIL(driver,
                           Value + " not entered",
                           message + " does not Exist");
         logERROR(message + " does not Exist");
         t.printStackTrace();
         throw new Exception("Element Not Present");
      }
   }

   public void Checkfontcolor(WebDriver driver,
                              WebElement xpath,
                              String FieldName,
                              String color) throws IOException
   {

      try
      {
         String font = xpath.getCssValue("color");
         System.out.println(font);
         if (font.equalsIgnoreCase(color))
         {
            extentReport.PASS(FieldName, FieldName + " is in expected color");
            log.info(FieldName + " is in expected color");
         }
         else
         {
            extentReport.FAIL(driver,
                              FieldName,
                              FieldName + " is not in expected color");
            logERROR(FieldName + " is not in expected color");
         }
      }
      catch (Exception e)
      {
         e.printStackTrace();
         extentReport.FailWithException(driver,
                           FieldName,
                           FieldName + " is not in expected color",
                           e);
         logERROR(FieldName + " is not in expected color", e);
      }
   }

   public String randomString()
   {
      String generatedRandomString = RandomStringUtils.randomAlphabetic(7);
      return generatedRandomString;
   }

   public String randomNumber()
   {
      String generatedRandomNumber = RandomStringUtils.randomNumeric(7);
      return generatedRandomNumber;
   }

   public String randomAlphaNumeric()
   {
      String generatedAlphaNumeric = RandomStringUtils.randomAlphanumeric(7);
      return generatedAlphaNumeric;
   }

   public void dragAndDrop(WebDriver driver,
                           WebElement sourceElement,
                           WebElement destinationElement)
   {
      Actions actions = new Actions(driver);
      actions.dragAndDrop(sourceElement, destinationElement)
            .pause(Duration.ofSeconds(2)).release().build().perform();
   }

   public void dragAndDropByMovingToDestination(WebDriver driver,
                                                WebElement sourceElement,
                                                WebElement destinationElement)
   {
      Actions actions = new Actions(driver);
      actions.clickAndHold(sourceElement).pause(Duration.ofSeconds(2))
            .moveToElement(destinationElement).pause(Duration.ofSeconds(2))
            .release().build().perform();
   }

   public void rightClick(WebDriver driver, WebElement element)
   {
      Actions actions = new Actions(driver);
      actions.contextClick(element).build().perform();
   }

   public void doubleClick(WebDriver driver,
                           WebElement element) throws IOException
   {
      try
      {
         Actions actions = new Actions(driver);
         actions.doubleClick(element).build().perform();
         extentReport.PASS("Double Click", "Double clicked on element");
         log.info("Double clicked on element");
      }
      catch (StaleElementReferenceException sere)
      {
         extentReport.FailWithException(driver,
                           "Element NOT clicked!",
                           " Element is not attached to DOM of the webpage. ",
                           sere);
         logERROR(" Element is not attached to DOM of the webpage. ", sere);
      }
      catch (NoSuchElementException nse)
      {
         extentReport.FailWithException(driver,
                           "Element NOT clicked!",
                           "Element is not available on the webpage ",
                           nse);
         logERROR("Element is not available on the webpage ", nse);
      }
      catch (ElementNotVisibleException env)
      {
         extentReport.FailWithException(driver,
                           "Element NOT clicked!",
                           "Element is not visible on the webpage ",
                           env);
         logERROR("Element is not visible on the webpage ", env);
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver,
                           "Element NOT clicked!",
                           " Something went wrong ",
                           e);
         logERROR(" Something went wrong ", e);
      }
   }

   public static void getPageInnerTextByJavaScript(WebDriver driver)
   {
      JavascriptExecutor javaScript = ((JavascriptExecutor) driver);
      String pageText = javaScript
            .executeScript("return document.documentElement.innerText;")
            .toString();
      System.out.println("The Text of the Page is ::: " + pageText);
   }

   // To Select Calendar Date Or Data Picker Using Java Script Executor.
   public static void selectDateByJS(WebDriver driver,
                                     WebElement element,
                                     String dateValue)
   {
      JavascriptExecutor js = ((JavascriptExecutor) driver);
      js.executeScript("arguments[0].setAttribute('value','" + dateValue
            + "');", element);
   }

   public void clearField(WebDriver driver,
                          WebElement element) throws IOException
   {
      try
      {
         element.clear();
         extentReport.PASS(element.getText(),
                           element.getText() + " field cleared");
         log.info(element.getText() + " field cleared");
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver,
                           element.getText(),
                           element.getText() + " field not cleared",
                           e);
         logERROR(element.getText() + " field not cleared", e);
      }
   }

   /**
    * Remove trial and leading spaces in the string
    */
   public String removeAllSpace(String text)
   {
      if (text != null)
      {
         text = text.replaceAll(" ", "").replaceAll("[\\s\\u00A0]", "");
      }
      return text;
   }

   public void jsScrollToElement(WebDriver driver, WebElement element)
   {
      JavascriptExecutor js = (JavascriptExecutor) driver;
      // This will scroll the page till the element is found
      js.executeScript("arguments[0].scrollIntoView();", element);

   }

   public void jsScrollUp(WebDriver driver, int position)
   {
      // to perform Scroll on application using Selenium
      JavascriptExecutor js = (JavascriptExecutor) driver;
      js.executeScript("window.scrollBy(0," + position + ")", "");
   }

   public void jsScrollDown(WebDriver driver, int position)
   {
      // to perform Scroll on application using Selenium
      JavascriptExecutor js = (JavascriptExecutor) driver;
      js.executeScript("window.scrollBy(0,-" + position + ")", "");
   }
   
   /**
    * this method kills the browserdrivers and browser in the taskmanager,
    * always use this method @aftersuite level
    * or @afterClass (i.e., after the test class execution is over)
    */
   public static void killBrowserDrivers(String browserName){
       
		try{
			if(browserName.equalsIgnoreCase("Chrome")){
				Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
				Runtime.getRuntime().exec("taskkill /F /IM chrome.exe");
				System.out.println("Chrome driver .exe process is deleted successfully in task manager");
			}else if(browserName.equalsIgnoreCase("Firefox")){
				Runtime.getRuntime().exec("taskkill /F /IM geckodriver.exe");
				Runtime.getRuntime().exec("taskkill /F /IM Firefox.exe");
				System.out.println("Gecko driver .exe process is deleted successfully in task manager");
			}else if(browserName.equalsIgnoreCase("IE")){
				Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
				Runtime.getRuntime().exec("taskkill /F /IM internetexplorer.exe");
				System.out.println("IEDriverServer .exe process is deleted successfully in task manager");
			}
                                                              
		}catch(Exception e){
			e.printStackTrace();
		}
	}
   
   public String getParentWindow(WebDriver driver)
   {
	return driver.getWindowHandle();
   }
   
}
