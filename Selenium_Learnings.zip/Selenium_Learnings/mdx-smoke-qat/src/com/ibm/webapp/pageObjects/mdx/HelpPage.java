package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.utils.Selenese;

/**
 * @author APeavy
 * 
 */
public class HelpPage extends Selenese
{
   private WebDriver driver;

   @FindBy(id = "btntoc")
   private WebElement helpContentLink;

   @FindBy(id = "toolbar")
   private WebElement frameHeader;

   @FindBy(id = "topic")
   private WebElement frameBody;

   @FindBy(xpath = "/html/body/h4[1]")
   private WebElement pageHeader;

   @FindBy(id = "brseq0")
   private WebElement cl;

   public HelpPage(WebDriver driver) throws IOException
   {
      this.driver = driver;
      PageFactory.initElements(driver, this);
      driver.switchTo().frame(1).switchTo().frame(1);
      waitForElementVisibility(driver, pageHeader);
   }

   /**
    * Use this method to verify help window loaded with expected content
    * 
    * @throws InterruptedException
    *            ,IOException
    */

   public void verifyHelpPageHeader() throws IOException, InterruptedException
   {
      try
      {
         System.out.println(driver.getTitle());
         isElementDisplayed(driver, "Help page header", pageHeader);
         windowClose();

      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver,
                                        "Verification of help page header visibility",
                                        pageHeader
                                              + "is not displayed in help popup window",
                                        e);
         logERROR(pageHeader + "is not displayed in help popup window", e);
      }
   }

   /**
    * Use this method to verify help window is closed properly
    * 
    * @throws IOException
    */

   public void windowClose() throws IOException
   {
      try
      {
         driver.close();
         extentReport.PASS("Closing the help window",
                           "Help window closed successfully");
         log.info("Help window closed successfully");
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver,
                                        "Closing the help window",
                                        "Help window is not closed",
                                        e);
         logERROR("Help window is not closed", e);
      }
   }

}
