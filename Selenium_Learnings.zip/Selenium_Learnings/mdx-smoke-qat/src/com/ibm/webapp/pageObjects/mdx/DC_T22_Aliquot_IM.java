package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.utils.Selenese;

public class DC_T22_Aliquot_IM extends Selenese
{
   private WebDriver driver;
   
   DC_Template_Constants data=new DC_Template_Constants();
   
   public String[] fieldUnits_Template22_PHENobarbital =  {data.MG_KG_DAY,data.DOSE_DAY,data.IV_OVER_15_TO_30_MINUTES,data.MG_ML};
   public String[] fieldUnits_Template22_Chloramphenicol =  {data.MG_KG_DAY,data.DOSES_DAY,data.IV_OVER_15_TO_60_MINUTES,data.MG_ML};
   public String[] fieldUnits_Template22_Ferrous_sulfate_Calcium_Oral_Diazoxide_Chlorothiazide =  {data.MG_KG_DAY,data.DOSES_DAY,data.ORALLY,data.MG_ML};
   public String[] fieldUnits_Template22_Cefotaxime =  {data.MG_KG_DAY,data.DOSES_DAY,data.IV_OVER_10_TO_30_MINUTES,data.MG_ML};
   public String[] fieldUnits_Template22_Amoxicillin_Vancomycin =  {data.MG_KG_DAY,data.DOSES_DAY,"orally",data.MG_ML};
   public String[] fieldUnits_Template22_Piperacillin_Tazobactam =  {data.MG_KG_DAY,data.DOSES_DAY,data.IV_OVER_ATLEAST_30_MINUTES,data.MG_ML};
   
   public String[] resultUnits={"mg/dose","mL/dose"};
   
   
	 // ******************---------------****************
   
   
	  @FindBy(id = "DrugNameDiv")
   private WebElement template1_drugName;
   
   @FindBy(id = "bMessage")
   private WebElement overDoseMessage;
	  
   @FindBy(xpath ="//table[@id='drugSelectionHelpTableID']//tr[1]/td[2]" )
   private WebElement actual_PMAorPedWeight ;
   
   @FindBy(xpath ="//input[@id='dose']" )
   private WebElement doseValue ;
   
   @FindBy(xpath ="//input[@id='interval']" )
   private WebElement intervalValue ;
   
   @FindBy(xpath ="//input[@id='admin']" )
   private WebElement adminValue ;
   
   @FindBy(xpath ="//input[@id='conc']" )
   private WebElement concValue ;
   
   @FindBy(id ="doseamount1" )
   private WebElement doseAmount1_Value ;
   
   @FindBy(id ="dosevolume1" )
   private WebElement doseVolume1_Value ;
   
   @FindBy(id ="deliveryrate1" )
   private WebElement deliveryRate1_Value ;
   
   @FindBy(id ="doseamount2" )
   private WebElement doseAmount2_Value ;
   
   @FindBy(id ="dosevolume2" )
   private WebElement doseVolume2_Value ;
   
   @FindBy(id ="deliveryrate2" )
   private WebElement deliveryRate2_Value ;
   
   @FindBy(id ="doseamount3" )
   private WebElement doseAmount3_Value ;
   
   @FindBy(id ="dosevolume3" )
   private WebElement doseVolume3_Value ;
   
   @FindBy(id ="deliveryrate3" )
   private WebElement deliveryRate3_Value ;
   
   @FindBy(id ="helpInformationDivId" )
   private WebElement standardiv_calculate_notes ;
   
   @FindBy(id ="validatemsgId" )
   private WebElement alertMessage ;
   
   @FindBy(xpath ="//div[@id='validatemsgId']//center" )
   private WebElement alert_range_val ;
  
   @FindBy(id = "validateDosemsgId")
   private WebElement alert_Maxdose_value;
   @FindBy(id = "invalidmsgId")
   private WebElement alert_Invalid_alert;
   @FindBy(id = "//input[@onclick='dijit.byId('validationPopup').hide()']")
   private WebElement alert_Invalid_Close_btn;
   @FindBy(xpath = "//div[@id='bMessage' and @class='CalcText']")
   private WebElement Max_dose_override_msg;
   /**
    * Default Constructor for DC_T3_StandardIV class
 * @throws IOException 
    */
   public DC_T22_Aliquot_IM(WebDriver driver) throws IOException
   {
	   this.driver = driver;
		PageFactory.initElements(this.driver, this);
		//waitForElementVisibility(driver, template1_drugName);
     
   }
   /**
    * @returns DC_Template1Page
    */
   public DC_Template_Utility getDC_Util()
   {
      
      return PageFactory.initElements(driver,DC_Template_Utility.class);
   }
   
   
   /**
    * Use this method for the validations of template 22
    * page
    * @throws InterruptedException 
 * @throws IOException 
    * 
    */

   public boolean validationForTemplate22(double weight,String calculationType) throws InterruptedException, IOException
   {
      boolean flag = false,flag1=false;
      try
      {
         switch (calculationType)
         {
            case "default":
              getDC_Util().click_btn(getDC_Util().CALCULATE);
              flag1 = true;
               flag = calculationForTemplate22(weight,"NA");
             break;
            case "enterLowDose":
               flag = reviseAndOverrideForTemp22(getDC_Util().field_dose,0);
               flag1 = calculationForTemplate22(weight,"NA");
               break;
            case "enterHighDose":
               flag = reviseAndOverrideForTemp22(getDC_Util().field_dose,1);
               flag1 = calculationForTemplate22(weight,"NA");
               break;
            case "enterLowInterval":
               flag = reviseAndOverrideForTemp22(getDC_Util().field_interval,0);
               flag1 = calculationForTemplate22(weight,"NA");
               break;
            case "enterHighInterval":
               flag = reviseAndOverrideForTemp22(getDC_Util().field_interval,1);
               flag1 = calculationForTemplate22(weight,"NA");
               break;
            case "enterLowConc":
               flag = reviseAndOverrideForTemp22(getDC_Util().field_Conc,0);
               flag1 = calculationForTemplate22(weight,"NA");
               break;
            case "enterHighConc":
               flag = reviseAndOverrideForTemp22(getDC_Util().field_Conc,1);
               flag1 = calculationForTemplate22(weight,"NA");
               break;
               
         }
        
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
      if(flag&&flag1)
      {
    	  
    	  extentReport.PASS("Validation of calculation for Template 22: "+calculationType,
                  "Calculation value is correct for: "+calculationType);
  		 log.info("Calculation value is correct for: "+calculationType);
         return true;
      }
      extentReport.FAIL(driver,"Validation of calculation for Template 22: "+calculationType,"Calculation value is correct for: "+calculationType);
      logERROR("Calculation value is correct for: "+calculationType);
      return false;
   }
   
   /**
    * Use this method for the override functionalities in alert box.
    * 
    */
   public boolean reviseAndOverrideForTemp22(WebElement field,int minOrMax) throws InterruptedException{
      try{
    	  if(minOrMax==0) {
    	      getDC_Util().validateRevise(field);
    	    	  }
      getDC_Util().clickOverRide(field,minOrMax);
      getDC_Util().click_btn(getDC_Util().CALCULATE);
      }
      catch(Exception e){
         e.printStackTrace();
      }
      return true;
   }

   /**
    * Use this method to verify the calculation for template 22
    * @return true, when the calculation is as expected.
    * @throws InterruptedException 
    */
   public boolean calculationForTemplate22(double weight,String maxDoseValue) throws InterruptedException
   {

      double doseAmountValue = 0;
      boolean flag = false;
      Thread.sleep(2000);
      double interval = getDC_Util().getFieldValuesinUI(intervalValue, "value");
      if(maxDoseValue.equalsIgnoreCase("NA")){
         double dose = getDC_Util().getFieldValuesinUI(doseValue, "value");
          doseAmountValue = (dose * weight)/interval;
      }
      else
      {
         doseAmountValue = Double.parseDouble(maxDoseValue.split(" ")[0])/interval;
      }
      double doseAmount_expected = getDC_Util().rounding_decimal_values(doseAmountValue);
      double conc = getDC_Util().getFieldValuesinUI(concValue, "value");
      double doseVolumeValue = doseAmount_expected/ conc ;
      double doseVolume_expected = getDC_Util().rounding_decimal_values(doseVolumeValue);
      double doseAmount1_actual = getDC_Util().getFieldValuesinUI(doseAmount1_Value,
                                                              "text");
      double doseVolume1_actual = getDC_Util().getFieldValuesinUI(doseVolume1_Value,
                                                              "text");
      if (doseAmount_expected == doseAmount1_actual
            && doseVolume_expected == doseVolume1_actual)
      {
         flag = true;
      }
      
      return flag;

   }
   
   /**
    * validating  Revise,override and Dosage Claculation in MAXDOSE USE alert and Drug calculation for
    * drug amount,drug volume,deliver rate
    * 
    * @param weight    = Weight of the patient should pass as parameter.
    * @param locatorName    = WebElement of Field should pass as parameter.
    * @param value    = High value(i.e.,999999) should pass as parameter.
    * @return true = When all the validations are passed. false = When all the
    *         validations are failed.
    */
     public boolean maxReviseOverRideandUseMax(double weight,WebElement locatorName,int value) throws InterruptedException{
    	 
         String max_dose=getDC_Util().maxReviseforDose(value+"");
         String maxdruguse_values[] = max_dose.trim().split(" ");
         double maxDoseValue_alert = Double.parseDouble(maxdruguse_values[0].trim());
         double interval = getDC_Util().getFieldValuesinUI(intervalValue, "value");
         getDC_Util().enterValueandCalculate(getDC_Util().field_dose, (value-1)+"");
         getDC_Util().click_btn(getDC_Util().MAXDOSEOVERRIDE);
         boolean maxOverrideValidation =  calculationForTemplate22(weight,"NA");
         if(!maxOverrideValidation || !getDC_Util().overDoseMessage.getText().equalsIgnoreCase("You have selected to override the Maximum Dose of "+max_dose)){
            return false;
         }
         getDC_Util().enterValueandCalculate(locatorName,(value-2)+"");
         getDC_Util().click_btn(getDC_Util().USEMAXDOSE);
         getDC_Util().isButtonEnabled(getDC_Util().CALCULATE, getDC_Util().DISABLED);
         if(getDC_Util().field_dose.isEnabled()){
            return false;
         }
          double doseamount_actual = getDC_Util().getFieldValuesinUI(getDC_Util().doseamount_field, "text");
         if(!((getDC_Util().rounding_decimal_values(maxDoseValue_alert/interval)) == doseamount_actual)) {
             return false;
         }
        
         if(!calculationForTemplate22(weight,max_dose+"")){
            return false;
         }
        	 
         
         return true;
         }
         
        
   
}
   

   
  
   
  
   
  
   
   
