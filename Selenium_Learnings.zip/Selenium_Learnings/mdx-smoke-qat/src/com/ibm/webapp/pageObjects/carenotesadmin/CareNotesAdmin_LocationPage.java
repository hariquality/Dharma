package com.ibm.webapp.pageObjects.carenotesadmin;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;


public class CareNotesAdmin_LocationPage extends Selenese
{
   private HashMap<String,WebElement> locationsMap = new HashMap<String,WebElement>();
  
   @FindBy(xpath = "//a[contains(@href,'carenotesadmin.Properties?CurrentLocation=')]")
   private List<WebElement> locations;
   
   @FindBy(xpath = "//a[contains(@href,'carenotesadmin.Home')]")
   public WebElement locationsTab;
   
   @FindBy(xpath = "//a[contains(@href,'pf.Logout')]")
   private WebElement logoutLink;
   
   @FindBy(xpath = "//a[contains(@href,'carenotesadmin.Properties')]")
   private WebElement propertiesTab;

   @FindBy(xpath = "//a[contains(@href,'carenotesadmin.Documents')]")
   private WebElement documentsTab;
    
   @FindBy(xpath = "//a[contains(@href,'carenotesadmin.Images')]")
   private WebElement imagesTab;
   
   protected final WebDriver driver;
   
   public CareNotesAdmin_LocationPage(WebDriver driver) {
      this.driver = driver;
      PageFactory.initElements(new AjaxElementLocatorFactory(this.driver,15), this);
      WebDriverWait wait = new WebDriverWait(this.driver, 20);
      wait.until(ExpectedConditions.visibilityOf(locationsTab));
      populateLocationsMap();
     }
 
   /**
    * to get the list of locations present in carenotes admin
    */
   private void populateLocationsMap() {
      locationsMap.clear();
      for (WebElement locationLink: locations) {
       locationsMap.put(locationLink.getText(), locationLink);
      }
     }
   
   /**
    * 
    * @param target
    * @return
    * @throws InterruptedException
    */
   public CareNotesAdmin_PropertiesTabPage clickOnLocation(String target) throws InterruptedException {
      locationsMap.get(target).click();
      Thread.sleep(2000);
      CareNotesAdmin_PropertiesTabPage page = PageFactory.initElements(driver, CareNotesAdmin_PropertiesTabPage.class);
      return page;
     }

   public CareNotesAdmin_LocationPage clickLocationsTab() {
      
      try
      {
         click(driver, "click on locations tab", locationsTab);
      }
      catch (IOException e)
      {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
      CareNotesAdmin_LocationPage page = PageFactory.initElements(driver, CareNotesAdmin_LocationPage.class);
      return page;
     }

    /**
     * Click on Documents tab in carenotes admin
     * @return carenotes admin documents page object
     */
     public CareNotesAdmin_DocumentsTabPage clickDocumentsTab() {
      
      try
      {
         click(driver, "click on documents tab", documentsTab);
      }
      catch (IOException e)
      {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
      CareNotesAdmin_DocumentsTabPage page = PageFactory.initElements(driver, CareNotesAdmin_DocumentsTabPage.class);
      return page;
     }
     
     /**
      * Click on Images tab in carenotes admin  
      * @return carenotes admin images page object
      */
     public CareNotesAdmin_ImagesTabPage clickImagesTab() {
      
      try
      {
         click(driver, "click on images tab", imagesTab);
      }
      catch (IOException e)
      {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
      CareNotesAdmin_ImagesTabPage page = PageFactory.initElements(driver, CareNotesAdmin_ImagesTabPage.class);
      return page;
     }
     


   
   
}
