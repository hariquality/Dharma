package com.ibm.webapp.pageObjects.top100hospitals;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

/**
 * @author APeavy
 * 
 */
public class Top100Hospitals_CreateStudyGroupPage extends Selenese {

	private final WebDriver driver;

	@FindBy(xpath = "//*[@id='User.Year_index_0']")
	private WebElement EnterYear;

	@FindBy(xpath = "//*[@id='User.StudyStart_index_0']")
	private WebElement EnterStartDate;

	@FindBy(xpath = "//*[@id='User.StudyEnd_index_0']")
	private WebElement EnterEndDate;

	@FindBy(xpath = "//*[@id='Submit']")
	private WebElement CreateStudyButton;

	@FindBy(xpath = "//*[@id='Cancel']")
	private WebElement CancelButton;

	@FindBy(xpath = "//*[@id='createStudyGroupMenu']/table/tbody/tr[1]/td/h4")
	private WebElement CreateNationalBenchmarkStudy;

	@FindBy(xpath = "//*[@id='createStudyGroupMenu']/table/tbody/tr[1]/td/h4]")
	private WebElement CreateCardioVasucularBenchmarkStudy;

	@FindBy(xpath = "//*[contains(text(),'A Study Group named Cardiovascular Benchmark Study Group - 2019')]")
	private WebElement alreadyExistingErrorMsg;

	@FindBy(xpath = "//*[contains(text(),'A Study Group named National Benchmark Study Group - 2019')]")
	private WebElement alreadyExistingErrorMsg_national;

	@FindBy(xpath = "//span[contains(text(),'Validation Error')]")
	private WebElement invalidErrorMsg;

	@FindBy(xpath = "//*[contains(text(), 'Create a new National Benchmarks Study Group')]")
	private WebElement nationalStudyGrpTitle;

	@FindBy(xpath = "//*[contains(text(), 'Create a new Cardiovascular Benchmarks Study Group')]")
	private WebElement cardioStudyGrpTitle;

	public Top100Hospitals_CreateStudyGroupPage(WebDriver driver) throws IOException {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);

		try {
			wait.until(ExpectedConditions.visibilityOf(CreateStudyButton));
		} catch (Exception e) {
			extentReport.FAIL(driver, "Top100Hospitals_CreateStudyGroupPage",
					"Create study group button is not visible");
			log.error("Create user for group link is not visible in user provisioning page");
		}
	}

	/**
	 * verify whether a year is already present in the user provisioning page
	 * 
	 * @param l
	 * @return
	 */
	
	public String verifyYearIsAlreadyCreatedInUserProv(@SuppressWarnings("rawtypes") List l) {
		String year = "2028";
		int yr = Integer.parseInt(year);

		for (int i = 0; i <= l.size(); i++) {
			if (l.contains(yr)) {
				System.out.println("Year" + yr + " is already present");
				yr++;
			}

			else {
				break;
			}
		}

		year = Integer.toString(yr);
		return year;
	}

	/**
	 * create study group
	 * 
	 * @param year
	 * @return
	 * @throws IOException
	 */
	public Top100Hospitals_UserProvisioningPage createStudyGroup(String year) throws IOException {

		sendKeys(driver, "year", EnterYear, year);
		String startDate = year + "/01/01";
		String endDate = year + "/12/31";
		sendKeys(driver, "start date", EnterStartDate, startDate);
		sendKeys(driver, "end date", EnterEndDate, endDate);
		click(driver, "create study group", CreateStudyButton);

		Top100Hospitals_UserProvisioningPage userProvPage = PageFactory.initElements(driver,
				Top100Hospitals_UserProvisioningPage.class);
		userProvPage.verifyStudyGrpCreationSuccessMsg();
		return userProvPage;

	}

}
