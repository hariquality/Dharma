package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.ibm.webapp.utils.Selenese;



public class DC_Template_Utility extends Selenese{
	
	WebDriver driver;
	
	Object obj = null;
	
	 @FindBy(xpath = "//div[contains(text(),' - Calculator')]")
	   private WebElement calculator_header;
	 
	 @FindBy(id = "doseamount1")
	   public WebElement doseamount_field;
	 
	 @FindBy(xpath = "//input[@type='button'][@value='Reset Form']")
	   private WebElement btn_Reset;

	  @FindBy(xpath = "//input[@type='button'][@value='Drug Monograph']")
	   private WebElement btn_DrugMonograph;

	 @FindBy(xpath = "//div[@id='exceededAlertPopup']//input[@id='reviseButtonId']")
	   public WebElement btn_Revise_MaxDose;

	@FindBy(xpath = "//div[@id='exceededAlertPopup']//input[@id='overrideButtonId']")
	   public WebElement btn_Override_MaxDose;
	
	 @FindBy(id = "validateDosemsgId")
	   public WebElement alert_Maxdose_value;
	 
	 @FindBy(id = "bMessage")
	   public WebElement overDoseMessage;
	
	 @FindBy(id = "5")
	   public WebElement field_conc_infusion;
	 
	 @FindBy(id = "3")
	   public WebElement field_dose_infusion;

	@FindBy(id = "maxdoseButtonId")
	   public WebElement btn_alert_UseMaxdose;
	 
	 public String minValue = null;

	   public String maxValue = null;

	   public String RangeValue = null;
	 
	 @FindBy(id = "DrugNameDiv")
	   private WebElement drugName;
	 
	 @FindBy(id = "calculatebtnId")
	   public WebElement btn_Calculate;
	 
	 @FindBy(id = "printFriendly")
	   public WebElement printpopup;
	   
	   @FindBy(xpath = "//input[@title='Close' and contains(@onclick,'printFriendly')]")
	   public WebElement printpopupClose;

	   @FindBy(id = "printButtonId")
	   private WebElement btn_Print;
	   
	   @FindBy(id = "doseVsRatePopup")
	   public WebElement dosevsratepopup;
	   
	   @FindBy(xpath = "//input[@title='Close' and contains(@onclick,'doseVsRatePopup')]")
	   public WebElement dosevsratepopupClose;
	 
	 @FindBy(xpath = "//div[@id='validatemsgId']//center")
	   private WebElement alert_range_val;
	 
	 @FindBy(xpath = "(//*[@id='DrugUseSelect'])/option[1]")
	   private WebElement first_DrugUse;
	 
	 @FindBy(xpath = "//input[@type='button'][@value='Comments']")
	   private WebElement btn_Comments;

	 @FindBy(xpath = "//input[@title='OK' and contains(@onclick,'saveComments')]")
	   public WebElement commentpopupClose;
	 
	 @FindBy(xpath = "(//*[@id='DrugRoute'])/option[1]")
	   private WebElement first_DrugRoute;
	 
	 @FindBy(xpath = "//div[contains(@class,'populationMode')]")
	   private WebElement populationMode;
	 
	 @FindBy(xpath = "(//table[@class='DataTable'])[1]//td[@align='left']/span[@style]")
	   public List<WebElement> doseFieldUnits;

	   @FindBy(xpath = "(//table[@class='DataTable'])[2]//td[@align='left']/span[@style][not(.='')]")
	   public List<WebElement> calculationUnits;
	   
	   @FindBy(id = "DrugUseSelect")
	   private WebElement select_druguse;
	   
	   @FindBy(id = "doseamount1")
	   public WebElement field_doseamount;

	   @FindBy(id = "DrugRoute")
	   private WebElement select_drugroute;
	   
	   @FindBy(id = "userComments_title")
	   public WebElement commentspopup;
	   
	   @FindBy(xpath = "//div[@id='overrideAlertPopup']//input[@id='reviseButtonId']")
	   public WebElement btn_Revise;

	   @FindBy(id = "doseVsRateBtn")
	   private WebElement btn_DosevsRate;

	   @FindBy(xpath = "//div[@id='overrideAlertPopup']//input[@id='overrieButtonId']")
	   public WebElement btn_Override;

	   @FindBy(id = "maxdoseButtonId")
	   public WebElement btn_alert_Maxdose;
	   
	   public static String[] minMaxValue;
	   
	   @FindBy(id = "changeDrug")
	   private WebElement btn_ChangeDrug;

	   public final String REVISE = "revise";

	   public final String OVERRIDE = "override";

	   public final String CHANGEDRUG = "changedrug";

	   public final String RESETFORM = "resetform";

	   public final String CALCULATE = "calculate";

	   public final String PRINT = "print";

	   public final String DRUGMONOGRAPH = "drugmonograph";

	   public final String COMMENTS = "comments";

	   public final String MAXDOSEREVISE = "maxdose_revise";

	   public final String MAXDOSEOVERRIDE = "maxdose_override";

	   public final String USEMAXDOSE = "use_maxdose";

	   public final String DEFAULT = "default";

	   public final String LOWDOSE = "lowDose";

	   public final String HIGHDOSE = "highDose";

	   public final String LOWADMIN = "lowAdmin";

	   public final String HIGHADMIN = "highAdmin";

	   public final String LOWINTERVAL = "lowInterval";

	   public final String HIGHINTERVAL = "highInterval";

	   public final String LOWCONC = "lowConc";

	   public final String HIGHCONC = "highConc";

	   public final String LOW = "low";

	   public final String HIGH = "high";

	   public final String ENABLED = "Enabled";

	   public final String DISABLED = "Disabled";

	   public String totalVolumeToBeGenerated = "";

	   public final String ALERT_OK = "alert_ok";

	   public final String LOWRATE = "lowRate";

	   public final String HIGHRATE = "highRate";
	   
	   @FindBy(id = "okButtonId")
	   private WebElement btn_Ok_Alert;

	   @FindBy(id = "comments")
	   private WebElement comments_input;

	   @FindBy(id = "pComments")
	   private WebElement print_comments;

	   // Standard IM PO SC(Template 4)
	   public static String NA = "NA";

	   public static String ORALLY = "Orally";

	   public static String ORAL = "Oral";

	   public static String ENDOTRACEAL = "Endotracheal";

	   public static String SUBQ = "subQ";

	   public static String IM = "IM";

	   public static String IV = "IV";

	   public static String INTRATRACHEALLY = "Intratracheally";

	   public static String ENDOTRACHEAL_TUBE = "Endotracheal tube";

	   public static String OVER_ATLEAST_60_MINUTES = "over at least 60 minutes";

	   public static String IV_INFUSION = "IV infusion";

	   public final String DOSEVSRATE = "doseVsRate";
	   
	   @FindBy(xpath = "//input[@id='dose']")
	   public WebElement field_dose;

	   @FindBy(xpath = "//input[@id='interval']")
	   public WebElement field_interval;

	   @FindBy(xpath = "//input[@id='admin']")
	   public WebElement field_admin;

	   @FindBy(xpath = "//input[@id='conc']")
	   public WebElement field_Conc;

	
	/**
	    * Default Constructor for DosingCalculators_Generics class
	 * @throws IOException 
	    */
	   public DC_Template_Utility(WebDriver driver) throws IOException
	   {
		   this.driver = driver;
			 PageFactory.initElements(this.driver, this);
			 waitForElementVisibility(driver, calculator_header);
	      
	   }
	   
	   /**
	    * 
	    * @param expectedTemplateID
	    *           = Pass the template ID to execute that template class.
	 * @throws IOException 
	    * @returns to the particular Template class, depending upon the TemplateID
	    *          passed.
	    */
	   
	   public Object goToTemplate(int tempID) throws IOException
	   {
	     
	      try
	      {
	         templateSelection(tempID);
	         extentReport.PASS("Verification of template "+ tempID +" is loaded" ,
	        		 "Template  "+tempID+" is loaded successfully");
	 		 log.info("Template  "+tempID+" is loaded successfully");
	      }
	      catch (Exception e)
	      {
	         String exception = e.toString();
	         if (exception.contains("InvocationTargetException"))
	         {
	            templateSelection(tempID);
	         }
	         else
	         {
	            e.printStackTrace();
	         }
	         extentReport.FailWithException(driver,"Verification of template "+ tempID +" is loaded","Template  "+tempID+" is not loaded successfully",e);
	          logERROR("Template  "+tempID+" is not loaded successfully", e);
	      }
	      return obj;
	   }
	   
	   /**
	    * Use this method to get the particular template object 
	    * @param tempID =
	    *           = Pass the template ID to execute that template class.
	    * @returns to the particular Template class, depending upon the TemplateID
	    *          passed.
	    */
	   
	   public Object templateSelection(int tempID)
	   {
	      
	      switch (tempID)
	      {
	         
	      case 22:
	            obj = PageFactory.initElements(driver, DC_T22_Aliquot_IM.class);
	            break;
         
	         case 7:
	            obj = PageFactory.initElements(driver,DC_T7_ContinuousInfusion_min.class);
	            break;	        
	        

	      }
	      return obj;
	   }


	   
	   /**
	    * Validating drug name in landing page.
	    * 
	    * @param drugNameEntered
	    *           = drug name entered in drug selection page
	 * @throws IOException 
	    */
	   public boolean verifyDrugNameInTemplatePage(String drugNameEntered) throws IOException
	   {
	      String drugNameInTemplatePage = drugName.getText();
	      if (drugNameEntered.equals(drugNameInTemplatePage))
	      {
	    	  extentReport.PASS("Verification of drug name in template page",
	                  "The drug name in the Template page is correct");
	  		 log.info("The drug name in the Template page is correct");

	         return true;
	      }
	      extentReport.FAIL(driver,"Verification of drug name in template page","The drug name in the Template page is incorrect");
          logERROR("The drug name in the Template page is incorrect");
	      return false;
	   }

	   /**
	    * Validating population mode in landing page.
	    * 
	    * @param mode
	    *           = Neonatal/Pediatric
	 * @throws IOException 
	    */
	   public boolean verifyPopulationModeInTemplatePage(String mode) throws IOException
	   {
	      String populationModeInTP = populationMode.getText();
	      if (mode.equals(populationModeInTP))
	      {
	    	  extentReport.PASS("Verification of population mode in template page",
	                  "The population mode in the template page is correct");
	  		 log.info("The population mode in the template page is correct");
	         return true;
	      }
	      extentReport.FAIL(driver,"Verification of population mode in template page","The population mode in the template page is incorrect");
          logERROR("The population mode in the template page is incorrect");
	      return false;
	   }
	   
	   /**
	    * Call this method to get patient information from Drug Selection page and
	    * DC-template1 page
	    * 
	    * @param drug_sel_patientDetails
	    *           = Pass the hashmap returned by the patient information method
	    *           from two pages
	    * @return true = Actual hashmap equals to Expected hashmap false = Actual
	    *         hashmap is not equals to Expected hashmap
	 * @throws IOException 
	    */

	   public boolean comparePatientInfo_DrugSelPage_TemplatePage(HashMap<String, String> drug_sel_patientDetails,
	                                                              HashMap<String, String> template_patientDetails) throws IOException
	   {
	      try
	      {
	         if (drug_sel_patientDetails.equals(template_patientDetails))
	        	 extentReport.PASS("Comparison of patient information in drug selection page and template page",
	                     "Patient information is correct in drug selection page and template page ");
	     		 log.info("Patient information is correct in drug selection page and template page ");
	            return true;
	      }
	      catch (Exception e)
	      {
	    	  extentReport.FailWithException(driver,"Comparison of patient information in drug selection page and template page","Patient information is incorrect on both pages ",e);
	          logERROR("Patient information is incorrect on both pages ", e);
	         e.printStackTrace();
	      }
	      return false;
	   }
	   
	   
	   /**
	    * @throws IOException 
	 * @returns TRUE if First Drug_use is selected or FALSE if First Drug_use is
	    *          NOT selected
	    */
	   public boolean isFirstDrugUseSelected() throws IOException
	   {
	      try
	      {
	         if (first_DrugUse.isSelected())
	            {
	        	 extentReport.PASS("Verification of first drug use is selected by default",
	                     "First Drug Use is Selected by default");
	     		 log.info("First Drug Use is Selected by default");
	        	 return true;
	            }
	      }
	      catch (Exception e)
	      {
	    	  extentReport.FailWithException(driver,"Verification of first drug use is selected by default","First Drug Use is not Selected by default",e);
	          logERROR("First Drug Use is not Selected by default", e);
	         e.printStackTrace();
	      }
	      return false;
	   }
	   
	   /**
	    * @throws IOException 
	 * @returns TRUE if First Drug_route is selected or FALSE if First Drug_route
	    *          is NOT selected
	    */
	   public boolean isFirstDrugRouteSelected() throws IOException
	   {
	      try
	      {
	         if (first_DrugRoute.isSelected())
	         {
	        	 extentReport.PASS("Verification of First Drug Route is Selected by default",
	                     "First Drug Route is Selected by default");
	     		 log.info("First Drug Route is Selected by default");
	            return true;
	         }
	      }
	      catch (Exception e)
	      {
	    	  extentReport.FailWithException(driver,"Verification of First Drug Route is Selected by default", "First Drug Route is not Selected by default",e);
	          logERROR("First Drug Route is not Selected by default", e);
	         e.printStackTrace();
	      }
	      return false;
	   }
	   
	   
	   /**
	    * Call this method to get Drug Units information DC-template page
	    * 
	    * @param FieldUnits=
	    *           Pass the Field units. * @param FieldUnits= Pass the Calculation
	    *           units.
	    * @param FieldUnits=
	    *           Pass the Calculation units.
	    * @return true = Actual text equals to Expected text false = Actual text is
	    *         not equals to Expected text
	 * @throws IOException 
	    */
	   public void validate_Template_Dosing_Units(String[] FieldUnits,
	                                              String[] Resultunits) throws IOException
	   {
	      try
	      {
	         boolean units_status = validateFieldAndResultsUnit(FieldUnits,
	                                                            Resultunits);
	         extentReport.PASS("Verification of drug dosage units information ",
	                 "Drug dosage units content is matched");
	 		 log.info("Drug dosage units content is matched");
	         Assert.assertTrue(units_status, "DRUG DOASAGE UNITS CONTENT  MISMATCH");
	      }

	      catch (Exception e)
	      {
	    	  extentReport.FailWithException(driver,"Verification of drug dosage units information","Drug dosage units content is mismatched",e);
	          logERROR("Drug dosage units content is mismatched", e);
	         e.printStackTrace();
	      }
	   }
	   
	   /**
	    * use this method to Validate Units values
	    * 
	    * @param fieldUnits
	    *           = Pass Units of Field(i.e.,Drug,Conc,Interval,admin) as Array.
	    * @param calUnits
	    *           = Pass Units of Calculation(i.e.,Dose amount,Dose
	    *           valume,Delievery Rate) as Array.
	    * @throws InterruptedException
	    */ 
	   public boolean validateFieldAndResultsUnit(String[] fieldUnits,
	                                              String[] calUnits)
	   {
	      ArrayList<String> fieldunits_array = new ArrayList<String>();
	      ArrayList<String> resultunits_array = new ArrayList<String>();
	      for (int i = 0; i < fieldUnits.length; i++)
	      {
	         fieldUnits[i] = fieldUnits[i].toLowerCase();
	      }
	      for (int i = 0; i < calUnits.length; i++)
	      {
	         calUnits[i] = calUnits[i].toLowerCase();
	      }

	      for (WebElement tes : doseFieldUnits)
	      {
	         fieldunits_array.add(tes.getText().trim().toLowerCase());
	      }

	      for (WebElement tes : calculationUnits)
	      {
	         resultunits_array.add(tes.getText().trim().toLowerCase());
	      }
	      if (fieldunits_array.equals(Arrays.asList(fieldUnits))
	            && resultunits_array.equals(Arrays.asList(calUnits)))
	      {
	         return true;
	      }
	      return false;
	   }
	   
	   /**
	    * Selects the expected Drug use and Drug route in dosing calculator page.
	    * 
	    * @param drug_use
	    *           = enter the drug_use which has to be selected.
	    * @param drug_route
	    *           = enter the drug_route which needs to be selected.
	 * @throws IOException 
	    * 
	    */
	   public void select_druguse_drugroute(String drug_use, String drug_route) throws IOException
	   {
	      try
	      {
	         Select du = new Select(select_druguse);
	         du.selectByVisibleText(drug_use);
	         Select dr = new Select(select_drugroute);
	         dr.selectByVisibleText(drug_route);
	         extentReport.PASS("Verification of drug use and drug route is selected",
	        		 "Selected drug use: "+drug_use+" and Selected drug route: "+drug_route);
	 		 log.info( "Selected drug use: "+drug_use+" and Selected drug route: "+drug_route);
	      }
	      catch (Exception e)
	      {
	    	  extentReport.FailWithException(driver,"Verification of drug use and drug route is selected","Drug use and drug route is not selected",e);
	          logERROR("Drug use and drug route is not selected", e);
	         e.printStackTrace();
	         Assert.assertFalse(true, "DRUGUSE and DRUDROUTE SELECTION FAILED");
	      }
	   }
	   
	   /**
	    * get the max & min range in the alert pop-Up.
	    * 
	    * @param locatorName
	    *           = pass the expected element(ex: fieldDose or fieldConc etc)
	    * @return minvalue, maxvalue, actual range to be administered
	    * 
	    */
	   public String[] getAlert(WebElement locatorName) throws InterruptedException
	   {
	      locatorName.clear();
	      // textboxto display alert.
	      Thread.sleep(1000);
	      locatorName.sendKeys(Keys.TAB);
	      Thread.sleep(3000);
	     
	      // From REVISE AND OVERRIDE Alert getting range values and splitting MAX
	      // range
	      // and MIN range
	      String Range = alert_range_val.getText().trim();
	      String[] drug_max_range = Range.split("- ");
	      String[] drug_min_range = drug_max_range[0].split(": ");
	      Double min = 0.0;
	      double value = Double.parseDouble(drug_min_range[1]);
	      if (value <= 20)
	      {
	         if (value <= 0.1)
	         {
	            if (value <= 0.01)
	               min = value - 0.001;
	            else
	               min = value - 0.01;
	         }
	         else
	            min = value - 0.1;
	      }
	      else
	      {
	         min = Double.parseDouble(drug_min_range[1]) - 1;
	      }
	      Double max = Double.parseDouble(drug_max_range[1]) + 1;
	      click_btn(REVISE);
	      //btn_Revise.click();
	      minValue = min + "";
	      maxValue = max + "";
	      RangeValue = Range;
	      return minMaxValue = new String[]
	      { minValue, maxValue, RangeValue };
	   }

	   /**
	    * Use this method to click the all button in Dosing calculator
	    * 
	    * @param btn_Name
	    *           = Pass BUTTON name to click.
	    * @return = True or False according to the Click functionality.
	    * @throws InterruptedException
	    */
	   public void click_btn(String getbtn_Name) throws InterruptedException
	   {
		   String buttonName=getbtn_Name;
	      WebElement btnName = null;
	      try
	      {
	         switch (getbtn_Name.toLowerCase())
	         {
	            case "revise":
	               btnName = btn_Revise;
	               break;

	            case ALERT_OK:
	               btnName = btn_Ok_Alert;
	               break;

	            case "override":
	               btnName = btn_Override;
	               break;

	            case "changedrug":
	               btnName = btn_ChangeDrug;
	               break;

	            case "resetform":
	               btnName = btn_Reset;
	               break;

	            case "calculate":
	               btnName = btn_Calculate;
	               break;

	            case "print":
	               btnName = btn_Print;
	               break;

	            case "drugmonograph":
	               btnName = btn_DrugMonograph;
	               break;

	            case "comments":
	               btnName = btn_Comments;
	               break;

	            case "maxdose_revise":
	               btnName = btn_Revise_MaxDose;
	               break;

	            case "maxdose_override":
	               btnName = btn_Override_MaxDose;
	               break;

	            case "use_maxdose":
	               btnName = btn_alert_UseMaxdose;
	               break;

	            case "dosevsrate":
	               btnName = btn_DosevsRate;
	               break;
	         }
	        
	         try {
				click(driver, buttonName +" button", btnName);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	         Thread.sleep(1500);
	      }
	      catch (NoSuchElementException e)
	      {
	         driver.navigate().refresh();
	         Assert.assertTrue(false);
	      }
	   }

	   /**
	    * use this method to wait
	    * @param Waittime
	    *           = pass seconds as parameter.
	    * @throws InterruptedException
	    */
	   public void sleep(int Waittime) throws InterruptedException
	   {
	      Thread.sleep(Waittime);
	   }
	   
	   
	   /**
	    * Clicks the override button in the alert message.
	    * 
	    * @param locatorName
	    *           = pass the expected element(ex: fieldDose or fieldConc etc)
	    * @param minOrMax
	    *           = enter '0' to get min_value OR '1' to get max_value
	    * 
	    * @throws InterruptedException
	 * @throws IOException 
	    */
	   public boolean isAlertPresentForInfusion() throws InterruptedException, IOException
	   {
	      try
	      {
	    	  waitForElementVisibility(driver, alert_range_val);
	        
	         sleep(500);
	         click_btn(OVERRIDE);
	         click_btn(CALCULATE);
	         click_btn(REVISE);
	      }
	      catch (NoSuchElementException e)
	      {
	         return false;
	      }
	      return true;
	   }


	   /**
	    * Entering value and Clicking on TAB.
	    * 
	    */
	   public void enterValueinFieldandPressTab(WebElement locatorName,
	                                            String value) throws InterruptedException
	   {
	      locatorName.sendKeys(Keys.chord(Keys.CONTROL, "a"));
	      sleep(1000);
	      locatorName.sendKeys(value);
	      sleep(1000);
	      locatorName.sendKeys(Keys.TAB);
	      sleep(1000);
	   }
	   
	   public void clickOverRide() throws InterruptedException
	   {
	      click_btn(OVERRIDE);
	   }
	   /**
	    * This method rounds of the decimal values after calculation
	    * @param calculatedDosingValue
	    *           = pass(eg:DOSE_Amount,DOSE_Volume,Delivery_Rate values.).
	    * @return dose_parameter_expected= Value after rounding will be returned
	    */
	   public double rounding_decimal_values(Double calculatedDosingValue)
	   {
	      double dose_parameter_expected = -1;
	      try
	      {
	         int roundingDigits = 0;
	         if (calculatedDosingValue < 1)
	         {
	            if (calculatedDosingValue < 0.1)
	            {
	               // Format the values present for the range <0.1
	               roundingDigits = 1000;
	            }
	            else
	            {
	               // Format the values present b/w the range >0.1 & <1
	               roundingDigits = 100;
	            }
	         }
	         else
	         {
	            // Format the values present for the range >1
	            roundingDigits = 10;
	         }

	         if (calculatedDosingValue >= 20)
	         {
	            // Format the values present for the range >20
	            dose_parameter_expected = Math.round(calculatedDosingValue);
	         }
	         else
	         {
	            // Format the values present for the range <20
	            dose_parameter_expected = Math
	                  .round(calculatedDosingValue * roundingDigits)
	                  / Double.parseDouble(roundingDigits + "");
	         }
	      }
	      catch (Exception e)
	      {
	         e.printStackTrace();
	      }
	      return dose_parameter_expected;
	   }

	   /**
	    * gets the values present inside the field box that is displayed in the UI
	    * 
	    * @param id
	    *           = pass the required id number for the field box.
	    * @return the value present inside the field box.
	    */
	   public String getFieldValue(int id)
	   {
	      JavascriptExecutor js = (JavascriptExecutor) driver;
	      return (String) js.executeScript("return document." + "getElementById('"
	            + id + "').value");
	   }
	   
	   public double roundToTwoDigit( Double value ) {
		   DecimalFormat df = new DecimalFormat("0.00");
		   return Double.valueOf(df.format( value ));
	   }
	  
	   /**
	    * Validating Comments btn Functionality.
	 * @throws IOException 
	    * 
	    */
	   public void validateCommentsBtn() throws IOException
	   {
	      try
	      {
	         boolean commentfunctionality = false;
	        
	         click_btn("comments");
	        
	         if (commentspopup.isDisplayed())
	         {
	            sendKeys(driver, "Comments box", comments_input, "TEST");
	            click(driver, "close button comment box", commentpopupClose); 
	            commentfunctionality = true;
	         }
	         extentReport.PASS("Verification of Comments button functionality",
	                 "Comment button functionality is working as expected");
	 		 log.info("Comment button functionality is working as expected");
	         Assert.assertTrue(commentfunctionality,
	                    "Comments Button Functionality Failed");
	      }
	      catch (Exception e)
	      {
	    	  extentReport.FailWithException(driver,"Verification of Comments button functionality","Comment button functionality is not working as expected",e);
	          logERROR("Comment button functionality is not working as expected", e);
	         e.printStackTrace();
	      }
	   }

	   /**
	    * Validating ResetForm btn Functionality.
	    * 
	    */
	   public void validateResetForm()
	   {
	      try
	      {
	         boolean resetformfunctionality = false;
	         click_btn("resetform");
	         if (field_doseamount.getText().equals("?"))
	         {
	            resetformfunctionality = true;
	         }
	         Assert.assertTrue(resetformfunctionality,
	                    "Reset Form Button Functionality Failed");
	      }
	      catch (Exception e)
	      {
	         e.printStackTrace();
	      }
	   }

	   /**
	    * Validating Print Functionality.
	 * @throws IOException 
	    * 
	    */
	   public void validatePrintBtn() throws IOException
	   {
	      try
	      {
	         boolean printfunctionality = false;
	         click_btn("calculate");
	        
	         click_btn("print");
	         
	         if (printpopup.isDisplayed())
	         {
	            Assert.assertEquals(print_comments.getText().trim(), "Order Notes: TEST");
	            printpopupClose.click();
	            printfunctionality = true;
	         }
	         extentReport.PASS("Verification print button functionality",
	                 "Print button is working fine as expected");
	 		 log.info("Print button is working fine as expected");
	         Assert.assertTrue(printfunctionality, "Print Button Functionality Failed");
	      }
	      catch (Exception e)
	      {
	    	  extentReport.FailWithException(driver,"Verification print button functionality","Print button is not working fine as expected",e);
	          logERROR("Print button is not working fine as expected", e);
	         e.printStackTrace();
	      }

	   }

	   /**
	    * Validating Dose Vs rate Functionality.
	 * @throws IOException 
	    * 
	    */

	   public void validateDosevsRateBtn() throws IOException
	   {
	      try
	      {
	         boolean dosevsratefunctionality = false;
	         
	         click_btn("dosevsrate");
	         
	         if (dosevsratepopup.isDisplayed())
	         {
	            click(driver, "Dose Vs rate close button", dosevsratepopupClose);
	            dosevsratefunctionality = true;
	         }
	         extentReport.PASS("Verification of dose Vs rate button functionality",
	                 "Dose Vs rate is working fine as expected");
	 		 log.info("Dose Vs rate is working fine as expected");
	         Assert.assertTrue(dosevsratefunctionality,"Dose vs Rate Button Functionality Failed");
	      }
	      catch (Exception e)
	      {
	    	  extentReport.FailWithException(driver,"Verification of dose Vs rate button functionality","Dose Vs rate is not working fine as expected",e);
	          logERROR("Dose Vs rate is not working fine as expected", e);
	         e.printStackTrace();
	      }
	   }
	   
	   /**
	    * Validating clickDrugMonographbtn Functionality.
	    * 
	    * @return TRUE if validation is as expected
	    * 
	    */
	   public boolean validateDrugMonographbtn()
	   {
	      String parentWindow = null;
	      try
	      {
	         parentWindow = driver.getWindowHandle();
	         try{
	         click_btn("drugmonograph");
	         extentReport.PASS("Clicking on DoseVsrate button",
	                 "DoseVsrate button is clicked");
	 		 log.info("DoseVsrate button is clicked");
	         }catch(Exception e){
	        	 extentReport.FailWithException(driver,"Clicking on DoseVsrate button","DoseVsrate button is not clicked",e);
		          logERROR("DoseVsrate button is not clicked", e); 
	         }
	         // Switch to new window opened
	         Thread.sleep(2000);
	         ArrayList<String> tabWindow = new ArrayList<String>(driver
	               .getWindowHandles());
	         driver.switchTo().window(tabWindow.get(1));
	         if (driver.getTitle().contains("Drug Monographs"))
	         {
	            driver.close();
	            driver.switchTo().window(parentWindow);
	            return true;
	         }
	         else
	         {
	            driver.close();
	            driver.switchTo().window(parentWindow);
	            return false;
	         }
	         
	      }

	      catch (Exception e)
	      {
	         e.printStackTrace();
	         driver.close();
	         driver.switchTo().window(parentWindow);
	      }
	      return false;
	   }
	   
	   /**
	    * Validated the revise button functionality in the alert pop-up
	    * 
	    * @param locatorName
	    *           = pass the expected element(ex: fieldDose or fieldConc etc)
	    * @throws InterruptedException
	 * @throws IOException 
	    */

	   public boolean validateRevise(WebElement locatorName) throws InterruptedException, IOException
	   {
	      try
	      {
	         minMaxValue = getAlert(locatorName);
	         enterValueinFieldandPressTab(locatorName, minMaxValue[0]);
	         sleep_until(4, btn_Revise);
	         click_btn("revise");
	 		extentReport.PASS("Validation of revise button functionality in alert popup",
	                "Revise button is working as expected after entering the value in field");
			 log.info("Revise button is working as expected after entering the value in field");
	         return true;
	      }
	      catch (Exception e)
	      {
	    	  extentReport.FailWithException(driver,"Validation of revise button functionality in alert popup","Revise button is not working as expected after entering the value in field",e);
	          logERROR("Revise button is not working as expected after entering the value in field", e);
	         e.printStackTrace();
	         return false;
	      }
	   }
	   
	   /**
	    * use this method to wait
	    * @param Waittime
	    *           = pass seconds as parameter.
	    * @param Locator
	    *           = Pass locator of element to wait.
	    * @throws InterruptedException
	    * 
	    */
	   public void sleep_until(int Waittime,
	                           WebElement Locator) throws InterruptedException
	   {
	      try
	      {
	         WebDriverWait wait = new WebDriverWait(driver, Waittime);
	         wait.until(ExpectedConditions.visibilityOf(Locator));
	      }
	      catch (Exception e)
	      {
	         e.printStackTrace();
	      }
	   }
	   
	   
	   /**
	    * Clicks the override button in the alert message.
	    * 
	    * @param locatorName
	    *           = pass the expected element(ex: fieldDose or fieldConc etc)
	    * @param minOrMax
	    *           = enter '0' to get min_value OR '1' to get max_value
	    * 
	    * @throws InterruptedException
	 * @throws IOException 
	    */

	   public void clickOverRide(WebElement locatorName,
	                             int minOrMax) throws InterruptedException, IOException
	   {
		   try{
	      String value = minMaxValue[minOrMax];
	      enterValueinFieldandPressTab(locatorName, value);
	      //_webDriverwait.until(ExpectedConditions.visibilityOf(alert_range_val));
	      click_btn(OVERRIDE);
	      extentReport.PASS("Validation of Override button functionality in alert popup",
	                "Override button is working as expected after entering the value in field");
			 log.info("Override button is working as expected after entering the value in field");
		   }
		   catch(Exception e){
			   extentReport.FailWithException(driver,"Validation of Override button functionality in alert popup","Override button is not working as expected after entering the value in field",e);
		          logERROR("Override button is not working as expected after entering the value in field", e);
			   e.printStackTrace();
		   }
	   }
	   
	   
	   /**
	    * This method is for Getting values from UI specifically from fields
	    * @param element
	    *           = pass the field Locator to get the
	    *           value.(i.e.,DOSE,CONC,ADMIN.).
	    * @param type
	    *           = pass "value" to the get the attribute value OR = pass as the
	    *           value as "text should to get the text value
	    * @return double values according to the expected Value.
	    * @throws InterruptedException
	    * 
	    */
	   public double getFieldValuesinUI(WebElement element,
	                                    String type) throws InterruptedException
	   {
	      String getFieldValue = null;
	      try
	      {
	         if (type.equals("value"))
	         {
	            if (element.getAttribute("value").equals("?"))
	            {
	               Thread.sleep(1500);
	            }
	            getFieldValue = element.getAttribute("value");
	         }
	         else
	         {
	            if (element.getText().equals("?"))
	            {
	               Thread.sleep(1500);
	            }
	            getFieldValue = element.getText().trim();
	         }
	      }
	      catch (NoSuchElementException e)
	      {
	         e.printStackTrace();
	         return 0;
	      }
	      return Double.parseDouble(getFieldValue.replaceAll(",", ""));
	   }
	   

	   /**
	    * validating revise in MAX DOSE alert
	    * 
	    * @param value
	    *           = High Value(i.e.,999999) should pass as parameter.
	    */

	   public String maxReviseforDose(String value) throws InterruptedException
	   {
	      enterValueandCalculate(field_dose, value);
	      Thread.sleep(1000);
	      String[] Range = alert_Maxdose_value.getAttribute("innerHTML")
	            .split("</b>");
	      click_btn(MAXDOSEREVISE);
	      String max_dose_values = Range[1].trim();
	      return max_dose_values;
	   }
	   
	   /**
	    * To enter value into text field and to click calculate to display MAX DOSE
	    * popup.
	    * 
	    * @param locatorName
	    *           = WebElement should pass as parameter.
	    * @param value
	    *           = High Value(i.e.,999999) should pass as parameter.
	    */
	   public void enterValueandCalculate(WebElement locatorName,
	                                      String value) throws InterruptedException
	   {
	      enterValueinFieldandPressTab(locatorName, value);
	      click_btn(OVERRIDE);
	      click_btn(CALCULATE);
	   }
	   
	   /**
	    * Call this method to validate Either buttons are enabled/disabled as per
	    * requirements
	    * @param: buttonName=
	    *            pass BUTTON NAME
	    *            (eg:ChangeDrug,ResetForm,Calculate,Print,DrugMonograph,Comments)
	    * @param: btn_State=
	    *            Pass "Enable" or "Disable" for validating Button state
	    *            according to the requirement
	    * @return true = if the button is enabled
	    * @return false = if the button is disabled
	    */
	   public void isButtonEnabled(String buttonName, String btn_State)
	   {
	      WebElement btnName = null;
	      try
	      {
	         switch (buttonName.toLowerCase())
	         {
	            case "changedrug":
	               btnName = btn_ChangeDrug;
	               break;

	            case "resetform":
	               btnName = btn_Reset;
	               break;

	            case "calculate":
	               btnName = btn_Calculate;
	               break;

	            case "print":
	               btnName = btn_Print;
	               break;

	            case "drugmonograph":
	               btnName = btn_DrugMonograph;
	               break;

	            case "comments":
	               btnName = btn_Comments;
	               break;

	            case "dosevsrate":
	               btnName = btn_DosevsRate;
	               break;
	         }
	         boolean btnstatus;
	         if (btnName.isEnabled())
	            btnstatus = true;
	         else
	            btnstatus = false;
	         if (btn_State.equalsIgnoreCase(ENABLED))
	            Assert.assertTrue(btnstatus, buttonName
					      + " Button is disabled, but it has to be enabled");
	         if (btn_State.equalsIgnoreCase(DISABLED))
	            Assert.assertFalse(btnstatus, buttonName
					      + " Button is enabled, but it has to be disabled");
	      }
	      catch (Exception e)
	      {
	         e.printStackTrace();
	      }
	   }


}

