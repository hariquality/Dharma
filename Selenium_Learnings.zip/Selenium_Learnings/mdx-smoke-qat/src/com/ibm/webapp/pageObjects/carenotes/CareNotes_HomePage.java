package com.ibm.webapp.pageObjects.carenotes;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.utils.Selenese;

public class CareNotes_HomePage extends Selenese {
	WebDriver driver;

	@FindBy(id = "Search.searchText_index_0")
	private WebElement searchInputTextBox;

	@FindBy(xpath = "/html/body/table[1]/tbody/tr[1]/td[1]/table/tbody/tr/td/span[1]")
	private WebElement cnLogo;

	@FindBy(id = "LocationList_index_0")
	private WebElement locationDropdown;

	@FindBy(xpath = "//*[@id='PFFormActionId_carenotes.SetLocation']")
	private WebElement locationGoButton;

	@FindBy(xpath = "//*[@id='menu']/li[2]/a")
	private WebElement hotListLink;

	@FindBy(xpath = "//*[@id='menu']/li[3]/a")
	private WebElement careAndCondLink;

	@FindBy(xpath = "//*[@id='menu']/li[4]/a")
	private WebElement medTitlesLink;

	@FindBy(xpath = "//*[@id='menu']/li[5]/a")
	private WebElement labTitlesLink;

	@FindBy(id = "PFFormActionId_carenotescommon.Search")
	private WebElement searchButton;

	@FindBy(xpath = "//*[contains(text(),'The search ran successfully but no results were found.')]")
	private WebElement unpublishedMessage;

	@FindBy(xpath = "//*[contains(text(),'LOGOUT')]")
	private WebElement logoutLink;

	public CareNotes_HomePage(WebDriver driver) {
		try {
			this.driver = driver;
			PageFactory.initElements(driver, this);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		} catch (Exception e) {

		}
	}

	/**
	 * method to choose location in carenotes search page
	 * 
	 * @param location
	 * @return carenotes search page
	 */
	public CareNotes_HomePage chooseLocation(String location) {

		try {
			selectDropDownByVisibleText(driver, locationDropdown, location);
			click(driver, "click on Go button after selecting location", locationGoButton);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		CareNotes_HomePage page = PageFactory.initElements(driver, CareNotes_HomePage.class);
		return page;
	}

	/**
	 * Use this method to verify if CareNotes Home Page is displayed,
	 * 
	 * @throws IOException
	 */
	public void isHomePageDisplayed() throws IOException {
		try {
			if (driver.getTitle().equalsIgnoreCase("CareNotes : Keyword Search")) {
				extentReport.PASS("CareNotes Home Page Verification", "CareNotes Home Page is displayed correctly");
			} else {
				extentReport.FAIL(driver, "CareNotes Home Page Verification", "CareNotes Home Page is not displayed");
			}
		} catch (Exception e) {
			extentReport.FAIL(driver, "CareNotes Home Page Verification",
					"CareNotes Home Page is not displayed- Some Exception occured");
		}

	}

	/**
	 * method to verify if the unpublished document is displayed
	 * 
	 * @param document
	 * 
	 */
	public void searchUnpublished(String searchTerm) throws IOException {
		sendKeys(driver, "search input Text", searchInputTextBox, searchTerm);
		click(driver, "click search", searchButton);
		verifyunPublishMessage("The search ran successfully but no results were found.");
	}

	/**
	 * verify message appearing for successful savenotes publish
	 * 
	 * @param message
	 * @throws IOException 
	 */
	public void verifyunPublishMessage(String message) throws IOException {
		
		if (unpublishedMessage.getText().contains(message)) {
			extentReport.PASS("unpublishedMessage verification",
					"unpublishedMessage is displayed correclty in Carenotes");
			logINFO("unpublishedMessage is displayed correclty in Carenotes");
		} else {
			extentReport.FAIL(driver, "unpublishedMessage verification",
					"unpublishedMessage is displayed incorreclty in Carenotes");
			logERROR("unpublishedMessage is displayed incorreclty in Carenotes");
		}
	}

	/**
	 * Enter a search term and search for the savenotes created in carenotes
	 * admin admin
	 * 
	 * @param searchTerm
	 * @return
	 * @throws IOException
	 */
	public CareNotes_SelectDocumentsPage search(String searchTerm) throws IOException {
		sendKeys(driver, "search input Text", searchInputTextBox, searchTerm);
		click(driver, "click search", searchButton);
		CareNotes_SelectDocumentsPage page = PageFactory.initElements(driver, CareNotes_SelectDocumentsPage.class);

		try {
			if (page != null) {
				extentReport.PASS("Create save notes and verify in Carenotes",
						"Save Note created in Carenotes Admin is displayed in Carenotes");
				logINFO("Save Note created in Carenotes Admin is displayed in Carenotes");
			} else {
				extentReport.FAIL(driver, "Create save notes and verify in Carenotes",
						"Save Note created in Carenotes Admin is not displayed in Carenotes");
				logERROR("Save Note created in Carenotes Admin is displayed in Carenotes");
			}
		} catch (Exception e) {
			extentReport.FAIL(driver, "Create save notes and verify in Carenotes",
					"Save Note created in Carenotes Admin is not displayed in Carenotes - Some Exception occured");
			logERROR("Carenotes Admin Home Page is not displayed- Some Exception occured");
		}

		return page;
	}

	/**
	 * Use this method to log out of the application,
	 * 
	 * @throws IOException
	 */
	public void LogOut() throws IOException {
		click(driver, "Log out", logoutLink);
	}

	/**
	 * method to choose Hotlist in carenotes search page
	 * 
	 * @return HotListPage
	 */
	public CareNotes_HotlistPage clickHotListLink() {
		try {
			click(driver, "click on hotlist link", hotListLink);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		CareNotes_HotlistPage page = PageFactory.initElements(driver, CareNotes_HotlistPage.class);
		return page;
	}

	/**
	 * method to choose Care and Condition title
	 * 
	 * @return Care and Condition Title page
	 */
	public CareNotes_CareAndConditionTitlesPage clickCareAndConditionTitlesLink() {
		try {
			click(driver, "click on care and conditions link", careAndCondLink);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		CareNotes_CareAndConditionTitlesPage page = PageFactory.initElements(driver,
				CareNotes_CareAndConditionTitlesPage.class);
		return page;
	}

	/**
	 * method to choose Medication title
	 * 
	 * @return Medication Title page
	 */
	public CareNotes_MedicationTitlesPage clickMedicationTitlesLink() {
		try {
			click(driver, "click on medication titles link", medTitlesLink);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		CareNotes_MedicationTitlesPage page = PageFactory.initElements(driver, CareNotes_MedicationTitlesPage.class);
		return page;
	}

	/**
	 * method to choose a LabTitle
	 * 
	 * @return Lab Title page
	 */
	public CareNotes_LabTitlesPage clickLabTitlesLink() {
		try {
			click(driver, "click on lab titles link", labTitlesLink);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		CareNotes_LabTitlesPage page = PageFactory.initElements(driver, CareNotes_LabTitlesPage.class);
		return page;
	}

}
