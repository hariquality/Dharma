package com.ibm.webapp.pageObjects.carenotesadmin;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.ibm.webapp.utils.Selenese;

public class CareNotesAdmin_PublishUnpublishDocPage extends Selenese {
	protected final WebDriver driver;

	@FindBy(xpath = "//*[contains(text(),'Matching Titles: Publish or Unpublish Documents')]")
	private WebElement pageTitle;

	@FindBy(xpath = "//a[contains(text(),'Check All')]")
	private WebElement checkAll;

	@FindBy(xpath = "//a[contains(text(),'Uncheck All')]")
	private WebElement unCheckAll;

	@FindBy(xpath = "//strong[text()='Selected Documents were unpublished from this Location successfully.']")
	private WebElement unPublishMessage;

	@FindBy(xpath = "//img[@title='My MICROMEDEX Gateway']")
	private WebElement micromedexTitle;

	@FindBy(xpath = "//*[@id='PFFormActionId_carenotesadmin.PublishDocumentsToLocation']")
	private WebElement saveChanges;

	public CareNotesAdmin_PublishUnpublishDocPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		wait.until(ExpectedConditions.visibilityOf(pageTitle));
	}

	public void clickdocumentLink(String docname) {

		String docuxpath = "//a[contains(text()," + "'" + docname + "'" + ")]";
		WebElement doclink = driver.findElement(By.xpath(docuxpath));
		doclink.click();
	}

	/**
	 * click on save changes in save notes doc searched page
	 */
	public void clickSaveChanges() {
		saveChanges.click();
	}

	/**
	 * unselects language from savenotes selection page
	 */
	public void unselectAllCheckbx() {
		if (driver.findElement(By.xpath("(//td/input[@type='checkbox'])[1]")).isSelected()) {
			unCheckAll.click();

		} else {
			checkAll.click();
			saveChanges.click();
			unCheckAll.click();
		}
	}

	/**
	 * click on My Micromedex Gateway
	 */
	public void clickmicromedexTitle() {
		// micromedexTitle.click();
		try {
			click(driver, "My MICROMEDEX Gateway", micromedexTitle);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * verify message appearing for successful savenotes publish
	 * 
	 * @param message
	 */
	public void verifyunPublishMessage(String message) {
		Assert.assertTrue((unPublishMessage.getText().contains(message)));
	}

}
