package com.ibm.webapp.pageObjects.carenotes;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class CareNotes_CareAndConditionTitlesPage extends Selenese {
	protected final WebDriver driver;

	@FindBy(xpath = "//strong[contains(text(),'Care and Condition Titles')]")
	private WebElement hotlistCaption;

	@FindBy(xpath = "/html/body/table/tbody/tr[3]/td/table[2]/tbody/tr/td/table[2]/tbody/tr/td[1]/a[2]")
	private WebElement firstCareCondTitle;

	public CareNotes_CareAndConditionTitlesPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		wait.until(ExpectedConditions.visibilityOf(hotlistCaption));
	}

	/**
	 * click on first care and condition title in carenotes
	 */
	public void clickFirstCareCondTitle() {
		// firstCareCondTitle.click();
		try {
			click(driver, "click first care and condition title", firstCareCondTitle);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public CareNotes_HeaderPage getHeaderPage() {
		CareNotes_HeaderPage headerPage = PageFactory.initElements(driver, CareNotes_HeaderPage.class);
		return headerPage;
	}
}
