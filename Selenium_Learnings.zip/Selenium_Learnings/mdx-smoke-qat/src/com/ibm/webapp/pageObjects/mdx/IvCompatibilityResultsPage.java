package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class IvCompatibilityResultsPage extends Selenese {
	public WebDriver driver;

	@FindBy(id = "ivResultRight")
	private WebElement ivResultRightPane;

	@FindBy(xpath = "//a[text()='Drug-Drug: Y-Site']")
	private WebElement drugDrugYsiteHeading;

	@FindBy(xpath = "(//table[@id='ivResultList']//a)[1]")
	private WebElement ySiteResultsPage;

	@FindBy(xpath = "//div[contains(@class,'dijitDialog')]//div[@title='IV Compatibility Detail']//following-sibling::div//input[@title='Close']")
	private WebElement resultPageClose;

	@FindBy(xpath = "//input[@title='Close']")
	private List<WebElement> resultPagePopUpClose;

	@FindBy(xpath = "//a[@title='IV Drug-Drug: Admixture tab.']")
	private WebElement drugAdmixure;

	@FindBy(xpath = "(//table[@id='ivResultList']//a)[1]")
	private WebElement admixureResultsPage;

	@FindBy(xpath = "//a[@title='IV Drug-Drug: Syringe tab.']")
	private WebElement drugSyringe;

	@FindBy(xpath = "(//table[@id='ivResultList']//a)[1]")
	private WebElement syringeResultsPage;

	@FindBy(xpath = "//a[@title='IV Y-Site tab.']")
	private WebElement ysiteTab;

	@FindBy(xpath = "//a[contains(text(),'Drug-Solution')]")
	private WebElement drugSolutionTab;

	@FindBy(xpath = "//a[@title='IV Admixture tab.']")
	private WebElement admixtureTab;

	@FindBy(xpath = "//a[@title='IV Syringe tab.']")
	private WebElement syringeTab;

	@FindBy(xpath = "//a[text()='TPN/TNA']")
	private WebElement tpnTnaTab;

	@FindBy(xpath = "(//table[@id='ivResultList']//a)[1]")
	private WebElement tpnTnaResultPage;

	@FindBy(xpath = "//a[@title='IV Drug-Solution tab.']")
	private WebElement drugSolutionTitle;

	@FindBy(xpath = "//div[text()='Matching Solution(s) Results ']")
	private WebElement drugSolutionMatchingSolutionSubTitle;

	@FindBy(xpath = "(//div[@class='linkDetails']/a)[1]")
	private WebElement drugSolutionMatchingSolutionListElement;

	@FindBy(xpath = "//div[text()='Relevant Common Solution(s) Results ']")
	private WebElement drugSolutionRelevantSolutionSubTitle;

	@FindBy(xpath = "(//div[@class='linkDetails']/a)[7]")
	private WebElement drugSolutionRelevantSolutionListElement;

	@FindBy(xpath = "//div[text()='Other Solution(s) Results ']")
	private WebElement drugSolutionOtherSolutionSubTitle;

	@FindBy(xpath = "(//div[@class='linkDetails']/a)[12]")
	private WebElement drugSolutionOtherSolutionListElement;

	@FindBy(xpath = "(//div[text()='Drugs'])[1]")
	private WebElement preparationAndStorageForDrugsTitle;

	@FindBy(xpath = "(//table//tbody)[5]//td//a")
	private List<WebElement> preparationAndStorageForDrugs;

	@FindBy(xpath = "//div[text()='Solutions']")
	private WebElement preparationAndStorageForSolutionTitle;

	@FindBy(xpath = "(//table//tbody)[6]//td//a")
	private List<WebElement> preparationAndStorageForSolutions;

	/* DrugFilters */
	@FindBy(xpath = "(//a[text()='Uncheck all'])[1]")
	private WebElement drugFiltersUncheckAll;

	@FindBy(xpath = "(//a[text()='Check all'])[1]")
	private WebElement drugFiltersCheckAll;

	@FindBy(id = "refSubmit1")
	private WebElement updateAllDrugFilters;

	/* Compat Filters */

	@FindBy(id = "lnkCompOpts")
	private WebElement compatDropDown;

	@FindBy(xpath = "(//a[text()='Uncheck all'])[2]")
	private WebElement compatFiltersUncheckAll;

	@FindBy(id = "btnSubmit1")
	private WebElement updateAllCompatFilters;

	@FindBy(xpath = "//input[@value='Compatible']")
	private WebElement checkCompatibility;

	@FindBy(xpath = "//input[@value='Caution:Variable']")
	private WebElement checkCautionVariable;

	@FindBy(xpath = "//input[@value='Incompatible']")
	private WebElement checkIncompatible;

	@FindBy(xpath = "//input[@value='Uncertain']")
	private WebElement checkUncertain;

	@FindBy(xpath = "//input[@value='Not Tested']")
	private WebElement checkNotTested;

	@FindBy(xpath = "//button[@class='submitBtn']")
	private WebElement modifySelections;

	@FindBy(xpath = "//div[@class='agentHeading leftPadding5']/span")
	private WebElement ivCompatabilitySingleDrugName1;

	@FindBy(xpath = "//*[@id='ivResultLeftTop']/table/tbody/tr/td/a/label")
	private WebElement ivCompatabilitySingleDrugName;

	@FindBy(xpath = "//div[@class='pageTitle inline']")
	private WebElement ivCompatabilitySingleDrugPageTitle;

	@FindBy(xpath = "//div[@id='refineMultiInteractions']//div[@class='pageTitle inline']")
	private WebElement IVCompatibilityPageTitle;

	@FindBy(xpath = "//div[@id='ivResultLeft']/span")
	private WebElement IVCompatibilityDrugsTitle;

	@FindBy(xpath = "//div[@id = 'drugOpts']//table/tbody/tr/td/label")
	private List<WebElement> IVCompatibilityMultipleDrugsNames;

	public IvCompatibilityResultsPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		wait.until(ExpectedConditions.visibilityOf(ivResultRightPane));
	}

	/**
	 * Call this method to get Drug solution tab details
	 * 
	 * @return ivResultpage = To return the result page of IV Compatibility for
	 *         Drug Solution Tab
	 */

	public IvCompatibilityResultsPage clickDrugsolutionTab() {
		drugSolutionTab.click();
		IvCompatibilityResultsPage ivResultpage = PageFactory.initElements(driver, IvCompatibilityResultsPage.class);
		return ivResultpage;
	}

	/**
	 * Call this method to verify the label of drug-solution tab
	 * 
	 * @param expected
	 *            = label of drug-solution tab is passed in this field
	 * @return true = If both label of drug-solution tab and Expected value IV
	 *         Compatibility result are equal
	 * @return false = If both label of drug-solution tab and Expected IV
	 *         Compatibility result are not equal
	 * @throws IOException
	 */

	public boolean isDrugSolutionTextEqualTo(String expected) throws IOException {
		try {
			drugSolutionTitle.click();
			if (drugSolutionTitle.getText().equals(expected)) {
				extentReport.PASS("IV result Page Verification isDrugSolutionTextEqualTo",
						"isDrugSolutionTextEqualTo is working correctly");
				log.info("Verified isDrugSolutionTextEqualTo");
				return true;
			}
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVResultPage", "isDrugSolutionTextEqualTo method failed");
			logERROR("isDrugSolutionTextEqualTo method failed");

		}
		return false;
	}

	/**
	 * Call this method to verify the label of Y-Site tab
	 * 
	 * @param expected
	 *            = label of Y-Site tab is passed in this field
	 * @return true = If both label of Y-Site tab and Expected value IV
	 *         Compatibility result are equal
	 * @return false = If both label of Y-Site tab and Expected IV Compatibility
	 *         result are not equal
	 * @throws IOException
	 */

	public boolean isDrugYsiteTextEqualTo(String expected) throws IOException {
		try {
			if (drugDrugYsiteHeading.getText().equals(expected)) {
				extentReport.PASS("IV Comp result Page Verification isDrugYsiteTextEqualTo",
						"isDrugYsiteTextEqualTo is working correctly");
				log.info("Verified viewcompbutton");
				return true;
			}
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompResult page", "isDrugYsiteTextEqualTo method failed");
			logERROR("isDrugYsiteTextEqualTo method failed");
		}
		return false;
	}

	/**
	 * Call this method to click Drug-Ysite Tab
	 * 
	 * @throws IOException
	 * 
	 * @ySiteResultsPage = To view the result page of Drug-Ysite tab
	 * @resultPageClose = To close the result page of Drug-Ysite tab
	 */

	public void clickDrugYsiteTab() throws IOException {
		try {
			ySiteResultsPage.click();
			Thread.sleep(2000);
			resultPageClose.click();
			extentReport.PASS("IV Comp result Page Verification clickDrugYsiteTab",
					"clickDrugYsiteTab is working correctly");
			log.info("Verified clickDrugYsiteTab");
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompResult page", "clickDrugYsiteTab method failed");
			logERROR("clickDrugYsiteTab method failed");
		}
	}

	/**
	 * Call this method to View details popup close functionality
	 */
	private void viewDetailPopUpCloseHandle() {
		Iterator<WebElement> i = resultPagePopUpClose.iterator();
		while (i.hasNext()) {
			WebElement e = i.next();
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", e);

		}

	}

	/**
	 * Call this method to click Drug-Admixture Tab
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * 
	 * @drugAdmixure = To click the Drug-Admixture Tab
	 * @admixureResultsPage = To view the result page of Drug-Admixture tab
	 * @resultPageClose = To close the result page of Drug-Admixture tab
	 */
	public void clickDrugAdmixureTab() throws InterruptedException, IOException {
		try {
			drugAdmixure.click();
			admixureResultsPage.click();
			Thread.sleep(2000);
			resultPageClose.click();
			extentReport.PASS("IV Comp result Page Verification clickDrugAdmixureTab",
					"clickDrugAdmixureTab is working correctly");
			log.info("Verified clickDrugAdmixureTab");
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompResult page", "clickDrugAdmixureTab method failed");
			logERROR("clickDrugAdmixureTab method failed");
		}
	}

	/**
	 * Call this method to verify DrugAdmixture Text is Equal to the expected
	 * value
	 * 
	 * @param expected
	 *            = The expected value of the drug mixture
	 * @param Heading
	 *            = The drug mixture heading should be passed
	 * @return true = when Drug mixture Text is equal to the Expected value of
	 *         the drug
	 * @return false = when Drug mixture Text is not equal to the Expected value
	 *         of the drug
	 * @throws IOException
	 */

	public boolean isDrugAdmixtureTextEqualTo(String expected) throws IOException {
		try {
			drugAdmixure.click();
			if (drugAdmixure.getText().equals(expected)) {
				extentReport.PASS("IV Comp result Page Verification isDrugAdmixtureTextEqualTo",
						"isDrugAdmixtureTextEqualTo is working correctly");
				log.info("Verified viewcompbutton");
				return true;
			}
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompResult page", "isDrugAdmixtureTextEqualTo method failed");
			logERROR("isDrugAdmixtureTextEqualTo method failed");
		}
		return false;
	}

	/**
	 * Call this method to click YSite Tab
	 * 
	 * @throws IOException
	 * 
	 * @drugSyringe = To click the Drug Syringe Tab
	 * @syringeResultsPage = To view the result page of YSite tab
	 * @resultPageClose = To close the result page of YSite tab
	 */
	public void clickDrugSyringeTab() throws IOException {
		try {
			drugSyringe.click();
			syringeResultsPage.click();
			Thread.sleep(2000);
			resultPageClose.click();
			extentReport.PASS("IV Comp result Page Verification clickDrugSyringeTab",
					"clickDrugSyringeTab is working correctly");
			log.info("Verified clickDrugSyringeTab");
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompResult page", "clickDrugSyringeTab method failed");
			logERROR("clickDrugSyringeTab method failed");
		}
	}

	/**
	 * Call this method to verify Drug-Syringe Text is Equal to the expected
	 * value
	 * 
	 * @param expected
	 *            = The expected value of the drug Syringe
	 * @param Heading
	 *            = The drug Syringe heading should be passed
	 * @return true = when Drug mixture Text is equal to the Expected value of
	 *         the drug
	 * @return false = when Drug mixture Text is not equal to the Expected value
	 *         of the drug
	 * @throws IOException
	 */

	public boolean isDrugSyringeTextEqualTo(String expected) throws IOException {
		try {
			drugSyringe.click();
			if (drugSyringe.getText().equals(expected)) {
				extentReport.PASS("IV Comp result Page Verification isDrugSyringeTextEqualTo",
						"isDrugSyringeTextEqualTo is working correctly");
				log.info("Verified isDrugSyringeTextEqualTo");
				return true;
			}
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompResult page", "isDrugSyringeTextEqualTo method failed");
			logERROR("isDrugSyringeTextEqualTo method failed");
		}
		return false;
	}

	/**
	 * Call this method to click YSite Tab
	 * 
	 * @throws IOException
	 * 
	 * @ySiteResultsPage = To view the result page of YSite tab
	 * @resultPageClose = To close the result page of YSite tab
	 */
	public void clickYsiteTab() throws InterruptedException, IOException {
		try {
			ySiteResultsPage.click();
			Thread.sleep(2000);
			resultPageClose.click();
			extentReport.PASS("IV result Page Verification clickYsiteTab", "clickYsiteTab is working correctly");
			log.info("Verified clickYsiteTab");
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVResultPage", "clickYsiteTab method failed");
			logERROR("clickYsiteTab method failed");

		}
	}

	/**
	 * Call this method to verify YSite Text is Equal to the expected value
	 * 
	 * @param expected
	 *            = The expected value of the drug Syringe
	 * @param Heading
	 *            = The drug Syringe heading should be passed
	 * @return true = when Drug mixture Text is equal to the Expected value of
	 *         the drug
	 * @return false = when Drug mixture Text is not equal to the Expected value
	 *         of the drug
	 * @throws IOException
	 */

	public boolean isYsiteTextEqualTo(String expected) throws IOException {
		try {
			ysiteTab.click();
			if (ysiteTab.getText().equals(expected)) {
				extentReport.PASS("IV result Page Verification isYsiteTextEqualTo",
						"isYsiteTextEqualTo is working correctly");
				log.info("Verified isYsiteTextEqualTo");
				return true;
			}
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVResultPage", "isYsiteTextEqualTo method failed");
			logERROR("isYsiteTextEqualTo method failed");
		}
		return false;
	}

	/**
	 * Call this method to click Admixture Tab
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * 
	 * @admixureResultsPage = To view the result page of Admixture tab
	 * @resultPageClose = To close the result page of Admixture tab
	 */
	public void clickAdmixtureTab() throws InterruptedException, IOException {
		try {
			admixureResultsPage.click();
			Thread.sleep(2000);
			;
			resultPageClose.click();
			extentReport.PASS("IV Comp result Page Verification clickAdmixtureTab",
					"clickAdmixtureTab is working correctly");
			log.info("Verified clickAdmixtureTab");
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompResult page", "clickAdmixtureTab method failed");
			logERROR("clickAdmixtureTab method failed");
		}
	}

	/**
	 * Call this method to verify Admixture Text is Equal to the expected value
	 * 
	 * @param expected
	 *            = The expected value of the drug Admixture
	 * @param Heading
	 *            = The drug Syringe heading should be passed
	 * @return true = when Drug Admixture Text is equal to the Expected value of
	 *         the drug Admixture
	 * @return false = when Drug Admixture Text is not equal to the Expected
	 *         value of the drug Admixture
	 * @throws IOException
	 */

	public boolean isAdmixtureTextEqualTo(String expected) throws IOException {
		try {
			admixtureTab.click();
			if (admixtureTab.getText().equals(expected)) {
				extentReport.PASS("IV Comp result Page Verification isAdmixtureTextEqualTo",
						"isAdmixtureTextEqualTo is working correctly");
				log.info("Verified isAdmixtureTextEqualTo");
				return true;
			}
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompResult page", "isAdmixtureTextEqualTo method failed");
			logERROR("isAdmixtureTextEqualTo method failed");
		}
		return false;
	}

	/**
	 * Call this method to click Admixture Tab
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * 
	 * @syringeResultsPage = To view the result page of Syringe tab
	 * @resultPageClose = To close the result page of Syringe tab
	 */

	public void clickSyringeTab() throws InterruptedException, IOException {
		try {
			syringeResultsPage.click();
			Thread.sleep(2000);
			resultPageClose.click();
			extentReport.PASS("IV Comp result Page Verification clickSyringeTab",
					"clickSyringeTab is working correctly");
			log.info("Verified clickSyringeTab");
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompResult page", "clickSyringeTab method failed");
			logERROR("clickSyringeTab method failed");
		}
	}

	/**
	 * Call this method to verify Syringe Text is Equal to the expected value
	 * 
	 * @param expected
	 *            = The expected value of the Syringe
	 * @param Heading
	 *            = The Syringe heading should be passed
	 * @return true = when Syringe Text is equal to the Expected value of the
	 *         Syringe
	 * @return false = when Syringe Text is not equal to the Expected value of
	 *         the Syringe
	 * @throws IOException
	 */
	public boolean isSyringeTextEqualTo(String expected) throws IOException {
		try {
			syringeTab.click();
			if (syringeTab.getText().equals(expected)) {
				extentReport.PASS("IV Comp result Page Verification isSyringeTextEqualTo",
						"isSyringeTextEqualTo is working correctly");
				log.info("Verified isSyringeTextEqualTo");
				return true;
			}
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompResult page", "isSyringeTextEqualTo method failed");
			logERROR("isSyringeTextEqualTo method failed");
		}
		return false;
	}

	/**
	 * Call this method to click TPN/TNA Tab
	 * 
	 * @throws IOException
	 * 
	 * @tpnTnaResultPage = To view the result page of TPN/TNA tab
	 * @resultPageClose = To close the result page of TPN/TNA tab
	 */

	public void clickTpnTnaTab() throws IOException {
		try {
			tpnTnaResultPage.click();
			Thread.sleep(2000);
			resultPageClose.click();
			extentReport.PASS("IV Comp result Page Verification clickTpnTnaTab", "clickTpnTnaTab is working correctly");
			log.info("Verified clickTpnTnaTab");
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompResult page", "clickTpnTnaTab method failed");
			logERROR("clickTpnTnaTab method failed");
		}

	}

	/**
	 * Call this method to verify TPN/TNA Text is Equal to the expected value
	 * 
	 * @param expected
	 *            = The expected value of the Syringe
	 * @param Heading
	 *            = The TPN/TNA heading should be passed
	 * @return true = when TPN/TNA Text is equal to the Expected value of the
	 *         TPN/TNA
	 * @return false = when TPN/TNA Text is not equal to the Expected value of
	 *         the TPN/TNA
	 * @throws IOException
	 */
	public boolean isTpnTnaTextEqualTo(String expected) throws IOException {
		try {
			tpnTnaTab.click();
			if (tpnTnaTab.getText().equals(expected)) {
				extentReport.PASS("IV Comp result Page Verification isTpnTnaTextEqualTo",
						"isTpnTnaTextEqualTo is working correctly");
				log.info("Verified isTpnTnaTextEqualTo");
				return true;
			}
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompResult page", "isTpnTnaTextEqualTo method failed");
			logERROR("isTpnTnaTextEqualTo method failed");
		}
		return false;
	}

	/**
	 * Call this method to verify the Matching Solution title text is Equal to
	 * the expected value
	 * 
	 * @param expected
	 *            = The expected value of the Matching Solution title
	 * @param Heading
	 *            = The Matching Solution title heading should be passed
	 * @return true = when Matching Solution title Text is equal to the Expected
	 *         value of the Matching Solution title
	 * @return false = when Matching Solution title Text is not equal to the
	 *         Expected value of the Matching Solution title
	 */
	private boolean isMatchingSolutionSubTitlePresent(String exepectedTitle) {
		if (drugSolutionMatchingSolutionSubTitle.getText().equals(exepectedTitle)) {
			return true;
		}
		return false;
	}

	/**
	 * Call this method to verify the DrugSolution text under the Matching
	 * solution is Equal to the expected value
	 * 
	 * @drugSolutionMatchingSolutionListElement = To click first link in
	 *                                          matching solution
	 * @resultPageClose = To close the result page of Drug Solution tab
	 */

	public void matchingSolutionLinkInDrugSolutionTab() {
		if (isMatchingSolutionSubTitlePresent("Matching Solution(s) Results (View Compatibility Details)")) {
			try {
				drugSolutionMatchingSolutionListElement.click();
				Thread.sleep(1000);
				resultPageClose.click();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Call this method to verify the Relevant Solution title text is Equal to
	 * the expected title value
	 * 
	 * @param expected
	 *            = The expected value of the Relevant Solution title
	 * @param Heading
	 *            = The Relevant Solution title heading should be passed
	 * @return true = when Relevant Solution title Text is equal to the Expected
	 *         value of the Relevant Solution title
	 * @return false = when Relevant Solution title Text is not equal to the
	 *         Expected value of the Relevant Solution title
	 */

	private boolean isRelevantSolutionSubTitlePresent(String exepectedTitle) {
		if (drugSolutionRelevantSolutionSubTitle.getText().equals(exepectedTitle)) {
			return true;
		}
		return false;
	}

	/**
	 * Call this method to verify the DrugSolution text under the relevant
	 * solution is Equal to the expected value
	 * 
	 * @drugSolutionRelevantSolutionListElement = To click first link in
	 *                                          relevant
	 *                                          solution @viewDetailPopUpCloseHandle()
	 *                                          = To close the result page of
	 *                                          Drug Solution tab
	 */
	public void relevantSolutionLinkInDrugSolutionTab() throws InterruptedException {
		Thread.sleep(2000);
		if (isRelevantSolutionSubTitlePresent("Relevant Common Solution(s) Results (View Compatibility Details)")) {
			scrollDown();
			drugSolutionRelevantSolutionListElement.click();
			Thread.sleep(1000);
			viewDetailPopUpCloseHandle();
		}
	}

	/**
	 * Call this method to verify the Other Solution title text is Equal to the
	 * expected title value
	 * 
	 * @param expected
	 *            = The expected value of the Other Solution title
	 * @param Heading
	 *            = The Other Solution title heading should be passed
	 * @return true = when Other Solution title Text is equal to the Expected
	 *         value of the Other Solution title
	 * @return false = when Other Solution title Text is not equal to the
	 *         Expected value of the Other Solution title
	 */
	private boolean isOtherSolutionSubTitlePresent(String exepectedTitle) {
		if (drugSolutionOtherSolutionSubTitle.getText().equals(exepectedTitle)) {
			return true;
		}
		return false;
	}

	/**
	 * Call this method to verify the DrugSolution text under the relevant
	 * solution is Equal to the expected value
	 * 
	 * @drugSolutionOtherSolutionListElement = To click first link in relevant
	 *                                       solution @viewDetailPopUpCloseHandle()
	 *                                       = To close the result page of Drug
	 *                                       Solution tab
	 */

	public void otherSolutionLinkInDrugSolutionTab() throws InterruptedException {
		Thread.sleep(2000);
		if (isOtherSolutionSubTitlePresent("Other Solution(s) Results (View Compatibility Details)")) {

			scrollDown();
			drugSolutionOtherSolutionListElement.click();
			Thread.sleep(1000);
			viewDetailPopUpCloseHandle();
		}
	}

	/**
	 * Call this method to verify the Solution link to check in Drug Solution
	 * tab
	 * 
	 * @matchingSolutionLinkInDrugSolutionTab = Functionality of Matching
	 *                                        solution link in Drug solution
	 *                                        tab @relevantSolutionLinkInDrugSolutionTab=
	 *                                        Functionality of relevant solution
	 *                                        link in Drug solution tab
	 */
	public void solutionLinkCheckinDrugSolutionTab() throws Exception {
		try {
			matchingSolutionLinkInDrugSolutionTab();
			relevantSolutionLinkInDrugSolutionTab();
			extentReport.PASS("IV Comp result Page Verification solutionLinkCheckinDrugSolutionTab",
					"solutionLinkCheckinDrugSolutionTab is working correctly");
			log.info("Verified solutionLinkCheckinDrugSolutionTab");
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompResult page", "solutionLinkCheckinDrugSolutionTab method failed");
			logERROR("solutionLinkCheckinDrugSolutionTab method failed");
		}
	}

	/**
	 * Call this method to verify the Solution link to check in Drug Solution
	 * tab for single drug & solution
	 * 
	 * @matchingSolutionLinkInDrugSolutionTab = Functionality of Matching
	 *                                        solution link in Drug solution
	 *                                        tab @relevantSolutionLinkInDrugSolutionTab=
	 *                                        Functionality of relevant solution
	 *                                        link in Drug solution tab
	 * @otherSolutionLinkInDrugSolutionTab = Functionality of other solution
	 *                                     link in Drug solution tab
	 */
	public void solutionLinkinDrugSolutionTabForSingleDrugSolution() throws Exception {
		try {
			matchingSolutionLinkInDrugSolutionTab();
			relevantSolutionLinkInDrugSolutionTab();
			otherSolutionLinkInDrugSolutionTab();
			extentReport.PASS("IV result Page Verification solutionLinkinDrugSolutionTabForSingleDrugSolution",
					"solutionLinkinDrugSolutionTabForSingleDrugSolution is working correctly");
			log.info("Verified solutionLinkinDrugSolutionTabForSingleDrugSolution");
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVResultPage",
					"solutionLinkinDrugSolutionTabForSingleDrugSolution method failed");
			logERROR("solutionLinkinDrugSolutionTabForSingleDrugSolution method failed");

		}
	}

	/**
	 * Call this method for Scroll down
	 */
	public void scrollDown() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("scroll(0,250)");
	}

	/**
	 * Call this method to verify Multiple Drug Filters
	 * 
	 * @throws IOException
	 * 
	 * @drugFiltersUncheckAll = To click un check All checkbox
	 * @drugFiltersCheckAll = to click Check All checkbox @updateAllDrugFilters=
	 *                      To click Update All button
	 **/
	public IvCompatibilityResultsPage multipleDrugFilters() throws InterruptedException, IOException {
		try {
			drugFiltersUncheckAll.click();
			drugFiltersCheckAll.click();
			Thread.sleep(2000);
			updateAllDrugFilters.click();
			extentReport.PASS("IV Comp result Page Verification multipleDrugFilters",
					"multipleDrugFilters is working correctly");
			log.info("Verified multipleDrugFilters");
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompResult page", "multipleDrugFilters method failed");
			logERROR("multipleDrugFilters method failed");
		}
		IvCompatibilityResultsPage ivResultpage = PageFactory.initElements(driver, IvCompatibilityResultsPage.class);
		return ivResultpage;
	}

	/**
	 * Call this method to verify Multiple Compatibility Filters
	 * 
	 * @throws IOException
	 **/
	public IvCompatibilityResultsPage multipleCompatFilters() throws InterruptedException, IOException {
		try {
			compatDropDown.click();
			compatFiltersUncheckAll.click();
			checkCompatibility.click();
			Thread.sleep(2000);
			updateAllCompatFilters.click();
			extentReport.PASS("IV Comp result Page Verification multipleCompatFilters",
					"multipleCompatFilters is working correctly");
			log.info("Verified multipleCompatFilters");
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompResult page", "multipleCompatFilters method failed");
			logERROR("multipleCompatFilters method failed");
		}
		IvCompatibilityResultsPage ivResultpage = PageFactory.initElements(driver, IvCompatibilityResultsPage.class);
		return ivResultpage;
	}

	/**
	 * Call this method to verify Multiple Caution:Variable Filters
	 * 
	 * @throws IOException
	 **/
	public IvCompatibilityResultsPage multipleCautionVariableFilters() throws InterruptedException, IOException {
		try {
			compatDropDown.click();
			compatFiltersUncheckAll.click();
			checkCautionVariable.click();
			Thread.sleep(2000);
			updateAllCompatFilters.click();
			extentReport.PASS("IV Comp result Page Verification multipleCautionVariableFilters",
					"multipleCautionVariableFilters is working correctly");
			log.info("Verified multipleCautionVariableFilters");
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompResult page", "multipleCautionVariableFilters method failed");
			logERROR("multipleCautionVariableFilters method failed");
		}
		IvCompatibilityResultsPage ivResultpage = PageFactory.initElements(driver, IvCompatibilityResultsPage.class);
		return ivResultpage;
	}

	/**
	 * Call this method to verify Multiple Incompatible Filters
	 * 
	 * @throws IOException
	 **/
	public IvCompatibilityResultsPage multipleIncompatibleFilters() throws InterruptedException, IOException {
		try {
			compatDropDown.click();
			compatFiltersUncheckAll.click();
			checkIncompatible.click();
			Thread.sleep(2000);
			updateAllCompatFilters.click();
			extentReport.PASS("IV Comp result Page Verification multipleIncompatibleFilters",
					"multipleIncompatibleFilters is working correctly");
			log.info("Verified multipleIncompatibleFilters");
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompResult page", "multipleIncompatibleFilters method failed");
			logERROR("multipleIncompatibleFilters method failed");
		}
		IvCompatibilityResultsPage ivResultpage = PageFactory.initElements(driver, IvCompatibilityResultsPage.class);
		return ivResultpage;
	}

	/**
	 * Call this method to verify Multiple Uncertain Filters
	 * 
	 * @throws IOException
	 **/
	public IvCompatibilityResultsPage multipleUncertainFilters() throws InterruptedException, IOException {
		try {
			compatDropDown.click();
			compatFiltersUncheckAll.click();
			checkUncertain.click();
			Thread.sleep(2000);
			updateAllCompatFilters.click();
			extentReport.PASS("IV Comp result Page Verification multipleUncertainFilters",
					"multipleUncertainFilters is working correctly");
			log.info("Verified multipleUncertainFilters");
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompResult page", "multipleUncertainFilters method failed");
			logERROR("multipleUncertainFilters method failed");
		}
		IvCompatibilityResultsPage ivResultpage = PageFactory.initElements(driver, IvCompatibilityResultsPage.class);
		return ivResultpage;
	}

	/**
	 * Call this method to verify Multiple Not tested Filters
	 * 
	 * @throws IOException
	 **/
	public IvCompatibilityResultsPage multipleNotTestedFilters() throws InterruptedException, IOException {
		try {
			compatDropDown.click();
			compatFiltersUncheckAll.click();
			checkNotTested.click();
			Thread.sleep(2000);
			updateAllCompatFilters.click();
			extentReport.PASS("IV Comp result Page Verification multipleNotTestedFilters",
					"multipleNotTestedFilters is working correctly");
			log.info("Verified multipleNotTestedFilters");
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompResult page", "multipleNotTestedFilters method failed");
			logERROR("multipleNotTestedFilters method failed");
		}
		IvCompatibilityResultsPage ivResultpage = PageFactory.initElements(driver, IvCompatibilityResultsPage.class);
		return ivResultpage;
	}

	public String verifySingleIVCompatibilityName(String labelText) {
		String result = "PASS";
		String[] drugName = labelText.split("Here is iv compatibility for ");
		String drugNameFromTestData = drugName[1].replace(":", "").replace(" ", "").replace("\"", "").toLowerCase();
		String drugNameInIVPage = ivCompatabilitySingleDrugName.getText().replace(" ", "").toLowerCase();
		if (!("IV Compatibility Results".equals(ivCompatabilitySingleDrugPageTitle.getText())
				&& drugNameFromTestData.equals(drugNameInIVPage.toLowerCase()))) {
			result = "FAIL";
		}
		return result;
	}

	public boolean verifyDrugNamesInIVCompatibilityResultsPage(String drugUsedForSearch, String labelText) {
		boolean result = true;

		String[] drugsNotPresent = labelText.split("Here is iv compatibility for ");
		String b = drugsNotPresent[1].replace(" and ", ",").replace(":", "").replace(" ", "").replace("\"", "");
		String[] drugsNotPresent1 = b.split(",");
		List<String> n = Arrays.asList(drugsNotPresent1);

		List<String> getDrugNames = new ArrayList<>();
		List<String> drugsList = Arrays.asList(drugUsedForSearch.split(":"));
		Collections.sort(drugsList);
		if (!("IV Compatibility Results".equals(IVCompatibilityPageTitle.getText()))
				&& IVCompatibilityDrugsTitle.getText().equals("All Drugs " + "(" + drugsList.stream().count() + ")")) {
			result = false;
		} else {
			for (WebElement drug : IVCompatibilityMultipleDrugsNames) {
				getDrugNames.add(drug.getText().toLowerCase().replace(" ", ""));
			}
			Collections.sort(getDrugNames);
			if (!n.equals(getDrugNames)) {
				result = false;
			}
		}
		return result;
	}

}
