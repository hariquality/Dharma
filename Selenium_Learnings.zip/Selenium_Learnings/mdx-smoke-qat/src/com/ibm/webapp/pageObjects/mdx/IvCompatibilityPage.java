package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;

import org.openqa.selenium.Keys;
//import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class IvCompatibilityPage extends Selenese {
	public WebDriver driver;

	@FindBy(xpath = "//div[@id='noMatch']")
	private WebElement drugNoresults;

	// Solution no results found

	@FindBy(xpath = "//div[@id='noMatchSoln']")
	private WebElement solnNoresults;

	// Drugpopup
	@FindBy(xpath = "//span[@id='lbDrugAdded_title']")
	private WebElement sameDrugPopupTitle;

	@FindBy(xpath = "(//div[@class='outputContent'])[2]")
	private WebElement sameDrugPopupContent;

	@FindBy(xpath = "(//input[@title='Close'])[2]")
	private WebElement sameDrugPopupClose;

	// Solution popup

	@FindBy(xpath = "//span[@id=\"lbSolutionAdded_title\"]")
	private WebElement samesolnPopuptitle;

	@FindBy(xpath = "(//div[@class='outputContent'])[3]")
	private WebElement sameSolutionPopupContent;

	@FindBy(xpath = "(//input[@class='dojoxDialogCloseIcon'])[3]")
	private WebElement samesolnPopupclose;

	@FindBy(xpath = "(//div[@class='searchSubTitle'])[1]")
	private WebElement drugtotalHeading;

	@FindBy(xpath = "(//div[@class='searchSubTitle'])[2]")
	private WebElement solutiontotalHeading;

	@FindBy(xpath = "//input[@id='btnSubmit']")
	private WebElement viewcompatibilitybutton;

	@FindBy(xpath = "//div[@class='tooltipInfoBlock']")
	private WebElement drugPopup;

	@FindBy(xpath = "//input[@id='txtInputSolution']")
	private WebElement SolutionText;

	@FindBy(xpath = "//input[@value='Clear All']")
	private WebElement ClearAllbutton;

	@FindBy(xpath = "(//img[@class='infoIcon'])[1]")
	private WebElement drugInfoToolTip;

	@FindBy(xpath = "(//img[@class='infoIcon'])[2]")
	private WebElement solutionInfoToolTip;

	@FindBy(xpath = "//input[@id='txtInputDrug']")
	private WebElement drugsearchTextBox;

	@FindBy(xpath = "//input[@id='txtInputSolution']")
	private WebElement solutionsearchTextBox;

	@FindBy(xpath = "//span[@class='clearContextIcon clearContextIcon-clear']")
	private WebElement removeItem;

	public IvCompatibilityPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		wait.until(ExpectedConditions.visibilityOf(SolutionText)); // userNameInput));
	}

	/**
	 * Call this method to verify the Drug selection
	 * 
	 * @throws IOException
	 * 
	 */
	public void drugSelection(String searchInput) throws IOException {
		try {
			drugsearchTextBox.clear();
			drugsearchTextBox.sendKeys(searchInput);
			drugsearchTextBox.sendKeys(Keys.DOWN);
			drugsearchTextBox.sendKeys(Keys.ENTER);
			Thread.sleep(1000);
			extentReport.PASS("IV Compatibility Page Verification drugSelection", "drugSelection is working correctly");
			log.info("Verified drugSelection");
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompatibilityPage", "drugSelection method failed");
			logERROR("drugSelection method failed");

		}
	}

	/**
	 * Call this method to verify the Solution selection
	 * 
	 * @throws IOException
	 */
	public void SolnSelection(String searchInput) throws IOException {
		try {
			solutionsearchTextBox.clear();
			solutionsearchTextBox.sendKeys(searchInput);
			solutionsearchTextBox.sendKeys(Keys.DOWN);
			solutionsearchTextBox.sendKeys(Keys.ENTER);
			extentReport.PASS("IV Compatibility Page Verification SolnSelection", "SolnSelection is working correctly");
			log.info("Verified SolnSelection");
			Thread.sleep(1000);
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompatibilityPage", "SolnSelection method failed");
			logERROR("SolnSelection method failed");

		}
	}

	/**
	 * Call this method to Verify the clear all button on search page
	 */

	public IvCompatibilityPage ClearAllbutton() {

		ClearAllbutton.click();
		IvCompatibilityPage searchivPage = PageFactory.initElements(driver, IvCompatibilityPage.class);
		return searchivPage;
	}

	/**
	 * Call this method to Verify View compatibility button on Search page
	 * 
	 * @throws IOException
	 */

	public IvCompatibilityResultsPage viewcompbutton() throws IOException {
		try {
			viewcompatibilitybutton.click();
			extentReport.PASS("IV Comp result Page Verification viewcompbutton", "viewcompbutton is working correctly");
			log.info("Verified viewcompbutton");
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompResult page", "viewcompbutton method failed");
			logERROR("viewcompbutton method failed");
		}
		IvCompatibilityResultsPage ivResultpage = PageFactory.initElements(driver, IvCompatibilityResultsPage.class);
		return ivResultpage;
	}

	/**
	 * Call this method to verify remove item on text box
	 */

	public void removeItem() {
		removeItem.click();
	}

}
