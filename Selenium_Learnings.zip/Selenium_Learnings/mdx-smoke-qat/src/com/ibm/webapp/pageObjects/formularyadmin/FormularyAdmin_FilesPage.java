package com.ibm.webapp.pageObjects.formularyadmin;

import java.io.File;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class FormularyAdmin_FilesPage extends Selenese
{
   private final WebDriver driver;

   @FindBy(xpath = "//strong[contains(text(),'Files')]")
   private WebElement filesHeader;

   @FindBy(name = "upload.fileName")
   private WebElement uploadFile;

   @FindBy(name = "PFFormActionId_formularyadmin.PIFileUpload")
   private WebElement save;

   @FindBy(name = "upload.fileTitle")
   private WebElement fileTitle;

   @FindBy(name="PIFiles.FileList_index_0")
   private WebElement currFiles;
   
   public FormularyAdmin_FilesPage(WebDriver driver)
   {
      this.driver = driver;
      PageFactory.initElements(this.driver, this);
      WebDriverWait wait = new WebDriverWait(this.driver, 20);
      wait.until(ExpectedConditions.visibilityOf(filesHeader));
   }
   /**method to upload a file in Formulary Admin
    * 
    * @param fileName, filePath
    *
    */
   public void enterFileNameandUpload(String name, String filePath)
   {
      fileTitle.sendKeys(name);
      File file = new File(filePath);
      String absolutePath = file.getAbsolutePath();
      uploadFile.sendKeys(absolutePath);
      save.sendKeys(Keys.ENTER);
   }
   /**Verify if the file upload is successful
    * 
    */
   public boolean isFileUploaded(String fileName){
      boolean flag = false;
      Select cFile = new Select(currFiles);
      for(WebElement ele:cFile.getOptions()){
       if(ele.getText().equalsIgnoreCase(fileName)){
        flag=true;
        break;
       }
      }
      return flag;
     }

}
