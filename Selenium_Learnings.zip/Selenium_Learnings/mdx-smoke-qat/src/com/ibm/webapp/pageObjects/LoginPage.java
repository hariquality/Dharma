package com.ibm.webapp.pageObjects;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.config.JenkinsConfiguration;
import com.ibm.webapp.utils.Selenese;

public class LoginPage extends Selenese {

	WebDriver driver;

	@FindBy(xpath = "//a[contains(@href,'pf.LogoutToLoginPage')]")
	private WebElement loginLink;

	@FindBy(id = "login.username_index_0")
	private WebElement userNameInput;

	@FindBy(id = "login.password_index_0")
	private WebElement passwordInput;

	@FindBy(id = "Submit")
	private WebElement loginButton;

	public LoginPage(WebDriver driver) throws IOException {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		try {
			wait.until(ExpectedConditions.visibilityOf(loginButton));
		} catch (Exception e) {
			extentReport.FAIL(driver, "LoginPageClass", "LoginButton is not visible");
			log.error("LoginButton is not visible in the Login Page");
		}
	}

	public GatewayPage loginAs(String creds) throws IOException {
		try {
			String[] cred;
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			if (JenkinsConfiguration.isAdminUser.equalsIgnoreCase("No")) {
				cred = JenkinsConfiguration.getValueFromPropertiesFile(creds).split("/");
			} else {
				cred = JenkinsConfiguration.getValueFromPropertiesFile("adminuser").split("/");
			}
			sendKeys(driver, "Username textbox", userNameInput, cred[0]);
			sendKeys(driver, "Password textbox", passwordInput, cred[1]);
			click(driver, "Login button", loginButton);
			extentReport.PASS("Login", "Login into Application Successful");
			log.info("Login into Application Successful");
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.FailWithException(driver, "LOGIN", "Login Failed.", e);
			logERROR("Login Failed.", e);
		}
		return PageFactory.initElements(this.driver, GatewayPage.class);
	}

	public GatewayPage loginTo(String userName, String password) throws IOException {
		try {
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			sendKeys(driver, "Username textbox", userNameInput, userName);
			sendKeys(driver, "Password textbox", passwordInput, password);
			click(driver, "Login button", loginButton);
			extentReport.PASS("Login", "Login into Application Successful");
			log.info("Login into Application Successful");
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.FailWithException(driver, "LOGIN", "Login Failed.", e);
			logERROR("Login Failed.", e);
		}
		return PageFactory.initElements(this.driver, GatewayPage.class);
	}

}
