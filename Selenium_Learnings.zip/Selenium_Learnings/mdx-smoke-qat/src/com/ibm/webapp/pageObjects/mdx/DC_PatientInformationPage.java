package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.ibm.webapp.utils.Selenese;


public class DC_PatientInformationPage extends Selenese{
	
	   WebDriver driver;
	   //private WebDriverWait webDriverwait;
	   
	   @FindBy(id = "birthDate")
	   private WebElement dob_field;
	   
	   @FindBy(id = "currentWeightTxtId")
	   public WebElement field_weight;
	   
	   @FindBy(id = "SearchBtn")
	   public WebElement btn_Calculator;
	   
	   public LocalDate currentDate = LocalDate.now();
	   
	   String expectedDate = null;
	   
	   @FindBy(id = "gestationalWeekSel")
	   private WebElement selectGestation;
	   
	   @FindBy(id = "gestationalDaysId")
	   private WebElement gestationDays;
	   
	   @FindBy(id = "selPopulationType")
	   private WebElement selectPopulation;
	
	 public DC_PatientInformationPage(WebDriver driver) throws IOException
	   {
		 this.driver = driver;
		 PageFactory.initElements(this.driver, this);
		 waitForElementVisibility(driver, dob_field);
	     //webDriverwait.until(ExpectedConditions.elementToBeClickable(field_weight));
	   }
	 
	 /**
	    * use this method to enter birth date either by full date OR 
	    * by decrementing the day or month or year 
	    * @param day = enter the integer value which has to be 
	    * decremented from the current system date
	    * enter @param enterFullDate = NA
	    * OR 
	    * @param enterFullDate = if you want to enter the fulldate 
	    * enter it in the format in the format YYYY-MM-DD(ex:2019-08-12) 
	    * and remaining @parameters should be entered as 0
	 * @throws IOException 
	    */
	   public void enterBirthDate(int day, int month, int year,String enterPostDate) throws IOException
	   {
		   try{
	      currentDate = LocalDate.now();
	      if(!enterPostDate.equalsIgnoreCase("NA")){
	         currentDate = currentDate.plusDays(Integer.parseInt(enterPostDate));
	      }
	      else {
	         if (!(day == 0))
	         {
	            currentDate = currentDate.minusDays(day);
	         }
	         if (!(month == 0))
	         {
	            currentDate = currentDate.minusMonths(month);
	         }
	         if (!(year == 0))
	         {
	            currentDate = currentDate.minusYears(year);
	         }
	      }
	      expectedDate = DateTimeFormatter.ofPattern("MM/dd/yyyy")
	            .format(currentDate);
	      click(driver, "Clear button",dob_field);
	      sendKeys(driver, "Date field", dob_field, expectedDate);
	      dob_field.sendKeys(Keys.TAB);
	      extentReport.PASS("Verification of birthdate is entered in DOB field",
	    		  expectedDate + "is entered successfully");
			 log.info(expectedDate + "is entered successfully");
		   }
		   catch(Exception e){
			   extentReport.FailWithException(driver,"Verification of birthdate is entered in DOB field","Birthdate is not entered successfully",e);
		          logERROR(expectedDate + "is entered not successfully", e);
		   }
	   }
	   
	   /**
	    * Selects the gestation week in NEOFax UI
	    * use this method when birthdate falls <= 29 days
	    * @param weekNumber = enter number between 22 -44
	    * @param days = enter number between 0-7
	 * @throws IOException 
	    */
	   public void selectGestationAge(int weekNumber,int days ) throws IOException
	   {
	      try
	      {
	         Select populationType = new Select(selectGestation);
	         populationType.selectByValue(Integer.toString(weekNumber));
	         click(driver, "Clear button", gestationDays);
	         try{
	         gestationDays.sendKeys(Integer.toString(days));
	         extentReport.PASS("Verification of gestational week is selected",
	                 "Gestational week is selected from dropdown");
	 		 log.info("Gestational week is selected from dropdown");
	         }catch(Exception e){
	        	 extentReport.FailWithException(driver,"Verification of gestational week is selected","Gestational week is not selected from dropdown",e);
		          logERROR("Gestational week is not selected from dropdown", e);
	         }
	         gestationDays.sendKeys(Keys.TAB);
	      }
	      catch (Exception e)
	      {
	    	  extentReport.FailWithException(driver,"Verification of gestational week and days are selected","Problem of selecting gestation week and days",e);
	          logERROR("Problem of selecting gestation week and days", e);
	         e.printStackTrace();
	      }

	   }
	   
	   /**
	    * enter the user weight in the current weight field
	 * @throws IOException 
	    */
	   public void enterWeight(double weight) throws IOException {
	      try {
	         click(driver, "Current weight field Text box", field_weight);
	         field_weight.sendKeys( Double.toString(weight));
	         field_weight.sendKeys(Keys.TAB);
	         extentReport.PASS("Verification of current weight is entered in weight field",
	        		 weight+" is entered in current weight field");
	 		 log.info(weight+" is entered in current weight field");
	      }
	      catch(Exception e) {
	    	  extentReport.FailWithException(driver,"Verification of current weight is entered in weight field",weight+" is not entered in current weight field",e);
	          logERROR(weight+" is entered in current weight field", e);
	         e.printStackTrace();
	      }
	   }
	   
	   /**
	    * clicks the proceed to calculator button
	 * @throws IOException 
	    */
	   public DC_DrugSelectionPage clickProceedToCalculator() throws IOException
	   {
	      try
	      {
	         click(driver, "Proceed to calculator button", btn_Calculator);
	         extentReport.PASS("Verification of Drug selection page is loaded",
	                 "Drug selection page is loaded");
	 		 log.info("Drug selection page is loaded");
	         
	      }
	      catch (Exception e)
	      {
	    	  extentReport.FailWithException(driver,"Verification of Drug selection page is loaded","Drug selection page is not loaded",e);
	          logERROR("Drug selection page is not loaded", e);
	    	 driver.navigate().refresh();
	         e.printStackTrace();
	      }
	   return  PageFactory.initElements(driver, DC_DrugSelectionPage.class);
	   }

	   /**
	    * @returns TRUE if the type is enabled or 
	    * FALSE if the type is disabled
	    */
	   public boolean isPopulationTypeEnabled()
	   {
	      try 
	      {
	         if (selectPopulation.isEnabled())
	         {
	            return true;
	         }
	      }
	      catch (Exception e)
	      {
	         e.printStackTrace();
	      }
	      return false;
	   }
	  
}
