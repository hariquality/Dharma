package com.ibm.webapp.pageObjects.drugid;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.ibm.webapp.utils.Selenese;

public class DrugID_MDXLandingPage extends Selenese
{
   WebDriver driver;
   
   @FindBy(xpath = "//*[@id=\"landingPageTitle\"]/div/h1")
   private WebElement drugTitle;
   
   public DrugID_MDXLandingPage(WebDriver driver)
   {
      this.driver = driver;
      PageFactory.initElements(driver, this);
      driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
   }
   
   public void verifyLandingPageDrugTitle()
   {
      Assert.assertEquals(drugTitle.getText(), "Codeine");
      extentReport.PASS("Drug landing page for Codeine", "Drug landing page for Codeine");
      log.info("Drug landing page for Codeine");
   }
   
   
   
}
