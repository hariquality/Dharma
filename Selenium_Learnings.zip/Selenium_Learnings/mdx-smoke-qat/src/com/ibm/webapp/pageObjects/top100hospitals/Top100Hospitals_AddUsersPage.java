package com.ibm.webapp.pageObjects.top100hospitals;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.ibm.webapp.utils.Selenese;

public class Top100Hospitals_AddUsersPage extends Selenese
{
   private final WebDriver driver;

   Top100Hospitals_CreateStudyUserPage createstudy;

   @FindBy(xpath = "//*[@id=\"AddUsers\"]/div/table[2]/tbody/tr[2]/td/table/tbody/tr[2]/td[1]/select/option[344]")
   private WebElement SelectUser;

   @FindBy(xpath = "//*[@id=\"AddUsers\"]/div/table[2]/tbody/tr[1]/td/h3")
   private WebElement AddUsersTitle;

   @FindBy(xpath = "//*[@id=\"Submit\"]")
   private WebElement submitButton;

   @FindBy(xpath = "//*[@id=\"AddUsers\"]/div/table[2]/tbody/tr[2]/td/table/tbody/tr[2]/td[2]/img[1]")
   private WebElement AddToRightButton;

   public Top100Hospitals_AddUsersPage(WebDriver driver) throws IOException
   {
      this.driver = driver;
      PageFactory.initElements(this.driver, this);
      WebDriverWait wait = new WebDriverWait(this.driver, 20);

      try
      {
         wait.until(ExpectedConditions.visibilityOf(AddUsersTitle));
      }
      catch (Exception e)
      {
         extentReport.FAIL(driver,
                           "Top100Hospitals_AdministrativeTasksPage",
                           "Create user for group link is not visible");
         log.error("Create user for group link is not visible in user provisioning page");
      }
   }

   /**
    * method to add a user to the group
    * 
    * @return adminpage object
    * @throws IOException
    */
   public Top100Hospitals_AdministrativeTasksPage AddUsers() throws IOException
   {

      click(driver, "Select a user", SelectUser);
      click(driver, "Right arrow button", AddToRightButton);
      click(driver, "Add user button", submitButton);
      Top100Hospitals_AdministrativeTasksPage adminTaskPage = PageFactory
            .initElements(driver,
                          Top100Hospitals_AdministrativeTasksPage.class);
      adminTaskPage.verifyAddUserSuccessMsg();
      return adminTaskPage;
   }

}
