package com.ibm.webapp.pageObjects.healthcheck;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class HealthCheckApplicationPage extends Selenese {
	WebDriver driver;

	@FindBy(xpath = "//application/name")
	private WebElement pageHeader;

	@FindBy(xpath = "//application/healthcheck/name")
	private List<WebElement> appList;

	@FindBy(xpath = "//application/healthcheck/status")
	private List<WebElement> serviceStatusList;

	public HealthCheckApplicationPage(WebDriver driver) throws IOException {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		try {
			wait.until(ExpectedConditions.visibilityOf(pageHeader));
			extentReport.PASS("Health check application", "Health app page header displayed");
		} catch (Exception e) {
			extentReport.FAIL(driver, "HealthCheckApplicationPage", "Page Header is not visible");
			log.error("Page Header is not visible in the HealthCheck application page ");
		}

	}

	/**
	 * Iterate over the 10 services and check the status to be "OK"
	 * 
	 * @return
	 * @throws IOException
	 */
	public boolean checkHealth() throws IOException {
		try {
			boolean flag = true;
			int i = 0;
				if (serviceStatusList.get(i).getText().startsWith("https://")) {
					flag = true;
				} else if (!serviceStatusList.get(i).getText().contains("OK")) {
					flag = false;
					extentReport.PASS("Health  check URL application", "Health check applications are working fine");
			}
			return flag;
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Health app", "Health app check method failed", e);
			logERROR("Health app check method failed", e);
		}
		return false;
	}
}
