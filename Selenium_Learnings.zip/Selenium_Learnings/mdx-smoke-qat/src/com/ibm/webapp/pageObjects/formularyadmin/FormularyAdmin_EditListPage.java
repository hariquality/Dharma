package com.ibm.webapp.pageObjects.formularyadmin;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;


public class FormularyAdmin_EditListPage extends Selenese
{
   private final WebDriver driver;

   @FindBy(xpath = "//strong[contains(text(),'Edit List')]")
   private WebElement editListheader;

   @FindBy(name = "formularyList_index_0")
   private WebElement selectedformularyList;

   @FindBy(id = "PFFormActionId_formularyadmin.Add")
   private WebElement addToFormularybtn;

   @FindBy(id = "managementEditList.SearchTerm_index_0")
   private WebElement searchtxtbox;

   @FindBy(id = "managementEditList.formularyList_index_0")
   private WebElement formularyList;

   @FindBy(name = "PFFormActionId_formularyadmin.EditListSearchTranslator")
   private WebElement searchBtn;

   @FindBy(xpath = "//strong[contains(text(),'SEARCH RESULTS')]")
   private WebElement searchResultHeading;

   @FindBy(name = "mainList_index_0")
   private WebElement searchResultsMainList;

   @FindBy(id = "PFFormActionId_formularyadmin.SaveProductUpdatesAndEditList")
   private WebElement saveandEditBtn;
   
   @FindBy(xpath="//table[@id='Navigation']/tbody/tr[2]/td/table/tbody/tr/td[1]/div/a[3]/img")//@FindBy(xpath="//img[@title='Pharmacy Information.']")
   private WebElement linkPharmacyInfo;

   public FormularyAdmin_EditListPage(WebDriver driver)
   {
      this.driver = driver;
      PageFactory.initElements(this.driver, this);
      WebDriverWait wait = new WebDriverWait(this.driver, 20);
      wait.until(ExpectedConditions.visibilityOf(editListheader));
   }
   /**method to search for a drug
    * 
    * @param drug
    * @throws IOException 
    */
   public boolean searchForDrug(String drug) throws IOException
   {
      searchtxtbox.clear();
      // searchtxtbox.sendKeys(drug);
      try
      {
         sendKeys(driver, "search", searchtxtbox, drug);
         searchBtn.click();
      }
      catch (IOException e1)
      {
         // TODO Auto-generated catch block
         e1.printStackTrace();
      }

      try
      {
         waitForElementVisibility(driver, searchResultHeading);
      }
      catch (IOException e)
      {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
      if (searchResultHeading.isDisplayed())
      {
         extentReport.PASS("Search Results verification",
                           "Search results displayed");
         log.info("Search results displayed");
         return true;
      }

      else
      {
         extentReport.FAIL(driver,
                           "Search Results verification",
                           "Search results not displayed");
         log.error("Search results not displayed");
         return false;
      }
   }
   /**method to add drug to a formulary
    * 
    * @throws IOException 
    */
   public boolean addDrugstoFormulary(String drugs)
   {
      boolean flag = true;
      String[] drugsToadd = drugs.split(";");

      Select drugsList = new Select(searchResultsMainList);

      for (int i = 0; i < drugsToadd.length; i++)
      {
         drugsList.selectByValue(drugsToadd[i]);
         // addToFormularybtn.click();
         try
         {
            click(driver, "adding drugs to formulary", addToFormularybtn);
         }
         catch (IOException e)
         {
            // TODO Auto-generated catch block
            e.printStackTrace();
         }
      }

      Select formularydrugsList = new Select(selectedformularyList);

      for (int j = 0; j < drugsToadd.length; j++)
      {
         formularydrugsList.deselectAll();
         formularydrugsList.selectByValue(drugsToadd[j]);
         if (!formularydrugsList.getFirstSelectedOption().getAttribute("value")
               .equalsIgnoreCase(drugsToadd[j]))
         {
            flag = false;
            break;
         }

      }
      return flag;
   }
   /**Method to save and edit an item page in Formulary Admin
    * 
    * @param drugName
    * returns Edit Item Page
    * @throws IOException 
    */
   public FormularyAdmin_EditItemPage saveandEdit()
   {
     // saveandEditBtn.click();
      try
      {
         click(driver, "Save and Edit", saveandEditBtn);
      }
      catch (IOException e)
      {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
      FormularyAdmin_EditItemPage editPage = PageFactory
            .initElements(driver, FormularyAdmin_EditItemPage.class);
      return editPage;
   }
   /**Method to click on Pharmacy Information link
    * 
    * @param drugName
    * @throws IOException 
    */
   public FormularyAdmin_SectionsPage clickOnPharmacyInformation(){
      
      JavascriptExecutor executor = (JavascriptExecutor)driver;
      executor.executeScript("arguments[0].click();", linkPharmacyInfo);
      //linkPharmacyInfo.sendKeys(Keys.ENTER);
      FormularyAdmin_SectionsPage pip = PageFactory.initElements(driver, FormularyAdmin_SectionsPage.class);
      return pip;
     }
   
}
