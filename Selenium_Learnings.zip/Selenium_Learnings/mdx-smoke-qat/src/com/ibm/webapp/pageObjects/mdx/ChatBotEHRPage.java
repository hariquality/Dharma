package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

/**
 * Page object for EHR chatbot servlet entry points
 * 
 * @author APeavy
 */
public class ChatBotEHRPage extends Selenese

{
	private final WebDriver driver;

	private WebDriverWait _wait;

	@FindBy(xpath = "//div[@id='chatbox-learnmoreText']/a")
	private WebElement link_LearnMore;

	@FindBy(id = "chatbox-helpImage")
	private WebElement img_LearnMore;

	@FindBy(xpath = "//h2[.='About IBM Cognitive Search']")
	private WebElement helpWindowHeader;

	@FindBy(id = "EHRBotWrapper")
	private WebElement ehrWrapper;

	@FindBy(id = "sectionArea")
	private WebElement sectionArea;

	@FindBy(id = "chatbotTextInput")
	private WebElement chatbotTextInput;

	@FindBy(xpath = "//div[@id='chatbox-contentpane']//div")
	private List<WebElement> chatboxDivs;

	@FindBy(xpath = "//div[@id='chatbox-contentpane']//div/a[@target='IntSearchWordWheel']")
	private List<WebElement> chatboxAs;

	@FindBy(id = "chatCloseIcon")
	private WebElement chatBotWindowCloseIcon;

	@FindBy(id = "mdxChatBotDiv")
	private WebElement landingPageChatIcon;

	@FindBy(id = "WatsonContainer")
	private WebElement homePageChatIcon;

	private static final String QUICK = "Quick";

	private static final String INDEPTH = "InDepth";

	public ChatBotEHRPage(WebDriver driver) {
		this.driver = driver;
		// make sure test is viewing conv window
		PageFactory.initElements(this.driver, this);
		_wait = new WebDriverWait(this.driver, 20);
		_wait.until(ExpectedConditions.visibilityOf(ehrWrapper));
	}

	public MDX_HomePage getHomePage() {
		return PageFactory.initElements(driver, MDX_HomePage.class);
	}

	public DashBoardPage getDashboardPage() {
		return PageFactory.initElements(driver, DashBoardPage.class);
	}

	/**
	 * Enter text into conv dialog, then send 'RETURN' key.
	 * 
	 * @param inputText
	 * @return
	 * @throws IOException
	 */
	public ChatBotEHRPage enterText(String inputText) throws IOException {
		try {
			Thread.sleep(3000);
			sendKeys(driver, "Search box", chatbotTextInput, inputText);
			chatbotTextInput.sendKeys(Keys.RETURN);
			// extentReport.PASS("Search box",inputText+" is entered in EHR
			// chatbot");
			// log.info(inputText+" is entered in EHR search box");

			if (!waitForResponse()) {
				System.out.println("No chat Response");
			}
			extentReport.PASS("Verification of chat response in EHR",
					"ChatResponse is displayed for the EHR user after query entered");
			log.info("ChatResponse is displayed for the EHR user after query entered");
		} catch (Exception e) {
			extentReport.FAIL(driver, "Verification of chat response in EHR after query entered",
					"Empty ChatResponse is not displayed for the EHR user, some exception is occurred");
			logERROR("Empty ChatResponse is not displayed for the EHR user, some exception is occurred");
			e.printStackTrace();
		}
		return PageFactory.initElements(driver, ChatBotEHRPage.class);
	}

	/**
	 * Convenience method to wait until chatbot has a 'response' from conv.
	 * service in the chatbot's content pane
	 */
	private boolean waitForResponse() {
		boolean found = false;
		try {
			// loop until 20secs
			Thread.sleep(2000);
			int i = 0;
			while (i < 20) {
				PageFactory.initElements(driver, this);
				// get class attr from very last chatboxDivs
				String type = chatboxDivs.get(i).getAttribute("class");
				// if it is a 'response' from watson, break
				if (type.contains("chatResponse highlightResponse")) {
					found = true;
					break;
				}
				i++;
			}
			if (found == false) {
				extentReport.FAIL(driver, "Verification of chat response in EHR",
						"Empty ChatResponse is displayed for the EHR user");
				logERROR("Empty ChatResponse is displayed for the EHR user");
				System.out.println("Empty ChatResponse is displayed for the EHR user");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return found;
	}

	/**
	 * Return text of the last link in the chatbot's content pane
	 * 
	 * @return
	 */
	public String getLastLinkText(String sectionName) {
		String text = null;
		try {
			if (waitForResponse()) {
				pause(5000);
				System.out.print(chatboxAs.size());
				if (chatboxAs.size() > 0) {
					if (sectionName.equals(QUICK)) {
						text = chatboxAs.get(chatboxAs.size() - 2).getText();
					} else {
						text = chatboxAs.get(chatboxAs.size() - 1).getText();
					}
					return text;
				} else {
					return "no <a> tags found";
				}

			}

			else {
				extentReport.FAIL(driver, "Returns text of last link in chatbot's content pane",
						"Failed to return the last link in the chatbot's pane");
				logERROR("Failed to return the last link in the chatbot's pane");
				System.out.println("Chat Response is not displayed");
			}

		}

		catch (Exception e) {
			e.printStackTrace();
		}
		return text;
	}

	/**
	 * Click on the last response's <a> tag link in the chatbot's content pane
	 * 
	 * @param sectionName=
	 *            Pass tab name as Quick or In-depth
	 * @return DashBoardPage
	 * @throws IOException
	 */
	public DashBoardPage clickOnLastResponseATag(String sectionName) throws IOException {

		if (sectionName.equals(QUICK)) {
			chatboxAs.get(chatboxAs.size() - 2).click();
			extentReport.PASS("Click on Quick answer response tag on EHR chatbot window",
					"Quick answer response tag is clicked on EHR chatbot window");
			log.info("Quick answer response tag is clicked on EHR chatbot window");
		} else {
			chatboxAs.get(chatboxAs.size() - 1).click();
			extentReport.PASS("Click on Indepth answer response tag on EHR chatbot window",
					"Indepth answer response tag is clicked on EHR chatbot window");
			log.info("Indepth answer response tag is clicked on EHR chatbot window");
		}
		try {
			switchWindowTo("evidencexpert.RedirectChatLinkToIntermediateDocument?");
			getDashboardPage().isLoadingImageDisabled();
			extentReport.PASS(
					"Verification of drug landing page is loaded after click on " + sectionName + " tag on EHR window",
					"Drug landing page is loaded successfully after click on " + sectionName + " tag on EHR window");
			log.info("Drug landing page is loaded successfully after click on " + sectionName + " tag on EHR window");
		} catch (Exception e) {
			extentReport.FailWithException(driver,
					"Verification of drug landing page is loaded after click on " + sectionName + " tag on EHR window",
					"Drug landing page is not loaded successfully after click on " + sectionName + " tag on EHR window",
					e);
			logERROR(
					"Drug landing page is not loaded successfully after click on " + sectionName + " tag on EHR window",
					e);
		}
		DashBoardPage page = PageFactory.initElements(driver, DashBoardPage.class);
		return page;
	}

	public ChatBotEHRPage switchToChatWindow() {
		try {
			switchWindowTo("evidencexpert.openWatsonConversation");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.navigate().refresh();
		ChatBotEHRPage chatPage = PageFactory.initElements(driver, ChatBotEHRPage.class);
		return chatPage;
	}

	public ChatBotEHRPage switchToIntermediatePageWindow() {
		try {
			switchWindowTo("librarian/watsonwindow");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ChatBotEHRPage chatPage = PageFactory.initElements(driver, ChatBotEHRPage.class);
		return chatPage;
	}

	/**
	 * Use to switch windows to a newly opened window if you have a 'signature'
	 * to use in the window's title.
	 * 
	 * @param targetWindowURLSignature
	 * @throws IOException
	 */
	public void switchWindowTo(String targetWindowURLSignature) throws IOException {
		try {
			pause(2000);
			// System.out.println("targetWindowURLSignature:" +
			// targetWindowURLSignature);
			Iterator<String> itr = this.driver.getWindowHandles().iterator();
			while (itr.hasNext()) {
				String handle = itr.next();
				driver.switchTo().window(handle);
				if (driver.getCurrentUrl().contains(targetWindowURLSignature)) {
					// System.out.println("Found " + targetWindowURLSignature +
					// " window.");
					break;
				}
			}
			extentReport.PASS("Switch to Newly opened window", "Switched to Newly opened window");
			log.info("Switched to Newly opened window");
		} catch (Exception e) {
			extentReport.FAIL(driver, "Switch to Newly opened window", "Problem of window handling action");
			logERROR("Problem of window handling action");
		}

	}

	protected void pause(long milliseconds) {
		try {
			Thread.sleep(milliseconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Verifies chaticon is visible in HomePage or any other landing pages.
	 * 
	 * @param Page
	 *            =Pass the landing page
	 * @return true= if chaticon is visible, false = if chaticon is not visible
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public boolean isChatBotVisible(String Page) throws InterruptedException, IOException {
		boolean flag;
		try {
			getDashboardPage().scrollDown(500);
			if ("Home".equals(Page) && homePageChatIcon.isDisplayed()) {
				flag = true;
			} else {
				landingPageChatIcon.isDisplayed();
				flag = true;
			}
			extentReport.FAIL(driver, "validation of chaticon is visible in HomePage or any other landing pages",
					"AskWatson option is enabled in MDX Landing Page,when navigating from EHR tool");
			logERROR("AskWatson option is enabled in MDX Landing Page,when navigating from EHR tool");

		} catch (NoSuchElementException e) {
			// System.out.println("ChatBot Not Found");
			flag = false;
			extentReport.PASS("validation of chaticon is visible in HomePage or any other landing pages",
					"AskWatson option is not enabled in MDX Landing Page,when navigating from EHR tool");
			log.info("AskWatson option is not enabled in MDX Landing Page,when navigating from EHR tool");
		}
		return flag;

	}

	/**
	 * Verifies learnmore functionality for EHR tool
	 * 
	 * @return
	 */
	public boolean verifyLearnMoreFunctionality(String ehrURL) {
		boolean flag = true;
		link_LearnMore.sendKeys(Keys.ENTER);
		flag = verifyLearnMoreContents(ehrURL);
		if (flag) {
			img_LearnMore.click();
			flag = verifyLearnMoreContents(ehrURL);
		}
		return flag;

	}

	private boolean verifyLearnMoreContents(String ehrURL) {
		boolean flag = true;
		try {
			switchWindowTo("webtier/scripts/micromedex/widget/watsonHelpContent.html");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (!"About IBM Cognitive Search".equals(helpWindowHeader.getText())) {
			flag = false;
		}
		driver.close();
		if ("watsonwindow".equals(ehrURL)) {
			switchToChatWindow();
		} else {
			try {
				switchWindowTo("librarian/watsonaccessui");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return flag;
	}

	public boolean getMDXLandingPageCount() {
		boolean flag = true;
		int landingPageWindow = 0;
		Iterator<String> itr = this.driver.getWindowHandles().iterator();
		while (itr.hasNext()) {
			String handle = itr.next();
			driver.switchTo().window(handle);
			if (driver.getCurrentUrl().contains("evidencexpert.RedirectChatLinkToIntermediateDocument")) {
				landingPageWindow++;
			}
		}

		if (landingPageWindow > 1) {
			flag = false;
		}
		return flag;
	}

	/**
	 * Use this method to Validate the tab name and section name are present in
	 * the drug landing page after navigating from EHR chatbot window
	 * 
	 * @param tabName=
	 *            Pass the tab name as Quick answer or In-depth answer
	 * @param sectionName=
	 *            Pass the section name of quick or In-depth answer tab
	 * @throws Exception
	 */

	public boolean verifyNavItemTabSelectionandSectionName(String tabName, String sectionName) {
		boolean flag = false;
		String navItemURLParameter = null;
		boolean isTabSelected = false;
		try {
			String url = driver.getCurrentUrl();
			switch (tabName) {
			case QUICK:
				isTabSelected = getDashboardPage().quickAnswerTabselected();
				navItemURLParameter = "navitem=cognitivemdxquickansdoclink#";
				break;

			case INDEPTH:
				isTabSelected = getDashboardPage().isIndepthAnswerTabselected();
				navItemURLParameter = "navitem=cognitivemdxindepthansdoclink#";
				break;

			}
			if (isTabSelected) {
				if (url.contains(navItemURLParameter)) {
					flag = getDashboardPage().isSubsectionSelected(sectionName);
					extentReport.PASS("Validate the tab name and section name are present in the drug landing page",
							"For " + tabName + " Answers " + sectionName + " is present in DrugLanding Page");
					log.info("For " + tabName + " Answers " + sectionName + " is present in DrugLanding Page");
				}

				else {
					extentReport.FAIL(driver,
							"Validate the tab name and section name are present in the drug landing page",
							"For " + tabName + " Answers " + sectionName + " is not present in DrugLanding Page");
					log.info("For " + tabName + " Answers " + sectionName + " is not present in DrugLanding Page");
					System.out.println(
							"For " + tabName + " Answers " + sectionName + " is not present in DrugLanding Page");
				}
			} else
				System.out.println(tabName + " Answers Tab is not selected in DrugLanding Page");
		}

		catch (Exception e) {
			e.printStackTrace();
			flag = false;
		}
		return flag;
	}

}