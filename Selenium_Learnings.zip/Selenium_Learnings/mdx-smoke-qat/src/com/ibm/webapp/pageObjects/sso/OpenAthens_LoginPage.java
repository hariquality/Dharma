package com.ibm.webapp.pageObjects.sso;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.config.JenkinsConfiguration;
import com.ibm.webapp.utils.Selenese;

public class OpenAthens_LoginPage extends Selenese {
	WebDriver driver;

	@FindBy(id = "login-username")
	private WebElement userNameInput;

	@FindBy(id = "login-password")
	private WebElement passwordInput;

	@FindBy(xpath = "//*[@id=\"login-controls\"]/form/button")
	private WebElement loginButton;

	@FindBy(xpath = "//li[@class='login']/a")
	private WebElement logoutButton;

	public OpenAthens_LoginPage(WebDriver driver) throws IOException {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		try {
			wait.until(ExpectedConditions.visibilityOf(userNameInput));
		} catch (Exception e) {
			extentReport.FAIL(driver, "Open Athens LoginPage", "OPen Athens Login Page not displayed");
			log.error("OPen Athens Login Page not displayed");
		}
	}

	/**
	 * Use this method to log in to the application,
	 * 
	 * @throws IOException
	 */

	public MyAthensDashboardPage loginTo(String creds) throws IOException {
		try {
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			String[] cred = JenkinsConfiguration.getValueFromPropertiesFile(creds).split("/");
			sendKeys(driver, "Username textbox", userNameInput, cred[0]);
			sendKeys(driver, "Password textbox", passwordInput, cred[1]);
			click(driver, "Login button", loginButton);
			extentReport.PASS("Login", "Login into Application Successful");
			log.info("Login into Application Successful");
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.FailWithException(driver, "LOGIN", "Login Failed.", e);
			logERROR("Login Failed.", e);
		}
		return PageFactory.initElements(this.driver, MyAthensDashboardPage.class);
	}

	public void LogOut() throws IOException {
		click(driver, "Sign out", logoutButton);
	}

}
