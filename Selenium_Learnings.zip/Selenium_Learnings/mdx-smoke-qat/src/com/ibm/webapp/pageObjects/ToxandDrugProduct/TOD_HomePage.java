package com.ibm.webapp.pageObjects.ToxandDrugProduct;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.config.JenkinsConfiguration;
import com.ibm.webapp.utils.Selenese;

public class TOD_HomePage extends Selenese
{
   WebDriver driver;

   @FindBy(xpath = "//a[contains(text(),'Tox & Drug')]")
   private WebElement thiasToxandProductMenu;

   @FindBy(xpath = "//table[@id='othItems']/tbody/tr/td[contains(text(),'Tox & Drug')]")
   private WebElement otherToolsToxAndDrugLink;

   @FindBy(xpath = "//div[@id='header']/div[@id='tbOpt_MT']")
   private WebElement otherToolsDropDownBackground;

   @FindBy(xpath = "//span[@id='comboBtn_label']")
   private WebElement otherToolsDropDownLink;

   @FindBy(id = "IntSearchWordWheel_SearchTerm_index_0")
   private WebElement drugSearchBox;

   @FindBy(id = "WordWheel_SearchTerm_index_0")
   private WebElement toxAndDrugSearchBox;

   @FindBy(xpath = "//div[@id='pdxButton']/input")
   private WebElement submitButton;

   @FindBy(xpath = "//table[@id= 'PSN_Table']")
   private WebElement resultsTable;

   @FindBy(xpath = "//table[@id= 'PSN_Table']/tbody/tr")
   private List<WebElement> toxAndDrugSearchSmokeResults;

   @FindBy(id = "doSearchBtn")
   private WebElement btn_drugSearch;

   public TOD_HomePage(WebDriver driver) throws IOException
   {
      this.driver = driver;
      PageFactory.initElements(driver, this);
      WebDriverWait wait = new WebDriverWait(this.driver, 20);
      try
      {
         wait.until(ExpectedConditions.visibilityOf(submitButton));
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver,"Tox&Drug Product LookUp Home Page",
                           "Page Not Displayed",e);
         log.error("Tox&Drug Product LookUp Home Page is not displayed");
      }
   }

  
   public void isTODPageDisplayed() throws IOException
   {
      try
      {
         if (driver.getTitle()
               .equalsIgnoreCase("Tox and Drug Product Lookup - MICROMEDEX"))
         {// Home - MICROMEDEX
            extentReport
                  .PASS("Tox and Drug Product Home Page Verification",
                        "Tox and Drug Product Home Page is displayed correctly");
         }
         else
         {
            extentReport.FAIL(driver,
                              "Tox and Drug Product Home Page Verification",
                              "Tox and Drug Product Home is not displayed");
         }
      }
      catch (Exception e)
      {
         extentReport
               .FAIL(driver,
                     "Tox and Drug Product Home Page Verification",
                     "Tox and Drug Product Home Page is not displayed- Some Exception occured");
      }

   }

   /*
    * To validate whether the application pages protocols(either HTTP or HTTPS)
    * are as expected
    */
   public boolean verifyProtocol()
   {
      String url = "https://" + JenkinsConfiguration.executionEnv + "."
            + JenkinsConfiguration.getValueFromPropertiesFile("appURL");
      if (url.contains("https://"))
      {

         if (driver.getCurrentUrl().contains("https"))
         {
            return true;
         }
         else
         {
            return false;
         }
      }
      else
      {
         if (driver.getCurrentUrl().contains("http"))
         {
            return true;
         }
         else
         {
            return false;
         }
      }
   }

   public void typeCharsIntoSearchBox(String searchInput)
   {
      toxAndDrugSearchBox.clear();
      toxAndDrugSearchBox.sendKeys(searchInput);
      try
      {
         Thread.sleep(1000);
      }
      catch (InterruptedException e)
      {
         e.printStackTrace();
      }
   }

   public TOD_SearchResultPage clickOnSubmitButton() throws IOException
   {
      click(driver, "Submit Button", submitButton);
      if (isErrorMessageDisplayed())
      {
         extentReport.infoWithScreenShot(driver, "Error Displayed");
      }
      TOD_SearchResultPage tdSearchResultsPage = PageFactory
            .initElements(driver, TOD_SearchResultPage.class);
      return tdSearchResultsPage;

   }

   /**
    * Return true if Error Message is displayed otherwise return false
    *
    *
    * @return
    */
   public boolean isErrorMessageDisplayed()
   {

      JavascriptExecutor js = (JavascriptExecutor) driver;
      Object errorMessage = js
            .executeScript("return document.getElementById('PDX_errorContainer')");
      if (errorMessage == null)
      {
         return false;
      }
      return true;
   }

}
