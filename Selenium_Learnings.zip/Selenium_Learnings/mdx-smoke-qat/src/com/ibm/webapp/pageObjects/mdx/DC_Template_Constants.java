package com.ibm.webapp.pageObjects.mdx;

public class DC_Template_Constants {

	// Dose Units
	public final String MG_KG_DOSE = "mg/kg/dose";
	public final String MMOL_KG_DAY = "mmol/kg/day";
	public final String MMOL_ML = "mmol/mL";
	public final String MMOL_DOSE = "mmol/dose";
	public final String UNITS_KG_DOSE = "units/kg/dose";
	public final String G_KG = "g/kg";
	public final String G_KG_DOSE = "g/kg/dose";
	public final String MG_M2_DOSE = "mg/m2/dose";
	public final String MG_M_2_DOSE = "mg/m(2)/dose";
	public final String MG_M_2 = "mg/m(2)";
	public final String ML_KG_DOSE = "mL/kg/dose";
	public final String MCG_KG_DAY = "mcg/kg/day";
	public final String MG_KG_DAY = "mg/kg/day";
	public final String ML_vial = "mL vial";
	public final String MG_ML = "mg/mL";
	public final String G_ML = "g/mL";
	public final String MG_CAPSULE_TABLET = "mg/capsule or tablet";
	public final String MG_KG = "mg/kg";
	public final String UNITS_KG = "units/kg";
	public final String UNIT_KG = "unit/kg";
	public final String UNITS_ML = "units/mL";
	public final String MCG_KG = "mcg/kg";
	public final String MCG_ML = "mcg/mL";
	public final String ML_KG = "mL/kg";
	public final String ML_ML = "mL/mL";
	public final String HOURS = "hours";
	public final String HOURS_IV = "hours IV";
	public final String MINUTES = "minutes";
	public final String MINUTES_IV = "minutes IV";
	public final String WEEK = "week";
	public final String DOSE_WEEK = "dose/week";
	public final String MCG_KG_DOSE = "mcg/kg/dose";
	public final String INTERNATIONAL_UNITS_KG = "international units/kg";
	public final String INTERNATIONAL_UNITS_ML = "international units/mL";
	public final String INTERNATIONAL_UNITS_DOSE = "international units/dose";
	public final String HOURS_NEEDED_CLOCK = "hours as needed or around-the-clock";
	public final String TOTAL_LOADING_DOSE_IV = "Total loading dose IV";
	public final String SINGLE_DOSE = "single dose";
	public final String IV_OVER_4_6_HOURS = "IV over 4 to 6 hours";
	public final String G_DOSE = "g/dose";
	public final String MG_DOSE = "mg/dose";
	public final String ML_DOSE = "mL/dose";
	public final String UNITS_DOSE = "units/dose";
	public final String UNIT_ML = "unit/ml";
	public final String MCG_DOSE = "mcg/dose";
	public final String ML_DOSE_Dilute_250_500_NS = "mL/dose Dilute in 250 to 500 mL of NS";
	public final String ML_HOUR = "mL/hour";
	public final String ML_HR = "mL/hr";
	public final String VIALS = "vials";
	public final String MG_M_2_DAY = "mg/m(2)/day";

	// Template9,10,12,13
	public final String MINUTES_EACH = "minutes each";
	public final String TOTAL_LOADING_DOSE = "Total loading dose";
	public final String ORALLY = "Orally";
	public final String Orally_IN_2_DOSES = "Orally in 2 doses";
	public final String MEQ_L_deficit = "mEq/L deficit";
	public final String Dose_Deficit_KG = "Dose = Deficit x 0.3 x kg";
	public final String MEQ_ML = "mEq/mL";

	// Template7,11,18
	public final String MG_KG_HR = "mg/kg/hr";
	public final String MCG_KG_MIN = "mcg/kg/min";
	public final String MCG_KG_HR = "mcg/kg/hr";
	public final String ML = "mL";
	// Template22
	public final String DOSE_DAY = "dose/day";
	public final String IV_OVER_15_TO_30_MINUTES = "IV over 15 to 30 minutes";
	public final String IV_OVER_15_TO_60_MINUTES = "IV over 15 to 60 minutes";
	public final String IV_OVER_10_TO_30_MINUTES = "IV over 10 to 30 minutes";
	public final String IV_OVER_ATLEAST_30_MINUTES = "IV over at least 30 minutes";

	public final String LOADING_DOSE = "Loading dose";

	// Template23
	public final String MG_M2_DAY = "mg/m2/day";
	public final String DOSES_DAY = "doses/day";
	public final String IV_OVER_30_SECONDS_TO_10_MINUTES = "IV over 30 seconds to 10 minutes";
	public final String G_M2_DAY = "g/m(2)/day";
	public final String MG_MOF2_DAY = "mg/m(2)/day";
	public final String MG_CAPSULES = "mg/capsules";
	public final String IV_RATE_OF_INFUSION_DEPENDS_ON_THE_VOLUME = "IV (rate of infusion depends on the volume)";
	public final String MG_TABLETS = "mg/tablets";
	public final String MG_MOF2_DAY_TMP_COMPONENT = "mg/m(2)/day (tmp component)";
	public final String DIVIDED_DOSES = "divided doses";

}
