package com.ibm.webapp.pageObjects.ToxandDrugProduct;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.pageObjects.PDXSimulator.PDXSearchResultPage;
import com.ibm.webapp.utils.Selenese;

public class TOD_SearchResultPage extends Selenese
{
   WebDriver driver;

   @FindBy(xpath = "//a[contains(text(),'Tox & Drug')]")
   private WebElement thiasToxandProductMenu;
   
   @FindBy(id = "logoutLink")
   public WebElement logoutButton;
   
   @FindBy(xpath = "//button/span[(text()='Modify Search')]")
   public WebElement modifySearch;
   
   @FindBy(id = "IntSearchWordWheel_SearchTerm_index_0")
   private WebElement drugSearchBox;

   @FindBy(id = "WordWheel_SearchTerm_index_0")
   private WebElement toxAndDrugSearchBox;

   @FindBy(xpath = "//table[@id= 'PSN_Table']")
   private WebElement resultsTable;

   @FindBy(xpath = "//table[@id= 'PSN_Table']/tbody/tr")
   private List<WebElement> toxAndDrugSearchSmokeResults;

   @FindBy(xpath = "(//td[@class='selProdIcon']/a)[1]")
   private WebElement link_SelectProduct;

   public TOD_SearchResultPage(WebDriver driver) throws IOException
   {
	      this.driver = driver;
	      PageFactory.initElements(driver, this);
	      WebDriverWait wait = new WebDriverWait(this.driver, 20);
	      try
	      {
	         wait.until(ExpectedConditions.visibilityOf(modifySearch));
	      }
	      catch (Exception e)
	      {
	         extentReport.FailWithException(driver,"Tox&Drug Product LookUp Search Results Page",
	                           "Page Not Displayed",e);
	         log.error("Tox&Drug Product Search Results Page is not displayed");
	      }
	   }

   public void isTODResultPageDisplayed() throws IOException
   {
      try
      {
         driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
         if (driver.getTitle()
               .equalsIgnoreCase("Tox and Drug Product results - MICROMEDEX"))
         {// Home - MICROMEDEX
            extentReport
                  .PASS("Tox and Drug Product results Page Verification",
                        "Tox and Drug Product results Page is displayed correctly");
            log.info("Tox and Drug Product results Page is displayed correctly");
         }
         else
         {
            extentReport.FAIL(driver,
                              "Tox and Drug Product results Page Verification",
                              "Tox and Drug Product results is not displayed");
            log.error("Tox and Drug Product results is not displayed");
         }
      }
      catch (Exception e)
      {
         extentReport
               .FAIL(driver,
                     "Tox and Drug Product results Page Verification",
                     "Tox and Drug Product results Page is not displayed- Some Exception occured");
         log.error("Tox and Drug Product results Page is not displayed- Some Exception occured");
      }

   }

   public void isResultTableDisplayed() throws IOException
   {
      try
      {
         WebDriverWait wait = new WebDriverWait(this.driver, 20);
         wait.until(ExpectedConditions.visibilityOf(resultsTable));
         if (resultsTable.isDisplayed())
         {
            extentReport
                  .PASS("Tox and Drug Product results Table Verification",
                        "Tox and Drug Product results Table is displayed correctly");
            log.info("Tox and Drug Product results Table is displayed correctly");
         }
      }
      catch (Exception e)
      {
         extentReport
               .FAIL(driver,
                     "Tox and Drug Product results Table Verification",
                     "Tox and Drug Product results Table is not displayed- Some Exception occured");
         log.error("Tox and Drug Product results  Table is not displayed- Some Exception occured");
      }
   }

   /**
    * Return true if Tox and Drug Search Results is displayed otherwise return
    * false
    *
    * @return
    */
   public boolean isToxAndDrugSearchResultsDisplayed()
   {
      if (toxAndDrugSearchSmokeResults.size() > 0)
      {
         return true;
      }
      else
         return false;
   }
   
   public PDXSearchResultPage clickSelectProductLink() throws IOException, InterruptedException{
      click(driver, "Select Product Link", link_SelectProduct);
      log.info("Product Link Selected");
      Thread.sleep(2000);
      return PageFactory.initElements(driver, PDXSearchResultPage.class);
   }

  
}
