package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.ibm.webapp.utils.Selenese;

public class DrugLandingPage extends Selenese {
	
	private final WebDriver driver;

	@FindBy(xpath = "//div[@id='indepthpanel_taxonomy_panel']/ul/li/a")
	private List<WebElement> IndepthTabLeftpaneMainHeadings;

	@FindBy(id = "indepthpanel_section_topic_head")
	private List<WebElement> indepthPanelTopHeading;

	@FindBy(xpath = "//div[@class='titleLink_all']/a")
	private List<WebElement> allResultsTitlelinks;

	@FindBy(id = "quickanspanel_section_topic_header")
	private List<WebElement> quickSectionTopHeader;

	@FindBy(id = "quickanspanel_section_subtopic_header")
	private List<WebElement> quickSubHeader;

	@FindBy(xpath = "//div[@id='quickanspanel_relatedresults_panel']/div[@class='maindivshowresults']/ul/li/a")
	private List<WebElement> relatedResultmenus;

	@FindBy(xpath = "//*[@id='quickanspanel_relatedresults_panel']/div[@class='maindivshowresults']/h3")
	private WebElement quickanswerRelatedResults;

	@FindBy(xpath = "//*[@id='indepthpanel_relatedresults_panel']/div[@class='maindivshowresults']/h3")
	private WebElement indepthRelatedResults;

	@FindBy(xpath = "//*[@id='indepthpanel_relatedresults_panel']/div[@class='maindivshowresults']/ul/li/a")
	private List<WebElement> indepthResultMenus;

	@FindBy(xpath = "//*[@id='allResultsPanel_relatedresults_panel']/div[@class='maindivshowresults']/h3")
	private WebElement allRelatedResults;

	@FindBy(xpath = "//*[@id='allResultsPanel_relatedresults_panel']/div[@class='maindivshowresults']/ul/li/a")
	private List<WebElement> AllRelatedResultMenus;

	@FindBy(xpath = "//div[@id='AllfilterLinks']//ul/li/a")
	private List<WebElement> filterBylinks;

	@FindBy(xpath = "//div[@id='quickanspanel_taxonomy_panel']/ul/li/a")
	private List<WebElement> QuickTabLeftpaneMainHeadings;

	@FindBy(xpath = "//*[@id='allResultsPanelTab']/a")
	private WebElement allResults;

	@FindBy(xpath = "//*[@id='loadingImage'][@class='no_background_Image']")
	private WebElement loadingImage;

	@FindBy(xpath = "//*[@id='quickAnsPanelTab']")
	private WebElement quickansTab;

	@FindBy(xpath = "//div[@id='indepthpanel_taxonomy_panel']/ul/li/ul/li")
	private List<WebElement> IndepthTabLeftNavPaneSubHeaders;

	@FindBy(xpath = "//div[@id='quickanspanel_taxonomy_panel']/ul/li/ul/li")
	private List<WebElement> QuickAnswerTabLeftNavPaneSubHeaders;

	@FindBy(id = "landingTitle")
	private WebElement dashboardheading;

	@FindBy(xpath = "//div[@id='quickanspanel_relatedresults_panel']")
	private List<WebElement> relatedResultsPanelForQuick;

	@FindBy(xpath = "//div[@id='indepthpanel_relatedresults_panel']")
	private List<WebElement> relatedResultsPanelForIndepth;

	@FindBy(xpath = "//*[@id='indepthPanelTab']/a")
	private WebElement indepthPanelTab;

	@FindBy(xpath = "//*[@id='quickAnsPanelTab']/a")
	private WebElement quickPanelTab;

	@FindBy(xpath = "//div[@id='allResultsPanel_relatedresults_panel']/div[@class='maindivshowresults']/h3")
	private WebElement allResultsRelatedResults;

	@FindBy(xpath = "//*[@id='allResultsPanel_relatedresults_panel']")
	private List<WebElement> relatedResultsPanelForAllResults;

	@FindBy(xpath = "//li[@id='quickAnsPanelTab']")
	private WebElement quickAnswerPanelTab;

	@FindBy(id = "quickanspanel_section_topic_header") // xpath =
	// "//*[@id='quickanspanel_section_topic_header']")
	private WebElement medicationSafetyTitle;

	@FindBy(xpath = "//*[@id='allResultsPanel_relatedresults_panel']/div[@class='maindivshowresults']/h3")
	private WebElement relatedSecAllResults;

	@FindBy(id = "filterby_all")
	private WebElement filterBy;

	@FindBy(id = "landingTitle")
	private WebElement mainDrugHeading1;

	@FindBy(id = "indepthpanel_section_topic_header")
	private WebElement topicHeaderForIndepth;

	@FindBy(id = "quickanspanel_section_topic_header")
	private WebElement topicHeaderForQuick;

	@FindBy(xpath = "//*[@id='centerDoc']/table/tbody/tr[1]/th[3]/span[1]")
	private WebElement mainDrugHeading2;

	@FindBy(xpath = "//li[contains(@id,'quickanspanel_taxonomy_panel')]//a")
	private List<WebElement> quickLeftNav;

	@FindBy(xpath = "//li[contains(@id,'indepthpanel_taxonomy_panel')]//a")
	private List<WebElement> IndepthLeftNav;

	@FindBy(id = "quickanspanel_section_topic_header")
	private WebElement quickPageheader;

	@FindBy(id = "indepthpanel_section_topic_header")
	private WebElement IndepthPageHeader;

	@FindBy(id = "quickanspanel_section_subtopic_header")
	private WebElement quickPagesubheader;

	@FindBy(id = "indepthpanel_section_subtopic_header")
	private WebElement IndepthPagesubheader;

	@FindBy(xpath = "//div[@id='quickanspanel_left_panel']//a")
	private List<WebElement> quickleftNavlinks;

	@FindBy(xpath = "//div[@id='indepthpanel_left_panel']//a")
	private List<WebElement> indepthleftNavLinks;

	@FindBy(xpath = "//div[@id='AllfilterLinks']//a")
	private List<WebElement> FilterByLinks;

	@FindBy(xpath = "//span[@class='paginationTitle']")
	private WebElement PaginationTitle;

	@FindBy(xpath = "//span[@class='primaryText_all']")
	private List<WebElement> FilterClass;

	@FindBy(xpath = "//a[@title='Next Results Page']")
	private WebElement nextPage;

	public DrugLandingPage(WebDriver driver) throws IOException {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 50);
		try {
			wait.until(ExpectedConditions.visibilityOf(allResults));
		} catch (Exception e) {
			extentReport.FailWithException(driver, "AltMedPageVerification", "AltMedPage is not displayed", e);
			log.error("AltMedPage is not displayed");
		}
	}

	/**
	 * Use this method to verify the all results page is loaded
	 * 
	 * @return drug landing page
	 * @throws IOException
	 */

	public DrugLandingPage clickOnAllResultsTab() throws IOException {
		try {
			click(driver, "All results tab", allResults);
			isLoadingImageDisabled();
			extentReport.PASS("All results page verification", "All results page is loaded");
			log.info("All results page is loaded");
		} catch (Exception e) {
			extentReport.FailWithException(driver, "All results page verification", "All results page is not loaded",
					e);
			logERROR("All results page is not loaded", e);
		}

		return PageFactory.initElements(driver, DrugLandingPage.class);

	}

	/**
	 * Use this method to verify the In depth page is loaded
	 * 
	 * @return drug landing page
	 * @throws IOException
	 */

	public DrugLandingPage clickOnInDepthTab() throws IOException {
		try {
			click(driver, "Indepth answer tab", indepthPanelTab);
			isLoadingImageDisabled();
			extentReport.PASS("In depth page verification", "In depth answer page is loaded");
			log.info("Indepth answer page is loaded");
		} catch (Exception e) {
			extentReport.FailWithException(driver, "indepth result page verification",
					"In depth results page is not loaded", e);
			logERROR("Indepth results page is not loaded", e);
		}

		return PageFactory.initElements(driver, DrugLandingPage.class);

	}

	/**
	 * Use this method to verify the quick answer page is loaded the drugs as
	 * parameter
	 * 
	 * @throws IOException
	 */

	public void clickOnQuickTab() throws IOException {
		try {
			click(driver, "Quick answer tab", quickPanelTab);
			isLoadingImageDisabled();
			extentReport.PASS("Quick answer page verification", "Quick answer page is loaded");
			log.info("Quick answer page is loaded");
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Quick answer page verification", "Quick answer page is not loaded",
					e);
			logERROR("Quick answer page is not loaded", e);
		}
	}

	public void isLoadingImageDisabled() {
		WebDriverWait wait = new WebDriverWait(this.driver, 60);
		wait.until(ExpectedConditions.visibilityOf(loadingImage));
	}

	/**
	 * Use this method to verify the main header and sub headers of quick and in
	 * depth tab in drug landing page
	 * 
	 * @param TabName
	 *            = Pass the tab name such as in depth or quick answer tab
	 * @param term
	 *            =Pass the Main header of quick or indepth answer tab
	 * @param subHeaders
	 *            =Pass the sub header of corresponding main header
	 * @throws InterruptedException
	 * @throws IOException
	 */

	public boolean verifyLeftNavPaneMainandSubHeaders(String TabName, String term, String subHeaders)
			throws InterruptedException, IOException {
		boolean result = true;
		List<WebElement> WebElementCollection = null;
		String idValue = null;
		switch (TabName) {
		case "Indepth":
			WebElementCollection = new ArrayList<WebElement>(IndepthTabLeftpaneMainHeadings);
			idValue = "indepthpanel_taxonomy_panel";

			break;
		case "Quick":
			WebElementCollection = new ArrayList<WebElement>(QuickTabLeftpaneMainHeadings);
			idValue = "quickanspanel_taxonomy_panel";

			break;
		default:
			extentReport.FAIL(driver, "Verification of no tab is selected for searched drug",
					"Quick and indepth answer tabs are not selected from drug landing page");
			logERROR("Quick and indepth answer tabs are not selected from drug landing page");
		}
		int flag = 0;
		int HeaderCount = 0;

		for (WebElement heading : WebElementCollection) {

			HeaderCount = HeaderCount + 1;
			if (heading.getText().trim().contentEquals(term)) {
				flag = 1;
				Assert.assertTrue(heading.getText().equalsIgnoreCase(term));
				click(driver, "Main header from left navigation pane", heading);
				break;
			}

		}

		if (flag == 1) {

			String[] subHeaderValues = subHeaders.split(";");
			List<WebElement> subHeaderList = driver
					.findElements(By.xpath("//div[@id='" + idValue + "']/ul/li[" + HeaderCount + "]/ul/li/a"));
			for (WebElement subheading : subHeaderList) {
				if (subheading.getText().trim() == subHeaderValues.toString()) {
					flag = 1;
					click(driver, "Click on sub header", subheading);
					Thread.sleep(3000);
					Assert.assertTrue(subheading.getText().equalsIgnoreCase(subHeaders));
					break;
				}
			}
		}

		if (flag == 0) {
			extentReport.FAIL(driver, "Verification of main header and sub header of left navigation pane",
					subHeaders + " sub headers are not under the" + term + " Main header");
			logERROR(subHeaders + " sub headers are not under the" + term + " Main header");
			result = false;
			// break;
		}
		extentReport.PASS("Verification of main header and sub header of left navigation pane",
				subHeaders + " sub headers are present under the" + term + " Main header");
		log.info(subHeaders + " sub headers are present under the" + term + " Main header");
		return result;
	}

	/**
	 * Use this method to click on document title on all results page
	 * 
	 * @param docname
	 *            = Pass the document name to be clicked
	 * @return AllResultsDocumentPage
	 * @throws IOException
	 */

	public AllResultsDocumentPage isClickedDocumentdisplayed(String docname) throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(this.driver, 50000);
			wait.until(ExpectedConditions.visibilityOfAllElements(allResultsTitlelinks));
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Visibility of elements", "Expected elemets is not visibled", e);
			logERROR("Expected elemets is not visibled", e);
		}

		for (WebElement doclink : allResultsTitlelinks) {
			if (doclink.getText().equalsIgnoreCase(docname)) {
				click(driver, "Document link", doclink);
				break;
			}
		}
		AllResultsDocumentPage Alldocpage = PageFactory.initElements(driver, AllResultsDocumentPage.class);
		return Alldocpage;
	}

	/**
	 * Return a list of related results
	 * 
	 * @return
	 */
	public String getInDepthRelatedResults() {
		StringBuilder categories = new StringBuilder();
		String separator = "|";
		Iterator<WebElement> i = relatedResultsPanelForIndepth.iterator();
		while (i.hasNext()) {
			WebElement e = i.next();
			categories.append(e.getText());
			categories.append(separator);

		}
		// trim last separator
		if (categories.toString().endsWith("|")) {
			categories.deleteCharAt(categories.length() - 1);

		}
		return categories.toString();

	}

	/**
	 * Return a list of related results of Quick answer tab
	 * 
	 * @return
	 * @throws IOException
	 */
	public String getQuickAnswerRelatedResults() throws IOException {
		StringBuilder categories = new StringBuilder();
		String separator = "|";
		Iterator<WebElement> i = relatedResultsPanelForQuick.iterator();
		try {
			while (i.hasNext()) {
				WebElement e = i.next();
				categories.append(e.getText());
				categories.append(separator);

			}
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Getting the list of related results from quick answer tab ",
					"List of related results are not captured", e);
			logERROR("List of related results are not captured from quick answer tab", e);
		}
		try {
			// trim last separator
			if (categories.toString().endsWith("|")) {
				categories.deleteCharAt(categories.length() - 1);

			}
		} catch (Exception e) {
			extentReport.FailWithException(driver,
					"Deletion of seperator at end of the related results from quick answer tab",
					"Seperator is not deleted at the end of the related results", e);
			logERROR("Seperator is not deleted at the end of the related results", e);
		}

		return categories.toString();

	}

	/**
	 * Return a list of related results of In-depth answer tab
	 * 
	 * @return
	 * @throws IOException
	 */
	public String getIndepthAnswerRelatedResults() throws IOException {
		StringBuilder categories = new StringBuilder();
		String separator = "|";
		Iterator<WebElement> i = relatedResultsPanelForIndepth.iterator();
		try {
			while (i.hasNext()) {
				WebElement e = i.next();
				categories.append(e.getText());
				categories.append(separator);

			}
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Getting the list of related results from In-depth answer tab ",
					"List of related results are not captured", e);
			logERROR("List of related results are not captured from In-depth answer tab", e);
		}
		try {
			// trim last separator
			if (categories.toString().endsWith("|")) {
				categories.deleteCharAt(categories.length() - 1);

			}
		} catch (Exception e) {
			extentReport.FailWithException(driver,
					"Deletion of seperator at end of the related results from In-depth answer tab",
					"Seperator is not deleted at the end of the related results", e);
			logERROR("Seperator is not deleted at the end of the related results", e);
		}
		return categories.toString();

	}

	/**
	 * Return a list of related results of All Results tab
	 * 
	 * @return
	 * @throws IOException
	 */
	public String getAllAnswerRelatedResults() throws IOException {
		StringBuilder categories = new StringBuilder();
		String separator = "|";
		Iterator<WebElement> i = relatedResultsPanelForAllResults.iterator();
		try {
			while (i.hasNext()) {
				WebElement e = i.next();
				categories.append(e.getText());
				categories.append(separator);

			}
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Getting the list of related results from All answer tab ",
					"List of related results are not captured", e);
			logERROR("List of related results are not captured from In-depth answer tab", e);
		}
		try {
			// trim last separator
			if (categories.toString().endsWith("|")) {
				categories.deleteCharAt(categories.length() - 1);

			}
		} catch (Exception e) {
			extentReport.FailWithException(driver,
					"Deletion of seperator at end of the related results from All answer tab",
					"Seperator is not deleted at the end of the related results", e);
			logERROR("Seperator is not deleted at the end of the related results", e);
		}
		return categories.toString();

	}

	/**
	 * Use this method to verify the actual and expected related results are
	 * same of Quick answer or In-depth or All results tab
	 * 
	 * @param TabName
	 *            = Pass tab name (Quick answer, In-depth or All results tab)
	 * @param expectedResults
	 *            - Getting the list expected related results from user
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 *             ,IOException
	 */
	public void verifyRelatedResults(String TabName, String expectedResults) throws IOException {
		try {
			String actualResult = null;
			Thread.sleep(1000);
			switch (TabName) {
			case "Quick Answer":
				actualResult = getQuickAnswerRelatedResults();
				break;
			case "In-Depth Answer":
				actualResult = getIndepthAnswerRelatedResults();
				break;
			case "All Results":
				actualResult = getAllAnswerRelatedResults();
				break;
			}
			if (expectedResults.contains(actualResult)) {
				extentReport.PASS("Verification of related results sections in ToxResults Page", "For the tab" + TabName
						+ ": Links displayed below Related Results header are " + expectedResults);
				log.info("Links displayed below Related Results header are " + expectedResults);
			} else {
				extentReport.FAIL(driver, "Verification of related results sections in ToxResults Page", "For the tab"
						+ TabName + ": Links displayed below Related Results header are " + expectedResults);
				log.info("For the tab" + TabName + ": Links displayed below Related Results header are "
						+ expectedResults);
			}
		}

		catch (Exception e) {
			extentReport.FAIL(driver, "Verification of related results sections in ToxResults Page",
					"Links displayed below Related Results header are " + expectedResults);
			log.info("Links displayed below Related Results header are " + expectedResults);
		}
	}

	/**
	 * Use this method to verify the related results headings are displayed for
	 * Quick, In-depth and all results tab.
	 * 
	 * @param TabName=
	 *            To get the tab name
	 * @throws IOException
	 * @throws InterruptedException
	 *             ,IOException
	 */

	public void isRelatedResultsHeadingdisplayed(String TabName) throws IOException {
		WebElement Relatedresultheading = null;
		switch (TabName) {
		case "Quick Answer":
			Relatedresultheading = quickanswerRelatedResults;
			break;
		case "In-Depth Answer":
			Relatedresultheading = indepthRelatedResults;
			break;
		case "All Results":
			Relatedresultheading = allRelatedResults;
			break;
		}
		isElementDisplayed(driver, "Validation Of Related Results Header Name in ResultsPage", Relatedresultheading);
	}

	/**
	 * Return a list of headers and sub headers of Quick or In-depth answer tab
	 * 
	 * @return
	 * @throws IOException
	 */

	public String getResultOfLeftNavPaneMainandSubHeaders(String TabName, String term, String subHeaders)
			throws IOException {

		List<WebElement> WebElementCollection = null;
		String idValue = null;
		switch (TabName) {
		case "In-Depth Answer":
			WebElementCollection = new ArrayList<WebElement>(IndepthTabLeftpaneMainHeadings);
			idValue = "indepthpanel_taxonomy_panel";
			break;
		case "Quick Answer":
			WebElementCollection = new ArrayList<WebElement>(QuickTabLeftpaneMainHeadings);
			idValue = "quickanspanel_taxonomy_panel";
			break;
		}

		int HeaderCount = 0;
		for (WebElement heading : WebElementCollection) {
			HeaderCount = HeaderCount + 1;
			if (heading.getText().trim().contentEquals(term)) {
				break;
			}
		}

		StringBuilder categories = new StringBuilder();
		String separator = "\n";
		Iterator<WebElement> i = driver
				.findElements(By.xpath("//div[@id='" + idValue + "']/ul/li[" + HeaderCount + "]/ul/li/a")).iterator();

		try {
			while (i.hasNext()) {
				WebElement e = i.next();
				categories.append(e.getText());
				categories.append(separator);

			}
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Getting the list of sub headers list ",
					"List of sub headers are not captured", e);
			logERROR("List of sub headers are not captured", e);
		}
		try {
			// trim last separator
			if (categories.toString().endsWith("\n")) {
				categories.deleteCharAt(categories.length() - 1);

			}
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Deletion of seperator at end of the sub header list",
					"Seperator is not deleted at the end of the sub headers list", e);
			logERROR("Seperator is not deleted at the end of the sub headers list", e);
		}

		return categories.toString();
	}

	/**
	 * Use this method to verify the headers and sub headers of Quick answer or
	 * In-depth answer tab
	 * 
	 * @param TabName
	 *            = Pass tab name (Quick answer, In-depth or All results tab)
	 * @param term
	 *            = Pass the header of Quick or In-depth answer tab
	 * @param subHeaders
	 *            =Pass the sub headers of the corresponding header of quick or
	 *            In-depth answer tab
	 * @throws IOException
	 * @throws InterruptedException
	 *             ,IOException
	 */

	public void verifyHeaderAndSubheader(String TabName, String term, String subHeaders) throws IOException {
		switch (TabName) {
		case "Quick Answer":
			String headerAndSubheaderDisplayForQuickAnswer = getResultOfLeftNavPaneMainandSubHeaders(TabName, term,
					subHeaders);
			try {
				Assert.assertEquals(headerAndSubheaderDisplayForQuickAnswer, subHeaders);
				extentReport.PASS("Verification of header and sub headers display for searched drug",
						"Header and sub headers are displayed as expected in quick answer tab, " + "Header: " + term
								+ " Subheaders: " + subHeaders);
				log.info("Header and sub headers are displayed as expected in quick answer tab, " + "Header: " + term
						+ " Subheaders: " + subHeaders);
			} catch (Exception e) {
				e.printStackTrace();
				extentReport.FAIL(driver, "Verification of header and sub headers display for searched drug",
						"Header and sub headers are displayed as expected in quick answer tab, " + "Header: " + term
								+ " Subheaders: " + subHeaders);
				logERROR("Header and sub headers are displayed as expected in quick answer tab, " + "Header: " + term
						+ " Subheaders: " + subHeaders);
			}
			break;
		case "In-Depth Answer":
			String headerAndSubheaderDisplayForIndepthAnswer = getResultOfLeftNavPaneMainandSubHeaders(TabName, term,
					subHeaders);
			try {
				Assert.assertEquals(headerAndSubheaderDisplayForIndepthAnswer, subHeaders);
				extentReport.PASS("Verification of header and sub headers display for searched drug",
						"Header and sub headers are displayed as expected in In-depth answer tab, " + "Header: " + term
								+ " Subheaders: " + subHeaders);
				log.info("Header and sub headers are displayed as expected in In-depth answer tab, " + "Header: " + term
						+ " Subheaders: " + subHeaders);
			} catch (Exception e) {
				e.printStackTrace();
				extentReport.FAIL(driver, "Verification of header and sub headers display for searched drug",
						"Header and sub headers are displayed as expected in Indepth answer tab, " + "Header: " + term
								+ " Subheaders: " + subHeaders);
				logERROR("Header and sub headers are displayed as expected in Indepth answer tab, " + "Header: " + term
						+ " Subheaders: " + subHeaders);
			}

		}
	}

	/**
	 * Use this method to verify the drug header in drug results page by passing
	 * the drugs as parameter
	 * 
	 * @param drugHeaderOne,
	 *            drugHeaderTwo = Passing the drug headers as a parameters
	 * @throws IOException
	 */

	public void verifyDrugHeadersInDrugResultPage(String drugHeader) throws IOException {
		try {

			Assert.assertTrue(mainDrugHeading1.getText().equalsIgnoreCase(drugHeader));
			extentReport.PASS("Verification of Drug header in drug results page",
					drugHeader + " is displayed in drug results page");
			log.info(drugHeader + " isdisplayed in drug results page");
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Verification of Drug headers in drug results page",
					drugHeader + " is not displayed in drug results page", e);
			logERROR(drugHeader + " is not displayed in drug results page", e);
		}

	}

	/**
	 * Use this method to verify the Topic header in drug results page by
	 * passing the drugs as parameter
	 * 
	 * @param TabName
	 *            = Pass the TabName (Quick Answer, In-depth)
	 * @param getTopicHeader
	 *            = Pass the expected topic header name to compare with actual
	 *            actual topic header of drug
	 * @throws IOException
	 */

	public void verifyTopicHeadersInDrugResultPage(String TabName, String getTopicHeader) throws IOException {
		WebElement drugTopicheading = null;
		switch (TabName) {
		case "Quick":
			drugTopicheading = topicHeaderForQuick;
			break;
		case "In-Depth":
			drugTopicheading = topicHeaderForIndepth;
			break;
		}
		try {

			Assert.assertTrue(drugTopicheading.getText().equalsIgnoreCase(getTopicHeader));
			extentReport.PASS("Verification of Drug header in drug results page",
					getTopicHeader + " is displayed in drug results page");
			log.info(getTopicHeader + " is displayed in drug results page");
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Verification of Drug headers in drug results page ",
					getTopicHeader + "is not displayed in drug results page", e);
			logERROR(getTopicHeader + " is not displayed in drug results page ", e);
		}
	}

	/**
	 * Use this method to verify the content displayed for headers and sub
	 * headers of Quick Answer tab by passing the header and sub headers
	 * 
	 * @param leftNavHeader
	 *            = Pass header under the quick answer tab
	 * @param leftNavsubHeader
	 *            = Pass the sub header for corresponding header
	 * @throws IOException
	 */

	public boolean isContentdisplayedForQuickAnswerTab(String leftNavHeader, String leftNavsubHeader)
			throws IOException {
		for (WebElement e : quickLeftNav) {
			if (e.getText().contentEquals(leftNavsubHeader)) {
				click(driver, "Alt Med HomePage Sub header Validation", e);
				break;
			}
		}
		if (quickPageheader.getText().contentEquals(leftNavHeader)
				&& quickPagesubheader.getText().contentEquals(leftNavsubHeader)) {
			extentReport.PASS(
					"Verification of content displayed for corresponding headers and sub headers of Quick Answer tab",
					"Contents are displayed under the " + leftNavsubHeader + " of Quick Answer tab");
			log.info("Contents are displayed under the " + leftNavsubHeader + " of Quick Answer tab");
			return true;
		} else {
			extentReport.FAIL(driver,
					"Verification of content displayed for corresponding headers and sub headers of Quick Answer tab",
					"Contents are displayed under the " + leftNavsubHeader + " of Quick Answer tab");
			logERROR("Contents are displayed under the " + leftNavsubHeader + " of Quick Answer tab");
			return false;
		}
	}

	/**
	 * Use this method to verify the content displayed for headers and sub
	 * headers of In depth tab by passing the header and sub headers
	 * 
	 * @param leftNavHeader
	 *            = Pass header under the In depth answer tab
	 * @param leftNavsubHeader
	 *            = Pass the sub header for corresponding header
	 * @throws IOException
	 */

	public boolean isContentdisplayedForInDepthAnswerTab(String leftNavHeader, String leftNavsubHeader)
			throws IOException {
		for (WebElement e : IndepthLeftNav) {
			if (e.getText().contentEquals(leftNavsubHeader)) {
				click(driver, "Sub header", e);
				break;
			}
		}
		if (IndepthPageHeader.getText().contentEquals(leftNavHeader)
				&& IndepthPagesubheader.getText().contentEquals(leftNavsubHeader)) {
			extentReport.PASS(
					"Verification of content displayed for corresponding headers and sub headers of Indepth Answer tab",
					"Contents are displayed under the " + leftNavsubHeader + " of Indepth Answer tab");
			log.info("Contents are displayed under the " + leftNavsubHeader + " of Indepth Answer tab");
			return true;
		}

		else {
			extentReport.FAIL(driver,
					"Verification of content displayed for corresponding headers and sub headers of Indepth Answer tab",
					"Contents are not displayed under the " + leftNavsubHeader + " of Indepth Answer tab");
			logERROR("Contents are not displayed under the " + leftNavsubHeader + " of Indepth Answer tab");
			return false;
		}
	}

	/**
	 * Use this method to verify the content displayed for filter of All results
	 * by passing the filter term
	 * 
	 * @param filterTerm
	 *            = Pass filter term to click and verify the content and count
	 *            of that
	 * @throws IOException,
	 *             InterruptedException
	 */

	public boolean verifyFilteringContentOfAllResultsTab(String filterTerm) throws InterruptedException, IOException {
		boolean flag = true;
		String[] TermandCount, PaginationSplit, pagecount;
		String value = null;
		int totalPages = 0, page = 0;
		for (WebElement ele : FilterByLinks) {
			TermandCount = ele.getText().split(" ");
			if (ele.getText().contains(filterTerm)) {
				value = TermandCount[TermandCount.length - 1].substring(1,
						(TermandCount[TermandCount.length - 1].length()) - 1);
				ele.click();
				break;
			}
		}
		PaginationSplit = PaginationTitle.getText().split(" ");
		if (PaginationSplit[5].trim().contentEquals(value)) {
			pagecount = PaginationSplit[3].split("-");
			totalPages = (int) Math.ceil(Double.parseDouble(value) / 15);
			page = Integer.parseInt(pagecount[1]) / 15;
			while (page <= totalPages) {
				for (WebElement e : FilterClass) {
					if (!e.getText().contains(filterTerm)) {
						flag = false;
						break;
					}
				}
				if (!flag || page == 0) {
					break;
				}

				page++;

				if (page <= totalPages) {
					if ((page % 5) == 1 && nextPage.isEnabled()) {
						nextPage.click();
					}
					driver.findElement(By.xpath("//a[@title='Page " + page + "']")).click();
				}
				PaginationSplit = PaginationTitle.getText().split(" ");
				pagecount = PaginationSplit[3].split("-");
			}
			extentReport.PASS(
					"Verification of content availability and functionality of navigation pane of All results tab",
					"Contents are displayed under the " + filterTerm + " of All results tab");
			log.info("Contents are displayed under the " + filterTerm + " of All results tab");
		}

		else {
			flag = false;
			extentReport.FAIL(driver,
					"Verification of content availability and functionality of navigation pane of All results tab",
					"Contents are not displayed under the " + filterTerm + " of All results tab");
			logERROR("Contents are not displayed under the " + filterTerm + " of All results tab");
		}
		return flag;
	}

}
