package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.NeoFaxUtility;
import com.ibm.webapp.utils.Selenese;


public class EnteralFormulaPage extends Selenese
{
	   WebDriver driver;
	   private WebDriverWait webDriverwait;
	   @FindBy(xpath = "//label[@class='displayFormulaBlock']")
	   private WebElement displayFormat;
	   
	   @FindBy(xpath = "//input[@type='button'][@title='Clear']")
	   public WebElement btn_Clear;
	   
	   @FindBy(id = "neoFormulaList")
	   public WebElement formulas_neo;
	   
	   @FindBy(id = "pedFormulaList")
	   public WebElement formulas_ped;
	   
	   @FindBy(id = "selectedFormulas")
	   private WebElement formulas_selected;
	   
	   @FindBy(xpath = "//select[@id='selectedFormulas']/option")
	   private List<WebElement> formulaSelected;
	   	  
	   @FindBy(xpath = "//input[@title='Adds Formula']")
	   private WebElement btn_Add;
	   
	   @FindBy(xpath = "//input[@title='Removes Formula']")
	   private WebElement btn_Remove;
	 
	   
	  @FindBy(id = "productfield")
	   public WebElement btn_ProductNote;
	   
	   @FindBy(id = "displayfield")
	   public WebElement btn_Display;
	   
	   @FindBy(id = "//div[@id='nutrientResultsDiv']//tr")
	   private List<WebElement> nutrientTable;
	   
	   @FindBy(xpath = "//div[@id='nutrientResultsDiv']//thead[@class='NFTableHeader']/tr[2]/td[position()>1]")
	   private List<WebElement> FormulaHeader;
	   
	   @FindBy(xpath = "//div[@id='nutrientResultsDiv']//thead[@class='NFTableHeader']/tr[2]/td")
	   private List<WebElement> DisplayFormatHeader;
	   
	  /* @FindBy(xpath = "//table[@style='display: table;']//span[contains(@id,'strFormulaName')]")
	   private List<WebElement> productNotesHeader;*/
	   @FindBy(xpath = "//table[@style='display: table;']//*[contains(@id,'strFormulaName')]")
	   private List<WebElement> productNotesHeader;
	 
	   
	   @FindBy(id = "cancelButtonId")
	   public WebElement btn_Close;
	   
	   @FindBy(id = "productNotesPopup_title")
	   public WebElement productNotesTitle;
	   
	   @FindBy(id = "selectFormulaPopup_title")
	   private WebElement alertHeader;
	   
	   @FindBy(id = "popupContentDIV")
	   private WebElement alertContent;
	   
	   /**
	    * Default Constructor for DrugMonograph class
	    */
	   public EnteralFormulaPage(WebDriver driver)
	   {
	      this.driver = driver;
	      PageFactory.initElements(this.driver, this);
	      webDriverwait = new WebDriverWait(this.driver, 25);
	      webDriverwait.until(ExpectedConditions.visibilityOf(displayFormat));
	   }
	     
	   
	   
	   /**
	    * 
	    * @returns NeofaxHeaderPage
	    */
	   public NeoFaxUtility getNeofaxUtility()
	   {
	      return PageFactory.initElements(driver, NeoFaxUtility.class);
	      
	   }
	   
	   /**
	    * Clicks ProductNotes button in the Enteral Formula Page
	    * 
	    */
	   public void clickClearButton()
	   {
	      try
	      {
	         click(driver, "Clear button",btn_Clear);
	         Thread.sleep(2000);
	      }

	      catch (Exception e)
	      {
	         e.printStackTrace();
	      }
	   }
	   
	   /**
	    * Selects the radio button based on the given name
	    * @param displayFormatName
	 * @throws IOException 
	    */
	   public void selectRadio(String displayFormatName) throws IOException
	   {
		   try{
		  waitForElementVisibility(driver, btn_Clear);
	       driver.findElement(By.xpath("//label[@class='displayFormulaBlock'][@title='"+displayFormatName+ "']")).click();
	       extentReport.PASS("Select radio button in enteral formula page",
	    		   displayFormatName+" is clicked");
			 log.info(displayFormatName+" is clicked");
		   }
		   catch(Exception e){
			   extentReport.FailWithException(driver,"User guide window handling",displayFormatName+" is not clicked",e);
		          logERROR(displayFormatName+" is not clicked", e);
		   }
	   }

	   /**
	    * Selects the formulas from Formulas Available Box
	    * @param tabName = to be given as neo OR ped
	    * @param formulaToClick = enter the formulaName which has to be selected
	    * returns true if the selected formula is clickable
	    * returns false if the selected formula is not clickable
	 * @throws IOException 
	    */
	   public boolean selectFormula(String tabName, String formulaToClick) throws IOException
	   {
	      try
	      {
	         WebElement formulaList ;
	         if(tabName.equalsIgnoreCase("neo")) {
	            formulaList = formulas_neo;
	         }
	         else {
	            formulaList = formulas_ped;
	         }
	         Select drugList = new Select(formulaList);
	         drugList.selectByVisibleText(formulaToClick);
	         click(driver, "Add formula", btn_Add);
	         int i=0;
	         while(formulasSelectedCount()==0 && i<5) {
	        	 click(driver, "Add formula", btn_Add);
	            i++;
	         }
	         extentReport.PASS("Selects the formulas from Formulas Available Box",
	        		 formulaToClick+" is selected");
	 		 log.info(formulaToClick+" is selected");
	         return true;
	      }
	      catch (Exception e)
	      {
	    	  extentReport.FailWithException(driver,"Selects the formulas from Formulas Available Box",formulaToClick+" are not selected",e);
	          logERROR(formulaToClick+" are not selected", e);
	         e.printStackTrace();
	      }

	      return false;
	   }
	   
	   /**
	    * Verifies the added formula count in formulas selected box.
	    * returns 0 if the selected formula box is empty.
	    * or returns >0 if the selected formula box contains some formulas.
	    * @throws InterruptedException 
	    */
	   public int formulasSelectedCount() throws InterruptedException
	   {
	      Thread.sleep(1500);
	      JavascriptExecutor js = (JavascriptExecutor)driver;
	      return Integer.parseInt(js.executeScript("return document.getElementById('selectedFormulas').length").toString());
	   }
	   
	   
	   /**
	    * Clicks Display button in the Enteral Formula Page
	    * 
	    */
	   public void clickDisplayButton()
	   {
	      try
	      {
	         click(driver, "Display button",btn_Display);
	      }

	      catch (Exception e)
	      {
	         e.printStackTrace();
	      }

	   }
	   
	   /**
	    * Verifies the added formula in formulas selected box is displayed
	    * in the nutrient info table.
	    * Also validates the formula order b/w the 
	    * nutrient info table & formulas selected box
	    * @param expectedFormulaValue = pass the expected formula Name in string array format
	    * @param NutrientHeaderOrProductNotesHeader = enter Nutrient to validate the formula Name in Nutrient table
	    *  or enter ProductNotes to validate the formulaName in productnotes pop-up.
	 * @throws IOException 
	    * 
	    * @returns true if the formulasSelected and formulasDisplayed in 
	    * nutrient info table is matched.
	    * 
	    * @returns false if the formula order is not matched or 
	    * if formulaSize is mismatching.
	    */
	   public boolean verifySelectedFormulaName(String[] expectedFormulaValue, String NutrientHeaderOrProductNotesHeader) throws IOException
	   {
	      try
	      {
	         List<WebElement> formulaNameList = new ArrayList<WebElement>();
	         if(NutrientHeaderOrProductNotesHeader.equalsIgnoreCase("Nutrient")) {
	            formulaNameList =FormulaHeader;
	         }
	         else {
	            formulaNameList =productNotesHeader;
	         }
	         if(!(expectedFormulaValue.length==formulaNameList.size())){
	            return false;
	         }
	         for(int i=0; i< formulaNameList.size(); i++) {
	            if(!(formulaNameList.get(i).getText().equals(expectedFormulaValue[i])))
	            {
	               return false;
	            }
	         }
	         extentReport.PASS("Verification of added formula in formulas selected box is displayed in the nutrient info table",
	                 "Expected formulas are added in the nutrient info table");
	 		 log.info("Expected formulas are added in the nutrient info table");
	      }

	      catch (Exception e)
	      {
	    	  extentReport.FailWithException(driver,"Verification of added formula in formulas selected box is displayed in the nutrient info table","Expected formulas are not added in the nutrient info table",e);
	          logERROR("Expected formulas are not added in the nutrient info table", e);
	         e.printStackTrace();
	         return false;
	      }
	      return true;
	   }
	   
	   
	   /**
	    * Verifies the added formula in formulas selected box is displayed
	    * in the nutrient info table.
	    * Also validates the formula order b/w the 
	    * nutrient info table & formulas selected box
	    * @param expectedDisplayFormat = pass the expectedDisplayFormat
	    * ex: Per100Cal or PerLiter or PerBoth
	 * @throws IOException 
	    * 
	    * @returns true if the formulasSelected and formulasDisplayed in 
	    * nutrient info table is matched.
	    * 
	    * @returns false if the formula order is not matched or 
	    * if formulaSize is mismatching.
	    */
	   public boolean formatToBeDisplayed(String expectedDisplayFormat, int addedFormulaCount) throws IOException
	   {
	      try
	      {
	         int formatCount = 0;
	         switch (expectedDisplayFormat)
	         {
	            case "Per 100 Cal":
	               formatCount = driver.findElements(By.xpath("//thead[@class='NFTableHeader']/"
	                     + "tr[3]/td[.=' Per 100 cal']")).size();
	               break;
	               
	            case "Per Liter":
	               formatCount = driver.findElements(By.xpath("//thead[@class='NFTableHeader']/"
	                     + "tr[3]/td[.=' Per Liter']")).size();
	               break;

	            case "Per Both":
	               formatCount = driver.findElements(By.xpath("//thead[@class='NFTableHeader']/tr[3]/"
	                     + "td[text()=' Per 100 cal' or text() =' Per Liter']")).size();
	               addedFormulaCount = 2 * addedFormulaCount;
	               break;

	         }
	         if (!(formatCount == addedFormulaCount))
	         {
	        	
	            return false;
	         }
	         extentReport.PASS("Verification of selected formulas and formulas Displayed in nutrient info table is matched.",
	                 "Selected formulas and formulas Displayed in nutrient info table is matched.");
	 		 log.info( "Selected formulas and formulas Displayed in nutrient info table is matched.");
	      }

	      catch (Exception e)
	      {
	    	  extentReport.FailWithException(driver,"Verification of selected formulas and formulas Displayed in nutrient info table is matched.","Selected formulas and formulas Displayed in nutrient info table is not matched.",e);
	          logERROR("Selected formulas and formulas Displayed in nutrient info table is not matched.", e);
	         e.printStackTrace();
	         return false;
	      }
	      return true;
	   }
	   
	   
	   /**
	    * Clicks ProductNotes button in the Enteral Formula Page
	    * 
	    */
	   public void clickProductNotesButton()
	   {
	      try
	      {
	         btn_ProductNote.click();
	         Thread.sleep(2000);
	      }

	      catch (Exception e)
	      {
	         e.printStackTrace();
	      }
	   }



	   /**
	    * Use to switch windows to a newly opened window
	    * @param windowName
	    */
	   
	   //this method fails until dev adds doctype in ProductnoTes.html page
	   public void switchWindowTo(String windowName) {
	      
	      String parentWindow = null;
	      try
	      {
	         // Switch to new window opened
	         Thread.sleep(2000);
	         ArrayList<String> tabWindow = new ArrayList<String>(driver.getWindowHandles());
	         driver.switchTo().window(tabWindow.get(1));	       
	       
	        WebElement title = driver.findElement(By.xpath("/html/head/title"));
	        System.out.println(title.getText());
	        /** if (title.getText().contains(windowName))
	         {
	            driver.switchTo().window(windowName);
	         }*/
	      }

	      catch (Exception e)
	      {
	         e.printStackTrace();
	         driver.close();
	         driver.switchTo().window(parentWindow);
	      }
	      
	   }
}
