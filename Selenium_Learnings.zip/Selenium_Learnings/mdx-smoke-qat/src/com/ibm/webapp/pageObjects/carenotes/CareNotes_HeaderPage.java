package com.ibm.webapp.pageObjects.carenotes;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.utils.Selenese;

public class CareNotes_HeaderPage extends Selenese {
	WebDriver driver;

	@FindBy(xpath = "//a[contains(text(),'LOGOUT')]")
	private WebElement logoutLink;

	public CareNotes_HeaderPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	/**
	 * method to log out of the application
	 * 
	 * 
	 */
	public void logout() {
		logoutLink.click();
	}

}
