package com.ibm.webapp.pageObjects.mdx;


import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * @author APeavy
 * 
 */
public class DrugInteractionsSingleResultsPageForWatson  {
	private final WebDriver driver;
	
	@FindBy(xpath = "/html/body/div[8]/div/div[2]/table[1]/tbody/tr[4]/td[1]/div/a")
//	@FindBy(xpath = "/html/body/div[8]/div/div[2]/div[4]/div/div[2]/div")
	private WebElement weakXpathForFirstDrugDrugIntSummary;
	
//	@FindBy(xpath = "//*[@id='modifyButton']")
	@FindBy(xpath = "/html/body/div[8]/div/div[2]/div[4]/div/div[2]/form/button")
	private WebElement modifyButton;
	
	@FindBy(xpath = "//*[@id='lbNoDrugs_title']")
	private WebElement minimumDrugsMessage;
	
	@FindBy(xpath = "/html/body/div[33]/div[2]/div/div[2]/input")
	private WebElement closeMinDrugBtn;
	
	@FindBy(id = "btnSubmit2")
	private WebElement severityUpdateBtn;
	
	@FindBy(xpath = "//*[@id='lbNoItemSelectedInteractions_title'] ")
	private WebElement	noItemsSelectedMessage;
	
	@FindBy(xpath = "/html/body/div[35]/div[2]/div/div[2]/input")
	private WebElement closeNoItemsSelectedBtn;
	
	@FindBy(id = "quickanspanel_taxonomy_paneldruginteractions")
	private WebElement singleInteractionLink;
	
	@FindBy(xpath = "/html/body/div[8]/div/div[2]/div[6]/div[2]")
	protected List<WebElement> jumpToLinks;

//	@FindBy(xpath = "//div[@id='REDESIGNalphaJumpBar']//li[@class='enabledItem']")
//	protected List<WebElement> jumpToLetters;
	
	@FindBy(xpath = "//div[@id='refineMultiInteractions']//div[@class='pageTitle inline']")
	private WebElement drugInteractionsSinglePageTitle;

	@FindBy(id = "tdDrugName")
	private WebElement drugInteractionstdDrugName;

	@FindBy(id = "singleDrugName")
	private WebElement drugInteractionssingleDrugName;

	public DrugInteractionsSingleResultsPageForWatson(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		wait.until(ExpectedConditions.visibilityOf(drugInteractionsSinglePageTitle));
	}
	
	
   public String verifySingleDrugInteractionName(String drugName)
   {
      String result = "PASS";
      try
      {
         drugName = drugName.substring(drugName.lastIndexOf("for") + 4);
         String drugTitle = drugInteractionstdDrugName.getText();
         if (drugTitle.endsWith("..."))
         {
            drugTitle = drugInteractionssingleDrugName.getAttribute("title");
            if (drugTitle.endsWith("."))
            {
               drugTitle = drugTitle.substring(0, drugTitle.length() - 1);
            }
         }
         
         if (!("Drug Interaction Results"
               .equals(drugInteractionsSinglePageTitle.getText())
               && drugName.equals(drugTitle)))
         {
            result = "FAIL";
            System.out.println(drugName
                  + " drug is not present in the DrugInteractions Results Page");
         }
      }
      catch (Exception e)
      {
         result = "FAIL";
         e.printStackTrace();
      }
      return result;
   }
   
}
