package com.ibm.webapp.pageObjects.formularyadmin;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class FormularyAdmin_HomePage extends Selenese {
	private final WebDriver driver;

	@FindBy(id = "formularyList_index_0")
	private WebElement formularySelectionBox;

	@FindBy(id = "PFFormActionId_formularyadmin.CreateSetup")
	private WebElement createNew;

	@FindBy(linkText = "4. Publish")
	private WebElement publishlnk;

	@FindBy(xpath = "//img[@title='Return to Micromedex Gateway']")
	private WebElement micromedexTitle;

	@FindBy(xpath = "//table[@id='Navigation']/tbody/tr[2]/td/table/tbody/tr/td[1]/div/a[3]/img") 
	private WebElement linkPharmacyInfo;

	@FindBy(xpath = "//img[@title='Log Out']")
	private WebElement logoutLnk;

	@FindBy(id = "PFFormActionId_formularyadmin.HomeSelectTranslator")
	private WebElement formularySelectBtn;

	public FormularyAdmin_HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		wait.until(ExpectedConditions.visibilityOf(formularySelectionBox));
	}

	/**
	 * click on create new
	 * 
	 * @return settings page
	 */
	public FormularyAdmin_SettingsPage clickOnCreateNew() {
		createNew.click();
		FormularyAdmin_SettingsPage setpage = PageFactory.initElements(driver, FormularyAdmin_SettingsPage.class);
		return setpage;
	}

	/**
	 * click on Publish tab in formulary admin
	 * 
	 * @return publish page object
	 */
	public FormularyAdmin_PublishPage clickOnPublish() {
		// publishlnk.sendKeys(Keys.ENTER);
		try {
			keyBoardClick(driver, "Publish", publishlnk);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		FormularyAdmin_PublishPage publishPage = PageFactory.initElements(driver, FormularyAdmin_PublishPage.class);
		return publishPage;
	}

	/**
	 * click on My Micromedex Gateway
	 */
	public void clickmicromedexTitle() {
		// micromedexTitle.click();
		try {
			click(driver, "My Micromedex Gateway", micromedexTitle);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * click on Pharmacy Info
	 * 
	 * @return sections page object
	 */
	public FormularyAdmin_SectionsPage clickOnPharmacyInformation() {

		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", linkPharmacyInfo);
		FormularyAdmin_SectionsPage pip = PageFactory.initElements(driver, FormularyAdmin_SectionsPage.class);
		return pip;
	}

	public FormularyAdmin_EditListPage selectFormulary(String formularyName) {
		Select formSelect = new Select(formularySelectionBox);
		List<WebElement> allOptions = formSelect.getOptions();
		for (WebElement opt : allOptions) {
			if (opt.getText().contains(formularyName)) {
				formSelect.selectByValue(opt.getAttribute("value"));
				if (opt.getText().contains("Published"))
				break;
			}
		}
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("window.showModalDialog = window.openWindow;");
		executor.executeScript("arguments[0].click();", formularySelectBtn);
		FormularyAdmin_EditListPage editListPage = PageFactory.initElements(driver, FormularyAdmin_EditListPage.class);
		return editListPage;
	}

	/**
	 * Click the logout link
	 * 
	 * @throws IOException
	 */
	public void logout() throws IOException {
		click(driver, "Log Out", logoutLnk);
	}

}
