package com.ibm.webapp.pageObjects.carenotes;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.utils.Selenese;

public class CareNotes_HotlistPage extends Selenese {
	protected final WebDriver driver;

	@FindBy(xpath = "//strong[contains(text(),'Hot Lists')]")
	private WebElement hotlistCaption;

	@FindBy(xpath = "//table/tbody/tr[3]/td/table[2]/tbody/tr/td/strong")
	private WebElement hotlistCaption1;

	@FindBy(id = "LocationList_index_0")
	private WebElement location;

	@FindBy(xpath = "/html/body/table/tbody/tr[3]/td/table[2]/tbody/tr/td/table[2]/tbody/tr[2]/td/table[1]/tbody/tr/td[1]/a[2]")
	private WebElement firstHotListLink;

	public CareNotes_HotlistPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	/**
	 * clicks on the first hotlist in the hot lists page in carenotes
	 */
	public void clickFirstHotList() {
		try {
			click(driver, "click first hotlist link", firstHotListLink);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// firstHotListLink.click();

	}

	public CareNotes_HeaderPage getHeaderPage() {
		CareNotes_HeaderPage headerPage = PageFactory.initElements(driver, CareNotes_HeaderPage.class);
		return headerPage;
	}

}
