package com.ibm.webapp.pageObjects.sso;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class MyAthensDashboardPage extends Selenese {
	WebDriver driver;

	@FindBy(xpath = "//a[text() = 'Truven Health Analytics Micromedex INT']")
	private WebElement intResourcesLink;

	@FindBy(xpath = "//a[text() = 'IBM Micromedex QA']")
	private WebElement qaResourcesLink;

	@FindBy(xpath = "//a[text() = 'IBM Micromedex PRE']")
	private WebElement preResourcesLink;

	@FindBy(xpath = "//a[text() = 'Truven Health Production']")
	private WebElement mdxResourcesLink;

	@FindBy(xpath = "//span[contains(text(),'Sign out')]")
	private WebElement logoutLink;

	@FindBy(xpath = "//*[@id=\"main-content\"]/div/h1")
	private WebElement DashboardHeader;

	public MyAthensDashboardPage(WebDriver driver) throws IOException {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		try {
			wait.until(ExpectedConditions.visibilityOf(DashboardHeader));
		} catch (Exception e) {
			extentReport.FAIL(driver, "Open Athens LoginPage", "OPen Athens Home Page not displayed");
			log.error("OPen Athens Home Page not displayed");
		}
	}

	/**
	 * Use this method to verify if MyAthens dashboard is displayed,
	 * 
	 * @throws IOException
	 */
	public void isDashboardPageDisplayed() throws IOException {
		try {
			if (driver.getTitle().equalsIgnoreCase("MyAthens: Home")) {
				extentReport.PASS("MyAthens Home Page Verification", "MyAthens Home Page is displayed correctly");
			} else {
				extentReport.FAIL(driver, "MyAthens Home Page Verification", "MyAthens Home Page is not displayed");
			}
		} catch (Exception e) {
			extentReport.FAIL(driver, "MyAthens Home Page Verification",
					"MyAthens Home Page is not displayed- Some Exception occured");
		}

	}

	/**
	 * Use this method to log out of the application,
	 * 
	 * @throws IOException
	 */
	public void LogOut() throws IOException {
		click(driver, "Sign out", logoutLink);
	}

}
