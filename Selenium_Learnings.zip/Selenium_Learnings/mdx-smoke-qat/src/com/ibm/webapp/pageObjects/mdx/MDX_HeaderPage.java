package com.ibm.webapp.pageObjects.mdx;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.pageObjects.drugid.DrugIDPage;

/**
 * @author APeavy
 * 
 */
public class MDX_HeaderPage {
	private final WebDriver driver;

	// top navigation links

	// @FindBy(linkText = "My Subscription")
	@FindBy(xpath = "//a[@title = 'My Subscription']")
	private WebElement mySubscriptionLink;

	@FindBy(linkText = "Gateway")
	private WebElement gatewayLink;

	// @FindBy(linkText = "Logout")
	@FindBy(xpath = "//a[contains(@href,'pf.Logout')]")
	private WebElement logoutLink;

	// toolbar elements

	@FindBy(id = "header")
	private WebElement headerDiv;

	@FindBy(xpath = "//div[@id='header']//div[contains(@class,'menuItem')]")
	private List<WebElement> toolbarDivs;

	@FindBy(xpath = "//*[@id='homeLink']")
	private WebElement homeToolbarLink;

	// @FindBy(xpath = "//div[@id='header']/div[contains(@onclick,
	// 'pf.HomePage')]")
	@FindBy(xpath = "//div[@id='header']/div[@id='tbOpt_Home']")
	private WebElement homeToolbarBackground;

	@FindBy(xpath = "//div[@id='header']/div/div/a[contains(@href, 'AdvDrugSearch')]")
	private WebElement advancedSearchToolbarLink;

	// @FindBy(xpath = "//*[@id='drugIdToolLink']")
	@FindBy(xpath = "//a[contains(text(),'Drug ID')]")
	private WebElement drugIdentificationToolbarLink;

	@FindBy(xpath = "//div[@id='header']/div[contains(@onclick, 'FindADrugByPillImprint')]")
	private WebElement drugIdentificationToolbarBackground;

	// @FindBy(xpath = "//div[@id='tbOpt_PS']/div[@id='Prod_Search']/a")
	@FindBy(xpath = "//div[@id='header']/div/div/a[contains(text(),'Tox & Drug\nProduct Lookup')]")
	private WebElement productSearchToolbarLink;

	// @FindBy(xpath = "//div[@id='header']/div/div/a[contains(text(),'Tox &
	// Drug')]")
	@FindBy(xpath = "/html/body/div[14]/table/tbody/tr[2]/td[2]")
	private WebElement toxAndDrugToolbarLink;

	@FindBy(xpath = "//div[@id='header']/div[contains(@onclick, 'ProductSearch')]")
	private WebElement toxAndDrugToolbarBackground;

	// @FindBy(xpath = "//div[@id='header']//div[contains(@id,'tbOpt')]")
	@FindBy(xpath = "//div[@id='header']/div/div/a")
	private List<WebElement> toolbarElements;

	@FindBy(xpath = "//div[@id='header']//div[contains(@id,'tbOpt')]//a")
	private List<WebElement> toolbarLinkTexts;

	// @FindBy(xpath = "//span[@id='dijit_form_DropDownButton_0_label']")
	@FindBy(xpath = "//span[@id='comboBtn_label']")
	private WebElement otherToolsDropDownLink;

	@FindBy(xpath = "//table[@id='othItems']//tr")
	private List<WebElement> otherToolsRows;

	@FindBy(xpath = "//div[@id='header']/div[@id='tbOpt_MT']")
	private WebElement otherToolsDropDownBackground;

	@FindBy(xpath = "//table[@id='othItems']//td[contains(@class,'dijitMenuItemLabel')]")
	private List<WebElement> otherToolsTextItems;

	@FindBy(xpath = "//a[contains(text(),'Tox & Drug')]")
	private WebElement thiasToxandProductMenu;

	@FindBy(xpath = "//table[@id='othItems']/tbody/tr/td[contains(text(),'Tox & Drug')]/..")
	private WebElement otherToolsToxAndDrugBackground;

	@FindBy(xpath = "//table[@id='othItems']/tbody/tr/td[contains(text(),'Calculators')]/..")
	private WebElement otherToolsCalculatorsBackground;

	// end toolbar elements

	@FindBy(id = "norwayHeaderImage")
	private List<WebElement> helsibiblioteketImages;

	@FindBy(id = "IntSearchWordWheel_SearchTerm_index_0")
	private WebElement searchBox;

	@FindBy(id = "inputSearchTermBoxLarge_enhance")
	private WebElement searchBoxDiv;

	@FindBy(id = "inputSearchTermBoxLarge")
	private WebElement searchBoxDivTHIAS;

	@FindBy(id = "doSearchBtn")
	private WebElement searchButton;

	@FindBy(id = "widgetwrapper")
	private WebElement searchBar;

	@FindBy(id = "IntSearchTermListWrapper")
	private WebElement wordWheelPresence;

	@FindBy(xpath = "//div[@id='niceLogo']")
	private List<WebElement> niceLogoDivs;

	@FindBy(xpath = "//li[@id='searchFilterAll']/div/a")
	private WebElement allFilter;

	@FindBy(xpath = "//li[@id='searchFilterDrug']/div/a")
	private WebElement drugFilter;

	@FindBy(xpath = "//li[@id='searchFilterDisease']/div/a")
	private WebElement diseaseFilter;

	@FindBy(xpath = "//li[@id='searchFilterToxicology']/div/a")
	private WebElement toxicologyFilter;

	@FindBy(xpath = "//div[@class='searchBoxClass']/input[@id='IntSearchWordWheel_SearchTerm_index_0']")
	private WebElement headerSearchBar;

	@FindBy(xpath = "//div[@id='landingTab']/ul/li[@class='selected']/a")
	private WebElement currentSubTabHighlighted;

	@FindBy(xpath = "//*[@id='trainingLinkItem']/a")
	private WebElement trainingCenterLink;

	@FindBy(xpath = "//img[@alt='Go to MICROMEDEX2.']")
	private WebElement clickMicromedex2;

	@FindBy(id = "admincomboBtn_label")
	private WebElement tabAdmin;

	@FindBy(id = "admin_tox_text")
	private WebElement menuDefaultToxProduct;

	String mdx2WindowHandle = null;

	public MDX_HeaderPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		wait.until(ExpectedConditions.visibilityOf(homeToolbarLink));
	}

	public DrugIDPage clickOnDrugIdentToolbarLink() {
		drugIdentificationToolbarLink.click();
		DrugIDPage diPage = PageFactory.initElements(driver, DrugIDPage.class);
		return diPage;
	}

	/**
	 * Click the new Home toolbar link in the header
	 */
	// public MDX_HomePage clickOnHomeToolbarLink() {
	public MDX_HeaderPage clickOnHomeToolbarLink() {
		homeToolbarLink.click();
		// Mdx2HomePage homePage = PageFactory.initElements(driver,
		// Mdx2HomePage.class);
		MDX_HeaderPage homePage = PageFactory.initElements(driver, MDX_HeaderPage.class);
		return homePage;
	}

	/**
	 * Click the logout link
	 */
	public void logout() {
		logoutLink.click();
	}

	/**
	 * Return true if special Norway image is visible, else return false
	 * 
	 * @return
	 */
	public boolean isNorwayImageVisible() {
		if (helsibiblioteketImages.size() > 0) {
			return true;
		} else
			return false;
	}

	public void clearSearchBox() {
		searchBox.clear();
	}

	public void cutTermFromSearchBox() {
		searchBox.click();
		searchBox.sendKeys(Keys.CONTROL + "ax");
		// switched to use the line above as the lines below didn't work in
		// FF...the control key stayed down
		// so it failed future tests
		// Actions builder = new Actions(this.driver);
		// //
		// builder.keyDown(Keys.CONTROL).sendKeys("a").keyDown(Keys.CONTROL).sendKeys("x").perform();
		// builder.sendKeys(Keys.CONTROL + "ax").perform();
	}

	public void getURL() {
		String x = driver.getCurrentUrl();
		System.out.println("Using selenese: " + x);
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		Object val = jse.executeScript("return document.URL;");
		System.out.println("Using js: " + val);
	}

	/**
	 * Click on Search button in the header. Returns DashboardPage. Future work:
	 * may need to refactor for other page destinations or a generic results
	 * page object.
	 * 
	 * @return
	 */
	/**
	 * Clears search box, enters given searchTerm, then clicks search button.
	 * Doesn't return any type of page object...don't use.
	 * 
	 * @param searchTerm
	 */
	public void enterTermAndSearch(String searchTerm) {
		searchBox.clear();
		searchBox.sendKeys(searchTerm);
		searchButton.click();
	}

	/**
	 * Clears search box, enters given searchTerm
	 * 
	 * @param searchTerm
	 */
	public void enterSearchTerm(String searchTerm) {
		searchBox.clear();
		searchBox.sendKeys(searchTerm);
	}

	/**
	 * Return a delimited string (using | as the delimiter) that is a list of
	 * the id attribute of all the toolbar links. Example:
	 * tbOpt_DI|tbOpt_IV|tbOpt_ID
	 * 
	 * @return
	 */
	public String getToolbarLinksInOrderOfAppearance() {
		String separator = "|";
		StringBuilder toolbarOrder = new StringBuilder();
		Iterator<WebElement> i = toolbarElements.iterator();
		while (i.hasNext()) {
			WebElement element = i.next();
			toolbarOrder.append(element.getText());
			toolbarOrder.append(separator);
			// if (element.getAttribute("class").contentEquals("headLink") ||
			// element.getAttribute("id").contentEquals("tbOpt_MT")) {
			// toolbarOrder.append(element.getAttribute("id"));
			// toolbarOrder.append(separator);
			// }
		}
		// trim last separator
		if (toolbarOrder.toString().endsWith("|")) {
			toolbarOrder.deleteCharAt(toolbarOrder.length() - 1);
		}
		System.out.println("toolbarOrder:" + toolbarOrder.toString());
		System.out.println("toolbarElements size:" + toolbarElements.size());
		return toolbarOrder.toString();
	}

	/**
	 * This method shouldn't be used until we learn how to deal with special
	 * (tm, registered tm) symbols and how to test for them.
	 * 
	 * @return
	 */
	public String getToolbarLinksTextsInOrderOfAppearance() {
		String separator = "|";
		StringBuilder toolbarLinkTextOrder = new StringBuilder();
		Iterator<WebElement> i = toolbarLinkTexts.iterator();
		while (i.hasNext()) {
			WebElement element = i.next();
			String str;
			str = new String(element.getText());
			toolbarLinkTextOrder.append(str);
			toolbarLinkTextOrder.append(separator);
		}
		System.out.println("toolbarTextOrder:" + toolbarLinkTextOrder.toString());
		System.out.println("toolbarLinkTexts size:" + toolbarLinkTexts.size());
		return toolbarLinkTextOrder.toString();
	}

	/**
	 * Get text from the 'Other Tools' dropdown elements.
	 * 
	 * 
	 * 
	 * Example of a returned value: Calculators|Formulary|CareNotes®|NeoFax® /
	 * Pediatrics|
	 * 
	 * @return
	 */
	public String getOtherToolsTextItems() {
		String separator = "|";
		StringBuilder otherToolsTextItemsOrder = new StringBuilder();
		Iterator<WebElement> i = otherToolsTextItems.iterator();
		while (i.hasNext()) {
			WebElement element = i.next();
			String str;
			str = new String(element.getText());
			otherToolsTextItemsOrder.append(str);
			otherToolsTextItemsOrder.append(separator);
		}
		System.out.println("otherToolsTextItemsOrder:" + otherToolsTextItemsOrder.toString());
		System.out.println("otherToolsTextItems size:" + otherToolsTextItems.size());
		return otherToolsTextItemsOrder.toString();
	}

	/**
	 * Return a String for the Drug Identification toolbar link
	 * 
	 * @return
	 */
	public String getDrugIdentificationToolbarLinkText() {
		String returnVal = drugIdentificationToolbarLink.getText();
		System.out.println("drugIdentificationToolbarLink.getText()=" + returnVal);
		return returnVal;
	}

	/**
	 * Return the 'guidance text' from the search box. Note: this doesn't use
	 * the conventional selenium getText() method as the guidance text is
	 * populated via javascript, so the getText() method doesn't return
	 * anything. This method uses getAttribute("value")
	 * 
	 * @return
	 */
	public boolean getGuidanceTextFromSearchBox() {
		boolean guidanceResult = true;
		String text = searchBox.getAttribute("value");
		System.out.println(text);
		if (driver.getCurrentUrl().contains("micromedexsolutions.com")) {
			if (!text.trim().equalsIgnoreCase("Keyword search"))
				guidanceResult = false;
		} else {
			if (!text.trim().equalsIgnoreCase("Search Micromedex"))
				guidanceResult = false;
		}
		return guidanceResult;
	}

	/**
	 * Return an int representing the number of div tags that contain an id of
	 * 'niceLogo'. Used to test to make sure the NICE logo isn't rendered.
	 * 
	 * @return
	 */
	public int getNumberOfNiceLogoDivTags() {
		int number = niceLogoDivs.size();
		return number;
	}

	public boolean isLogoutLinkDisplayed() {
		if (logoutLink.isDisplayed()) {
			return true;
		} else
			return false;
	}

	public void switchbacktoHomewindow() {
		driver.close();
		driver.switchTo().window(mdx2WindowHandle);
	}

	/**
	 * Clicks on the Gateway link. Returns a GatewayPage object.
	 * 
	 * @return
	 */
	public GatewayPage clickGatewayLink() {
		gatewayLink.click();
		GatewayPage gwPage = PageFactory.initElements(driver, GatewayPage.class);
		return gwPage;

	}

	private String getCssColorInHexFormatForElement(WebElement element) {
		Color colorFromBrowser = Color.fromString(element.getCssValue("color"));
		String convertedColor = colorFromBrowser.asHex();
		System.out.println(element.getTagName() + " colorFromBrowser=" + colorFromBrowser);
		System.out.println(element.getTagName() + " convColor=" + convertedColor);
		return convertedColor;
	}

	private String getCssBackgroundColorInHexFormatForElement(WebElement element) {
		Color colorFromBrowser = Color.fromString(element.getCssValue("background-color"));
		String convertedColor = colorFromBrowser.asHex();
		System.out.println(element.getTagName() + " background-colorFromBrowser=" + colorFromBrowser);
		System.out.println(element.getTagName() + " convColor=" + convertedColor);
		return convertedColor;
	}

	private String getBorderLeftForElement(WebElement element) {
		StringBuilder returnString = new StringBuilder();
		Color colorFromBrowser = Color.fromString(element.getCssValue("border-left-color"));
		String convertedColor = colorFromBrowser.asHex();
		String width = element.getCssValue("border-left-width");
		String style = element.getCssValue("border-left-style");
		returnString.append(convertedColor + "|");
		returnString.append(width + "|");
		returnString.append(style);
		System.out.println(element.getText() + " border left=" + returnString.toString());
		return returnString.toString();
	}

	/**
	 * Returns a hex representation of the My Subscription link CSS value for
	 * color. example: #0072ce
	 * 
	 * @return
	 */
	public String getColorOfMySubscriptionLinkInHex() {
		String colorInHexFormat = getCssColorInHexFormatForElement(mySubscriptionLink);
		return colorInHexFormat;
	}

	public String getBorderLeftOfMySubscriptionLinkParentInHex() {
		WebElement parent = mySubscriptionLink.findElement(By.xpath(".."));
		String colorInHexFormat = getBorderLeftForElement(parent);
		return colorInHexFormat;
	}

	/**
	 * Returns a hex representation of the Gateway link CSS value for color.
	 * example: #0072ce
	 * 
	 * @return
	 */
	public String getColorOfGatewayLinkInHex() {
		String colorInHexFormat = getCssColorInHexFormatForElement(gatewayLink);
		return colorInHexFormat;
	}

	public String getBorderLeftOfGatewayLinkParentInHex() {
		WebElement parent = gatewayLink.findElement(By.xpath(".."));
		String colorInHexFormat = getBorderLeftForElement(parent);
		return colorInHexFormat;
	}

	/**
	 * Returns a hex representation of the Help link CSS value for color.
	 * example: #0072ce
	 * 
	 * @return
	 */

	public String getColorOfOtherToolsCalculatorsToolbarBackgroundInHex() {
		String colorInHexFormat = getCssBackgroundColorInHexFormatForElement(otherToolsCalculatorsBackground);
		return colorInHexFormat;
	}

	public String getSearchBarClassAttributeValue() {
		String attributeValue = "";
		attributeValue = searchBar.getAttribute("class");
		return attributeValue;
	}

	public String getSearchBarBackgroundImageUrl() {
		String attributeValue = "";
		attributeValue = searchBar.getCssValue("background-image");
		return attributeValue;
	}

	public String getSearchButtonClassAttributeValue() {
		String attributeValue = "";
		attributeValue = searchButton.getAttribute("class");
		return attributeValue;
	}

	public String getSearchButtonTitleAttribute() {
		String attribute = "";
		attribute = searchButton.getAttribute("title");
		return attribute;
	}

	public String getSearchButtonBackgroundImageUrl() {
		String attributeValue = "";
		attributeValue = searchButton.getCssValue("background-image");
		return attributeValue;
	}

	public String getSearchButtonCursor() {
		String cursor = "";
		cursor = searchButton.getCssValue("cursor");
		return cursor;
	}

	public String getSearchTerm() {
		String term = "";
		term = searchBox.getAttribute("value");
		return term;
	}

	/**
	 * Hover over new Home toolbar link in the header
	 */
	public void hoverOnHomeToolbarLink() {
		Actions builder = new Actions(this.driver);
		builder.moveToElement(homeToolbarBackground).perform();
	}

	public void hoverOnDrugIdentToolbar() {
		Actions builder = new Actions(this.driver);
		builder.moveToElement(drugIdentificationToolbarBackground).perform();
	}

	public void hoverOnToxAndDrugToolbar() {
		Actions builder = new Actions(this.driver);
		builder.moveToElement(toxAndDrugToolbarBackground).perform();
	}

	public void hoverOnOtherToolsToolbar() {
		Actions builder = new Actions(this.driver);
		builder.moveToElement(otherToolsDropDownBackground).perform();
	}

	public void hoverOnOtherToolsToxAndDrugToolbar() {
		Actions builder = new Actions(this.driver);
		builder.moveToElement(otherToolsToxAndDrugBackground).perform();
	}

	public void hoverOnOtherToolsCalculatorToolbar() {
		Actions builder = new Actions(this.driver);
		builder.moveToElement(otherToolsCalculatorsBackground).perform();
	}

	public String getHighlightedPrimaryToolbarItems() {
		// hover mouse away from toolbar
		Actions builder = new Actions(this.driver);
		builder.moveToElement(searchBox).perform();
		StringBuilder itemsHighlighted = new StringBuilder();
		String separator = "|";
		String highlightColor = "#1a76b9";
		Iterator<WebElement> i = toolbarDivs.iterator();
		while (i.hasNext()) {
			WebElement element = i.next();
			if (Color.fromString(element.getCssValue("background-color")).asHex().compareTo(highlightColor) == 0) {
				itemsHighlighted.append(decodeToolbarId(element.getAttribute("id")));
				itemsHighlighted.append(separator);
			}
		}
		// iterate through other tools items and add if highlighted
		Iterator<WebElement> otherItr = otherToolsRows.iterator();
		while (otherItr.hasNext()) {
			WebElement element = otherItr.next();
			if (element.getAttribute("class").contains("active")) {
				itemsHighlighted.append(decodeToolbarId(element.getAttribute("id")));
				itemsHighlighted.append(separator);
			}
		}
		// trim last separator
		if (itemsHighlighted.toString().endsWith("|")) {
			itemsHighlighted.deleteCharAt(itemsHighlighted.length() - 1);
		}

		return itemsHighlighted.toString();
	}

	private String decodeToolbarId(String id) {
		HashMap<String, String> toolbarMap = new HashMap<String, String>();
		toolbarMap.put("tbOpt_Home", "Home");
		toolbarMap.put("tbOpt_DI", "Drug Interactions");
		toolbarMap.put("tbOpt_IV", "IV Compatibility");
		toolbarMap.put("tbOpt_ID", "Drug ID");
		toolbarMap.put("tbOpt_DC", "Drug Comparison");
		toolbarMap.put("tbOpt_CN", "CareNotes");
		toolbarMap.put("tbOpt_NEO", "NeoFax");
		toolbarMap.put("tbOpt_PS", "Tox & Drug Product Lookup");
		toolbarMap.put("tbOpt_RB", "RED BOOK");
		toolbarMap.put("tbOpt_CALC", "Calculators");
		toolbarMap.put("tbOpt_MT", "Other Tools");
		return toolbarMap.get(id).toString();
	}

}
