package com.ibm.webapp.pageObjects.top100hospitals;

import java.io.IOException;
import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class Top100Hospitals_HomePage extends Selenese
{

   private final WebDriver driver;

   @FindBy(xpath = "//a[contains(text(),'User Provisioning')]")
   private WebElement UserProvisioningLink;

   @FindBy(xpath = "//a[contains(text(),'Member Login')]")
   private WebElement MemberLogin;

   @FindBy(xpath = "//*[@title=\"Access Marketplace Pricing\"]")
   private WebElement AccessMarketplacePricing;

   @FindBy(xpath = "//a[contains(text(),'Logout')]")
   private WebElement LogoutLink;

   @FindBy(xpath = "//*[@id=\"NBStudy\"]")
   private WebElement NationalBenchmarkStudy;

   @FindBy(xpath = "//*[@id=\"CardioStudy\"]")
   private WebElement CardioVasucularBenchmarkStudy;

   @FindBy(xpath = "//*[@id=\"MT\"]")
   private WebElement Montana;

   @FindBy(xpath = "//*[@id=\"UT\"]")
   private WebElement Utah;

   @FindBy(xpath = "//*[@id=\"CO\"]")
   private WebElement Colorado;

   @FindBy(xpath = "//*[@id=\"AR\"]")
   private WebElement Arkansas;

   @FindBy(xpath = "//*[@id=\"MI\"]")
   private WebElement Michigan;

   @FindBy(xpath = "//*[@id=\"HI\"]")
   private WebElement Hawaii;

   @FindBy(xpath = "//*[@id='id_of_tablebody']/tr[42]/td[2]/span/a")
   private WebElement hospitalName;

   @FindBy(xpath = "//*[@id=\"id_of_tablebody\"]/tr[1]/td[2]/span")
   private WebElement firstHospital;

   @FindBy(xpath = "//*[@id=\"id_of_tablebody\"]/tr[1]/td[2]/span/a")
   private WebElement hospName;

   @FindBy(xpath = "//*[@id='reportContent']/div[1]")
   private WebElement preparedFor;

   @FindBy(xpath = "//*[@id='id_of_tablebody']")
   private WebElement resultsTable;

   @FindBy(xpath = "//*[@id='CardioStudy']")
   private WebElement cardioRadioButton;

   @FindBy(xpath = "//*[@id='NBStudy']")
   private WebElement nationalRadioButton;

   @FindBy(xpath = "//*[@id='hospitalIdCenter']/a")
   private WebElement mCareIdLink;

   @FindBy(xpath = "//*[@id='nameTitle']/a")
   private WebElement hospitalNameLink;

   @FindBy(xpath = "//*[@id='locationTitle']/a")
   private WebElement locationTitleLink;

   @FindBy(xpath = "//*[@id='classTitle']/a")
   private WebElement classTitleLink;

   @FindBy(xpath = "//*[@id='statusTitle']/a")
   private WebElement statusTitleLink;

   @FindBy(xpath = "//*[@id='result_table']")
   private WebElement resultTable;

   public Top100Hospitals_HomePage(WebDriver driver) throws IOException
   {
      this.driver = driver;
      PageFactory.initElements(this.driver, this);
      WebDriverWait wait = new WebDriverWait(this.driver, 20);
      // wait.until(ExpectedConditions.visibilityOf(NationalBenchmarkStudy));
      try
      {
         wait.until(ExpectedConditions.visibilityOf(NationalBenchmarkStudy));
      }
      catch (Exception e)
      {
         extentReport.FAIL(driver,
                           "Top100Hospitals_HomePage",
                           "Report Search Page is not visible");
         log.error("Report Search Page is not visible");
      }
   }

   /**
    * click member login button
    * 
    * @return
    * @throws IOException
    */
   public Top100Hospitals_LoginPage ClickMemberLogin() throws IOException
   {
      click(driver, "Member login", MemberLogin);
      return PageFactory.initElements(this.driver,
                                      Top100Hospitals_LoginPage.class);
   }

   /**
    * click on national benchmark link
    * 
    * @throws IOException
    */
   public void ClickNationalBenchmark() throws IOException
   {
      // NationalBenchmarkStudy.click();
      click(driver, "national benchmark", NationalBenchmarkStudy);
   }

   /**
    * click on cardiovascular benchmark link
    * 
    * @throws IOException
    */
   public void ClickCardiovascularBenchmark() throws IOException
   {
      click(driver, "cardio benchmark", CardioVasucularBenchmarkStudy);
      CardioVasucularBenchmarkStudy.click();
   }

   /**
    * click on log out link
    * 
    * @throws IOException
    */
   public void clickLogOut() throws IOException
   {
      click(driver, "log out", LogoutLink);

   }

   /**
    * click on Colorado state
    * 
    * @throws IOException
    */
   public void clickColorado() throws IOException
   {

      click(driver, "Colorado", Colorado);
      Scroll(driver, "scroll(0,250)");
   }

   /**
    * click on Cardio radio button
    * 
    * @throws IOException
    */
   public void clickCardioRadioButton() throws IOException
   {
      click(driver, "Cardio radiobutton", cardioRadioButton);

   }

   /**
    * click on the particular hospital link
    * 
    * @throws IOException
    */
   public void clickHospitalLink() throws IOException
   {

      click(driver, "hosp name", hospitalName);
      String hospName = hospitalName.getText();
      Set<String> handles = driver.getWindowHandles();
      String firstWinHandle = driver.getWindowHandle();
      handles.remove(firstWinHandle);
      String winHandle = handles.iterator().next();
      if (winHandle != firstWinHandle)
      {
         String secondWinHandle = winHandle;
         driver.switchTo().window(secondWinHandle);
         driver.switchTo().activeElement();
         try
         {
            if (preparedFor.getText().equals(hospName)){
            	
            }
         }
         catch (Exception e)
         {
            System.out.println(e);
         }

         JavascriptExecutor jse = (JavascriptExecutor) driver;
         jse.executeScript("scroll(0,250)");

         driver.close();
      }
      driver.switchTo().window(firstWinHandle);
   }

   public void clickCardioNationalHospitalLink()
   {
      hospName.click();
      Set<String> handles = driver.getWindowHandles();
      String firstWinHandle = driver.getWindowHandle();
      handles.remove(firstWinHandle);
      String winHandle = handles.iterator().next();
      if (winHandle != firstWinHandle)
      {
         String secondWinHandle = winHandle;
         driver.switchTo().window(secondWinHandle);
         driver.switchTo().activeElement();
         System.out.println(preparedFor.getText());
         try
         {
            if (preparedFor.getText().equals(hospName))
               System.out.println("Test case passed");
         }
         catch (Exception e)
         {
            System.out.println(e);
         }

         JavascriptExecutor jse = (JavascriptExecutor) driver;
         jse.executeScript("scroll(0,250)");

         driver.close();
      }
      driver.switchTo().window(firstWinHandle);

   }

   public void scrollDown()
   {
      JavascriptExecutor jse = (JavascriptExecutor) driver;
      jse.executeScript("scroll(0,500)");
   }

   public Top100Hospitals_UserProvisioningPage clickUserProvisioning()
   {
      UserProvisioningLink.click();
      Top100Hospitals_UserProvisioningPage userProvPage = PageFactory
            .initElements(driver, Top100Hospitals_UserProvisioningPage.class);
      return userProvPage;
   }

}