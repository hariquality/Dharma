package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.ibm.webapp.utils.Selenese;


public class DrugCompareResultsPage extends Selenese {
	private final WebDriver driver;
	
	@FindBy(xpath = "//*[@id='centerDoc']/table/tbody/tr[1]/th[1]/span[1]")
	private WebElement mainDrugHeading1;
	
	@FindBy(xpath = "//*[@id='centerDoc']/table/tbody/tr[1]/th[3]/span[1]")
	private WebElement mainDrugHeading2;
	
	@FindBy(xpath = "//select[@id = 'docLeftSelector_index_0']//option")
	private List<WebElement> displayLeftSelectorValues;
		
	@FindBy(xpath = "//*[@id='docLeftSelector_index_0']")
	private List<WebElement> displayLeftSelector;

	@FindBy(xpath = "//select[@id='docLeftSelector_index_0']")
//	@FindBy(id = "docLeftSelector_index_0")
	private WebElement leftDocumentSelector;

	@FindBy(xpath = "//select[@id = 'docRightSelector_index_0']//option")
	private List<WebElement> displayRightSelectorValues;

	@FindBy(id = "docRightSelector_index_0")
	private WebElement rightDocumentSelector;

	@FindBy (xpath ="//*[@id='centerDoc']/table/tbody/tr[1]/th[1]/div[2]/a")
	private WebElement viewDetailedInfoInDrugdexLink;
	
	@FindBy(xpath = "//td[contains(@class,'jumpTo')]")
	protected List<WebElement> jumpToLinks;
	
	@FindBy(xpath = "//a[.='Toxicology']")
	private WebElement toxicologyLink;
	
	@FindBy(xpath = "//button[contains(@class,'moreInfoButton')]")
	private WebElement updateButton;
	
	@FindBy(xpath = "//*[@id='DRUGTOX']/div")
	private WebElement jumpToHeaders;
	
	@FindBy(xpath = "//button[contains(@class,'submitBtn')]")
	private WebElement modifySearchButton;
	
	
	

	public DrugCompareResultsPage(WebDriver driver) throws IOException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		waitForElementVisibility(driver, viewDetailedInfoInDrugdexLink);
		
	}

	/**
	 * Use this method to verify the drug header in drug results page by passing the drugs as parameter
	 * @param drugHeaderOne, drugHeaderTwo = Passing the drug headers as a parameters  
	 * @throws IOException 
	 */
	
	public void verifyDrugHeadersInDrugResultPage(String drugHeaderOne,String drugHeaderTwo) throws IOException
	{
		 try
	      {
		
		Assert.assertTrue(mainDrugHeading1.getText().equalsIgnoreCase(drugHeaderOne) && mainDrugHeading2.getText().equalsIgnoreCase(drugHeaderTwo));
		extentReport.PASS("Verification of Drug header in drug results page",
				drugHeaderOne+ drugHeaderTwo+ "are displayed in drug comparison results page");
		 log.info(drugHeaderOne+ drugHeaderTwo+ "are displayed in drug comparison results page");
	      }
		 catch (Exception e)
	      {
	          extentReport.FailWithException(driver,"Verification of Drug headers in drug results page",drugHeaderOne+ drugHeaderTwo+ "are not displayed in drug comparison results page",e);
	          logERROR(drugHeaderOne+ drugHeaderTwo+ "are not displayed in drug comparison results page", e);
	       }

		
	}
	
	public void verifyModifySearchInDrugResultPage() throws IOException
	{
		 try
	      {
		
		Assert.assertTrue(mainDrugHeading1.getText().equalsIgnoreCase("Factor IX Complex Human") && mainDrugHeading2.getText().equalsIgnoreCase("Decitabine/Cedazuridine"));
		extentReport.PASS("Verification of Drug header in drug results page",
               "Expected drug headers are displayed in drug results page");
		 log.info("Expected drug headers ares displayed in drug results page");
	      }
		 catch (Exception e)
	      {
	          extentReport.FailWithException(driver,"Verification of Drug headers in drug results page","Expected drug header is not displayed in drug results page",e);
	          logERROR("Expected drug headers are not displayed in drug results page", e);
	       }

		
	}
	
	/**
	 * Use this method to verify the toxicology link is present in jump to headers section and verify the functionality of toxicology link
	 * @return Drug comparison results page
	 * @throws IOException
	 */
	
	public DrugCompareResultsPage clickOnToxicologyLink() throws IOException {
		
		try{
			Assert.assertTrue(jumpToHeaders.getText().equalsIgnoreCase("Toxicology"));
			extentReport.PASS("Toxicology link verification",
	                "Toxicology link is present in jump to header section");
			log.info("Toxicology link is present in jump to header section");
		}
		catch (Exception e){
			   extentReport.FailWithException(driver,"Toxicology link verification","Toxicology link is not present in jump to headers section",e);
		          logERROR("Toxicology link is not present in jump to header section", e);
		   }
		click(driver, "Toxicology link in jump to headers section",toxicologyLink);
		DrugCompareResultsPage dcResultsPage = PageFactory.initElements(driver, DrugCompareResultsPage.class);
		return dcResultsPage;
	}
	
	
	/**
	 * Use this method to verify the jump to headers for corresponding drugs
	 * @return Drug comparison results page
	 * @throws IOException 
	 */
	
	public DrugCompareResultsPage verifyJumpToHeaders() throws IOException {
		String jumpToLinks = getJumpToLinks();
		try{
			Assert.assertEquals(" Top of Page | Dosing & Indications | Black Box Warning | REMS | Contraindications/Warnings | Drug Interactions (single) | Adverse Effects | Name Info | Mechanism of Action/Pharmacokinetics | Administration/Monitoring | How Supplied | Toxicology | Clinical Teaching | References",jumpToLinks);
			//System.out.println("Passed");
			extentReport.PASS("Verification of jump to headers",
		               "Jump to headers are displayed in drug comparison results page");
				 log.info("Jump to headers are displayed in drug comparison results page");
		} catch (Exception e)
		      {
		          extentReport.FailWithException(driver,"Verification of jump to headers","Jump to headers are not displayed in drug comparison results page",e);
		          logERROR("Jump to headers are not displayed in drug comparison results page", e);
		       }
		
		DrugCompareResultsPage dcResultsPage = PageFactory.initElements(driver, DrugCompareResultsPage.class);
		return dcResultsPage;
	}
	


	
	/**
	 * Use this method to navigate into drug landing page while we clicking on drugdex button 
	 * @return to DrugLandingPage
	 * @throws IOException 
	
	 */
	public DrugLandingPage clickViewDetailedInfoInDrugdex() throws IOException {
		try{
		viewDetailedInfoInDrugdexLink.click ();
		 extentReport.PASS("Drug landing page verification",
                 "Drug landing Page is displayed correctly while clicking on drug dex button");
		 log.info("Drug landing Page is displayed correctly while clicking on drug dex button");
		}catch (Exception e)
		   {
			extentReport.FailWithException(driver,"Drug landing page verification","Drug landing Page is not displayed correctly while clicking on drugdex button",e);
	          logERROR("Drug comparison Page is not displayed correctly", e);
		   }
		return PageFactory.initElements(driver, DrugLandingPage.class);
		
	}



	
	/**
	 * Use this method to click on modify button and navigated into drug comparison page
	 * @return to Drug ComparisonPage
	 * @throws IOException 
	
	 */
	
	public DrugComparisonPage clickModifyButton() throws IOException {
		try{
			click(driver, "Modify search button",modifySearchButton);
			 extentReport.PASS("Drug Comparison page verification",
                     "Drug comparison Page is displayed correctly");
			 log.info("Drug comparison Page is displayed correctly");
		}catch (Exception e)
		   {
	          extentReport.FailWithException(driver,"Drug Comparison page verification","Drug comparison Page is not displayed correctly",e);
	          logERROR("Drug comparison Page is not displayed correctly", e);
	       }
		
		return PageFactory.initElements(driver, DrugComparisonPage.class);
	}

/**
	 * Return a list of links from the jump to bar
	 * @return
	 */
	public String getJumpToLinks() {
		StringBuilder links = new StringBuilder();
		Iterator<WebElement> i = jumpToLinks.iterator();
		while (i.hasNext()) {
			WebElement e = i.next();
			links.append(e.getText());
		}
		return links.toString();

	}
	

}






