package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.pageObjects.ToxandDrugProduct.TOD_HomePage;
import com.ibm.webapp.utils.Selenese;

public class MDX_HomePage extends Selenese {
	WebDriver driver;

	@FindBy(id = "logoutLink")
	private WebElement logoutButton;

	@FindBy(xpath = "//div/a[@onfocus]")
	private List<WebElement> toolNames;

	@FindBy(xpath = "//a[contains(text(),'Tox & Drug')]")
	private WebElement toxAndDrugProductMenu;

	@FindBy(xpath = "//a[contains(text(),'NeoFax')]")
	private WebElement neofaxMenu;

	@FindBy(xpath = "//table[@id='othItems']/tbody/tr/td[contains(text(),'Tox & Drug')]")
	private WebElement otherToolsToxAndDrugLink;

	@FindBy(xpath = "//div[@id='header']/div[@id='tbOpt_MT']")
	private WebElement otherToolsDropDownBackground;

	@FindBy(id = "IntSearchWordWheel_SearchTerm_index_0")
	private WebElement drugSearchBox;

	@FindBy(id = "doSearchBtn")
	private WebElement btn_drugSearch;

	@FindBy(id = "IntSearchWordWheel_SearchTerm_index_0")
	private WebElement searchBox;

	@FindBy(id = "tbOpt_DC")
	private WebElement drugComparisonLink;

	@FindBy(id = "doSearchBtn")
	private WebElement searchButton;

	@FindBy(id = "redbookTrialToolLink")
	private WebElement module_redBook;

	@FindBy(id = "tbOpt_RB_text")
	private WebElement module_redBookinOtherToolsMenu;

	@FindBy(xpath = "//*[@id=\"comboBtn_label\"]")
	private WebElement menu_OtherTools;

	@FindBy(id = "tbOpt_CALC_text")
	private WebElement mdxCalculators;

	@FindBy(id = "calcToolLink")
	private WebElement module_Calculators;

	@FindBy(id = "tbOpt_CALC_text")
	private WebElement module_CalculatorsinOtherToolsMenu;

	@FindBy(xpath = "//a[contains(@title,'/ Pediatrics')]")
	private WebElement tab_NeoPed;

	@FindBy(id = "NeoFaxPedToolLink")
	private WebElement tab_NeoNatal;

	@FindBy(id = "headerHelpLink")
	private WebElement helpLink;

	@FindBy(id = "userGuideLink")
	private WebElement userGuideLink;

	@FindBy(xpath = "//a[@id='NeoFaxPedToolLink'][.='Pediatrics']")
	private WebElement tab_Pediatrics;

	@FindBy(xpath = "//*[@id='drugInteractionToolLink']")
	private WebElement drugInteractionsToolbarLink;

	@FindBy(xpath = "//*[@id='IVToolLink']")
	private WebElement ivCompatToolbarLink;

	@FindBy(xpath = "//div[@class='pageTitle pageTitleBottom leftAlign']")
	private WebElement tabTitle;

	@FindBy(xpath = "//div[@id='header']/div")
	private List<WebElement> all_tabs;

	@FindBy(xpath = "//settings-ui")
	private WebElement cacheURL;

	@FindBy(xpath = "//*[@id='homeLink']")
	private WebElement menu_Home;

	public MDX_HomePage(WebDriver driver) throws IOException {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		try {
			wait.until(ExpectedConditions.visibilityOf(menu_Home));
		} catch (Exception e) {
			extentReport.FAIL(driver, "MDX HomePage", "MDX HomePage is not displayed");
			log.error("MDX HomePage is not displayed");
		}
	}

	public void SearchDrug() throws IOException {
		try {
			sendKeys(driver, "Drug Search box", drugSearchBox, "Aspirin");
			click(driver, "Drug Search Button", btn_drugSearch);
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Search Drug", "Search Drug method failed", e);
			logERROR("Search Drug method failed", e);
		}
	}

	/**
	 * Use this method to click on Calculator module on MDX header
	 * 
	 * @returns Calculator Page
	 * @throws InterruptedException
	 *             ,IOException
	 */
	public MDX_CalculatorPage clickCalculator() throws Exception {
		boolean isModulePresentOnOtherToolsMenu = true;
		for (WebElement toolName : toolNames) {
			if (toolName.getText().contains("Calculator")) {
				click(driver, "Calculator Module Selection", module_Calculators);
				isModulePresentOnOtherToolsMenu = false;
				break;
			}
		}
		if (isModulePresentOnOtherToolsMenu) {
			hoverOnOtherToolsToolbar();
			click(driver, "Calculator Module Selection from OtherTools Menu", module_CalculatorsinOtherToolsMenu);
		}
		return PageFactory.initElements(driver, MDX_CalculatorPage.class);
	}

	public MDX_HeaderPage getHeaderPage() {
		MDX_HeaderPage headerPage = PageFactory.initElements(driver, MDX_HeaderPage.class);
		return headerPage;
	}

	/**
	 * Use this method to click on Red book link on MDX header
	 * 
	 * @return to RedBookPage
	 * @throws InterruptedException
	 *             ,IOException
	 */

	public RedBookPage clickRedbookLink() throws InterruptedException, IOException {
		boolean isModulePresentOnOtherToolsMenu = true;
		for (WebElement toolName : toolNames) {
			if (toolName.getText().contains("RED BOOK")) {
				click(driver, "RedBook Tool Selection", module_redBook);
				isModulePresentOnOtherToolsMenu = false;
				break;
			}
		}
		if (isModulePresentOnOtherToolsMenu) {
			hoverOnOtherToolsToolbar();
			click(driver, "RedBook Tool Selection from OtherTools Menu", module_redBookinOtherToolsMenu);
		}
		return PageFactory.initElements(driver, RedBookPage.class);
	}

	/**
	 * Based on the users Call this method to click on NeoFax or Pediatrics or
	 * NeoFax/Pediatrics tab in MDX Home Page
	 */
	public DrugMonograph_Homepage clickTab(String user) {
		try {
			if (user.equalsIgnoreCase("Neo")) {
				click(driver, "NeoNatal tab", tab_NeoNatal);
			} else if (user.equalsIgnoreCase("Ped")) {
				click(driver, "Pediatric tab", tab_Pediatrics);
			} else {
				click(driver, "NeoNatal/Pediatric tab", tab_NeoPed);
			}
			return PageFactory.initElements(driver, DrugMonograph_Homepage.class);
		}

		catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	/**
	 * Use this method to click on Drug Comparison link in MDX footer
	 * 
	 * @return to User guide page
	 * @throws InterruptedException
	 *             ,IOException
	 */

	public DrugComparisonPage clickDrugComparisonLink() throws InterruptedException, IOException {
		try {

			click(driver, "Drug Comparison link", drugComparisonLink);
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Drug comparison link", "Drug Comparision link is not clicked", e);
			logERROR("Drug Comparision link is not clicked", e);
		}
		return PageFactory.initElements(driver, DrugComparisonPage.class);

	}

	/**
	 * Use this method to enter the disease name and click on search icon
	 * 
	 * @return to DrugLandingPage
	 * @param searchTerm=
	 *            Pass the disease name to enter into the search bar
	 * @throws InterruptedException
	 *             ,IOException
	 */

	public DrugLandingPage searchAndReturnDiseasesLandingPage(String searchTerm) throws IOException {
		try {
			enterSearchTerm(searchTerm);
			click(driver, "Search button", searchButton);
			extentReport.PASS("Verification of landing page is loaded for searched disease",
					"Landing page is loaded for searched disease");
			log.info("Landing page is loaded for searched disease");
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Verification of landing page is loaded for searched disease",
					"Landing page is not loaded for searched disease", e);
			logERROR("Landing page is not loaded for searched disease", e);
		}
		DrugLandingPage page = PageFactory.initElements(driver, DrugLandingPage.class);
		return page;
	}

	/**
	 * Use this method to enter the drug name and click on search icon
	 * 
	 * @return to DrugLandingPage
	 * @param searchTerm=
	 *            Pass the disease name to enter into the search bar
	 * @throws InterruptedException
	 *             ,IOException
	 */

	public DrugLandingPage searchAndReturnDrugLandingPage(String searchTerm) throws IOException {
		try {
			enterSearchTerm(searchTerm);
			click(driver, "Search button", searchButton);
			extentReport.PASS("Verification of landing page is loaded for searched drug",
					"Landing page is loaded for searched drug");
			log.info("Landing page is loaded for searched drug");
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Verification of landing page is loaded for searched drug",
					"Landing page is not loaded for searched drug", e);
			logERROR("Landing page is not loaded for searched drug", e);
		}
		DrugLandingPage page = PageFactory.initElements(driver, DrugLandingPage.class);
		return page;
	}

	/**
	 * Use this method to enter the TOX name and click on search icon
	 * 
	 * @return to DrugLandingPage
	 * @param searchTerm=
	 *            Pass the TOX name to enter into the search bar
	 * @throws InterruptedException
	 *             ,IOException
	 */

	public DrugLandingPage searchAndReturnToxLandingPage(String searchTerm) throws IOException {
		try {
			enterSearchTerm(searchTerm);
			click(driver, "Search button", searchButton);
			extentReport.PASS("Verification of landing page is loaded for searched Tox",
					"Landing page is loaded for searched Tox");
			log.info("Landing page is loaded for searched Tox");
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Verification of landing page is loaded for searched disease",
					"Landing page is not loaded for searched Tox", e);
			logERROR("Landing page is not loaded for searched Tox", e);
		}
		DrugLandingPage page = PageFactory.initElements(driver, DrugLandingPage.class);
		return page;
	}

	/**
	 * Use this method to enter the TOX name and click on search icon
	 * 
	 * @return to DrugLandingPage
	 * @param searchTerm=
	 *            Pass the TOX name to enter into the search bar
	 * @throws InterruptedException
	 *             ,IOException
	 */

	public DrugLandingPage searchAndReturnAltMedLandingPage(String searchTerm) throws IOException {
		try {
			enterSearchTerm(searchTerm);
			click(driver, "Search button", searchButton);
			extentReport.PASS("Verification of landing page is loaded for AltMed Search",
					"Landing page is loaded for AltMed Search");
			log.info("Landing page is loaded for AltMed Search");
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Verification of landing page is loaded for AltMed Search",
					"Landing page is not loaded for AltMed Search", e);
			logERROR("Landing page is not loaded for AltMed Search", e);
		}
		DrugLandingPage page = PageFactory.initElements(driver, DrugLandingPage.class);
		return page;
	}

	/**
	 * Enters given searchTerm
	 * 
	 * @param searchTerm
	 * @throws IOException
	 */
	public void enterSearchTerm(String searchTerm) throws IOException {
		sendKeys(driver, "Search box", searchBox, searchTerm);
	}

	/**
	 * @return ChatBotPage.class
	 */
	public ChatBotPage getChatWindowComponent() {
		return PageFactory.initElements(driver, ChatBotPage.class);
	}

	/**
	 * @return DrugInteractionsPage.class
	 * @throws IOException
	 */
	public DrugInteractionsHomePage clickOnDrugInteractionsToolbarLink() throws IOException {
		try {
			drugInteractionsToolbarLink.click();
			extentReport.PASS("DI Home Page Verification drugInteractionsToolbarLink and verify interaction page",
					"drugInteractionsToolbarLink is working correctly");
			log.info("Verified drugInteractionsToolbarLink");
		} catch (Exception e) {
			extentReport.FAIL(driver, "DIHomePage", "DrugInteractionsToolbarLink method failed");
			logERROR("DrugInteractionsToolbarLink method failed");

		}
		DrugInteractionsHomePage diPage = PageFactory.initElements(driver, DrugInteractionsHomePage.class);
		return diPage;
	}

	/**
	 * @return IVCompatibilityPage.class
	 * @throws IOException
	 */
	public IvCompatibilityPage clickOnIVCompatToolbarLink() throws IOException {
		try {
			ivCompatToolbarLink.click();
		} catch (Exception e) {
			extentReport.FAIL(driver, "IVCompPage", "clickOnIVCompatToolbarLink method failed");
			logERROR("clickOnIVCompatToolbarLink method failed");

		}
		IvCompatibilityPage ivPage = PageFactory.initElements(driver, IvCompatibilityPage.class);
		return ivPage;
	}

	public TOD_HomePage clickOnOtherToolsToxAndDrugToolbarLink() throws IOException {
		if (!driver.getCurrentUrl().contains("micromedexsolutions.com")) {
			click(driver, "Other tools in Micromedex Home page", toxAndDrugProductMenu);
		} else {
			hoverOnOtherToolsToolbar();
			click(driver, "Tox and Drug Product option", otherToolsToxAndDrugLink);
		}
		return PageFactory.initElements(this.driver, TOD_HomePage.class);
	}

	public TOD_HomePage clickNeofax() throws IOException {

		for (WebElement toolName : toolNames) {
			if (toolName.getText().contains("NeoFax") || toolName.getText().contains("Pediatrics")) {
				click(driver, "Tool Selection", toolName);
				break;
			} else {
				hoverOnOtherToolsToolbar();
				click(driver, "Tox and Drug Product option", neofaxMenu);
			}
		}

		return PageFactory.initElements(this.driver, TOD_HomePage.class);
	}

	public void hoverOnOtherToolsToolbar() {
		Actions builder = new Actions(this.driver);
		builder.moveToElement(otherToolsDropDownBackground).perform();
	}

	public void validateToolLinkPage(String subscription) throws IOException {
		String[] subscritionType = subscription.split(";");
		for (int i = 0; i < subscritionType.length; i++) {
			WebElement toolLink = null;
			switch (subscritionType[i]) {
			case "Drug Interactions":
				toolLink = drugInteractionsToolbarLink;

				break;
			case "IV Compatibility":
				toolLink = ivCompatToolbarLink;

				break;

			}
			try {
				if (toolLink.isDisplayed())
					extentReport.passWithScreenShot(driver, subscritionType[i] + " displayed on Micromedex Home page");
				if ((subscritionType.length + 2) == (all_tabs.size())) {
					extentReport.PASS("Subscription Tabs Validation",
							subscritionType[i] + " only displayed on Micromedex Home page");
				} else {
					extentReport.FAIL(driver, "Subscription Tabs Validation",
							" More tabs displayed on Micromedex Home page other than subscription "
									+ subscritionType[i]);
				}
			} catch (Exception e) {
				extentReport.failWithScreenShot(driver, subscritionType[i] + " not displayed on Micromedex Home page");
			}
			clickOnSubscriptionTab(toolLink, subscritionType[i]);
		}
	}

	public void clickOnSubscriptionTab(WebElement tabXpath, String tabName) throws IOException {
		click(driver, "Clicked on subscription Tab", tabXpath);
		if (tabTitle.getText().equalsIgnoreCase(tabName)) {
			extentReport.PASS("Subscription Tabs Name Validation",
					"Tab Name displayed on Micromedex Home page is as expected");
		} else {
			extentReport.FAIL(driver, "Subscription Tabs Name Validation",
					"Tab Name displayed on Micromedex Home page is not expected");
		}
	}

	public void clearCache() throws InterruptedException {
		driver.get("chrome://settings/clearBrowserData");
		cacheURL.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
	}

	public String getParentWindow(WebDriver driver) {
		return driver.getWindowHandle();

	}

	/**
	 * Use this method to click on Help link in MDX Header
	 * 
	 * @return to help page
	 * @throws InterruptedException
	 *             ,IOException
	 */
	public HelpPage clickHelpLink() throws InterruptedException, IOException {

		try {

			click(driver, "Click on Help link", helpLink);

		} catch (Exception e) {
			extentReport.FailWithException(driver, "Click on help link", "Help ink element is not clicked", e);
			logERROR("Help link element is not clicked", e);
		}

		try {
			swithToWindowHandleWithTitle(driver, "Micromedex Solutions Help");
			extentReport.PASS("Verification of window handling action", "Help window action is handled properly");
			log.info("Help window action is handled properly");

		} catch (Exception e) {
			extentReport.FailWithException(driver, "Help window handling", "Window handling action is not occurred", e);
			logERROR("Window handling action is not occurred", e);
		}

		return PageFactory.initElements(driver, HelpPage.class);

	}

	/**
	 * Use this method to click on User guide link in MDX footer
	 * 
	 * @return to User guide page
	 * @throws InterruptedException
	 *             ,IOException
	 */
	public UserGuidePage clickUserGuideLink() throws InterruptedException, IOException {
		try {

			click(driver, "User guide link", userGuideLink);
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Click on User guide link", "User guide link element is not clicked",
					e);
			logERROR("User guide element is not clicked", e);
		}
		try {
			swithToWindowHandleWithTitle(driver, "IBM MICROMEDEX� User Guide");
			extentReport.PASS("Verification of window handling action", "User guide window action is handled properly");
			log.info("User guide window action is handled properly");

		} catch (Exception e) {
			extentReport.FailWithException(driver, "User guide window handling",
					"Window handling action is not occurred", e);
			logERROR("Window handling action is not occurred", e);

		}
		return PageFactory.initElements(driver, UserGuidePage.class);

	}

	public void LogOut() throws IOException {
		click(driver, "Logout", logoutButton);
	}
}
