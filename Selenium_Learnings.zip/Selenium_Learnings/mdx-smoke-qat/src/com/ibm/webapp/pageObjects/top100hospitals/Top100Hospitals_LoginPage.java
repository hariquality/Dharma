package com.ibm.webapp.pageObjects.top100hospitals;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.config.JenkinsConfiguration;
import com.ibm.webapp.utils.Selenese;

public class Top100Hospitals_LoginPage extends Selenese
{
   private final WebDriver driver;

   @FindBy(xpath = "//*[@id='login.username_index_0']")
   private WebElement UserName;

   @FindBy(xpath = "//*[@id='login.password_index_0']")
   private WebElement Password;

   @FindBy(xpath = "//*[@title='Report Search Page.']")
   private WebElement ReportSearchPage;

   @FindBy(xpath = "//*[@id='loginImage']/img")
   private WebElement Login;

   Top100Hospitals_HomePage homepage;
   

   public Top100Hospitals_LoginPage(WebDriver driver) throws IOException
   {
      this.driver = driver;
      PageFactory.initElements(this.driver, this);
      WebDriverWait wait = new WebDriverWait(this.driver, 20);
     
      try
      {
         wait.until(ExpectedConditions.visibilityOf(UserName));
      }
      catch (Exception e)
      {
         extentReport.FAIL(driver,
                           "Top100Hospitals_LoginPage",
                           "Login Page is not visible");
         log.error("Login Page is not visible");
      }
   }

   /**
    * to login into top 100 hospital application      
    * @param creds
    * @return
    * @throws IOException
    */
   public Top100Hospitals_HomePage loginToTop100(String creds) throws IOException
   {
      try
      {
         driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
         String[] cred = JenkinsConfiguration.getValueFromPropertiesFile(creds)
               .split("/");
         sendKeys(driver, "Username textbox", UserName, cred[0]);
         sendKeys(driver, "Password textbox", Password, cred[1]);
         click(driver, "Login button", Login);
         extentReport.PASS("Login", "Login into Top 100 Application Successful");
         log.info("Login into Top 100 Application Successful");
      }
      catch (Exception e)
      {
         e.printStackTrace();
         extentReport.FailWithException(driver, "LOGIN", "Login to top 100 Failed.", e);
         logERROR("Login to top 100 Failed.", e);
      }
      return PageFactory.initElements(this.driver, Top100Hospitals_HomePage.class);
      
   }
   
  

}
