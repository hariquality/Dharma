package com.ibm.webapp.pageObjects.mdx;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.ibm.webapp.utils.Selenese;

/**
 * @author APeavy
 * 
 */
public class UserGuidePage extends Selenese
{
   private final WebDriver driver;

   public UserGuidePage(WebDriver driver) throws Exception
   {
      this.driver = driver;
      PageFactory.initElements(driver, this);
      driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
   }

   /**
    * Use this to verify user guide PDF window loaded with expected content.
    * 
    * @throws Exception
    */

   public void verifyUserGuideHeader() throws Exception
   {
      String url = "https://qa.micromedexsolutions.com/micromedex2/4.372.5/webtier/pdf/UserGuide.pdf";
      driver.get(url);
      try
      {
         String pdfContent = readPDFContent(driver.getCurrentUrl());
         Assert.assertTrue(pdfContent.contains("IBM MICROMEDEX"));
         extentReport.PASS(
                           "Verification of PDF loaded with the text :IBM MICROMEDEX",
                           "Expected text is present in User guide PDF window");
         log.info("Expected text is present in User guide PDF window");
      }
      catch (Exception e)
      {
         extentReport.FailWithException(driver,
                                        "Verification of expected content is present in User guide PDF window",
                                        "Expected content is not present in user guide PDF window",
                                        e);
         logERROR("Expected content is not present in user guide PDF window",
                  e);
      }

   }

   /**
    * Use this method to read PDF content from user guide popup window
    * 
    * @throws Exception
    */

   public String readPDFContent(String appUrl) throws Exception
   {
      URL url = new URL(appUrl);
      InputStream is = url.openStream();
      BufferedInputStream fileToParse = new BufferedInputStream(is);
      PDDocument document = null;
      String output = null;
      try
      {
         document = PDDocument.load(fileToParse);
         extentReport.PASS("Verification of PDF loaded",
                           "User guide PDF window loaded successfully");
         log.info("User guide PDF window loaded successfully");
         output = new PDFTextStripper().getText(document);
         // System.out.println(output);
      }
      finally
      {
         if (document != null)
         {
            document.close();
         }
         fileToParse.close();
         is.close();
      }
      return output;
   }

}
