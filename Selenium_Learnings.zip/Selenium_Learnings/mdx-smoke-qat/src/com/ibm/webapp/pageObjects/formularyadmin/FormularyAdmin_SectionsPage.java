package com.ibm.webapp.pageObjects.formularyadmin;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;


public class FormularyAdmin_SectionsPage extends Selenese
{
   private final WebDriver driver;

   @FindBy(xpath = "//strong[text()='Sections:']")
   private WebElement sectionHeader;
   
   @FindBy(linkText="Files")
   private WebElement linkFiles;

   public FormularyAdmin_SectionsPage(WebDriver driver)
   {
      this.driver = driver;
      PageFactory.initElements(this.driver, this);
      WebDriverWait wait = new WebDriverWait(this.driver, 60);
      wait.until(ExpectedConditions.visibilityOf(sectionHeader));
   }
   
   public FormularyAdmin_FilesPage clickOnFiles(){
     // linkFiles.click();
      try
      {
         click(driver, "File upload", linkFiles);
      }
      catch (IOException e)
      {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
      FormularyAdmin_FilesPage pip = PageFactory.initElements(driver, FormularyAdmin_FilesPage.class);
      return pip;
     }
}
