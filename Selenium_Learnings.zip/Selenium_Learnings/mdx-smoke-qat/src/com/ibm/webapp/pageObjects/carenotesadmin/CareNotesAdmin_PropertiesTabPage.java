package com.ibm.webapp.pageObjects.carenotesadmin;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class CareNotesAdmin_PropertiesTabPage extends Selenese {
	protected final WebDriver driver;

	@FindBy(xpath = "//a[contains(@href,'carenotesadmin.Documents')]")
	private WebElement documentsTab;

	@FindBy(xpath = "//a[contains(@href,'carenotesadmin.Images')]")
	private WebElement imagesTab;

	@FindBy(xpath = "//table[contains(@class,'blueBackground')]")
	private WebElement majorTable;

	@FindBy(xpath = "//a[contains(@href,'carenotesadmin.HotLists')]")
	private WebElement hotListsTab;

	public CareNotesAdmin_PropertiesTabPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(this.driver, 15), this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		wait.until(ExpectedConditions.visibilityOf(majorTable));
	}

	/**
	 * Click on Documents tab in carenotes admin
	 * 
	 * @return carenotes admin documents page object
	 */
	public CareNotesAdmin_DocumentsTabPage clickDocumentsTab() {

		try {
			click(driver, "click on documents tab", documentsTab);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		CareNotesAdmin_DocumentsTabPage page = PageFactory.initElements(driver, CareNotesAdmin_DocumentsTabPage.class);
		return page;
	}

	/**
	 * click on hotlist tab in carenotes admin
	 * 
	 * @return
	 */
	public CareNotesAdmin_HotlistTabPage clickHotListsTab() {
		hotListsTab.click();
		CareNotesAdmin_HotlistTabPage page = PageFactory.initElements(driver, CareNotesAdmin_HotlistTabPage.class);
		return page;
	}

	/**
	 * Click on Images tab in carenotes admin
	 * 
	 * @return carenotes admin images page object
	 */
	public CareNotesAdmin_ImagesTabPage clickImagesTab() {
		try {
			click(driver, "click on images tab", imagesTab);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		CareNotesAdmin_ImagesTabPage page = PageFactory.initElements(driver, CareNotesAdmin_ImagesTabPage.class);
		return page;
	}
}
