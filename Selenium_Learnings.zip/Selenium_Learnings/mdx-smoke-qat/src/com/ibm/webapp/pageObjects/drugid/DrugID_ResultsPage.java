package com.ibm.webapp.pageObjects.drugid;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.pageObjects.mdx.MDX_HeaderPage;
import com.ibm.webapp.utils.Selenese;

public class DrugID_ResultsPage extends Selenese

{
   WebDriver driver;

   @FindBy(xpath = "//tr[@id='Content_1']")
   private WebElement resultRow1;

   @FindBy(xpath = "//*[@id='Content_2']//td/a [.='Triple Therapy - Amoxicillin']")
   private WebElement drugIdentLink;

   @FindBy(xpath = "//table[@id='id_of_table']//tr/td[3]/a")
   private List<WebElement> imprintDrugs;

   @FindBy(xpath = "//*[@id='imprintScroll']/table[2]/tbody/tr/td[1]/table/tbody/tr[2]/td")
   private WebElement drugIDLabel;

   @FindBy(xpath = "//tr[@id = 'Content_1']//a [.='Tylenol With Codeine No. 3']")
   private WebElement firstDrugNameToToxLink;

   // @FindBy(xpath = "//*[@id=\"Content_1\"]/td[3]/a")
   @FindBy(xpath = "//a[contains(@href,'PDX_DDX')]")
   private WebElement drugNameToImage;

   @FindBy(xpath = "//tr[@id = 'Content_1']//a [.='CODEINE']")
   private WebElement firstDrugToPoisendexMgmtLink;

   @FindBy(xpath = "//button/span[text()='Search Images']")
   protected WebElement searchImagesButton;

   @FindBy(xpath = "/html/body/div[8]/div/div[5]/div[2]/table/tbody/tr[1]/td[2]")
   protected WebElement drugResult;

   @FindBy(xpath = "//*[@id='sideOneTxt']")
   protected WebElement imprintSearchTerm;

   // Pagination Links
   @FindBy(id = "page-first-on")
   protected WebElement lnkFirstOn;

   @FindBy(id = "page-first-off")
   protected WebElement lnkFirstOff;

   @FindBy(id = "page-last-on")
   protected WebElement lnkLastOn;

   @FindBy(id = "page-last-off")
   protected WebElement lnkLastOff;

   @FindBy(id = "page-previous-on")
   protected WebElement lnkPrevOn;

   @FindBy(id = "page-previous-off")
   protected WebElement lnkPrevOff;

   @FindBy(id = "page-next-on")
   protected WebElement lnkNextOn;

   @FindBy(id = "page-next-off")
   protected WebElement lnkNextOff;

   @FindBy(xpath = "//*[@id='show']/a")
   protected WebElement showImgLnk;

   @FindBy(xpath = "//*[@id='hide']/a")
   protected WebElement hideImgLnk;

   @FindBy(xpath = "//input[contains(@onclick,3) and @value='Close']")
   protected WebElement btnClose2;

   public DrugID_ResultsPage(WebDriver driver)
   {
      this.driver = driver;
      PageFactory.initElements(driver, this);
      driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
   }

   public MDX_HeaderPage getHeaderPage()
   {
      MDX_HeaderPage headerPage = PageFactory
            .initElements(driver, MDX_HeaderPage.class);
      return headerPage;
   }

	/**
	 * @return
	 * @throws IOException
	 */
	public void isResultRow1Displayed() throws IOException {
		isElementDisplayed(driver, "Results Row Validation", resultRow1);
	}
	

   public DrugID_InformationPopupPage clickFirstDrugNameToToxLink() throws IOException
   {
      // firstDrugNameToToxLink.click ();

      click(driver, "click first drug name tox link", firstDrugNameToToxLink);
      try
      {
         Thread.sleep(1500);
      }
      catch (InterruptedException e)
      {
         e.printStackTrace();
      }
      DrugID_InformationPopupPage drugInfoPopup = PageFactory
            .initElements(driver, DrugID_InformationPopupPage.class);
      return drugInfoPopup;

   }

   public DrugID_ToxAndDrugSearchResultsPage clickOnToxAndDrugLink() throws InterruptedException,
                                                                     Exception
   {
      Thread.sleep(2000);
      // drugNameToImage.click();
      click(driver, "click on tox and drug results link", drugNameToImage);
      DrugID_ToxAndDrugSearchResultsPage tdSearchResultsPage = PageFactory
            .initElements(driver, DrugID_ToxAndDrugSearchResultsPage.class);
      return tdSearchResultsPage;
   }

   public DrugID_MDXLandingPage clickOnPoisindexLink() throws IOException
   {
      click(driver,"click first Poinindex link",firstDrugToPoisendexMgmtLink);
      DrugID_MDXLandingPage homePage = PageFactory.initElements(driver, DrugID_MDXLandingPage.class);
      return homePage;
      
   }
}
