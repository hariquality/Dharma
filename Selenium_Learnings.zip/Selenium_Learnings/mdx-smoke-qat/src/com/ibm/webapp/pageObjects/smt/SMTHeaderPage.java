package com.ibm.webapp.pageObjects.smt;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;


public class SMTHeaderPage extends Selenese  {
	WebDriver driver;

	@FindBy(xpath = "//span[contains(text(),'Gateway')]")
	private WebElement gatewayLink;

	@FindBy(xpath = "//a[contains(@href,'pf.Logout')]/span")
	private WebElement logoutLink;

	//SMT Menus and submenus
	@FindBy(xpath="/html/body/table/tbody/tr[2]/td[1]/table")
	private WebElement mainToolbar;
	
	//SMT system tab 
	@FindBy(id = "menu0")
	private WebElement tabSystem;
		
	//SMT system tab submenu1
	@FindBy(xpath="//a[@class='menuNo' and text()='System']")
	private WebElement dropdown_System;
		
	@FindBy(xpath="//a[@class='menuNo' and text()='Generate License Key']")
	//@FindBy(xpath = "//*[@id='qmitemhl0_2']/a")
	private WebElement generate_licensekey;
	
	
	@FindBy(xpath="//a[text()='Generate CKO License Key']")
//	@FindBy(xpath = "//*[@id='qmitemhl0_3']/a")
	private WebElement generate_ckolicensekey;
	
	
	public SMTHeaderPage(WebDriver driver)   {
	      this.driver = driver;
	      PageFactory.initElements(driver, this);
	     // driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	      WebDriverWait wait = new WebDriverWait(this.driver, 20);
	      wait.until(ExpectedConditions.visibilityOf(tabSystem));
	   }

	
	
	public SMT_HomePage clickOnSystem() throws InterruptedException{
		Actions hover = new Actions(driver);
		hover.moveToElement(tabSystem).perform();
		dropdown_System.click();
		Thread.sleep(3000);
		SMT_HomePage smtHomePage = PageFactory.initElements(driver, SMT_HomePage.class);
		return smtHomePage;
	}
	
	
	
	public SMTGenerateLicenseKeyPage clickOnGenerateLicenseKey(){
		Actions hover = new Actions(driver);
		hover.moveToElement(tabSystem).perform();
		generate_licensekey.click();
		SMTGenerateLicenseKeyPage genlicensekeyPage = PageFactory.initElements(driver, SMTGenerateLicenseKeyPage.class);
		return genlicensekeyPage;
	}

	public SMTGenerateCKOLicenseKeyPage clickOnGenerateCKOLicenseKey()
	{
		Actions hover = new Actions(driver);
		hover.moveToElement(tabSystem).perform();
		hover.click(generate_ckolicensekey).build().perform();//generate_ckolicensekey.click();
		SMTGenerateCKOLicenseKeyPage genckolicensekeyPage = PageFactory.initElements(driver, SMTGenerateCKOLicenseKeyPage.class);
		return genckolicensekeyPage;
		
	}
		/**
	 * Check for logout link presence
	 */

	public boolean isLogoutLinkDisplayed() {
		if (logoutLink.isDisplayed()) {
			return true;
		} else 	return false;
	}

	/**
	 * Click the logout link
	 */
	
	public void logout() {
		logoutLink.click();
	}

}
