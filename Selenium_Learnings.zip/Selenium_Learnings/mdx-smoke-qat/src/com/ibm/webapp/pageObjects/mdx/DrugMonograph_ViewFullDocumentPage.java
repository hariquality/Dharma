package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.ibm.webapp.utils.Selenese;

public class DrugMonograph_ViewFullDocumentPage extends Selenese {

	WebDriver driver;

	@FindBy(linkText = "View Document Sections")
	private WebElement lnk_ViewDoc;

	@FindBy(xpath = "//input[@id='neonatalpanel_fullDocumentSearchText']")
	private WebElement searchBar_neo;

	@FindBy(xpath = "//input[@id='pediatricpanel_fullDocumentSearchText']")
	private WebElement searchBar_ped;

	@FindBy(xpath = "//div[@id='neonatalpanel_fulldoc_search_container']/input[2]")
	public WebElement searchIcon_neo;

	@FindBy(xpath = "//div[@id='pediatricpanel_fulldoc_search_container']/input[2]")
	public WebElement searchIcon_ped;

	@FindBy(xpath = "//div[@id='neonatalpanel_fulldoc_search_container']/select")
	public WebElement dropdown_neo;

	@FindBy(xpath = "//div[@id='pediatricpanel_fulldoc_search_container']/select")
	public WebElement dropdown_ped;

	@FindBy(xpath = "//label[@id='neonatalpanel_resultId']")
	private WebElement neo_searchResults;

	@FindBy(xpath = "//label[@id='pediatricpanel_resultId']")
	private WebElement ped_searchResults;

	@FindBy(xpath = "//div[@id='neonatalpanel_fullcontentpanel']//span[@class='highlight' or @class='currentHighlight']")
	private List<WebElement> highlightedElement_neo;

	@FindBy(xpath = "//div[@id='pediatricpanel_fullcontentpanel']//span[@class='highlight' or @class='currentHighlight']")
	private List<WebElement> highlightedElement_ped;

	/**
	 * Default Constructor for DrugMonograph class
	 */
	public DrugMonograph_ViewFullDocumentPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		wait.until(ExpectedConditions.visibilityOf(lnk_ViewDoc));

	}

	/**
	 * enters the user input into the search bar of viewFull Document Page.
	 * 
	 * @param userInput
	 *            = enter the input to get highlighted in document Page.
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public void enterSearchInput(String userInput, String tabName) throws InterruptedException, IOException {
		try {

			if (tabName.equalsIgnoreCase("Neo")) {
				searchBar_neo.clear();
				sendKeys(driver, "Search bar of view full document page", searchBar_neo, userInput);
				Thread.sleep(2000);
				click(driver, "Search icon", searchIcon_neo);
			} else {
				searchBar_ped.clear();
				sendKeys(driver, "Search bar of view full document page", searchBar_ped, userInput);
				Thread.sleep(2000);
				click(driver, "Search icon", searchIcon_ped);
			}
			Thread.sleep(2000);
		} catch (NoSuchElementException e) {
			e.printStackTrace();
		}
	}

	/**
	 * gets the position count for currently highlighted element. and gets the
	 * total matched count for searched text.
	 * 
	 * @param currentORtotalMatch
	 *            = enter current to get the value for current highlighted
	 *            element OR enter totalMatch to get the total matched count.
	 *            based on the userInput @returns the least value or max value
	 * @throws IOException
	 */
	public int getValueFor(String currentORtotalMatch, String tabName) throws IOException {
		String actualSearchResult = getDefaultsearchResult(tabName);
		if (currentORtotalMatch.equalsIgnoreCase("current")) {
			return Integer.parseInt(actualSearchResult.split(" results")[0].split(" of")[0]);
		} else {
			
			return Integer.parseInt(actualSearchResult.split(" results")[0].split(" of ")[1]);
		}
	}

	/**
	 * Gets the Text Total count present in the page and compared with expected
	 * text count value
	 * 
	 * @param currentORtotalMatch
	 *            = pass as total or current
	 * @param tabName
	 *            = pass as NEO or PED
	 * @throws IOException
	 */
	public void getTotalValue(String currentORtotalMatch, String tabName) throws IOException {
		// int currentValue1 = getValueFor(currentORtotalMatch,tabName);
		int totalValue = getValueFor(currentORtotalMatch, tabName);
		int ExpectedTotalValue = getHighlightedTextCount(tabName);
		try {
			extentReport.PASS("Verification of total text count present in the view full document page",
					"Actual and expected text count is matched in the view full document page");
			log.info("Actual and expected text count is matched in the view full document page");

		} catch (Exception e) {
			extentReport.FailWithException(driver, "Verification of total text count present in the view full document page",
					"Actual and expected text count is not matched in the view full document page", e);
			logERROR("Actual and expected text count is not matched in the view full document page", e);
			Assert.assertEquals(totalValue, ExpectedTotalValue, "Expected TextCount of TotalValue is incorrect");
		}

	}

	/**
	 * Gets the Search Result value present in the page
	 * 
	 * @param tabName
	 *            = pass as NEO or PED
	 * @throws IOException 
	 */
	public String getDefaultsearchResult(String tabName) throws IOException {
		
		
			if (tabName.equalsIgnoreCase("neo"))
		
		{
			return neo_searchResults.getText();}
		else
		{
			return ped_searchResults.getText();
		}
		
		
	}

	/**
	 * get the total count of highlightedText
	 * @param tabName = pass as NEO or PED
	 * @throws IOException
	 * @returns "0" if no elements are highlighted.
	 */
	public int getHighlightedTextCount(String tabName) throws IOException {
		try {
			if (tabName.equalsIgnoreCase("neo")) {
				
				return highlightedElement_neo.size();
			} else {
				
				return highlightedElement_ped.size();
			}

		} catch (NoSuchElementException e) {
			extentReport.FAIL(driver, "Getting the total count of highlighted Text", "Problem of getting the highlighted text in view full document page");
			logERROR("Problem of getting the highlighted text in view full document page");
			return 0;
		}
	}
}
