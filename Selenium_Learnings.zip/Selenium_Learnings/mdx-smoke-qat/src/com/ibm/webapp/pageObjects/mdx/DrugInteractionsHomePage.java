package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class DrugInteractionsHomePage extends Selenese {

	WebDriver driver;

	@FindBy(id = "WordWheel_SearchTerm_index_0")
	private WebElement searchTermInputBox;

	@FindBy(xpath = "//div[@id = 'WordWheel_list']/div")
	private List<WebElement> matchingDrugNames;

	@FindBy(xpath = "//a/img[contains(@src,'arrow_next.gif')]")
	private WebElement moveDrugRightButton;

	@FindBy(xpath = "//input[@title='Submit']")
	private WebElement submitButtonSingle;

	@FindBy(id = "WordWheel_list")
	private WebElement wwList;

	public DrugInteractionsHomePage(WebDriver driver) throws IOException {
	      this.driver = driver;
	      PageFactory.initElements(this.driver, this);
	      WebDriverWait wait = new WebDriverWait(this.driver, 20);
	      try
	      {
	         wait.until(ExpectedConditions.visibilityOf(wwList));
	      }
	      catch (Exception e)
	      {
	         extentReport.FailWithException(driver,"DI HomePage Check",
	                           "DI HomePage is not displayed",e);
	         log.error("LoginButton is not visible is not message");
	      }
	}

	public void typeNewCharsIntoSearchBoxAndWaitForWordWheel(String searchInput) throws IOException {
		try {
			searchTermInputBox.clear();
			searchTermInputBox.sendKeys(searchInput);
			extentReport.PASS("DI Page Verification", "Search input character entered correctly");
			log.info("Search input character entered correctly");
			Thread.sleep(1000);
		} catch (Exception e) {
			extentReport.FAIL(driver, "DIPage Search input method ", "Search input method in DI result page");
			logERROR("Search input is not working in DI result page");

		}
	}

	public void moveDrugFromLeftToRight(String target) throws IOException {
		// loop through list of elements and single click on the target one
		try {
			Iterator<WebElement> itr = matchingDrugNames.iterator();
			System.out.println("matchingDrugNames size=" + matchingDrugNames.size());
			while (itr.hasNext()) {
				WebElement element = itr.next();
				if (element.getAttribute("fullname").compareTo(target) == 0) {
					element.click();
					break;
				}
			}
			moveDrugRightButton.click();
			extentReport.PASS("DI Page Verification - moveDrugFromLeftToRight",
					"Entered drug moved from left to right in Drugs to check");
			log.info("Entered drug moved from left to right in Drugs to check");
		} catch (Exception e) {
			extentReport.FAIL(driver, "DIPage", "Move drug method in DI page is not working");
			logERROR("Move drug method in DI page is not working");

		}
	}

	public DrugInteractionsResultsPage clickSubmitButtonSingle() throws IOException {
		try {
			submitButtonSingle.click();
			extentReport.PASS("DI Page Verification clickSubmitButtonSingle", "Submitt button clicked in DI page");
			log.info("Submitt button clicked in DI page");
		} catch (Exception e) {
			extentReport.FAIL(driver, "DIPage", "Move drug method in DI page is not working");
			logERROR("Move drug method in DI page is not working");

		}
		DrugInteractionsResultsPage diResultPage = PageFactory.initElements(driver, DrugInteractionsResultsPage.class);
		return diResultPage;
	}
}
