package com.ibm.webapp.pageObjects.carenotes;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.ibm.webapp.utils.Selenese;

public class CareNotes_SearchPage extends Selenese {
	protected final WebDriver driver;

	@FindBy(id = "Search.searchText_index_0")
	private WebElement searchInputTextBox;

	@FindBy(id = "LocationList_index_0")
	private WebElement locationDropdown;

	@FindBy(xpath = "//*[@id='PFFormActionId_carenotes.SetLocation']")
	private WebElement locationGoButton;

	@FindBy(xpath = "//*[@id='menu']/li[2]/a")
	private WebElement hotListLink;

	@FindBy(xpath = "//*[@id='menu']/li[3]/a")
	private WebElement careAndCondLink;

	@FindBy(xpath = "//*[@id='menu']/li[4]/a")
	private WebElement medTitlesLink;

	@FindBy(xpath = "//*[@id='menu']/li[5]/a")
	private WebElement labTitlesLink;

	@FindBy(id = "PFFormActionId_carenotescommon.Search")
	private WebElement searchButton;

	@FindBy(xpath = "//*[contains(text(),'The search ran successfully but no results were found.')]")
	private WebElement unpublishedMessage;

	@FindBy(xpath = "//*[contains(text(),'LOGOUT')]")
	private WebElement logoutLink;

	public CareNotes_SearchPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		wait.until(ExpectedConditions.visibilityOf(searchInputTextBox));
	}

	/**
	 * method to choose location in carenotes search page
	 * 
	 * @param location
	 * @return carenotes search page
	 */
	public CareNotes_SearchPage chooseLocation(String location) {

		try {
			selectDropDownByVisibleText(driver, locationDropdown, location);
			click(driver, "click on Go button after selecting location", locationGoButton);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		CareNotes_SearchPage page = PageFactory.initElements(driver, CareNotes_SearchPage.class);
		return page;
	}

	public void searchUnpublished(String searchTerm) throws IOException {
		sendKeys(driver, "search input Text", searchInputTextBox, searchTerm);
		click(driver, "click search", searchButton);
		verifyunPublishMessage("The search ran successfully but no results were found.");
	}

	/**
	 * verify message appearing for successful savenotes publish
	 * 
	 * @param message
	 */
	public void verifyunPublishMessage(String message) {
		Assert.assertTrue((unpublishedMessage.getText().contains(message)));
	}

	/**
	 * Enter a search term and search for the savenotes created in carenotes
	 * admin admin
	 * 
	 * @param searchTerm
	 * @return
	 * @throws IOException
	 */
	public CareNotes_SelectDocumentsPage search(String searchTerm) throws IOException {
		sendKeys(driver, "search input Text", searchInputTextBox, searchTerm);
		click(driver, "click search", searchButton);
		CareNotes_SelectDocumentsPage page = PageFactory.initElements(driver, CareNotes_SelectDocumentsPage.class);

		try {
			if (page != null) {
				extentReport.PASS("Create save notes and verify in Carenotes",
						"Save Note created in Carenotes Admin is displayed in Carenotes");
				logINFO("Save Note created in Carenotes Admin is displayed in Carenotes");
			} else {
				extentReport.FAIL(driver, "Create save notes and verify in Carenotes",
						"Save Note created in Carenotes Admin is not displayed in Carenotes");
				logERROR("Save Note created in Carenotes Admin is displayed in Carenotes");
			}
		} catch (Exception e) {
			extentReport.FAIL(driver, "Create save notes and verify in Carenotes",
					"Save Note created in Carenotes Admin is not displayed in Carenotes - Some Exception occured");
			logERROR("Micromedex Home Page is not displayed- Some Exception occured");
		}

		return page;
	}

	public void LogOut() throws IOException {
		click(driver, "LOGOUT", logoutLink);
	}

	public CareNotes_HotlistPage clickHotListLink() {
		try {
			click(driver, "click on hotlist link", hotListLink);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		CareNotes_HotlistPage page = PageFactory.initElements(driver, CareNotes_HotlistPage.class);
		return page;
	}

	public CareNotes_CareAndConditionTitlesPage clickCareAndConditionTitlesLink() {
		try {
			click(driver, "click on care and conditions link", careAndCondLink);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		CareNotes_CareAndConditionTitlesPage page = PageFactory.initElements(driver,
				CareNotes_CareAndConditionTitlesPage.class);
		return page;
	}

	public CareNotes_MedicationTitlesPage clickMedicationTitlesLink() {
		try {
			click(driver, "click on medication titles link", medTitlesLink);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		CareNotes_MedicationTitlesPage page = PageFactory.initElements(driver, CareNotes_MedicationTitlesPage.class);
		return page;
	}

	public CareNotes_LabTitlesPage clickLabTitlesLink() {
		try {
			click(driver, "click on lab titles link", labTitlesLink);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		CareNotes_LabTitlesPage page = PageFactory.initElements(driver, CareNotes_LabTitlesPage.class);
		return page;
	}

}
