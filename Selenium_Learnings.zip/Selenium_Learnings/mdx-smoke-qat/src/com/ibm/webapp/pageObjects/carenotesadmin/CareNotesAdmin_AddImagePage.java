package com.ibm.webapp.pageObjects.carenotesadmin;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class CareNotesAdmin_AddImagePage extends Selenese
{
   
   protected final WebDriver driver;

   @FindBy(xpath = "//input[@id='imageFile']")
   private WebElement btnChooseImage;
  
   @FindBy(id = "altTag_index_0")
   private WebElement txtImageTitle;

   @FindBy(id = "description_index_0")
   private WebElement txtImageDescription;
   
   @FindBy(id = "PFFormActionId_shielded.carenotesadmin.AddImage")
   private WebElement btnSave;

   
   public CareNotesAdmin_AddImagePage(WebDriver driver)
   {
      this.driver = driver;
      PageFactory.initElements(this.driver, this);
      WebDriverWait wait = new WebDriverWait(this.driver, 20);
      wait.until(ExpectedConditions.visibilityOf(btnChooseImage));
   }
   /**
    * method to upload an image in CareNotes Administration
    * 
    * @return Images page
    */
   public CareNotesAdmin_AddImagePage clickChooseImageButton()
   {
      
     System.out.println(System.getProperty("user.dir"));
      String imgFilePath = System.getProperty("user.dir") + "\\Uploads\\QA_TestImage.jpg";
      
      
      try
      {
         sendKeys(driver, "Choose File", btnChooseImage, imgFilePath);
      }
      catch (IOException e)
      {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
     
      CareNotesAdmin_AddImagePage page = PageFactory
            .initElements(driver, CareNotesAdmin_AddImagePage.class);
      
      page.uploadFileWithRobot(imgFilePath);
      return page;
   }
   /**
    * method to upload an Image using Robot in CareNotes Administration
    * 
    */
   
   public void uploadFileWithRobot(String imagePath)
   {
      StringSelection stringSelection = new StringSelection(imagePath);
      Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
      clipboard.setContents(stringSelection, null);

      Robot robot = null;

      try
      {
         robot = new Robot();
      }
      catch (AWTException e)
      {
         e.printStackTrace();
      }

      robot.delay(250);
      robot.keyPress(KeyEvent.VK_ENTER);
      robot.keyRelease(KeyEvent.VK_ENTER);
      robot.keyPress(KeyEvent.VK_CONTROL);
      robot.keyPress(KeyEvent.VK_V);
      robot.keyRelease(KeyEvent.VK_V);
      robot.keyRelease(KeyEvent.VK_CONTROL);
      robot.keyPress(KeyEvent.VK_ENTER);
      robot.delay(150);
      robot.keyRelease(KeyEvent.VK_ENTER);
   }
   
   

   /**
    * method to click on a Save Button
    * throws IO exception
    */
   public CareNotesAdmin_ImagesTabPage clickSaveButton()
   {
      try
      {
         click(driver, "Click Save button", btnSave);
      }
      catch (IOException e)
      {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
      CareNotesAdmin_ImagesTabPage page = PageFactory
            .initElements(driver, CareNotesAdmin_ImagesTabPage.class);
      return page;
   }
   
   /**
    * method to add an Image title
    * throws IO exception
    */
   public void enterImgTitleTxt(String name)
   {
      try
      {
         sendKeys(driver, "Title/Alt Tag", txtImageTitle, name);
      }
      catch (IOException e)
      {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
   }
   /**
    * method to add an Image Description
    * throws IO exception
    */
   public void enterImgDescriptionTxt(String name)
   {
      try
      {
         sendKeys(driver,"Description", txtImageDescription, name);
      }
      catch (IOException e)
      {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
   }

   

}
