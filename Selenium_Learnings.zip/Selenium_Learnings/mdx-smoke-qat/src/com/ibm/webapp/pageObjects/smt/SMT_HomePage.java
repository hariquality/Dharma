package com.ibm.webapp.pageObjects.smt;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class SMT_HomePage extends Selenese {
	WebDriver driver;

	@FindBy(xpath = "//a[@class='menuNo' and text()='Generate License Key']")
	private WebElement generate_licensekey;

	@FindBy(xpath = "//a[@class='menuNo' and text()='Generate CKO License Key']")
	private WebElement generate_ckolicensekey;

	@FindBy(id = "menu0")
	private WebElement tabSystem;

	@FindBy(xpath = "//a[@class='menuNo' and text()='System']")
	private WebElement dropdown_System;

	@FindBy(xpath = "/html/body/table/tbody/tr[1]/td[3]/a[2]/span")
	private WebElement Logout;

	public SMT_HomePage(WebDriver driver) throws IOException {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		try {
			wait.until(ExpectedConditions.visibilityOf(tabSystem));
		} catch (Exception e) {
			extentReport.FAIL(driver, "SMT HomePage", "SMT HomePage is not displayed");
			log.error("SMT HomePage is not displayed");
		}
	}

	/**
	 * Use this method to verify SMT Home Page is displayed,
	 * 
	 * @throws IOException
	 */
	public void isHomePageDisplayed() throws IOException {
		try {
			if (driver.getTitle().equalsIgnoreCase("Application Suite - System Management Application")) {
				extentReport.PASS("SMT Home Page Verification", "SMT Home Page is displayed correctly");
			} else {
				extentReport.FAIL(driver, "SMT Home Page Verification", "SMT Home Page is not displayed");
			}
		} catch (Exception e) {
			extentReport.FAIL(driver, "SMT Home Page Verification",
					"SMT Home Page is not displayed- Some Exception occured");
		}

	}

	/**
	 * Use this method to log out of the application,
	 * 
	 * @throws IOException
	 */
	public void SMTLogout() throws IOException {
		click(driver, "Log out", Logout);
	}

	public SMTGenerateLicenseKeyPage clickOnGenerateLicenseKey() throws InterruptedException {
		Thread.sleep(1000);
		Actions hover = new Actions(driver);
		hover.moveToElement(tabSystem).perform();
		Thread.sleep(1000);
		generate_licensekey.click();
		SMTGenerateLicenseKeyPage genlicensekeyPage = PageFactory.initElements(driver, SMTGenerateLicenseKeyPage.class);
		return genlicensekeyPage;
	}

	public SMTGenerateCKOLicenseKeyPage clickOnGenerateCKOLicenseKey() throws IOException, InterruptedException {
		Thread.sleep(1000);
		Actions hover = new Actions(driver);
		hover.moveToElement(tabSystem).perform();
		Thread.sleep(1000);
		hover.click(generate_ckolicensekey).build().perform();// generate_ckolicensekey.click();
		SMTGenerateCKOLicenseKeyPage genckolicensekeyPage = PageFactory.initElements(driver,
				SMTGenerateCKOLicenseKeyPage.class);
		return genckolicensekeyPage;

	}

}
