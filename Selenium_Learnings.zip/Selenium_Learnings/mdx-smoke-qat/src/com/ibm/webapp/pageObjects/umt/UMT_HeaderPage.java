package com.ibm.webapp.pageObjects.umt;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.utils.Selenese;

public class UMT_HeaderPage extends Selenese {
	WebDriver driver;

	@FindBy(xpath = "//a[contains(text(),'Add New User')]")
	private WebElement addNewUser;

	@FindBy(xpath = "//a[contains(text(),'Tesing_grpJai')]")
	private WebElement SelectUserGrpName;

	@FindBy(xpath = "//img[contains(@alt,'Logout not found')]")
	private WebElement logoutLink;

	public void SelectUserGrpName() {
		SelectUserGrpName.click();
	}

	public UMT_HeaderPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	/**
	 * method to click the link to add a new user return editUsernamePage
	 * 
	 */
	public UMT_EditUserNamePage addNewUserLink() {
		addNewUser.click();
		UMT_EditUserNamePage editUsernamePage = PageFactory.initElements(driver, UMT_EditUserNamePage.class);
		return editUsernamePage;

	}

	/**
	 * method to log out of the application
	 * 
	 * 
	 */
	public void logout() {
		logoutLink.click();
		System.out.println("You have successfully logged out of the application. To log in again, click below.");

	}

}
