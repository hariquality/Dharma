package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.NeoFaxUtility;
import com.ibm.webapp.utils.Selenese;

public class DrugMonograph_DrugLandingPage extends Selenese {

	WebDriver driver;

	private WebDriverWait webDriverwait;

	@FindBy(className = "dmSearchInputText")
	public WebElement searchInputText_LandingPage;

	@FindBy(xpath = "//div[@id='neonatalpanel_taxonomy_panel']/ul/li/a")
	private List<WebElement> neoSectionHeaderList;

	@FindBy(xpath = "//div[@id='neonatalpanel_taxonomy_panel']/ul/li/ul/li/a")
	private List<WebElement> neoSectionSubHeaderList;

	@FindBy(xpath = "//div[@id='pediatricpanel_taxonomy_panel']/ul/li/a")
	private List<WebElement> pedSectionHeaderList;

	@FindBy(xpath = "(//div[@id='pediatricpanel_taxonomy_panel']/ul/li/a)[1]")
	public WebElement pedFirstSectionHeader;

	@FindBy(xpath = "//div[@id='pediatricpanel_taxonomy_panel']/ul/li/ul/li/a")
	private List<WebElement> pedSectionSubHeaderList;

	@FindBy(id = "neonatalpanel_section_topic_header")
	private WebElement neo_HeaderSectionName;

	@FindBy(id = "neonatalpanel_section_subtopic_header")
	private WebElement neo_SubSectionName;

	@FindBy(id = "pediatricpanel_section_topic_header")
	private WebElement ped_HeaderSectionName;

	@FindBy(id = "pediatricpanel_section_subtopic_header")
	private WebElement ped_SubSectionName;

	@FindBy(id = "neonatalpanelbackToTop")
	public WebElement neo_BackToTop;

	@FindBy(id = "neonatalpanel_section_subtopic_header_with_flag")
	public WebElement neo_BackToTopSectionName;

	@FindBy(id = "pediatricpanelbackToTop")
	public WebElement ped_BackToTop;

	@FindBy(id = "pediatricpanel_section_subtopic_header_with_flag")
	public WebElement ped_BackToTopSectionName;

	@FindBy(linkText = "View Full Document")
	private WebElement lnk_ViewFullDoc;

	/**
	 * Default Constructor for DrugMonograph class
	 */
	public DrugMonograph_DrugLandingPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		webDriverwait = new WebDriverWait(this.driver, 25);
		webDriverwait.until(ExpectedConditions.visibilityOf(searchInputText_LandingPage));
	}

	/**
	 * 
	 * @returns NeofaxUtility
	 */
	public NeoFaxUtility getNeofaxUtility() {
		return PageFactory.initElements(driver, NeoFaxUtility.class);

	}

	/**
	 * Verify the drug name in the drug landing page.
	 * 
	 * @param userInput
	 *            = entered drug name
	 * @throws IOException
	 */
	public boolean verifySearchInputText_LandingPage(String userInput) throws IOException {
		try {
			if (searchInputText_LandingPage.getText().equals(userInput)) {
				extentReport.PASS("Verification of drug name text in drug landing page",
						userInput + " is present in drug landing page");
				log.info(userInput + " is present in drug landing page");
				return true;
			}
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Verification of drug name text in drug landing page",
					userInput + " is not present in drug landing page", e);
			logERROR(userInput + " is not present in drug landing page", e);

		}
		return false;

	}

	/**
	 * validates the section headersectionName (i.e., validates headers like
	 * Medication Safety, Dosing/ Administration etc)
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * @parameter tabName = pass as Neo or Ped
	 *
	 */

	public boolean verifyHeaderSectionName(String tabName) throws InterruptedException, IOException {
		List<WebElement> sectionHeaderNameList = new ArrayList<WebElement>();
		WebElement sectionHeaderName = null;
		try {
			if (tabName.equalsIgnoreCase("Neo")) {
				sectionHeaderNameList = neoSectionHeaderList;
				sectionHeaderName = neo_HeaderSectionName;
			} else {
				sectionHeaderNameList = pedSectionHeaderList;
				sectionHeaderName = ped_HeaderSectionName;
			}
			for (WebElement element : sectionHeaderNameList) {
				element.click();
				Thread.sleep(1000);
				if (!element.getText().equals(sectionHeaderName.getText())) {
					return false;
				}
			}
			extentReport.PASS("Verification of Section header name of " + tabName,
					"Expected headers are present in drug landing page for " + tabName);
			log.info("Expected headers are present in drug landing page for " + tabName);

		} catch (NoSuchElementException e) {
			extentReport.FailWithException(driver, "Verification of Section header name of " + tabName,
					"Expected headers are present in drug landing page for " + tabName, e);
			logERROR("Expected headers are present in drug landing page for " + tabName, e);
			return false;
		}
		return true;
	}

	/**
	 * Validates the section headersectionName (i.e., validates headers like
	 * Medication Safety, Dosing/ Administration etc)
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * @parameter tabName = pass as Neo or Ped
	 */

	public boolean verifysubHeaderSectionName(String tabName) throws InterruptedException, IOException {
		List<WebElement> subSectionHeaderName = new ArrayList<WebElement>();
		WebElement subSectionName = null;
		try {
			if (tabName.equalsIgnoreCase("Neo")) {
				subSectionHeaderName = neoSectionSubHeaderList;
				subSectionName = neo_SubSectionName;
			} else {
				subSectionHeaderName = pedSectionSubHeaderList;
				subSectionName = ped_SubSectionName;
			}
			for (WebElement element : subSectionHeaderName) {
				element.click();
				Thread.sleep(1000);
				if (!element.getText().equals(subSectionName.getText())) {
					return false;
				}
				if (!isBacktoTopdisplayed(tabName, subSectionName.getText())) {
					return false;
				}
			}
			extentReport.PASS("Verification of Section sub header name of " + tabName,
					"Expected sub headers are present in drug landing page for " + tabName);
			log.info("Expected sub headers are present in drug landing page for " + tabName);
		} catch (NoSuchElementException e) {
			extentReport.FailWithException(driver, "Verification of Section sub header name of " + tabName,
					"Expected sub headers are present in drug landing page for " + tabName, e);
			logERROR("Expected sub headers are present in drug landing page for " + tabName, e);
			return false;
		}
		return true;
	}

	public boolean isBacktoTopdisplayed(String tabName, String sectionName) throws InterruptedException {
		try {
			WebElement element, sectionElement;
			if (tabName.equalsIgnoreCase("neo")) {
				element = neo_BackToTop;
				sectionElement = neo_BackToTopSectionName;
			} else {
				element = ped_BackToTop;
				sectionElement = ped_BackToTopSectionName;
			}

			getNeofaxUtility().scrollDown(600);
			if (element.getAttribute("style").equalsIgnoreCase("visibility: visible;")) {
				if (!sectionName.equals(sectionElement.getText()))
					return false;
			}
			element.click();
			Thread.sleep(500);

		} catch (NoSuchElementException e) {
			// do nothing
		}
		return true;
	}

	/**
	 * @returns DM View Full Document page
	 */
	public DrugMonograph_ViewFullDocumentPage clickViewFullDoc() {
		try {
			click(driver, "View full document link", lnk_ViewFullDoc);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return PageFactory.initElements(driver, DrugMonograph_ViewFullDocumentPage.class);
	}

}
