package com.ibm.webapp.pageObjects.drugid;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.utils.Selenese;

public class DrugIDPage extends Selenese

{
   WebDriver driver;

   @FindBy(id = "sideOneTxt")
   private WebElement drugIdentSide1InputBox;

   @FindBy(id = "sideTwoTxt")
   private WebElement drugIdentSide2InputBox;

   @FindBy(xpath = "//*[@id='partialbx1_index_1_span']")
   private WebElement partialCheckBox1;

   @FindBy(xpath = "//*[@id='partialbx2_index_1_span']")
   private WebElement partialCheckBox2;

   @FindBy(id = "ClearBtn")
   private WebElement clearButton;

   @FindBy(id = "SearchBtn")
   private WebElement searchButton;

   @FindBy(xpath = "/html/body/div[8]/div/form/div[2]/div/div[3]/div/a")
   private WebElement searchByDescriptionLink;

   public DrugIDPage(WebDriver driver)
   {
      this.driver = driver;
      PageFactory.initElements(driver, this);
      driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
   }

   /**
    * Return true if Drug Identification side 1 input box is displayed,
    * otherwise return false.
    * 
    * @return
    */
   public boolean isDrugIdentSide1InputBoxVisible()
   {
      if (drugIdentSide1InputBox.isDisplayed())
      {
         return true;
      }
      else
         return false;
   }

   public void enterNewImprintIntoSide1(String imprint) throws IOException
   {
      drugIdentSide1InputBox.clear();
     // drugIdentSide1InputBox.sendKeys(imprint);
      sendKeys(driver,
               "drug identification side1",
               drugIdentSide1InputBox,
               imprint);
   }

   public DrugIDPage clickClearButton() throws IOException
   {
      // clearButton.click();
      click(driver, "Clear", clearButton);
      DrugIDPage diPage = PageFactory.initElements(driver, DrugIDPage.class);
      return diPage;
   }

   public DrugID_ResultsPage clickSearchButton() throws IOException
   {
      // searchButton.click();
      click(driver, "search", searchButton);
      DrugID_ResultsPage diResultPage = PageFactory
            .initElements(driver, DrugID_ResultsPage.class);
      return diResultPage;
   }

   public DrugID_DescriptionPage clickSearchByDescriptionLink() throws IOException
   {
      // searchByDescriptionLink.click();
      click(driver, "search by description link", searchByDescriptionLink);
      DrugID_DescriptionPage diDescriptionPage = PageFactory
            .initElements(driver, DrugID_DescriptionPage.class);
      return diDescriptionPage;
   }

}
