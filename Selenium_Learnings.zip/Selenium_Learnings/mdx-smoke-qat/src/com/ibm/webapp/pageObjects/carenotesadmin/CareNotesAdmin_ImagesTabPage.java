package com.ibm.webapp.pageObjects.carenotesadmin;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.ibm.webapp.utils.Selenese;

public class CareNotesAdmin_ImagesTabPage extends Selenese
{
   protected final WebDriver driver;

   @FindBy(xpath = "//a[contains(@href,'carenotesadmin.Images')]")
   private WebElement btnImagesTab;

   @FindBy(id = "unusedImgTable")
   private List<WebElement> imgUnusedChildObjects;

   @FindBy(css = "[title='New Image.']")
   private WebElement btnNewImage;

   @FindBy(xpath = "//strong[contains(text(),'Images')]")
   private WebElement imagePageDisplay;

   @FindBy(css = "[title='Log Out.']")
   private WebElement logOutLink;

   public CareNotesAdmin_ImagesTabPage(WebDriver driver)
   {
      this.driver = driver;
      PageFactory.initElements(this.driver, this);
      WebDriverWait wait = new WebDriverWait(this.driver, 20);
      wait.until(ExpectedConditions.visibilityOf(imagePageDisplay));
   }

   /**
    * click on new image button
    * @return
    */
   public CareNotesAdmin_AddImagePage clickNewImageButton()
   {
      
      try
      {
         click(driver, "click on new image button", btnNewImage);
      }
      catch (IOException e)
      {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
      CareNotesAdmin_AddImagePage page = PageFactory
            .initElements(driver, CareNotesAdmin_AddImagePage.class);
      return page;
   }

   /**
    * Validate if the uploaded .JPG image is present in the Unused image list
    * @param imgNameConcat
    * @throws IOException
    */
   public void imageValidation(String imgNameConcat) throws IOException
   {
      System.out.println("\n" + "Newly Added Image: " + imgNameConcat + "\n");
      try
      {
         for (int i = 0; i < imgUnusedChildObjects.size(); i++)
         {
            Assert.assertTrue(imgUnusedChildObjects.get(i).getText()
                  .contains(imgNameConcat));

            extentReport
                  .PASS("Add new image in carenotes admin",
                        "New image is added in carenotes and displayed in unused images list");
            logINFO("New image is added in carenotes and displayed in unused images list");
         }
      }

      catch (Exception e)
      {
         extentReport
               .FAIL(driver,
                     "Add new image in carenotes admin",
                     "New image is not added in carenotes and displayed in unused images list - Some Exception occured");
         logERROR("New image is not added in carenotes and displayed in unused images list Some Exception occured");
      }

   }

   /**
    * click on log out link from images tab in carenotes admin
    * @throws IOException
    */
   public void LogOut() throws IOException
   {
      click(driver, "LOGOUT", logOutLink);
   }

}
