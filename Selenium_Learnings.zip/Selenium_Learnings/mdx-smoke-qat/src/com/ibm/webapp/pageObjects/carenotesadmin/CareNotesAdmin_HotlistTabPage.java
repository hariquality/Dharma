package com.ibm.webapp.pageObjects.carenotesadmin;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class CareNotesAdmin_HotlistTabPage extends Selenese {
	protected final WebDriver driver;

	@FindBy(xpath = "//span[.='Steps:']")
	private WebElement stepsLabel;

	@FindBy(xpath = "(//input[@id='PFFormActionId_carenotesadmin.SavePublishedHotList'])[2]")
	private WebElement btnPublishHotList;

	@FindBy(xpath = "//table//input[@type = 'checkbox']")
	private List<WebElement> hotListCBs;

	@FindBy(xpath = "//img[@title='My MICROMEDEX Gateway']")
	private WebElement micromedexTitle;

	public CareNotesAdmin_HotlistTabPage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(this.driver, 15), this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		wait.until(ExpectedConditions.visibilityOf(stepsLabel));
	}

	/**
	 * method to get the list of Published HotLists
	 */
	public int getListofPublishedHotlists() {
		List<WebElement> publishedHotlists = new ArrayList<WebElement>();

		Iterator<WebElement> i = hotListCBs.iterator();
		while (i.hasNext()) {
			WebElement cb = i.next();
			if (cb.isSelected()) {
				publishedHotlists.add(cb);

			}

		}
		return publishedHotlists.size();
	}

	/**
	 * click on My Micromedex Gateway
	 */
	public void clickmicromedexTitle() {
		// micromedexTitle.click();
		try {
			click(driver, "My MICROMEDEX Gateway", micromedexTitle);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
