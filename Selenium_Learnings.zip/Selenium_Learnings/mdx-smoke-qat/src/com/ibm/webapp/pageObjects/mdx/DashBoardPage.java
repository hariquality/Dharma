package com.ibm.webapp.pageObjects.mdx;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;



public class DashBoardPage extends Selenese  {
   WebDriver driver;
   
   @FindBy(xpath = "//*[@id='allResultsPanelTab']/a")
   private WebElement allResults;
   
   @FindBy(xpath="//li[@id='quickAnsPanelTab']")
   private WebElement quickAnswerPanelTab;
   
   @FindBy(xpath = "//*[@id='indepthPanelTab']/a")
   private WebElement indepthPanelTab;
   
   @FindBy (xpath ="//*[@id='loadingImage'][@class='no_background_Image']")
   private WebElement loadingImage;
   
   @FindBy(xpath = "//*[@id='quickanspanel_contentpanel']//span/strong")
   private static String applicationErrorMsg;
   
   @FindBy(xpath = "//*[@id='quickanspanel_contentpanel']//span/strong")
   private WebElement applicationErrorMessage;
   
   /**
    * Methods Start here
    * 
    */
   
   public DashBoardPage(WebDriver driver) {
    this.driver = driver;
    PageFactory.initElements(this.driver, this);
    WebDriverWait wait = new WebDriverWait(this.driver, 50);
    wait.until(ExpectedConditions.visibilityOf(allResults));
   }
   
   
   public Boolean quickAnswerTabselected(){
      if(quickAnswerPanelTab.getAttribute("class").equalsIgnoreCase("selected")){
         isLoadingImageDisabled();
         return true;
      }
      else return false;
     } 

   
   public Boolean isIndepthAnswerTabselected(){
      if(indepthPanelTab.findElement(By.xpath("..")).getAttribute("class").equalsIgnoreCase("selected")){
         isLoadingImageDisabled();
         return true;
      }
      else return false;
     }
   
   
   public void isLoadingImageDisabled(){
      WebDriverWait wait = new WebDriverWait(this.driver, 60);
      wait.until(ExpectedConditions.visibilityOf(loadingImage));
   }
   
   public boolean isApplicationerrorMessageDisplayed(){
      boolean flag=false;
      
      JavascriptExecutor js = (JavascriptExecutor)driver;
      Object appErrorMsg = js.executeScript("return document.evaluate(\""+applicationErrorMsg+"\"," +"document.body,null,XPathResult.UNORDERED_NODE_ITERATOR_TYPE,null).iterateNext()!=null;");
      
      
      if(appErrorMsg.equals(false)){
         flag=false;
      }
      else if(applicationErrorMessage.isDisplayed()){
         flag= true;
         System.out.println("This application has encountered an unexpected error. Please close your browser and restart the application. Our apologies for any inconvenience this may cause."
                      +applicationErrorMessage.getText());
      }
      return flag;
   }
   
   
   public boolean isSubsectionSelected(String subSection){
	    boolean flag = false;
	    try {
	    scrollDown(200);
	    WebElement child = driver.findElement(By.linkText(subSection));
	    WebElement parent = child.findElement(By.xpath(".."));
	    if( parent.getAttribute("class").equals("active"))
	    {
	    	if(!subSection.equals(parent.getText()) && isApplicationerrorMessageDisplayed()) {
	    		System.out.println("Section selected in MDX drug landing page is incorrect");    		
	    		flag=false;
	    	}
	    	flag=true; 
	    }}
	    catch(NoSuchElementException e) {
	    	flag=false;
	    }
	    	return flag;
	   }
   
   public void scrollDown(int scrollamt){
		JavascriptExecutor js = (JavascriptExecutor)driver; 
		js.executeScript("scrollBy(0, "+scrollamt+")");
	}
}
