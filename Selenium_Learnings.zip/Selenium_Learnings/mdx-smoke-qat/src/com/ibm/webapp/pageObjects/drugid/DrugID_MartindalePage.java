package com.ibm.webapp.pageObjects.drugid;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.utils.Selenese;

public class DrugID_MartindalePage extends Selenese
{
   WebDriver driver;

   @FindBy(xpath = "//*[@id=\"pgContentSet\"]/text()[1]")
   private WebElement martindalePageTitle;
   
   public DrugID_MartindalePage(WebDriver driver)
   {
      this.driver = driver;
      PageFactory.initElements(driver, this);
      driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
   }

   public void verify_martindalePageTitleDisplayed() throws IOException
   {
      isElementDisplayed(driver,"Martindale page is displayed",martindalePageTitle);
   }
   
}
