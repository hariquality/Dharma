package com.ibm.webapp.pageObjects.drugid;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.pageObjects.mdx.MDX_HeaderPage;
import com.ibm.webapp.utils.Selenese;

public class DrugID_ImageResultsPage extends Selenese

{
   WebDriver driver;

   @FindBy(xpath = "//*[@id='Content_1']")
   private WebElement resultRow1;

   @FindBy(xpath = "//*[@id=\"Content_1\"]/td[3]/a")
   private WebElement firstDrugNameToToxLink;

   public DrugID_ImageResultsPage(WebDriver driver)
   {
      this.driver = driver;
      PageFactory.initElements(driver, this);
      driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
   }

   public MDX_HeaderPage getHeaderPage()
   {
      MDX_HeaderPage headerPage = PageFactory
            .initElements(driver, MDX_HeaderPage.class);
      return headerPage;
   }

   /**
    * Return true if result row 1 is displayed, otherwise return false.
    * 
    * @return
    */
   public boolean isResultRow1Displayed()
   {
      if (resultRow1.isDisplayed())
      {
         return true;
      }
      else
         return false;
   }

   public DrugID_ResultsPage clickFirstDrugNameToToxLink() throws IOException
   {
      // firstDrugNameToToxLink.click ();
      click(driver, "click on first tox link", firstDrugNameToToxLink);
      log.info("First drug name clicked");
      try
      {
         Thread.sleep(1500);
      }
      catch (InterruptedException e)
      {
         e.printStackTrace();
      }

      DrugID_ResultsPage diResults = PageFactory
            .initElements(driver, DrugID_ResultsPage.class);
      return diResults;
   }
}
