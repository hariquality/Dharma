package com.ibm.webapp.pageObjects.carenotesadmin;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.ibm.webapp.utils.Selenese;

public class CareNotesAdmin_DocumentsTabPage extends Selenese {

	protected final WebDriver driver;

	@FindBy(xpath = "//a[contains(text(),'Create')]")
	private WebElement createlink;

	@FindBy(xpath = "//strong[contains(text(), 'Document Search')]")
	private WebElement docSearchBox;

	@FindBy(xpath = "//strong[contains(text(),'document is published')]")
	private WebElement SNpublishMessage;

	@FindBy(xpath = "//a[contains(text(),'Create a new document from scratch')]")
	private WebElement createDocFromScratch;

	@FindBy(xpath = "//input[@name='title_name']")
	private WebElement titleText;

	@FindBy(xpath = "//img[@title='My MICROMEDEX Gateway']")
	private WebElement micromedexTitle;

	@FindBy(xpath = "//*[@id='CareNote']")
	private WebElement careandCarenoteRBtn;

	@FindBy(xpath = "//*[@id='PFFormActionId_carenotesadmin.PublishDocumentsToLocation']")
	private WebElement saveChanges;

	@FindBy(xpath = "(//input[@name='PFFormActionId_carenotesadmin.SaveSaveNoteDocumentPublished'])[2]")
	private WebElement publishbtn;

	@FindBy(xpath = "//input[@name='document_description']")
	public WebElement documentDescriptionText;

	@FindBy(xpath = "//select[@name='documentTypesForCN']")
	private WebElement documentType;

	@FindBy(xpath = "//select[@name='language']")
	private WebElement selectLanguage;

	@FindBy(xpath = "//a[text()='About Us']")
	public WebElement aboutUs;

	@FindBy(xpath = "//*[title='Log Out.']")
	public WebElement logoutButton;

	@FindBy(xpath = "//*[@id='Search.searchText_index_0']")
	private WebElement searchbox;

	@FindBy(xpath = "//*[@id='PFFormActionId_carenotescommon.Search']")
	public WebElement searchbutton;


	public CareNotesAdmin_DocumentsTabPage(WebDriver driver) throws IOException {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 50);
		try {
			wait.until(ExpectedConditions.visibilityOf(docSearchBox));
		} catch (Exception e) {
			extentReport.FailWithException(driver, "CareNotesAdminPage Verification", "CareNotesAdminPage is not displayed", e);
			log.error("CareNotesAdminPage is not displayed");
		}
	}

	/**
	 * click on create link
	 */
	public void clickCreateLink() {
		try {
			click(driver, "Click on Create link", createlink);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * click on save changes in save notes doc searched page
	 */
	public void clickSaveChanges() {
		saveChanges.click();
	}

	/**
	 * Click on 'create document from scratch'
	 */
	public void clickcreateDocFromScratch() {
		try {
			click(driver, "Click on Create Document from scratch", createDocFromScratch);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Enter title text
	 * 
	 * @param term
	 * @return
	 * @throws IOException
	 */
	public String enterTitleText(String term) {
		try {
			// clearField(driver,titleText);
			sendKeys(driver, "title Text", titleText, term);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return term;
	}

	/**
	 * Enter the string in the document description field
	 * 
	 * @param term
	 */
	public void enterDocumentDescriptionText(String term) {
		try {
			// clearField(driver,documentDescriptionText);
			sendKeys(driver, "Document description Text", documentDescriptionText, term);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Select document type from the drop down
	 * 
	 * @param docType
	 */
	public void selectDocumentType(String docType) {
		try {
			selectDropDownByVisibleText(driver, documentType, docType);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * select language from language drop down field
	 * 
	 * @param lang
	 */
	public void selectLanguage(String lang) {

		try {
			selectDropDownByVisibleText(driver, selectLanguage, lang);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * click on publish button
	 */
	public void clickPublish() {

		try {
			click(driver, "Click on Publish button", publishbtn);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * verify the message after publishing the save note
	 * 
	 * @param message
	 * @param message2
	 */
	public void verifyPublishMessage(String message, String message2) {
		String message3 = message + " " + message2;
		Assert.assertTrue(SNpublishMessage.getText().equalsIgnoreCase(message3));
	}

	public void LogOut() throws IOException {
		click(driver, "Logout", logoutButton);
	}

	public void enterArea(String string) {
		WebElement iFrame = driver.findElement(By.xpath("(//iframe[@frameborder='0'])[1]"));
		driver.switchTo().frame(iFrame);
		try {
			// clearField(driver,driver.findElement(By.xpath("//body[@contenteditable='true']")));
			sendKeys(driver, "Document description Text",
					driver.findElement(By.xpath("//body[@contenteditable='true']")), string);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.switchTo().defaultContent();
	}

	public boolean verifyRbtn() {
		if (careandCarenoteRBtn.isSelected()) {
			return true;
		} else {
			fail("exception thrown === ");
		}
		return false;
	}

	/**
	 * Fails a test with the given message.
	 *
	 * @param message
	 *            the identifying message for the {@link AssertionError}
	 * @see AssertionError
	 */
	static public void fail(String message) {
		if (message == null) {
			throw new AssertionError();
		}
		throw new AssertionError(message);
	}

	public CareNotesAdmin_DocumentsTabPage enterSearchForText(String term) {
		searchbox.clear();
		searchbox.sendKeys(term);
		CareNotesAdmin_DocumentsTabPage page = PageFactory.initElements(driver, CareNotesAdmin_DocumentsTabPage.class);
		return page;
	}

	public CareNotesAdmin_PublishUnpublishDocPage clicksearchbutton() {
		searchbutton.click();
		CareNotesAdmin_PublishUnpublishDocPage pubunpubPage = PageFactory.initElements(driver,
				CareNotesAdmin_PublishUnpublishDocPage.class);
		return pubunpubPage;
	}

}
