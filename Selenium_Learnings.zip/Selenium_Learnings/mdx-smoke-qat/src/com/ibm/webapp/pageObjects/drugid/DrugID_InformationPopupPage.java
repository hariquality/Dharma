package com.ibm.webapp.pageObjects.drugid;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.pageObjects.mdx.MDX_HeaderPage;
import com.ibm.webapp.utils.Selenese;

public class DrugID_InformationPopupPage extends Selenese

{
   WebDriver driver;

   @FindBy(id = "1_title")
   private WebElement drugInformationPopup;

   @FindBy(xpath = "//div[@id='dialogueBottomAlternateDrugId']/input[@title='Close']")
   private WebElement btnClose;

   @FindBy(xpath = "//a[contains(@href,'PDX_DDX')]")
   // a[contains(@href,'PDX')]
   private WebElement toxAndDrugLink;

   @FindBy(xpath = "//a[contains(@href,'MARTINDALE')]")
   private WebElement martindaleLink;

   public DrugID_InformationPopupPage(WebDriver driver)
   {
      this.driver = driver;
      PageFactory.initElements(driver, this);
      driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
   }

   public MDX_HeaderPage getHeaderPage()
   {
      MDX_HeaderPage headerPage = PageFactory
            .initElements(driver, MDX_HeaderPage.class);
      return headerPage;
   }

   public void isDrugPopupDisplayed(String statustoMaintain) throws InterruptedException, IOException
   {
	   isElementDisplayed(driver, "DrugInfoPopUp", drugInformationPopup);
         try{
        	 if (statustoMaintain.equalsIgnoreCase("Close"))
         {
            btnClose.click();
         }
         }
         catch(Exception e){
        	 extentReport.FAIL(driver, "DrugInfoPopUP Close Button", "Close Button is not displayed in pop-up");
             log.error("DrugInfoPopUP Close Button is not displayedd",e);
      }
   }

   public DrugID_ToxAndDrugSearchResultsPage clickOnToxAndDrugLink() throws InterruptedException, IOException
   {
      try
      {
         click(driver,"click Tox and Drug link",toxAndDrugLink);
         extentReport.PASS("tox and drug click", "tox and drug link clicked");
         log.info("tox and drug link clicked");
      }
      catch (IOException e)
      {
         // TODO Auto-generated catch block
         e.printStackTrace();
         extentReport.FAIL(driver, "tox and drug click", "tox and drug link not clicked");
         log.error("tox and drug link not clicked",e);
      }
      DrugID_ToxAndDrugSearchResultsPage tdSearchResultsPage = PageFactory
            .initElements(driver, DrugID_ToxAndDrugSearchResultsPage.class);
      return tdSearchResultsPage;
   }

   public DrugID_ToxAndDrugSearchResultsPage clickOnMartindaleLink() throws InterruptedException, IOException
   {
      Thread.sleep(2000);
     // martindaleLink.click();
      try
      {
         click(driver,"Martindale Link",martindaleLink);
         extentReport.PASS("Martindale link clicked", "Martindale link clicked");
         log.info("Martindale link clicked");
      }
      catch (IOException e)
      {
         // TODO Auto-generated catch block
         e.printStackTrace();
         extentReport.FAIL(driver, "Martindale link not clicked", "Martindale link not clicked");
         log.error("Martindale link not clicked",e);
      }
      DrugID_ToxAndDrugSearchResultsPage tdSearchResultsPage = PageFactory
            .initElements(driver, DrugID_ToxAndDrugSearchResultsPage.class);
      return tdSearchResultsPage;
   }

}