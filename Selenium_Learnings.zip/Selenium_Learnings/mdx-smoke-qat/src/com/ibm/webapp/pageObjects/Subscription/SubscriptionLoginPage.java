package com.ibm.webapp.pageObjects.Subscription;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.utils.Selenese;

public class SubscriptionLoginPage extends Selenese
{
   WebDriver driver;

   @FindBy(xpath = "//a[contains(@title,'/ Pediatrics')]")
   private WebElement tab_NeoPed;

   @FindBy(xpath = "//div[@class='pageTitle pageTitleBottom leftAlign']")
   private WebElement tabTitle;

   @FindBy(xpath = "//div[@id='header']/div")
   private List<WebElement> all_tabs;

   @FindBy(id = "NeoFaxPedToolLink")
   private WebElement tab_NeoNatal;

   @FindBy(xpath = "//a[@id='NeoFaxPedToolLink'][.='Pediatrics']")
   private WebElement tab_Pediatrics;

   @FindBy(xpath = "//*[@id='drugInteractionToolLink']")
   private WebElement drugInteractionsToolbarLink;

   @FindBy(xpath = "//*[@id='IVToolLink']")
   private WebElement ivCompatToolbarLink;

   @FindBy(xpath = "//a/img[@title='Login']")
   private WebElement btn_login;

   @FindBy(xpath = "//settings-ui")
   private WebElement cacheURL;

   public SubscriptionLoginPage(WebDriver driver)
   {
      this.driver = driver;
      PageFactory.initElements(driver, this);
      driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
   }

   public void isHomePageDisplayed() throws IOException
   {
      try
      {
         if (driver.getTitle().equalsIgnoreCase("Home - MICROMEDEX"))
         {// Home - MICROMEDEX
            extentReport.PASS("Micromedex Home Page Verification",
                              "Micromedex Home Page is displayed correctly");
         }
         else
         {
            extentReport.FAIL(driver,
                              "Micromedex Home Page Verification",
                              "Micromedex Home Page is not displayed");
         }
      }
      catch (Exception e)
      {
         extentReport
               .FAIL(driver,
                     "Micromedex Home Page Verification",
                     "Micromedex Home Page is not displayed- Some Exception occured");
      }

   }

   public void validateToolLinkPage(String subscription) throws IOException
   {
      String[] subscritionType = subscription.split(";");
      for (int i = 0; i < subscritionType.length; i++)
      {
         WebElement toolLink = null;
         switch (subscritionType[i])
         {
            case "Drug Interactions":
               toolLink = drugInteractionsToolbarLink;

               break;
            case "IV Compatibility":
               toolLink = ivCompatToolbarLink;

               break;

         }
         try
         {
            if (toolLink.isDisplayed())
               extentReport
                     .passWithScreenShot(driver,
                                         subscritionType[i]
                                               + " displayed on Micromedex Home page");
            if ((subscritionType.length + 2) == (all_tabs.size()))
            {
               extentReport
                     .PASS("Subscription Tabs Validation",
                           subscritionType[i]
                                 + " only displayed on Micromedex Home page");
            }
            else
            {
               extentReport.FAIL(driver,
                                 "Subscription Tabs Validation",
                                 " More tabs displayed on Micromedex Home page other than subscription "
                                       + subscritionType[i]);
            }
         }
         catch (Exception e)
         {
            extentReport
                  .failWithScreenShot(driver,
                                      subscritionType[i]
                                            + " not displayed on Micromedex Home page");
         }
         clickOnSubscriptionTab(toolLink, subscritionType[i]);
      }
   }

   public void clickOnSubscriptionTab(WebElement tabXpath,
                                      String tabName) throws IOException
   {
      click(driver, "Clicked on subscription Tab", tabXpath);
      if (tabTitle.getText().equalsIgnoreCase(tabName))
      {
         extentReport
               .PASS("Subscription Tabs Name Validation",
                     "Tab Name displayed on Micromedex Home page is as expected");
      }
      else
      {
         extentReport
               .FAIL(driver,
                     "Subscription Tabs Name Validation",
                     "Tab Name displayed on Micromedex Home page is not expected");
      }
   }

   public void clickLogin() throws IOException
   {
      click(driver, "Clicked on Login", btn_login);
   }

   public void clearCache() throws InterruptedException
   {
      driver.get("chrome://settings/clearBrowserData");
      cacheURL.sendKeys(Keys.ENTER);
      Thread.sleep(2000);
   }

}
