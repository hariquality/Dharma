package com.ibm.webapp.pageObjects.top100hospitals;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.ibm.webapp.utils.Selenese;

/**
 * @author APeavy
 * 
 */
public class Top100Hospitals_AdministrativeTasksPage extends Selenese
{

   private final WebDriver driver;

   @FindBy(xpath = "//*[@id=\"workflowMenu\"]/p[3]/span/a")
   private WebElement CreateCardioVasucularBenchmarkStudy;

   @FindBy(xpath = "//*[@id=\"workflowMenu\"]/p[4]/span/a")
   private WebElement CreateNationalBenchmarkStudy;

   @FindBy(xpath = "//*[@id=\"userList\"]/table/tbody/tr[2]/td/div/h3/strong/span")
   private WebElement removeUserSuccessMsg;

   @FindBy(xpath = "//*[@id=\"workflowMenu\"]/p[3]/a")
   private WebElement AddUser;

   @FindBy(xpath = "//*[@id=\"workflowMenu\"]/p[2]/span/a")
   private WebElement createUserForGroup;

   @FindBy(xpath = "//a[contains(text(),'Update this Study Group')]")
   private WebElement updateStudyGroupLink;

   @FindBy(xpath = "//*[@id=\"userList\"]/table/tbody/tr[2]/td/div/h3/strong/span")
   private WebElement userCreationSuccessMsg;

   @FindBy(xpath = "//*[@id=\"workflowMenu\"]/span")
   private WebElement additionalAdminTasks;

   @FindBy(xpath = "//a[contains(text(),'Logout')]")
   private WebElement LogoutLink;

   @FindBy(xpath = "//*[@id=\"id_of_tablebody\"]/tr[1]")
   private List<WebElement> rowForRemoval;

   @FindBy(xpath = "//*[@id=\"hospitalIdCenter\"]/a")
   private WebElement mCareId;

   @FindBy(xpath = "//*[@id=\"id_of_tablebody\"]")
   private WebElement usersTable;

   @FindBy(xpath = "//*[contains(text(),'All selected users were added to the Group')]")
   private WebElement successMsg;

   @FindBy(xpath = "//tr[@class='rowWhite']//a[contains(text(),'Remove')]")
   private WebElement removeUserForGroup;

   Top100Hospitals_CreateStudyUserPage createStudyUserPage;

   Top100Hospitals_AddUsersPage addNewUsersPage;

   public Top100Hospitals_AdministrativeTasksPage(WebDriver driver) throws IOException
   {
      this.driver = driver;
      PageFactory.initElements(this.driver, this);
      WebDriverWait wait = new WebDriverWait(this.driver, 20);

      try
      {
         wait.until(ExpectedConditions.visibilityOf(createUserForGroup));
      }
      catch (Exception e)
      {
         extentReport.FAIL(driver,
                           "Top100Hospitals_AdministrativeTasksPage",
                           "Create user for group link is not visible");
         log.error("Create user for group link is not visible in user provisioning page");
      }
   }

   /**
    * click on add user link
    * 
    * @return addnewuser page object
    * @throws IOException 
    */
   public Top100Hospitals_AddUsersPage AddUserLogin() throws IOException
   {
      try
      {
         AddUser.click();
         extentReport.PASS("Add user link click",
                           "Add user link is clicked successfully");
         log.info("Add user link is clicked");
      }
      catch (Exception e)
      {
         e.printStackTrace();
         extentReport.FailWithException(driver, "LOGIN", "Login Failed.", e);
         logERROR("Login Failed.", e);
      }
      addNewUsersPage = PageFactory
            .initElements(driver, Top100Hospitals_AddUsersPage.class);
      return addNewUsersPage;
   }

   /**
    * to verify success message which is displayed after adding user
    * successfully
    * 
    * @throws IOException
    */
   public void verifyAddUserSuccessMsg() throws IOException
   {
      try
      {
         if (successMsg.getText()
               .equals("All selected users were added to the Group"))
         {
            extentReport.PASS("Add user Verification",
                              "User is added to group correctly");
            logINFO("User is added to group correctly");
         }

         else
         {
            extentReport.FAIL(driver,
                              "Add user Verification",
                              "User is added to group correctly");
            logERROR("User is not added to group");
         }
      }
      catch (Exception e)
      {
         extentReport.FAIL(driver,
                           "Add user Verification",
                           "User is not added- Some Exception occured");
         logERROR("User is not added- Some Exception occured");
      }

   }

   /**
    * method to click remove user from a group
    * 
    * @throws IOException
    */
   public void click_removeUserForGroup() throws IOException
   {
      click(driver, "remove user from group", removeUserForGroup);
   }

   /**
    * to verify user removal is successful message
    */
   public void verifyStudyUserRemovalSuccessMsg()
   {

      String removeUserMessage = removeUserSuccessMsg.getText();
      if (removeUserMessage.equalsIgnoreCase("User Removal Successful"))
      {
         Assert.assertEquals(removeUserSuccessMsg.getText(),
                             "User Removal Successful");
      }
      else
      {
         int rowForRemovalSize = rowForRemoval.size();
         if (rowForRemovalSize == 0)
         {
            System.out.println("The table is empty");
         }
      }
   }

   /**
    * to click create user in the group
    * @return create user page object
    * @throws IOException 
    */
   public Top100Hospitals_CreateStudyUserPage click_createUserForGroup() throws IOException
   {
      try
      {
         click(driver,"click create user",createUserForGroup);
         extentReport.PASS("click create user link", "create user link clicked");
         log.info("create user link clicked");
      }
      catch (IOException e)
      {
         // TODO Auto-generated catch block
         e.printStackTrace();
         extentReport.FAIL(driver, "create user link not clicked", "create user link not clicked");
         log.error("create user link clicked", e);
      }
      createStudyUserPage = PageFactory
            .initElements(driver, Top100Hospitals_CreateStudyUserPage.class);
      return createStudyUserPage;
   }

   /**
    * verify success message after user creation
    */
   public void verifyStudyUserCreationSuccessMsg()
   {
      Assert.assertEquals(userCreationSuccessMsg.getText(),
                          "User Creation Successful");
   }

   /**
    * click on log out from admin tasks page
    * @throws IOException 
    */
   public void clickLogOut() throws IOException
   {
      click(driver,"click log out",LogoutLink);
   }

}
