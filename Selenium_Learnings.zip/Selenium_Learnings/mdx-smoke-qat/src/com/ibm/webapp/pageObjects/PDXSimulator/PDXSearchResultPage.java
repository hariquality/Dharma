package com.ibm.webapp.pageObjects.PDXSimulator;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

import javax.xml.parsers.ParserConfigurationException;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.jdom.Document;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.xml.sax.SAXException;

import com.ibm.webapp.config.JenkinsConfiguration;
import com.ibm.webapp.utils.Selenese;

public class PDXSearchResultPage extends Selenese
{
   WebDriver driver;

   @FindBy(xpath = "//body/pre")
   private WebElement jsonDocContent;

   public PDXSearchResultPage(WebDriver driver)
   {
      this.driver = driver;
      PageFactory.initElements(this.driver, this);

   }

   public void validateResponseDocument(String CredentialType,
                                        String pdxRefId,
                                        String responseDocType) throws JsonGenerationException,
                                                                JsonMappingException,
                                                                IOException,
                                                                SAXException,
                                                                ParserConfigurationException,
                                                                InterruptedException
   {
      String[] cred = JenkinsConfiguration
            .getValueFromPropertiesFile(CredentialType).split("/");
      if (responseDocType.equalsIgnoreCase("json"))
      {
         String finalTOXResponse = "https://"
               + JenkinsConfiguration.executionEnv + "."
               + JenkinsConfiguration
                     .getValueFromPropertiesFile("pdxSimulatorURL")
               + "/micromedex2/librarian/pdxwsgetdocument?" + "pdxRefID="
               + pdxRefId + "&docType=POISINDEX-PROD&responseFormat="
               + responseDocType + "&institution=MDX^" + cred[0] + "^"
               + cred[1];
         Thread.sleep(2000);
         driver.get(finalTOXResponse);
         if (jsonDocContent.getText().contains("\"Success\": true"))
         {
            extentReport.PASS("JSON Document validation",
                              "JSON Validation successful for ref id:"+pdxRefId);
            log.info("JSON Validation successful for ref id:"+pdxRefId);
         }
         else
         {
            extentReport.FAIL(driver,
                              "JSON Document validation",
                              "JSON Validation not successful");
            log.error("JSON Validation not successful for ref id:"+pdxRefId);
         }
      }
      else
      {
         URL url = new URL("https://" + JenkinsConfiguration.executionEnv + "."
               + JenkinsConfiguration
                     .getValueFromPropertiesFile("pdxSimulatorURL")
               + "/micromedex2/librarian/pdxwsgetdocument?" + "pdxRefID="
               + pdxRefId + "&docType=POISINDEX-PROD&responseFormat="
               + responseDocType + "&institution=MDX^" + cred[0] + "^"
               + cred[1]);
         URLConnection connection = url.openConnection();
         connection.setRequestProperty("Content-Type", "text/xml");
         connection.setDoOutput(true);
         InputStream is = connection.getInputStream();
         Document doc = buildDoc(is);
         String header = doc.getRootElement().getChildText("Success");
         if (header.equals("TRUE"))
         {
            extentReport.PASS("XML Document validation",
                              "XML Validation successful");
            log.info("XML Validation successful for ref id:"+pdxRefId);
         }
         else
         {
            extentReport.FAIL(driver,
                              "XML Document validation",
                              "XML Validation not successful");
            log.error("XML Validation not successful for ref id:"+pdxRefId);
         }
         Thread.sleep(1000);
      }
   }

   private Document buildDoc(InputStream is)
   {
      Document doc = null;
      SAXBuilder builder = new SAXBuilder();
      try
      {
         doc = builder.build(is);
      }
      catch (JDOMException | IOException e)
      {
         e.printStackTrace();
      }

      // output xml for debugging
      try
      {
         System.out.println("Response Document built:\n"
               + XMLOutputter.class.newInstance().outputString(doc));
      }
      catch (InstantiationException e)
      {
         e.printStackTrace();
      }
      catch (IllegalAccessException e)
      {
         e.printStackTrace();
      }
      // end output of xml for debugging
      return doc;
   }

}