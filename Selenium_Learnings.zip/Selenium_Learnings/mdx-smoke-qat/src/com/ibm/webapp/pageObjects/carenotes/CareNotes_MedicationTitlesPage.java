package com.ibm.webapp.pageObjects.carenotes;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.utils.Selenese;

public class CareNotes_MedicationTitlesPage extends Selenese {
	protected final WebDriver driver;

	@FindBy(xpath = "//strong[contains(text(),'Medication Titles')]")
	private WebElement hotlistCaption;

	@FindBy(xpath = "/html/body/table/tbody/tr[3]/td/table[2]/tbody/tr/td/table[2]/tbody/tr/td/strong[3]/a")
	private WebElement clickA;

	public CareNotes_MedicationTitlesPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	/**
	 * click on first care and condition title in carenotes
	 */
	public void clickMedTitleWithA() {

		try {
			click(driver, "click first care and condition title", clickA);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public CareNotes_HeaderPage getHeaderPage() {
		CareNotes_HeaderPage headerPage = PageFactory.initElements(driver, CareNotes_HeaderPage.class);
		return headerPage;
	}

}
