package com.ibm.webapp.pageObjects.smt;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class SMTGenerateLicenseKeyPage extends Selenese {

	WebDriver driver;

	@FindBy(xpath = "//*[text()='Generate License Key']")
	private WebElement generateLicenseKeyHeading;

	@FindBy(linkText = "System Management Tool")
	private WebElement applcationvrsn_link;

	@FindBy(xpath = "//*[@id='customerID_index_0']")
	private WebElement customerId;

	@FindBy(xpath = "//*[@id='activationKey_index_0']")
	private WebElement activationCode;

	@FindBy(xpath = "//*[@id= 'PFFormActionId_systemmanagementtool.status.save.key']")
	private WebElement generateLicenseKeyButton;

	@FindBy(xpath = "//p[text()='The Customer ID and Activation Code cannot be blank.']")
	private WebElement errorMsgBoth;

	@FindBy(xpath = "//p[text()='The License Key data was successfully generated.']")
	private WebElement licenseKeyGeneratedMsg;

	@FindBy(xpath = "//p[text()='Error generating License Key. Check your Customer ID and Activation Code.']")
	private WebElement licenseKeyGenerateErrorMsg;

	boolean fileDownloaded = false;

	public SMTGenerateLicenseKeyPage(WebDriver driver) throws IOException {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		try {
			wait.until(ExpectedConditions.visibilityOf(customerId));
		} catch (Exception e) {
			extentReport.FAIL(driver, "GenerateLicense Key", "GenerateLicense Key page is not displayed");
			log.error("GenerateLicense Key page is not displayed");
		}
	}

	public void generateLicenseKey() throws InterruptedException, IOException {
		generateLicenseKeyButton.click();
		errorMsgValidation();
		customerId.sendKeys("472870001");
		activationCode.sendKeys("1D73-082C");
		driver.findElements(By.xpath("//input[@type='radio']")).get(1).click();
		generateLicenseKeyButton.click();

		String homePath = System.getProperty("user.home");
		String dirPath = homePath + "\\Downloads";

		if (isFileDownloaded(dirPath, "license.txt"))

			licenseKeyGeneratedSuccessMsgValidation();

	}

	public void errorMsgValidation() throws IOException {
		String expectedText = "The Customer ID and Activation Code cannot be blank.";
		String actualText = errorMsgBoth.getText();
		if (expectedText.equals(String.valueOf(actualText))) {
			extentReport.PASS("LicenseKeyError Message Validation", "LicenseKey Error Message is displayed correctly");
		} else {
			extentReport.FAIL(driver, "LicenseKey Error Message Validation",
					"LicenseKey is not generated successfully. " + "Actual Value:" + actualText + " , "
							+ "Expected Value" + expectedText);
		}
	}

	public void licenseKeyGeneratedSuccessMsgValidation() throws IOException {
		String expectedText = "The License Key data was successfully generated.";
		String actualText = licenseKeyGeneratedMsg.getText();
		if (expectedText.equals(String.valueOf(actualText))) {
			extentReport.PASS("LicenseKeyMessage Validation", "LicenseKey is generated successfully");
		} else {
			extentReport.FAIL(driver, "LicenseKeyMessage Validation", "LicenseKey is not generated successfully. "
					+ "Actual Value:" + actualText + " , " + "Expected Value" + expectedText);
		}
	}

	public void licenseKeyGenerateFailMsgValidation() throws IOException {
		String expectedText = "Error generating License Key. Check your Customer ID and Activation Code.";
		String actualText = licenseKeyGenerateErrorMsg.getText();
		if (expectedText.equals(String.valueOf(actualText))) {
			extentReport.PASS("LicenseKeyGenerate Fail Message Validation",
					"LicenseKey Fail message is verified successfully");
		} else {
			extentReport.FAIL(driver, "LicenseKeyGenerate Fail Message Validation",
					"LicenseKey Fail message is incorrect " + "Actual Value:" + actualText + " , " + "Expected Value"
							+ expectedText);
		}
	}

	public boolean isFileDownloaded(String downloadPath, String fileName) {
		File dir = new File(downloadPath);

		File[] dirContents = dir.listFiles();
		System.out.println(dirContents.length);
		for (int i = 0; i < dirContents.length; i++) {
			if (dirContents[i].getName().equals(fileName)) {
				System.out.println("License.txt has been downloaded successfully");
				// File has been found, it can now be deleted:
				dirContents[i].delete();
				return true;
			}
		}
		return false;
	}

	public void clickBrowserBackKey() {
		driver.navigate().back();
	}
}
