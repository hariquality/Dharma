package com.ibm.webapp.pageObjects.umt;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.AssertJUnit;

import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.utils.Selenese;

public class UMT_EditUserNamePage extends Selenese {
	WebDriver driver;

	@FindBy(xpath = "//img[contains(@alt,'View or maintain user group data relating to Organization or Facility.')]")
	private WebElement UserGroupLink;

	@FindBy(id = "group.name_index_0")
	private WebElement UserGroupname;

	@FindBy(xpath = "//input[@alt='Save Changes']")
	private WebElement SaveUserGroupname;

	@FindBy(xpath = "//span[contains(text(),'User Group was updated successfully.')]")
	private WebElement UpdateUserGroupSuccessfully;

	@FindBy(xpath = "//img[contains(@alt,'View or maintain user data relating to Organization or Facility.')]")
	private WebElement UserLink;

	@FindBy(id = "user.userID_index_0")
	private WebElement enterUserID;

	@FindBy(id = "user.password_index_0")
	private WebElement enterUserPwd;

	@FindBy(xpath = "//table[@cellspacing='1' and @cellpadding='5']//tr//td[1]/a")
	private WebElement selectSearchResult;

	@FindBy(id = "user.zip_index_0")
	private WebElement EnterZipCode;

	@FindBy(id = "user.jobTitle_index_0")
	private WebElement EnterJobTitle;

	@FindBy(id = "user.firstName_index_0")
	private WebElement enterUserfirstName;

	@FindBy(id = "user.city_index_0")
	private WebElement enterUserCityName;

	@FindBy(id = "user.state_index_0")
	private WebElement enterUserStateName;

	@FindBy(id = "user.country_index_0")
	private WebElement enterUserCountryName;

	@FindBy(id = "user.lastName_index_0")
	private WebElement enterUserlastName;

	@FindBy(id = "user.eMailAddress_index_0")
	private WebElement EnterEmailID;

	@FindBy(id = "A")
	private WebElement CheckBoxActiveUser;

	@FindBy(id = "CNADM")
	private WebElement CheckBoxCarenote;

	@FindBy(xpath = "//input[@alt='Save Changes']")
	private WebElement SaveButton_User;

	@FindBy(xpath = "//span[contains(text(),'User data was updated successfully.')]")
	private WebElement UpdateSuccessfully;

	@FindBy(xpath = "/html/body/table[2]/tbody/tr[1]/td[2]/table/tbody/tr[1]/td/font/a")
	private WebElement loginLink;

	@FindBy(id = "login.username_index_0")
	private WebElement userNameInput;

	@FindBy(id = "login.password_index_0")
	private WebElement passwordInput;

	@FindBy(id = "Submit")
	private WebElement loginButton;

	@FindBy(xpath = "//span[contains(text(), 'The User or Password that you entered has not been found. Please try again.')]")
	private WebElement loginError;

	public UMT_EditUserNamePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	public void UserGroupname(String term) {
		UserGroupname.sendKeys(term);
	}

	public void enterUserID(String term) {
		enterUserID.sendKeys(term);
	}

	public void enterUserPwd(String term) {
		enterUserPwd.sendKeys(term);
	}

	public void enterUserfirstName(String term) {
		enterUserfirstName.sendKeys(term);
	}

	public void enterUserlastName(String term) {
		enterUserlastName.sendKeys(term);
	}

	public void EnterZipCode(String term) {
		EnterZipCode.sendKeys(term);
	}

	public void EnterJobTitle(String term) {
		EnterJobTitle.sendKeys(term);
	}

	public void EnterUserCityName(String term) {
		enterUserCityName.sendKeys(term);
	}

	public void EnterUserCountryName(String term) {
		enterUserCountryName.sendKeys(term);
	}

	public void EnterUserStateName(String term) {
		enterUserStateName.sendKeys(term);
	}

	public void Email_ID(String term) {
		EnterEmailID.sendKeys(term);
	}

	public void CheckBoxActiveUser() {
		CheckBoxActiveUser.click();
	}

	public void CheckBoxCarenote() {
		CheckBoxCarenote.click();
	}

	/**
	 * method to click the UserGroup link
	 * 
	 * 
	 */
	public UMT_HeaderPage UserGroupLink() {
		UserGroupLink.click();
		UMT_HeaderPage umtheaderPage = PageFactory.initElements(driver, UMT_HeaderPage.class);
		return umtheaderPage;
	}

	/**
	 * method to save the usergroup created
	 * 
	 * 
	 */
	public void SaveUserGroupname() throws InterruptedException {
		SaveUserGroupname.click();
		Thread.sleep(3000);
	}

	public UMT_HeaderPage UserLink() {
		UserLink.click();
		UMT_HeaderPage umtheaderPage = PageFactory.initElements(driver, UMT_HeaderPage.class);
		return umtheaderPage;
	}

	/**
	 * method to get the header of the page
	 * 
	 * 
	 */
	public UMT_HeaderPage getHeaderPage() {
		UMT_HeaderPage headerPage = PageFactory.initElements(driver, UMT_HeaderPage.class);
		return headerPage;
	}

	/**
	 * method to click the save button and verify the message of user data
	 * updation
	 * 
	 * @throws InterruptedException
	 */
	public void Savebutton() throws InterruptedException {
		SaveButton_User.click();
		Thread.sleep(3000);
		String actual = UpdateSuccessfully.getText();
		AssertJUnit.assertEquals("User data was updated successfully.", actual);
		System.out.println(actual);
	}

	/**
	 * method to check if inactive users are provided access to application
	 * 
	 * @param username,
	 *            password
	 * @return gatewaypage
	 * @throws IOException
	 */
	public GatewayPage loginToApplicationFailure(String username, String password) throws IOException {
		userNameInput.sendKeys(username);
		passwordInput.sendKeys(password);
		loginButton.click();
		GatewayPage gateWay = PageFactory.initElements(driver, GatewayPage.class);

		try {
			if (loginError.isDisplayed()) {
				System.out.println("Login Error!!!!!!");
			} else {
				System.out.println("Login Successful!!!!!!");
			}
		} catch (Exception e)

		{
			extentReport.FAIL(driver, "Add an Active/Inactive User functionality", "Some Exception occured");
		}
		return gateWay;
	}

}
