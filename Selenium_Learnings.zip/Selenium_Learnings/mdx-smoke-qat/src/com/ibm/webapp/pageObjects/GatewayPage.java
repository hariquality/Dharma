package com.ibm.webapp.pageObjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.pageObjects.carenotes.CareNotes_HomePage;
import com.ibm.webapp.pageObjects.carenotesadmin.CareNotesAdmin_LocationPage;
import com.ibm.webapp.pageObjects.formulary.Formulary_HomePage;
import com.ibm.webapp.pageObjects.formularyadmin.FormularyAdmin_HomePage;
import com.ibm.webapp.pageObjects.mdx.MDX_HomePage;
import com.ibm.webapp.pageObjects.smt.SMT_HomePage;
import com.ibm.webapp.pageObjects.umt.UMT_HomePage;
import com.ibm.webapp.utils.Selenese;

public class GatewayPage extends Selenese {

	private final WebDriver driver;

	@FindBy(xpath = "//img[contains(@src,'micromedex2_bttn.png')]")
	private WebElement mdx2;

	@FindBy(xpath = "//img[contains(@src,'pharmaKnowledge_bttn.png')]")
	private WebElement pharmacyXpertButton;

	@FindBy(xpath = "//a[contains(@href,'pf.LogoutToLoginPage')]")
	private WebElement loginLink;

	@FindBy(xpath = "//img[@title='Go to MICROMEDEX.']")
	private WebElement tabMicromedex;

	@FindBy(xpath = "//img[@title='Go to CareNotes Administration Tool.']")
	private WebElement tabCarenotesAdmin;

	@FindBy(xpath = "//img[@title= 'Go to CareNotes Tool.']")
	private WebElement tabCarenotes;

	@FindBy(xpath = "//img[@title='Go to Formulary Administration Tool.']")
	private WebElement tabFormularyAdmin;

	@FindBy(xpath = "//img[@title='Go to Formulary Tool.']")
	private WebElement tabFormulary;

	@FindBy(xpath = "//img[@title='Go to System Management Tool.']")
	private WebElement tabSMT;

	@FindBy(xpath = "//img[@title='Go to User Management Tool.']")
	private WebElement tabUMT;

	public GatewayPage(WebDriver driver) throws IOException {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		try {
			wait.until(ExpectedConditions.visibilityOf(loginLink));
		} catch (Exception e) {
			extentReport.FAIL(driver, "Gateway Page Loading verificaiton", "GatewayPage is not displayed");
			log.error("GatewayPage is not displayed");
		}
	}

	/**
	 * 
	 * @param tabName
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public Object goToApplication(String tabName) throws IOException {
		Object obj = null;
		try {
			Thread.sleep(1500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		switch (tabName) {
		case "Micromedex":
			click(driver, "Click on the Micromedex Tab", tabMicromedex);
			obj = PageFactory.initElements(driver, MDX_HomePage.class);
			break;

		case "CarenotesAdmin":
			click(driver, "Click on the Carenotes Administration Tab", tabCarenotesAdmin);
			obj = PageFactory.initElements(driver, CareNotesAdmin_LocationPage.class);
			break;

		case "SMT":
			click(driver, "Click on the System Management Tool Tab", tabSMT);
			obj = PageFactory.initElements(driver, SMT_HomePage.class);
			break;

		case "CareNotes":
			click(driver, "Click on the Carenotes Tab", tabCarenotes);
			obj = PageFactory.initElements(driver, CareNotes_HomePage.class);
			break;

		case "UMT":
			click(driver, "Click on the User Management Tool Tab", tabUMT);
			obj = PageFactory.initElements(driver, UMT_HomePage.class);
			break;

		case "FormularyAdmin":
			click(driver, "Click on the Formulary Administration Tab", tabFormularyAdmin);
			obj = PageFactory.initElements(driver, FormularyAdmin_HomePage.class);
			break;

		case "Formulary":
			click(driver, "Click on the Formulary Tab", tabFormulary);
			obj = PageFactory.initElements(driver, Formulary_HomePage.class);
			break;

		}

		return obj;

	}
}
