package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.utils.Selenese;

public class DC_T7_ContinuousInfusion_min extends Selenese {

	WebDriver driver;

	DC_Template_Constants data = new DC_Template_Constants();

	public String[] fieldUnits_ContinousInfusion_min = { data.MCG_KG_MIN, data.MCG_ML, data.ML_HR };

	public String[] resultUnits = { data.ML, data.ML, data.ML, data.HOURS };

	public double doseMin = 0, doseMax = 0, concMin = 0, concMax = 0, dd2InfusionMaxValue = 0;

	public String selectedCompoundValue = "";

	public String recommendedDosingValue = "";

	@FindBy(xpath = "//div[@id='ValidateVolumePopup']")
	public WebElement conc_maxPopUp;

	@FindBy(xpath = "//div[@id='calculatorDetailsDivId']//table[@class='HelpTable']//tr[2]/td/span")
	public WebElement recommendedDoseValue;

	@FindBy(xpath = "//div[@id='calculatorDetailsDivId']//table[@class='HelpTable']//tr[3]/td/span")
	public WebElement recommendedConcValue;

	@FindBy(id = "3")
	public WebElement field_dose;

	@FindBy(id = "5")
	public WebElement field_conc;

	@FindBy(id = "7")
	public WebElement field_rate;

	@FindBy(id = "btnDose")
	private WebElement btn_Dose;

	@FindBy(id = "btnConc")
	private WebElement btn_Conc;

	@FindBy(id = "btnRate")
	private WebElement btn_Rate;

	@FindBy(xpath = "//span[@id='dose_help']/img")
	private WebElement help_Dose;

	@FindBy(xpath = "//span[@id='conc_help']/img")
	private WebElement help_Conc;

	@FindBy(xpath = "//span[@id='rate_help']/img")
	private WebElement help_Rate;

	@FindBy(xpath = "//select[@id='10']/option")
	private List<WebElement> select1;

	@FindBy(id = "12")
	private WebElement select1_value;

	@FindBy(xpath = "//select[@id='11']/option")
	private List<WebElement> select2;

	@FindBy(id = "14")
	private WebElement select2_Value;

	@FindBy(id = "17")
	public WebElement field_totalVolume;

	@FindBy(id = "9")
	private WebElement select_Compound;

	@FindBy(id = "20")
	private WebElement infusionTime;

	@FindBy(id = "DrugNameDiv")
	private WebElement template1_drugName;

	@FindBy(id = "bMessage")
	private WebElement overDoseMessage;

	@FindBy(xpath = "//table[@id='drugSelectionHelpTableID']//tr[1]/td[2]")
	private WebElement actual_PMAorPedWeight;

	@FindBy(xpath = "//input[@id='dose']")
	private WebElement doseValue;

	@FindBy(xpath = "//input[@id='admin']")
	private WebElement adminValue;

	@FindBy(xpath = "//input[@id='conc']")
	private WebElement concValue;

	@FindBy(id = "doseamount1")
	private WebElement doseAmount1_Value;

	@FindBy(id = "dosevolume1")
	private WebElement doseVolume1_Value;

	@FindBy(id = "deliveryrate1")
	private WebElement deliveryRate1_Value;

	@FindBy(id = "doseamount2")
	private WebElement doseAmount2_Value;

	@FindBy(id = "dosevolume2")
	private WebElement doseVolume2_Value;

	@FindBy(id = "deliveryrate2")
	private WebElement deliveryRate2_Value;

	@FindBy(id = "doseamount3")
	private WebElement doseAmount3_Value;

	@FindBy(id = "dosevolume3")
	private WebElement doseVolume3_Value;

	@FindBy(id = "deliveryrate3")
	private WebElement deliveryRate3_Value;

	@FindBy(id = "helpInformationDivId")
	private WebElement standardiv_calculate_notes;

	@FindBy(id = "validatemsgId")
	private WebElement alertMessage;

	@FindBy(xpath = "//div[@id='validatemsgId']//center")
	private WebElement alert_range_val;

	@FindBy(id = "validateDosemsgId")
	private WebElement alert_Maxdose_value;

	@FindBy(id = "invalidmsgId")
	private WebElement alert_Invalid_alert;

	@FindBy(id = "//input[@onclick='dijit.byId('validationPopup').hide()']")
	private WebElement alert_Invalid_Close_btn;

	@FindBy(xpath = "//div[@id='bMessage' and @class='CalcText']")
	private WebElement Max_dose_override_msg;

	public String recommendedConcentrationValue = "";

	/**
	 * Default Constructor for DC_T3_StandardIV class
	 * 
	 * @throws IOException
	 */
	public DC_T7_ContinuousInfusion_min(WebDriver driver) throws IOException {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		waitForElementVisibility(driver, template1_drugName);

	}

	/***
	 * Gets the dose range min & max value for dose, conc and rate
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public void doseRange() throws InterruptedException, IOException {
		String[] doseMinMax = getDC_Util().getAlert(field_dose);
		doseMin = Double.parseDouble(doseMinMax[0]);
		doseMax = Double.parseDouble(doseMinMax[1]);
		field_dose.sendKeys(Keys.TAB);
		getDC_Util().sleep(2000);
		waitForElementVisibility(driver, alert_range_val);

		getDC_Util().click_btn(getDC_Util().OVERRIDE);
		getDC_Util().click_btn(getDC_Util().RESETFORM);

		String[] concMinMax = getDC_Util().getAlert(field_conc);
		concMin = Double.parseDouble(concMinMax[0]);
		concMax = Double.parseDouble(concMinMax[1]);
		field_dose.sendKeys(Keys.TAB);
		getDC_Util().sleep(2000);
		waitForElementVisibility(driver, alert_range_val);

		getDC_Util().click_btn(getDC_Util().OVERRIDE);
		getDC_Util().click_btn(getDC_Util().RESETFORM);
		dd2InfusionMaxValue = Integer.parseInt(select2.get(0).getAttribute("value").split("\\|")[0]);
		recommendedDosingValue = recommendedDoseValue.getText().split(" ")[0];
		recommendedConcentrationValue = recommendedConcValue.getText().split(" ")[0];
	}

	/**
	 * @returns DC_Template1Page
	 */
	public DC_Template_Utility getDC_Util() {
		return PageFactory.initElements(driver, DC_Template_Utility.class);
	}

	/**
	 * Use this method to verify the calculation for template 7
	 * 
	 * @return true, when the calculation is as expected.
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public boolean verifyCalculation(String fieldNameToBeCalculated, double weight)
			throws InterruptedException, IOException {

		double expectedToggleFieldValue;
		expectedToggleFieldValue = expectedCalculateToggleValueFor(fieldNameToBeCalculated, weight);

		if ((fieldNameToBeCalculated.equalsIgnoreCase("dose"))
				&& (expectedToggleFieldValue < doseMin || expectedToggleFieldValue > doseMax)) {
			if (getDC_Util().isAlertPresentForInfusion()) {
				getDC_Util().enterValueinFieldandPressTab(getDC_Util().field_conc_infusion,
						recommendedConcentrationValue + "");
				getDC_Util().click_btn(getDC_Util().CALCULATE);
			} else
				return false;
		}

		if ((fieldNameToBeCalculated.equalsIgnoreCase("conc"))
				&& (expectedToggleFieldValue < concMin || expectedToggleFieldValue > concMax)) {
			if (expectedToggleFieldValue > dd2InfusionMaxValue) {
				getDC_Util().click_btn(getDC_Util().ALERT_OK);
				getDC_Util().enterValueinFieldandPressTab(getDC_Util().field_dose_infusion,
						recommendedDosingValue + "");
				getDC_Util().click_btn(getDC_Util().CALCULATE);
			}

			else if (getDC_Util().isAlertPresentForInfusion()) {
				getDC_Util().enterValueinFieldandPressTab(getDC_Util().field_dose_infusion,
						recommendedDosingValue + "");
				getDC_Util().click_btn(getDC_Util().CALCULATE);
			}

			else
				return false;
		}
		expectedToggleFieldValue = expectedCalculateToggleValueFor(fieldNameToBeCalculated, weight);
		double actualToggleFieldValue = getValuePresentInFieldBox(fieldNameToBeCalculated);

		if (calculateDD1DD2andInfusionTime() && (actualToggleFieldValue == expectedToggleFieldValue)) {
			extentReport.PASS("Verification of calculation value", "Default calculation value is correct");
			log.info("Default calculation value is correct");
			return true;
		}

		extentReport.FAIL(driver, "Verification of calculation value", "Default calculation value is incorrect");
		logERROR("Default calculation value is incorrect");

		return false;

	}

	/**
	 * Use this method to verify the calculation after overriding the dose value
	 * for template 7
	 * 
	 * @return true, when the calculation is as expected.
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public boolean verifyCalculationafterDosevalueOverriden(String fieldNameToBeCalculated, double weight)
			throws InterruptedException, IOException {

		double expectedToggleFieldValue;
		expectedToggleFieldValue = expectedCalculateToggleValueFor(fieldNameToBeCalculated, weight);

		if ((fieldNameToBeCalculated.equalsIgnoreCase("dose"))
				&& (expectedToggleFieldValue < doseMin || expectedToggleFieldValue > doseMax)) {
			if (getDC_Util().isAlertPresentForInfusion()) {
				getDC_Util().enterValueinFieldandPressTab(getDC_Util().field_conc_infusion,
						recommendedConcentrationValue + "");
				getDC_Util().click_btn(getDC_Util().CALCULATE);
			} else
				return false;
		}

		if ((fieldNameToBeCalculated.equalsIgnoreCase("conc"))
				&& (expectedToggleFieldValue < concMin || expectedToggleFieldValue > concMax)) {
			if (expectedToggleFieldValue > dd2InfusionMaxValue) {
				getDC_Util().click_btn(getDC_Util().ALERT_OK);
				getDC_Util().enterValueinFieldandPressTab(getDC_Util().field_dose_infusion,
						recommendedDosingValue + "");
				getDC_Util().click_btn(getDC_Util().CALCULATE);
			}

			else if (getDC_Util().isAlertPresentForInfusion()) {
				getDC_Util().enterValueinFieldandPressTab(getDC_Util().field_dose_infusion,
						recommendedDosingValue + "");
				getDC_Util().click_btn(getDC_Util().CALCULATE);
			}

			else
				return false;
		}
		expectedToggleFieldValue = expectedCalculateToggleValueFor(fieldNameToBeCalculated, weight);
		double actualToggleFieldValue = getValuePresentInFieldBox(fieldNameToBeCalculated);

		if (calculateDD1DD2andInfusionTime() && (actualToggleFieldValue == expectedToggleFieldValue)) {
			extentReport.PASS("Verification of calculation value after overriding the dose value",
					"Default calculation value is correct after overriding the dose value");
			log.info("Default calculation value is correct after overriding the dose value");
			return true;
		}

		extentReport.FAIL(driver, "Verification of calculation value after overriding the dose value",
				"Default calculation value is incorrect after overriding the dose value");
		logERROR("Default calculation value is incorrect after overriding the dose value");

		return false;

	}

	public void clickOverRideForField(String fieldName, int overRideValue) throws InterruptedException {
		try {
			WebElement element = null;
			if (fieldName.equals("dose"))
				element = field_dose;
			else
				element = field_conc;
			getDC_Util().enterValueinFieldandPressTab(element, overRideValue + "");
			if (fieldName.equals("conc") && conc_maxPopUp.getAttribute("style").contains("opacity: 1")) {
				getDC_Util().click_btn(getDC_Util().ALERT_OK);
				if (concMin > 1) {
					concMin = concMin + 1.0;
				}
				getDC_Util().enterValueinFieldandPressTab(getDC_Util().field_conc_infusion, (concMin + 0.1) + "");
			} else
				getDC_Util().clickOverRide();
			extentReport.PASS("Overriding the dose value", "Dose value is overridden");
			log.info("Dose value is overridden");
		} catch (Exception e) {

		}
	}

	/**
	 * @param toggleFieldName
	 * @throws InterruptedException
	 */
	public double expectedCalculateToggleValueFor(String toggleFieldName, double Weight) throws InterruptedException {
		getDC_Util().sleep(500);
		double actualdose = getValuePresentInFieldBox("dose");
		double actualConc = getValuePresentInFieldBox("conc");
		double actualRate = getValuePresentInFieldBox("rate");
		double actualWeight = Weight;
		double expectedValue = 0;

		if (toggleFieldName.equalsIgnoreCase("dose")) {
			expectedValue = ((actualConc * actualRate) / actualWeight) / 60;
		} else if (toggleFieldName.equalsIgnoreCase("conc")) {
			expectedValue = ((actualdose * actualWeight) / actualRate) * 60;
		} else if (toggleFieldName.equalsIgnoreCase("rate")) {
			expectedValue = ((actualdose * actualWeight) / actualConc) * 60;
		}
		return getDC_Util().rounding_decimal_values(expectedValue); // for new
																	// fix
																	// rounding_decimal_values
																	//
	}

	/**
	 * 
	 * @param calculateValueFor
	 *            = pass the as dose or rate or conc
	 * @return the expected value present inside the field box.
	 */
	public double getValuePresentInFieldBox(String calculateValueFor) {
		int id = 0;
		if (calculateValueFor.equalsIgnoreCase("dose")) {
			id = 3;
		} else if (calculateValueFor.equalsIgnoreCase("conc")) {
			id = 5;
		} else if (calculateValueFor.equalsIgnoreCase("rate")) {
			id = 7;
		}
		return Double.parseDouble(getDC_Util().getFieldValue(id));
	}

	public boolean calculateDD1DD2andInfusionTime() throws InterruptedException {
		getDC_Util().sleep(500);
		double actualDD1Value = Double.parseDouble(select1_value.getText());
		double actualDD2Value = Double.parseDouble(select2_Value.getText());
		double actualTime = Double.parseDouble(infusionTime.getText());
		double expectedSelect1Value = calculateDD1();
		double expectedSelect2Value = calculateDD2();
		double expectedTime = calculateTime();

		if ((actualDD1Value == expectedSelect1Value) && (actualDD2Value == expectedSelect2Value)
				&& (actualTime == expectedTime))
			return true;
		return false;
	}

	/**
	 * when the Select = NS or D5W from the 1st drop down This method calculates
	 * the value , when the calculate button is pressed.
	 */
	public double calculateDD1() {
		int roundingDigits = 0;
		double result = 0.0;
		double totalVolume = Double.parseDouble(getDC_Util().getFieldValue(17));
		Double dd_value = Double.parseDouble(select2_Value.getText());
		if (totalVolume - dd_value < 0)
			result = 0.0;
		else {
			result = totalVolume - dd_value;
		}

		roundingDigits = 100;
		result = Math.round(result * roundingDigits) / Double.parseDouble(roundingDigits + "");
		return result;
	}

	/**
	 * when the Select = Nitroprusside from the 2nd drop down This method
	 * calculates the value , when the calculate button is pressed.
	 */
	public double calculateDD2() {
		int roundingDigits = 0;
		double result = 0.0;
		Double conc = Double.parseDouble(getDC_Util().getFieldValue(5));
		double totalVolume = Double.parseDouble(getDC_Util().getFieldValue(17));
		result = (conc * totalVolume) / dd2InfusionMaxValue;
		roundingDigits = 100;
		result = Math.round(result * roundingDigits) / Double.parseDouble(roundingDigits + "");
		return result;
	}

	/**
	 * Calculates the infusion time
	 */
	public double calculateTime() {
		double totalVolume = Double.parseDouble(getDC_Util().getFieldValue(17));
		Double actualRate = Double.parseDouble(field_rate.getAttribute("value"));
		return getDC_Util().roundToTwoDigit(totalVolume / actualRate);
	}
}
