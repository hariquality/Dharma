package com.ibm.webapp.pageObjects.carenotes;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class CareNotes_LabTitlesPage extends Selenese {
	protected final WebDriver driver;

	@FindBy(xpath = "//strong[contains(text(),'Lab Titles')]")
	private WebElement hotlistCaption;

	@FindBy(id = "SearchBox")
	private WebElement jumpToTxtBox;

	@FindBy(id = "PFFormActionId_carenotescommon.RetrieveDocumentDescriptorsForTitleLab")
	private WebElement searchButton;

	public CareNotes_LabTitlesPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		wait.until(ExpectedConditions.visibilityOf(hotlistCaption));
	}

	/**
	 * search a drug in Browse tests section in Lab titles page
	 **/
	public CareNotes_LabTitleListPage browseTests(String term) {
		try {
			sendKeys(driver, "Jump To", jumpToTxtBox, term);
			click(driver, "Search", searchButton);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		CareNotes_LabTitleListPage page = PageFactory.initElements(driver, CareNotes_LabTitleListPage.class);
		return page;

	}

	public CareNotes_HeaderPage getHeaderPage() {
		CareNotes_HeaderPage headerPage = PageFactory.initElements(driver, CareNotes_HeaderPage.class);
		return headerPage;
	}

}
