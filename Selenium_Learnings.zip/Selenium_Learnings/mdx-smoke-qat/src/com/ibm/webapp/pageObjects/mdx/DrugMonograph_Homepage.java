package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.utils.NeoFaxUtility;
import com.ibm.webapp.utils.Selenese;



public class DrugMonograph_Homepage extends Selenese{
	
	WebDriver driver;
	
	 @FindBy(xpath = "//div[@id='DrugDropDownList']/div[not(contains(@style,'none'))]")
	   private List<WebElement> dropDownListResult;
	 
	public DrugMonograph_Homepage(WebDriver driver)
	   {
	      this.driver = driver;
	      PageFactory.initElements(driver, this);
	      driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	   }
	
	
	 /**
	    * 
	    * @returns NeofaxUtility
	    */
	   public NeoFaxUtility getNeofaxUtility()
	   {
	      return PageFactory.initElements(driver, NeoFaxUtility.class);

	   }

	 /**
	    * Select the drug from the drop down list.
	    * 
	    * @param userInput
	    *           = enter the expectedDrugName starting characters ex: abel
	    * @param expectedDrugName
	    *           = pass the expected Drug Name to be selected from the dropdown
	 * @throws IOException 
	    */

	   public DrugMonograph_DrugLandingPage selectDrugByClicking(String userInput,
	                                                  String expectedDrugName) throws IOException
	   {
	      getNeofaxUtility().enterDrugName(userInput, "DM");
	      Iterator<WebElement> it = dropDownListResult.iterator();
	      while (it.hasNext())
	      {
	         WebElement drug_Element = it.next();
	         if (drug_Element.getText().toLowerCase()
	               .equalsIgnoreCase(expectedDrugName.toLowerCase()))
	         {
	            click(driver, "Drug name", drug_Element);
	            break;
	         }
	      }
	      return PageFactory.initElements(driver, DrugMonograph_DrugLandingPage.class);
	   }
	   
	   
	  
}
