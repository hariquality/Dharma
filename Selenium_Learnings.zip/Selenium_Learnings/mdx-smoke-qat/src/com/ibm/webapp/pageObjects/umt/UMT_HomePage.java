package com.ibm.webapp.pageObjects.umt;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.utils.Selenese;

public class UMT_HomePage extends Selenese {
	WebDriver driver;

	@FindBy(id = "search.entity.entityNo_index_0")
	private WebElement entityNo;

	@FindBy(id = "umt.THCSearch")
	private WebElement searchButton;

	public void Enter_EntityNo(String term) {
		entityNo.sendKeys(term);
	}

	public void Click_Search() {
		searchButton.click();
	}

	@FindBy(xpath = "//strong[contains(text(),'Your Search')]")
	private WebElement mainToolbarLinkForConstructor;

	@FindBy(linkText = "All Users")
	private WebElement AllUsersLinkClick;

	@FindBy(xpath = "//img[@title='Logout not found']")
	private WebElement LogoutButton;

	public UMT_HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	public UMT_AllUsersPage clickAll_UsersPage() {
		AllUsersLinkClick.click();
		UMT_AllUsersPage allUserPage = PageFactory.initElements(driver, UMT_AllUsersPage.class);
		return allUserPage;
	}

	public UMT_HeaderPage getHeaderPage() {
		UMT_HeaderPage headerPage = PageFactory.initElements(driver, UMT_HeaderPage.class);
		return headerPage;
	}

	/**
	 * Use this method to verify if UMT Home Page is displayed,
	 * 
	 * @throws IOException
	 */
	public void isHomePageDisplayed() throws IOException {
		try {
			if (driver.getTitle().equalsIgnoreCase("User Management Tool: Search Organization/Facility Results")) {
				extentReport.PASS("UMT Home Page Verification", "UMT Home Page is displayed correctly");
			} else {
				extentReport.FAIL(driver, "UMT Home Page Verification", "UMT Home Page is not displayed");
			}
		} catch (Exception e) {
			extentReport.FAIL(driver, "UMT Home Page Verification",
					"UMT Home Page is not displayed- Some Exception occured");
		}

	}

	/**
	 * Use this method to log out of the application,
	 * 
	 * @throws IOException
	 */
	public void UMTLogout() throws IOException {
		click(driver, "Log out", LogoutButton);
	}

}
