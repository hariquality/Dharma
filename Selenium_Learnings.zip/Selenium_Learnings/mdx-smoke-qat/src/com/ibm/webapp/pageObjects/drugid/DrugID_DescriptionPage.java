package com.ibm.webapp.pageObjects.drugid;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.pageObjects.mdx.MDX_HeaderPage;
import com.ibm.webapp.utils.Selenese;

public class DrugID_DescriptionPage extends Selenese

{
   WebDriver driver;

   @FindBy(xpath = "//*[@id='PillSelectShape_index_0']")
   private WebElement selectShapeDropdown;

   @FindBy(xpath = "//*[@id='PillSelectPattern_index_0']")
   private WebElement selectPatternDropdown;

   @FindBy(id = "showImages")
   private WebElement showImagesCheckbox;

   @FindBy(xpath = "//*[@id='color_index_0_span']")
   private WebElement blackCheckbox;

   @FindBy(xpath = "//*[@id='color_index_14_span']")
   private WebElement yellowCheckbox;

   @FindBy(xpath = "//*[@id='SearchBtn']")
   private WebElement searchImagesButton;

   public DrugID_DescriptionPage(WebDriver driver)
   {
      this.driver = driver;
      PageFactory.initElements(driver, this);
      driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
   }

   public MDX_HeaderPage getHeaderPage()
   {
      MDX_HeaderPage headerPage = PageFactory
            .initElements(driver, MDX_HeaderPage.class);
      return headerPage;
   }

	/**
	 * Return true if Drug Identification select shape dropdown box is
	 * displayed, otherwise return false.
	 * @return
	 * @throws IOException
	 */
	public void isSelectShapeDropdownVisible() throws IOException {
		isElementDisplayed(driver, "Select Shape DropDown Validation", selectShapeDropdown);
	}

   public void isSelectPatternDropdownVisible() throws IOException
   {
	   isElementDisplayed(driver, "Select Pattern DropDown Validation", selectPatternDropdown);
   }

   public DrugID_DescriptionPage clickBlackCheckbox_CapsuleShape() throws IOException
   {
      // blackCheckbox.click();
      try
      {
         click(driver, "Black", blackCheckbox);
         click(driver, "Shape", selectShapeDropdown);
         selectDropDownByVisibleText(driver,
                                     selectShapeDropdown,
                                     "Capsule-shape");
         extentReport.PASS("Selected shape and color",
                           "Selected shape and color");
         log.info("Selected shape and color");
      }
      catch (IOException e)
      {
         // TODO Auto-generated catch block
         e.printStackTrace();
         extentReport.FAIL(driver,
                           "Shape and color is not selected",
                           "shape and color is not selected");
         log.error("shape and color is not selected");
      }
      // selectShapeDropdown.click();

      DrugID_DescriptionPage diDescriptionPage = PageFactory
            .initElements(driver, DrugID_DescriptionPage.class);
      return diDescriptionPage;
   }

   public DrugID_ImageResultsPage clickSearchImagesButton() throws IOException
   {
      // searchImagesButton.click();
      try
      {
         click(driver, "search with images", searchImagesButton);
         extentReport.PASS("Search with image clicked",
                           "Search with images clicked");
         log.info("Search with images clicked");
      }
      catch (IOException e)
      {
         // TODO Auto-generated catch block
         e.printStackTrace();
         extentReport.FAIL(driver,
                           "Search with images not clicked",
                           "Search with images clicked");
         log.error("Search with images not clicked");
      }
      DrugID_ImageResultsPage diImageResultPage = PageFactory
            .initElements(driver, DrugID_ImageResultsPage.class);
      return diImageResultPage;
   }
}
