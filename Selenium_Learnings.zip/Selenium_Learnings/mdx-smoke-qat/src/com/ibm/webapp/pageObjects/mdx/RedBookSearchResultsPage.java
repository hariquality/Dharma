package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.ibm.webapp.utils.Selenese;

public class RedBookSearchResultsPage extends Selenese {
	private final WebDriver driver;

	@FindBy(id = "redbookPageTitle")
	private WebElement redbookResultsTitle;

	@FindBy(xpath = "//table[@id='RBSearchResults_Table']/tbody/tr")
	private List<WebElement> redBookSearchSmokeResults;

	@FindBy(xpath = "//table[@id='RBSearchResults_Table']/tbody/tr[2]/td[4]/a")
	private WebElement redBookSearchProductNameLink;

	@FindBy(xpath = "//*[@id='RBSearchResults_Table']//tr/td/a[contains(@title,'DIGOXIN')]")
	private WebElement productPopupLink;

	@FindBy(xpath = "//*[@id='detailPopupDivId_title']")
	private WebElement productPopupBox;

	@FindBy(xpath = "//input[@value='Close' and contains(@onclick,'detailPopupDivId')]")
	private WebElement productPopupClose;

	@FindBy(xpath = "//input[@value='Close' and contains(@onclick,'matchingProdsSubmit')]")
	private WebElement activeIngredientPopupClose;

	@FindBy(xpath = "//*[@id='RBSearchResults_Table']//tr/td/a[contains(@title,'aspirin')]")
	private WebElement activeIngredientPopupLink;

	@FindBy(xpath = "//table[@id='RBSearchResults_Table']/tbody/tr[3]/td[5]/a")
	private WebElement activeIngredientPopupLink1;

	@FindBy(xpath = "//*[@id='matchingProdsSubmit']")
	private WebElement activeIngredientPopupBox;

	@FindBy(xpath = "(//*[@id='RBSearchResults_Table']//a[contains(@title,'ADVANCE PHARMACEUTICAL INC.')])[3]")
	// @FindBy(xpath =
	// "//*[@id='RBSearchResults_Table']//tr/td/a[contains(text(),'manufacturerPopupDivId')]")
	private WebElement manufacturerPopupLink;

	@FindBy(xpath = "//table[@id='RBSearchResults_Table']/tbody/tr[2]/td[6]/a")
	private WebElement manufacturerPopupLink1;

	@FindBy(xpath = "//span[@id='manufacturerPopupDivId_title']")
	private WebElement manufacturerPopupBox;

	@FindBy(xpath = "//input[@value='Close' and contains(@onclick,'manufacturerPopupDivId')]")
	private WebElement manufacturerPopupClose;

	public RedBookSearchResultsPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(redbookResultsTitle));

	}

	/**
	 * Use this method to verify the red book search result page is reached
	 * 
	 * @param drug
	 *            name = Pass the drug name
	 * @throws IOException
	 */

	public void isRedBookSearchResultsDisplayed(String drugName) throws IOException {
		try {
			Assert.assertTrue((redBookSearchSmokeResults.size() > 0)
					&& (redBookSearchProductNameLink.getText().equalsIgnoreCase(drugName)));
			extentReport.PASS("Verification of relevant search result are displayed in Red book search result page",
					"Relevant search result are displayed in Red book search result page");
			log.info("Relevant search result are displayed in Red book search result page");
		} catch (Exception e) {
			extentReport.FailWithException(driver,
					"Verification of relevant search result are displayed in Red book search result page",
					"Relevant search result are not displayed in Red book search result page", e);
			logERROR("Relevant search result are not displayed in Red book search result page", e);
		}

	}

	/**
	 * Use this method is to click on product link
	 * 
	 * @return Red book search results page
	 * @throws IOException
	 */

	public RedBookSearchResultsPage clickOnProductPopupLink() throws IOException {
		try {
			click(driver, "Product link", productPopupLink);

		} catch (Exception e) {
			e.printStackTrace();
		}
		RedBookSearchResultsPage rbSearchResultsPage = PageFactory.initElements(driver, RedBookSearchResultsPage.class);
		return rbSearchResultsPage;
	}

	/**
	 * Use this method to verify the product details in the product Popup window
	 * 
	 * @throws IOException
	 */
	public void getProductPopupTitle() throws IOException {
		try {
			String popupTitle = "";
			popupTitle = productPopupBox.getText();
			Assert.assertTrue(popupTitle.contains("PRODUCT DETAILS"));
			extentReport.PASS("Verification of product details is displayed in popup window",
					"Product title is displayed in the popup window");
			log.info("Product title is displayed in the popup window");

		} catch (Exception e) {
			extentReport.FailWithException(driver, "Verification of product details is displayed in popup window",
					"Product title is not displayed in the popup window", e);
			logERROR("Product title is not displayed in the popup window", e);
		}

	}

	/**
	 * Use this method to close the product's popup window
	 * 
	 * @return Red book search results page
	 * @throws IOException
	 */
	public RedBookSearchResultsPage clickOnProductPopupCloseBtn() throws IOException {
		try {
			click(driver, "Close button", productPopupClose);
			extentReport.PASS("Closing the popup window", "Product popup window is closed");
			log.info("Product popup window is closed");
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Closing the popup window", "Product popup window is not closed", e);
			logERROR("Product popup window is not closed", e);
		}
		RedBookSearchResultsPage rbSearchResultsPage = PageFactory.initElements(driver, RedBookSearchResultsPage.class);
		return rbSearchResultsPage;
	}

	/**
	 * Use this method to click on active ingredients link
	 * 
	 * @return Red book search results page
	 * @throws IOException,InterruptedException
	 */
	public RedBookSearchResultsPage clickOnActiveIngredientPopupLink() throws InterruptedException {
		try {
			Thread.sleep(2000);
			click(driver, "Active ingredients link", activeIngredientPopupLink1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		RedBookSearchResultsPage rbSearchResultsPage = PageFactory.initElements(driver, RedBookSearchResultsPage.class);
		return rbSearchResultsPage;
	}

	/**
	 * Use this method to verify the active ingredients details in the Find
	 * similar products's Popup window
	 * 
	 * @throws IOException
	 */
	public void getActiveIngredientPopupTitle() throws IOException {
		try {
			String popupTitle = "";
			popupTitle = activeIngredientPopupBox.getText();
			Assert.assertTrue(popupTitle.contains("SIMILAR PRODUCTS"));
			extentReport.PASS("Verification of ingredients title is displayed in find similar products's Popup window",
					"Active ingredients title is displayed in find similar products's Popup window");
			log.info("Product title is displayed in find similar products's Popup window");

		} catch (Exception e) {
			extentReport.FailWithException(driver,
					"Verification of ingredients details is displayed in find similar products's Popup window",
					"Active ingredients details is not displayed in find similar products's Popup window", e);
			logERROR("Active ingredients details is not displayed in find similar products's Popup window", e);
		}

	}

	/**
	 * Use this method to close the find similar product's popup window
	 * 
	 * @return Red book search results page
	 * @throws IOException
	 */
	public RedBookSearchResultsPage clickOnActiveIngredientPopupCloseBtn() throws IOException {
		try {
			click(driver, "Close button", activeIngredientPopupClose);
			extentReport.PASS("Closing the popup window", "Find similar popup window is closed");
			log.info("Find similar popup window is closed");
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Closing the popup window",
					"Find similar popup window is not closed", e);
			logERROR("Find similar popup window is not closed", e);
		}
		RedBookSearchResultsPage rbSearchResultsPage = PageFactory.initElements(driver, RedBookSearchResultsPage.class);
		return rbSearchResultsPage;
	}

	/**
	 * Use this method to click on the Manufacturer popup window
	 * 
	 * @return Red book search results page
	 * @throws IOException,InterruptedException
	 */
	public RedBookSearchResultsPage clickOnManufacturerPopupLink() throws InterruptedException {
		try {
			Thread.sleep(3000);
			// Actions action = new Actions(driver);
			// action.moveToElement(manufacturerPopupLink1).click().perform();
			click(driver, "Click on manufacturer link", manufacturerPopupLink1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		RedBookSearchResultsPage rbSearchResultsPage = PageFactory.initElements(driver, RedBookSearchResultsPage.class);
		return rbSearchResultsPage;
	}

	/**
	 * Use this method to verify the manufacturer details in the manufacturer
	 * Popup window
	 * 
	 * @throws IOException
	 */
	public void getManufacturerPopupTitle() throws IOException {
		try {
			String popupTitle = "";
			popupTitle = manufacturerPopupBox.getText();
			Assert.assertTrue(popupTitle.contains("MANUFACTURER"));
			extentReport.PASS("Verification of Manufacturer title is displayed in Manufacturer Popup window",
					"Manufacturer title is displayed in Manufacturer Popup window");
			log.info("Manufacturer title is displayed in Manufacturer Popup window");

		} catch (Exception e) {
			extentReport.FailWithException(driver,
					"Verification of ingredients details is displayed in find similar products's Popup window",
					"Manufacturer title is not displayed in Manufacturer Popup window", e);
			logERROR("Manufacturer title is not displayed in Manufacturer Popup window", e);
		}

	}

	/**
	 * Use this method to close the manufacturer popup window
	 * 
	 * @return Red book search results page
	 * @throws IOException
	 */
	public RedBookSearchResultsPage clickOnManufacturerPopupCloseBtn() throws IOException {
		try {
			click(driver, "Click on manufacturer link", manufacturerPopupClose);
			extentReport.PASS("Closing the popup window", "Manufacturer popup window is closed");
			log.info("Manufacturer popup window is closed");
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Closing the popup window",
					"Manufacturer popup window is not closed", e);
			logERROR("Manufacturer popup window is not closed", e);
		}
		RedBookSearchResultsPage rbSearchResultsPage = PageFactory.initElements(driver, RedBookSearchResultsPage.class);
		return rbSearchResultsPage;
	}
}
