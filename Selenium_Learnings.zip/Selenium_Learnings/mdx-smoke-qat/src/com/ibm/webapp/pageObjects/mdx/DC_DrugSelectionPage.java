package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.ibm.webapp.utils.Selenese;

public class DC_DrugSelectionPage extends Selenese{
	
	WebDriver driver;
	   //private WebDriverWait webDriverwait;
	   
	   @FindBy(id = "drugCaptionDiv")
	   private WebElement drugSelection_header;
	   
	   @FindBy(id = "selDrugList")
	   private WebElement drugListBox;
	   
	   @FindBy(id = "alphaFilterId")
	   private WebElement alphaFilter;
	   
	   @FindBy(xpath ="//table[@id='drugSelectionHelpTableID']//tr[1]/td[1]" )
	   private WebElement actual_age;
	   
	   @FindBy(xpath ="//table[@id='drugSelectionHelpTableID']//tr[1]/td[2]" )
	   private WebElement actual_PMAorPedWeight ;
	   
	   @FindBy(xpath ="//table[@id='drugSelectionHelpTableID']//tr[2]/td[1]" )
	   private WebElement actual_Weight;
	   
	   @FindBy(xpath ="//table[@id='drugSelectionHelpTableID']//tr[2]/td[2]" )
	   private WebElement actual_EGA;
	   
	   @FindBy(xpath ="//select[@id='selDrugList']/option" )
	   private List<WebElement> drugListInBox; 
	   
	   JavascriptExecutor js = (JavascriptExecutor) driver;
	
	 public DC_DrugSelectionPage(WebDriver driver) throws IOException
	   {
		 this.driver = driver;
		 PageFactory.initElements(this.driver, this);
		 waitForElementVisibility(driver, drugSelection_header);
	    
	   }
	 
	 /**
	    * @return patientDetails - stores the patient details displayed in each page 
	    */
	   public LinkedHashMap<String, String> getPatientInformation(String NEOorPED)
	   {
		  
	      LinkedHashMap<String, String> patientDetails = new LinkedHashMap<>();
	      if (NEOorPED.equalsIgnoreCase("neo"))
	      {
	         patientDetails.put(actual_age.getText(),
	                            actual_PMAorPedWeight.getText());
	         patientDetails.put(actual_Weight.getText(), actual_EGA.getText());
	      }
	      else
	      {
	         patientDetails.put(actual_age.getText(),
	                            actual_PMAorPedWeight.getText());
	      }
	      return patientDetails;
		  
	   }
	   
	   /**
	    * enter the DrugName in alphaFilter box
	 * @throws IOException 
	    */
	   public void enterDrugName(String drugName) throws IOException
	   {
		   try{
	      click(driver, "Clear", alphaFilter);
	       sendKeys(driver, "Drug Search box", alphaFilter, drugName);
	       extentReport.PASS("Verification of expected drug is entered in drug list box",
	                "Expected drug is entered in drug list box");
			 log.info("Expected drug is entered in drug list box");
		   }catch(Exception e){
			   extentReport.FailWithException(driver,"Verification of expected drug is entered in drug list box", "Expected drug is not entered in drug list box",e);
		          logERROR( "Expected drug is not entered in drug list box", e);
			   e.printStackTrace();
		   }
	   }
	   
	   /**
	    * Select the drugName from the DrugList box
	    * @param enter the expected DrugName to be 
	    *  selected from the the DrugBox         
	    * @return 
	 * @throws IOException 
	    */
	   public DC_Template_Utility selectDrugfromDrugbox(String expectedDrugName) throws IOException
	   {

	      try
	      {
	         Select drugList = new Select(drugListBox);
	         drugList.selectByVisibleText(expectedDrugName);
	         extentReport.PASS("Verification of Template page is loaded after selecting the expected drug name in drug list box",
	                 "Template page loaded successfully after selecting the drug name from the drug list box");
	 		 log.info("Template page loaded successfully after selecting the drug name from the drug list box");
	         
	      }
	      catch (Exception e)
	      {
	    	  extentReport.FailWithException(driver,"Verification of Template page is loaded after selecting the expected drug name in drug list box","Template page is not loaded successfully after selecting the drug name from the drug list box",e);
	          logERROR("Template page is not loaded successfully after selecting the drug name from the drug list box", e);
	    	  driver.navigate().refresh();
	         e.printStackTrace();
	      }
	      return  PageFactory.initElements(driver, DC_Template_Utility.class);
	   }

}
