package com.ibm.webapp.pageObjects.mdx;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;


public class DrugInteractionsResultsPage extends Selenese {
	WebDriver driver;

	@FindBy(xpath = "/html/body/div[8]/div/div[2]/table[1]/tbody/tr[4]/td[1]/div/a")
	private WebElement firstDrugDrugIntSummary;

	@FindBy(xpath = "//div[@id='refineMultiInteractions']//div[@class='pageTitle inline']")
	private WebElement drugInteractionsTitle;

	@FindBy(xpath = "//button[@class='submitBtn']/span")
	private WebElement modifyButton;

	@FindBy(xpath = "//*[@id='lnkSeverityOpts']")
	private WebElement refineSeverityBtn;

	@FindBy(xpath = "//div[@id='dialogueBottomAlternate']//input[@class='printBtn']/following-sibling::input")
	public WebElement closeDrugDrugPopUp;

	@FindBy(xpath = "//div[@class='noprint']/a")
	public List<WebElement> jumpToLinksPrint;

	@FindBy(xpath = "//*[@id='lnkDocOpts']")
	private WebElement refineDocBtn;

	@FindBy(xpath = ".//*[@id='resultsTable']/tbody/tr[14]/td[4]")
	private WebElement firstDrugFoodIntSummary;

	@FindBy(xpath = "//*[@id='lnkTypeOpts']")
	private WebElement refineTypeBtn;

	@FindBy(xpath = "/html/body/div[8]/div/div[2]/div[6]/div[2]")
	private List<WebElement> jumpToLinks;

	@FindBy(id = "btnSubmit3")
	private WebElement docUpdateBtn;

	@FindBy(id = "btnSubmit2")
	private WebElement severityUpdateBtn;

	@FindBy(xpath = "//*[@id='lnkDrugList']")
	private WebElement refineDrugsBtn;

	@FindBy(xpath = "//*[@id='quickanspanel_section_topic_header']")
	private WebElement medicationSafetyTitle;

	@FindBy(xpath = "//*[@id='lbNoItemSelectedInteractions_title'] ")
	private WebElement noItemsSelectedMessage;

	@FindBy(xpath = "(//div[@id='dialogueBottomAlternate']//input[@value='Close'])[6]")
	private WebElement closeNoItemsSelectedBtn;

	@FindBy(xpath = "//*[@id='lbNoItemSelectedInteractions_title']")
	private WebElement noDocItemsSelectedMessage;

	@FindBy(xpath = "/html/body/div[8]/div/div[4]/table/tbody/tr[4]/td[3]/a")
	private WebElement popDocumentationLink;

	@FindBy(xpath = "//*[@id='documentationPop_title']")
	private WebElement popDocumentationHeader;

	@FindBy(xpath = "/html/body/div[8]/div/div[4]/table/tbody/tr[4]/td[2]/div/a")
	private WebElement popSeverityLink;

	@FindBy(xpath = "//input[@title='Close' and contains(@onclick,'1210631_index_0')]")
	public WebElement btnClose;

	@FindBy(xpath = "/html/body/div[32]/div[2]/div/div[3]/input[2]")
	private WebElement popSeverityCloseBtn;

	@FindBy(xpath = "(//div[@id='dialogueBottomAlternate']//input[@value='Close'])[6]")
	// @FindBy(xpath = "/html/body/div[35]/div[2]/div/div[2]/input")
	private WebElement closeNoDocItemsSelectedBtn;

	@FindBy(xpath = "/html/body/div[33]/div[2]/div/div[3]/input[2]")
	private WebElement popDocumentationCloseBtn;

	@FindBy(xpath = "//span[@class='dojoxDialogTitle' and @id='1210631_index_0_title']")
	public WebElement titleInteractionDetail;

	@FindBy(xpath = "//div[contains(@id,'monograph')]/h3")
	public List<WebElement> interationContentHeadings;

	@FindBy(xpath = "/html/body/div[8]/div/div[2]/div[4]/div/div[3]/form/table/tbody/tr/td[9]/div/div[3]/input[2]")
	private WebElement typeUpdateBtn;

	@FindBy(xpath = "//body/div[8]//div[2]/div[6]/div[2]/a[2]")
	private WebElement jumpToSelectedLinks;

	@FindBy(xpath = "//*[@id='1210631_index_0_title']") // *[@id="1210631_index_0_title"]
	private WebElement popDrugHeader;

	@FindBy(xpath = "//*[@id=\"refineMultiInteractionsEnd\"]/div[2]/form/button/span")
	private WebElement modifyIntBtn;

	@FindBy(xpath = "//*[@id='severityPop_title']")
	private WebElement popSeverityHeader;

	@FindBy(id = "btnSubmit1")
	private WebElement drugsUpdateBtn;

	@FindBy(xpath = "//*[@id='diDrugTitles']")
	private WebElement popDrugLink;

	@FindBy(xpath = "/html/body/div[15]/div[2]/div/div[2]/input[2]")
	private WebElement popDrugCloseBtn;

	@FindBy(xpath = "/html/body/div[8]/div/div[4]/table/tbody/tr[5]/td[4]")
	private WebElement secondDrugDrugIntSummary;

	@FindBy(xpath = "//div[@id='lbNoDrugs']//input[@value='Close']")
	private WebElement closeMinDrugBtn;

	@FindBy(xpath = "//*[@id='lbNoItemSelectedInteractions_title']")
	private WebElement noTypeItemsSelectedMessage;

	@FindBy(xpath = "//*[@id='lbNoDrugs_title']")
	private WebElement minimumDrugsMessage;

	@FindBy(xpath = "(//*[@id='diDrugTitles'])[1]")
	public WebElement drugDrugLink;

	@FindBy(xpath = "//div[@id='drugList']//input[@type='checkbox']/following-sibling::a")
	private List<WebElement> multipleDrugNameList;

	@FindBy(xpath = "/html/body/div[36]/div[2]/div/div[2]/input")
	private WebElement closeNoTypeItemsSelectedBtn;

	public DrugInteractionsResultsPage(WebDriver driver) throws IOException {
		 this.driver = driver;
	      PageFactory.initElements(this.driver, this);
	      WebDriverWait wait = new WebDriverWait(this.driver, 20);
	      try
	      {
	         wait.until(ExpectedConditions.visibilityOf(modifyButton));
	      }
	      catch (Exception e)
	      {
	         extentReport.FailWithException(driver,"DI Result Page",
	                           "DI ResultPage is not displayed",e);
	         log.error("LoginButton is not visible is not message");
	      }
	}

	public String getFirstDrugDrugInteractionSummary() throws IOException {

		String returnValue = "";
		returnValue = firstDrugDrugIntSummary.getText();
		extentReport.PASS("DI result Page Verification Drug DrugInteractionSummary",
				"Drug Drug InteractionSummary is displayed correctly");
		log.info("Drug DrugInteractionSummary is displayed");
		return returnValue;
	}

	public String getFirstDrugFoodInteractionSummary() {
		String returnValue = "";
		returnValue = firstDrugFoodIntSummary.getText();
		extentReport.PASS("DI result Page Verification Drug FoodInteractionSummary",
				"Drug FoodInteractionSummary is displayed correctly");
		log.info("Drug FoodInteractionSummary is displayed");
		return returnValue;
	}

	public String getDrugTitle() {
		String title = "";
		title = medicationSafetyTitle.getText();
		return title;
	}

	public DrugInteractionsResultsPage clickDrugsBtn() {
		refineDrugsBtn.click();
		extentReport.PASS("DI result Page Verification - clickDrugsBtn", "clickDrugsBtn is working");
		log.info("clickDrugsBtn is working");
		DrugInteractionsResultsPage diResultPage = PageFactory.initElements(driver, DrugInteractionsResultsPage.class);
		return diResultPage;
	}

	public DrugInteractionsResultsPage clickDrugsUpdateBtn() {
		drugsUpdateBtn.click();
		DrugInteractionsResultsPage diResultPage = PageFactory.initElements(driver, DrugInteractionsResultsPage.class);
		return diResultPage;
	}

	public DrugInteractionsResultsPage clickMinDrugCloseBtn() {
		closeMinDrugBtn.click();
		DrugInteractionsResultsPage diResultPage = PageFactory.initElements(driver, DrugInteractionsResultsPage.class);
		return diResultPage;
	}

	public DrugInteractionsResultsPage clickNoItemsSelectedCloseBtn() {
		closeNoItemsSelectedBtn.click();
		DrugInteractionsResultsPage diResultPage = PageFactory.initElements(driver, DrugInteractionsResultsPage.class);
		return diResultPage;
	}

	public DrugInteractionsResultsPage clickNoDocItemsSelectedCloseBtn() {
		closeNoDocItemsSelectedBtn.click();
		DrugInteractionsResultsPage diResultPage = PageFactory.initElements(driver, DrugInteractionsResultsPage.class);
		return diResultPage;
	}

	public DrugInteractionsResultsPage clickNoTypeItemsSelectedCloseBtn() {
		closeNoTypeItemsSelectedBtn.click();
		DrugInteractionsResultsPage diResultPage = PageFactory.initElements(driver, DrugInteractionsResultsPage.class);
		return diResultPage;
	}

	/**
	 * Gets the label text or any other chat response highlighted currently in
	 * the chat window
	 * 
	 * @return content of the Text
	 */
	private String getPopUpContentOrder(int responseHeaderOrder) {
		String content = null;
		try {
			Thread.sleep(1000);
			String script = "return document.getElementsByClassName('outputContent')[2].childNodes["
					+ responseHeaderOrder + "].textContent";
			JavascriptExecutor js = (JavascriptExecutor) driver;
			content = (String) js.executeScript(script);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return content.replaceAll("\n", "").replaceAll(" ", "").trim();

	}

	public HashMap<String, String> getDrugDrugInteractionsPopContent() {
		HashMap<String, String> drugDrugPopUpContent = new HashMap<>();
		drugDrugPopUpContent.put(getPopUpContentOrder(7), getPopUpContentOrder(8));
		drugDrugPopUpContent.put(getPopUpContentOrder(1), getPopUpContentOrder(2));
		drugDrugPopUpContent.put(getPopUpContentOrder(3), getPopUpContentOrder(4));
		drugDrugPopUpContent.put(getPopUpContentOrder(5), getPopUpContentOrder(6));
		drugDrugPopUpContent.put(getPopUpContentOrder(9), getPopUpContentOrder(10));

		return drugDrugPopUpContent;
	}

	public boolean isJumpToLinkPresent(String interactionName) {
		for (WebElement interactionLinks : jumpToLinks) {
			if (interactionLinks.getText().equalsIgnoreCase(interactionName))
				return true;
		}
		return false;
	}

	public boolean isInteractionDetailDisplayed() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(titleInteractionDetail));
		if (titleInteractionDetail.isDisplayed())
			return true;
		else
			return false;
	}

	public String isInteractionDetailContentDisplayed() {
		StringBuilder sb = new StringBuilder();
		for (WebElement header : interationContentHeadings) {
			sb.append(header.getText().toString());
		}
		return sb.toString().substring(0, sb.length() - 1);
	}

	public void closepopup() {
		btnClose.click();
	}

	public boolean isModifyButtonDisplayed() throws IOException {
		try {
			if (modifyButton.isDisplayed()) {
				// assertTrue(isModifyButtonDisplayed(), "Modify button is not
				// found in DI result page");
				extentReport.PASS("DI result Page Verification", "Modify button is displayed correctly");
				log.info("Modify button is displayed correctly");
				return true;
			} else
				return false;
		} catch (Exception e) {
			extentReport.FAIL(driver, "DIResultPage", "Modify button is not found in DI result pag");
			logERROR("Modify button is not found in DI result pag");

		}
		return false;
	}

	public boolean isSeverityTextEqualTo(String expected) throws IOException {
		try {

			if (refineSeverityBtn.getText().contentEquals(expected)) {
				assertTrue(refineSeverityBtn.getText().equals(expected),
						"Severity drop down default value ALL is not displayed");
				extentReport.PASS("DI result Page Verification", "Severity Text is equal to All");
				log.info("Severity Text is equal to All");
				return true;
			} else
				return false;
		} catch (Exception e) {
			extentReport.FAIL(driver, "DIResultPage", "Severity drop down default value ALL is not displayed");
			logERROR("Severity drop down default value ALL is not displayed");

		}
		return false;
	}

	public boolean isDocTextEqualTo(String expected) throws IOException {
		try {
			if (refineDocBtn.getText().contentEquals(expected)) {
				assertTrue(refineDocBtn.getText().equals(expected),
						"Documentation drop down default value ALL is not displayed");
				extentReport.PASS("DI result Page Verification", "Defalut Document text is displayed correctly");
				log.info("Defalut Document text is equal to All");
				return true;
			} else
				return false;
		} catch (Exception e) {
			extentReport.FAIL(driver, "DIResultPage", "Documentation drop down default value ALL is not displayed");
			logERROR("Documentation drop down default value ALL is not displayed");

		}
		return false;
	}

	public boolean isTypeTextEqualTo(String expected) throws IOException {
		try {
			if (refineTypeBtn.getText().contentEquals(expected)) {
				assertTrue(refineTypeBtn.getText().equals(expected),
						"Type drop down default value ALL is not displayed");
				extentReport.PASS("DI result Page Verification", "Default type text is displayed correctly");
				log.info("Default type text is equal to All");
				return true;
			} else
				return false;
		} catch (Exception e) {
			extentReport.FAIL(driver, "DIResultPage", "Type drop down default value ALL is not displayed");
			logERROR("Type drop down default value ALL is not displayed");

		}
		return false;
	}

	/**
	 * Return a list of links from the jump to bar
	 * 
	 * @return
	 * @throws IOException
	 */
	public void getJumpToLinks(String expectedJumpToLinks) throws IOException {
		StringBuilder actualJumpToLinks = new StringBuilder();
		Iterator<WebElement> i = jumpToLinks.iterator();
		while (i.hasNext()) {
			WebElement e = i.next();
			actualJumpToLinks.append(e.getText());
			extentReport.PASS("DI result Page Verification - Verify JumpToLinks",
					"getJumpToLinks is working correctly");
			log.info("Verified JumpToLinks");
		}
		actualJumpToLinks.toString().replaceAll("\\d", "");
		if (actualJumpToLinks.toString().contains(expectedJumpToLinks)) {
			extentReport.PASS("JumpToLinks text validation", "JumpToLinks is workingCorrectly");
			log.info("JumpToLinks is workingCorrectly");
		} else {
			extentReport.FAIL(driver, "JumpToLinks text validation",
					"ExpectedLink :" + expectedJumpToLinks + "/n" + "Actual Link :" + actualJumpToLinks);
			logERROR("JumpToLinks is incorrect, ExpectedLink :" + expectedJumpToLinks + "/n" + "Actual Link :"
					+ actualJumpToLinks);
		}
	}

	/**
	 * Click on desired jump to link and verify the header
	 * 
	 * @return
	 * @throws IOException
	 */
	public DrugInteractionsResultsPage clickOnJumpToLink() throws IOException {

		try {
			jumpToSelectedLinks.click();
			Thread.sleep(2000);
			extentReport.PASS("DI result Page Verification clickOnJumpToLink and verify result",
					"clickOnJumpToLink is working correctly");
			log.info("Verified desired drug- food interaction");

		} catch (Exception e) {
			extentReport.FAIL(driver, "DIResultPage", "clickOnJumpToLink method failed");
			logERROR("verify drug drug interaction method failed");

		}
		DrugInteractionsResultsPage page = PageFactory.initElements(driver, DrugInteractionsResultsPage.class);
		return page;

	}

	/**
	 * Scrolls up the vertical scroll bar,
	 * 
	 * @param y
	 *            - pass it to scroll down
	 */
	private void scrollUp(int y) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("scroll(" + y + ",0)");
	}

	/**
	 * Click on desired jump to link and verify the header
	 * 
	 * @return
	 * @throws IOException
	 */
	public DrugInteractionsHomePage clickModifyInteraction() throws IOException {

		try {
			scrollUp(250);
			modifyIntBtn.click();
			Thread.sleep(2000);
			extentReport.PASS("DI result Page Verification clickModifyInteraction and verify interaction page",
					"clickOnJumpToLink is working correctly");
			log.info("Verified clickModifyInteraction");
		} catch (Exception e) {
			extentReport.FAIL(driver, "DIResultPage", "clickModifyInteraction method failed");
			logERROR("clickModifyInteraction method failed");

		}
		DrugInteractionsHomePage dipage = PageFactory.initElements(driver, DrugInteractionsHomePage.class);
		return dipage;

	}

	public DrugInteractionsResultsPage clickDocBtn() throws IOException {

		try {
			refineDocBtn.click();
			extentReport.PASS("DI result Page Verification clickDocBtn", "clickDocBtn is working correctly");
			log.info("Verified click Document Button ");
			Thread.sleep(2000);
		} catch (Exception e) {
			extentReport.FAIL(driver, "DIResultPage", "clickDocBtn method failed");
			logERROR("clickDocBtn method failed");

		}
		DrugInteractionsResultsPage diResultPage = PageFactory.initElements(driver, DrugInteractionsResultsPage.class);
		return diResultPage;
	}

	public DrugInteractionsResultsPage clickDocUpdateBtn() throws IOException {

		try {
			docUpdateBtn.click();
			extentReport.PASS("DI result Page Verification clickDocUpdateBtn",
					"clickDocUpdateBtn is working correctly");
			log.info("Verified and clicked Document update Button ");
			Thread.sleep(2000);
		} catch (Exception e) {
			extentReport.FAIL(driver, "DIResultPage", "clickDocUpdateBtn method failed");
			logERROR("clickDocUpdateBtn method failed");

		}
		DrugInteractionsResultsPage diResultPage = PageFactory.initElements(driver, DrugInteractionsResultsPage.class);
		return diResultPage;
	}

	public DrugInteractionsResultsPage clickSeverityBtn() throws IOException {

		try {
			refineSeverityBtn.click();
			extentReport.PASS("DI result Page Verification clickSeverityBtn", "clickSeverityBtn is working correctly");
			log.info("Clicked severity Button ");
			Thread.sleep(2000);
		} catch (Exception e) {
			extentReport.FAIL(driver, "DIResultPage", "clickSeverityBtn method failed");
			logERROR("clickSeverityBtn method failed");

		}
		DrugInteractionsResultsPage diResultPage = PageFactory.initElements(driver, DrugInteractionsResultsPage.class);
		return diResultPage;
	}

	public DrugInteractionsResultsPage clickSeverityUpdateBtn() throws IOException {

		try {
			severityUpdateBtn.click();
			extentReport.PASS("DI result Page Verification clickSeverityUpdateBtn",
					"clickSeverityUpdateBtn is working correctly");
			log.info("Verified and clicked severity update Button ");
			Thread.sleep(2000);
		} catch (Exception e) {
			extentReport.FAIL(driver, "DIResultPage", "clickSeverityUpdateBtn method failed");
			logERROR("clickSeverityUpdateBtn method failed");

		}
		DrugInteractionsResultsPage diResultPage = PageFactory.initElements(driver, DrugInteractionsResultsPage.class);
		return diResultPage;
	}

	public DrugInteractionsResultsPage clickTypeBtn() throws IOException {

		try {
			refineTypeBtn.click();
			extentReport.PASS("DI result Page Verification clickTypeBtn", "clickTypeBtn is working correctly");
			log.info("Clicked Type  Button ");
			Thread.sleep(2000);
		} catch (Exception e) {
			extentReport.FAIL(driver, "DIResultPage", "clickTypeBtn method failed");
			logERROR("clickTypeBtn method failed");

		}
		DrugInteractionsResultsPage diResultPage = PageFactory.initElements(driver, DrugInteractionsResultsPage.class);
		return diResultPage;
	}

	public DrugInteractionsResultsPage clickTypeUpdateBtn() throws IOException {

		try {
			typeUpdateBtn.click();
			extentReport.PASS("DI result Page Verification clickTypeUpdateBtn",
					"clickTypeUpdateBtn is working correctly");
			log.info("Verified and clicked Type update Button ");
			Thread.sleep(2000);
		} catch (Exception e) {
			extentReport.FAIL(driver, "DIResultPage", "clickTypeUpdateBtn method failed");
			logERROR("clickTypeUpdateBtn method failed");

		}
		DrugInteractionsResultsPage diResultPage = PageFactory.initElements(driver, DrugInteractionsResultsPage.class);
		return diResultPage;
	}
	
 /**
  * 
  * 
  */
   public boolean verifyDrugNamesInDrugInteractionResultsPage(String drugUsedForSearch,
                                                              String labelText)
   {

      List<String> drugsExpectedToPresentInDIResultsPage;
      if (!labelText.contains("Here are the drug"))
      {
         drugsExpectedToPresentInDIResultsPage = Arrays.asList(drugUsedForSearch
               .toLowerCase().replace(" ", "").split(":"));
      }
      else
      {
         String[] labelName = labelText
               .split("Here are the drug interactions for ");
         String drugsWithInteraction[] = labelName[1].toLowerCase()
               .replace(" and ", ",").replace(":", "").replace(" ", "")
               .split(",");
         drugsExpectedToPresentInDIResultsPage = Arrays
               .asList(drugsWithInteraction);
      }
      Collections.sort(drugsExpectedToPresentInDIResultsPage);

      if (!("Drug Interaction Results".equals(drugInteractionsTitle.getText())))
      {
         return false;
      }

      List<String> drugsPresentinDI_ResultsPage = new ArrayList<>();
      if (refineDrugsBtn.getText().equals("All"))
      {
         refineDrugsBtn.click();
         for (WebElement drug : multipleDrugNameList)
         {
            drugsPresentinDI_ResultsPage
                  .add(drug.getText().toLowerCase().replace(" ", ""));
         }
         Collections.sort(drugsPresentinDI_ResultsPage);
      }
      if (!drugsExpectedToPresentInDIResultsPage
            .equals(drugsPresentinDI_ResultsPage))
      {
         return false;
      }
      return true;
   }
   
   public DrugInteractionsResultsPage clickPopDrugLink() {
  //  popDrugLink.click();
    drugDrugLink.click();
    DrugInteractionsResultsPage diResultPage = PageFactory.initElements(driver, DrugInteractionsResultsPage.class);
    return diResultPage;
   }

}