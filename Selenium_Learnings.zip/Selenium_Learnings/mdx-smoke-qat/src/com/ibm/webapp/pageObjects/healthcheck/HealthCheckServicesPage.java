package com.ibm.webapp.pageObjects.healthcheck;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class HealthCheckServicesPage extends Selenese {
	WebDriver driver;

	@FindBy(xpath = "//h2[contains(text(),'IBM')]")
	private WebElement servicePageHeader;

	@FindBy(xpath = "//*[@id='Health Check Status']//tbody/tr/td[1]")
	private List<WebElement> contentSetList;

	@FindBy(xpath = "//*[@id='Health Check Status']//tbody/tr//div/span")
	private List<WebElement> serviceStatusList;

	public HealthCheckServicesPage(WebDriver driver) throws IOException {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		try {
			wait.until(ExpectedConditions.visibilityOf(servicePageHeader));
			extentReport.PASS("Health Service", "Health service page header displayed");
		} catch (Exception e) {
			extentReport.FAIL(driver, "HealthCheckServicePage", "Page Header is not visible");
			log.error("Page Header is not visible in the HealthCheck service page");
		}

	}

	/**
	 * Call this method to verify service fail status
	 * 
	 * @return true = if Fail status in displayed
	 * @return false = if Pass status in displayed
	 * @throws IOException
	 * 
	 */

	public boolean checkServiceStatus() throws IOException {
		boolean flag = true;
		try {

			WebDriverWait wait = new WebDriverWait(this.driver, 20);
			wait.until(ExpectedConditions.visibilityOfAllElements(contentSetList));

			for (int i = 0; i <contentSetList.size(); i++) {

				String contentSetName = contentSetList.get(i).getText();
				String resultStatus = serviceStatusList.get(i).getAttribute("innerHTML");

				if (resultStatus.equalsIgnoreCase("Pass")) {
					logINFO(contentSetName + " = " + resultStatus);
				}

				if (resultStatus.equalsIgnoreCase("Fail")) {
					flag = false;
					logERROR(contentSetName + " = " + resultStatus);
					extentReport.FAIL(driver, contentSetName, resultStatus);
				}

			}

		}

		catch (Exception e) {
			extentReport.FAIL(driver, "HealthCheckService page", "Healthcheckservice is not working");

		}
		return flag;

	}

}
