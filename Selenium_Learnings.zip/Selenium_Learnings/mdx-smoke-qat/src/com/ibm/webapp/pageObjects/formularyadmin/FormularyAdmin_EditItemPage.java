package com.ibm.webapp.pageObjects.formularyadmin;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class FormularyAdmin_EditItemPage extends Selenese
{
   private final WebDriver driver;

   @FindBy(xpath = "//strong[contains(text(),'Edit Items')]")
   private WebElement editItemheader;

   @FindBy(id = "PFFormActionId_formularyadmin.EditItemsProductsForIdList")
   private WebElement selectBtn;

   @FindBy(name = "managementEditItems.editItemsList_index_0")
   private WebElement itemList;

   @FindBy(xpath = "//strong[contains(text(),'Formulary drug update was successful.')]")
   private WebElement saveSuccessMsg;

   @FindBy(id = "managementEditItems.costSymbolList_index_0")
   private WebElement relativecostDropDown;

   @FindBy(id = "managementEditItems.statusSelect_index_0")
   private WebElement tierDropdown;

   @FindBy(name = "managementEditItems.actualCost_index_0")
   private WebElement actualCostTxt;

   @FindBy(name = "managementEditItems.subNote_index_0")
   private WebElement therapTxt;

   @FindBy(id = "PFFormActionId_formularyadmin.EditItemsSaveProductUpdates")
   private WebElement saveChangedBtn;

   public FormularyAdmin_EditItemPage(WebDriver driver)
   {
      this.driver = driver;
      PageFactory.initElements(this.driver, this);
      WebDriverWait wait = new WebDriverWait(this.driver, 20);
      wait.until(ExpectedConditions.visibilityOf(editItemheader));
   }

   /**select a drug from the drop down under acetaminophen
    * 
    * @param drugName
    * @throws IOException 
    */
   public void selectItemFromList(String drugName) throws IOException
   {
      Select itemListdd = new Select(itemList);
      List<WebElement> listDrugs = itemListdd.getOptions();
      for (WebElement drug : listDrugs)
      {
         if (drug.getText().equalsIgnoreCase(drugName))
         {
            itemListdd.selectByValue(drug.getAttribute("value"));
            break;
         }
      }
     // selectBtn.click();
      click(driver, "select item from list", selectBtn);
   }

  
}
