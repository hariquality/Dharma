package com.ibm.webapp.pageObjects.formulary;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class Formulary_HomePage extends Selenese
{
   private final WebDriver driver;

   @FindBy(id = "formularyList_index_0")
   private WebElement formularySelectionBox;

   @FindBy(id = "PFFormActionId_formulary.Go")
   private WebElement btnGo;

   @FindBy(xpath = "//*[contains(text(),'Log Out')]")
   private WebElement logoutLink;

   public Formulary_HomePage(WebDriver driver)
   {
      this.driver = driver;
      PageFactory.initElements(this.driver, this);
      WebDriverWait wait = new WebDriverWait(this.driver, 20);
      wait.until(ExpectedConditions.visibilityOf(formularySelectionBox));
   }

   public void selectFormulary(String term)
   {
      Select defaultDD = new Select(formularySelectionBox);
      defaultDD.selectByVisibleText(term);
      btnGo.click();
   }

   public void LogOut() throws IOException
   {
      click(driver, "LOGOUT", logoutLink);
   }

   /**
    * Use this method to verify if Formulary Home Page is displayed,
    * 
    * @throws IOException
    */
   public void isHomePageDisplayed() throws IOException
   {
      try
      {
         if (driver.getTitle().equalsIgnoreCase("Formulary : Search"))
         {
            extentReport.PASS("Formulary Home Page Verification",
                              "Formulary Home Page is displayed correctly");
         }
         else
         {
            extentReport.FAIL(driver,
                              "Formulary Home Page Verification",
                              "Formulary Home Page is not displayed");
         }
      }
      catch (Exception e)
      {
         extentReport
               .FAIL(driver,
                     "Formulary Home Page Verification",
                     "Formulary Home Page is not displayed- Some Exception occured");
      }
}}
