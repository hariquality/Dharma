package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class RedBookPage extends Selenese {
	private final WebDriver driver;

	@FindBy(id = "WordWheel_SearchTerm_index_0")
	private WebElement redbookSearchBox;

	@FindBy(xpath = "//div[@id='WordWheel_list']/div")
	private List<WebElement> termInWordWheel;

	@FindBy(id = "rbSubmitBtn")
	private WebElement submitButton;

	public RedBookPage(WebDriver driver) throws IOException {

		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		try {
			wait.until(ExpectedConditions.visibilityOf(redbookSearchBox));
		} catch (Exception e) {
			extentReport.FAIL(driver, "RedBook Page Display", "RedBook Page is not displayed");
			log.error("RedBook Page is not displayed");
		}
	}

	/**
	 * Use this method to enter the drug name into search box
	 * 
	 * @param searchInput
	 *            = Pass the drug name into the search box
	 * @return to RedBookPage
	 * @throws IOException
	 */
	public RedBookPage typeCharsIntoSearchBox(String searchInput) throws IOException {
		try {
			sendKeys(driver, "Search box", redbookSearchBox, searchInput);
			Thread.sleep(1000);

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		RedBookPage rbPage = PageFactory.initElements(driver, RedBookPage.class);
		return rbPage;
	}

	/**
	 * Use this method to click on submit button and navigate into red book
	 * search results page
	 * 
	 * @return to RedBookSearchResultsPage
	 * @throws IOException
	 */
	public RedBookSearchResultsPage clickSubmitButton() throws IOException {
		try {
			Thread.sleep(3000);
			submitButton.click();
			// click(driver, "Submit button", submitButton);
			extentReport.PASS("Click on submit button", "Submit button is clicked in Redbook page");

		} catch (Exception e) {
			e.printStackTrace();
			extentReport.FAIL(driver, "Click on submit button", "Submit button is notclicked in Redbook page");
		}
		RedBookSearchResultsPage rbSearchResultsPage = PageFactory.initElements(driver, RedBookSearchResultsPage.class);
		return rbSearchResultsPage;
	}

	/**
	 * Use this method to Single click on the passed drug name from word wheel
	 * 
	 * @param term
	 *            = Pass the drug name
	 * @return to RedBookPage
	 * @throws IOException
	 */
	public RedBookPage singleClickTermInWordWheel(String term) throws IOException {
		Iterator<WebElement> it = termInWordWheel.iterator();
		try {
			while (it.hasNext()) {
				WebElement elem = it.next();
				if (term.contentEquals(elem.getAttribute("fullname"))) {
					click(driver, "Single click on " + elem.getText(), elem);
					break;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		RedBookPage rbPage = PageFactory.initElements(driver, RedBookPage.class);
		return rbPage;
	}

	/**
	 * Use this method to double click on the passed drug name from word wheel
	 * 
	 * @param term
	 *            = Pass the drug name
	 * @return to RedBookSearchResultsPage
	 * @throws IOException
	 */

	public RedBookSearchResultsPage doubleClickTermInWordWheel(String term) throws IOException {
		Iterator<WebElement> it = termInWordWheel.iterator();
		try {
			while (it.hasNext()) {
				WebElement elem = it.next();
				if (term.contentEquals(elem.getAttribute("fullname"))) {
					Actions action = new Actions(this.driver);
					action.doubleClick(elem);
					action.perform();
					break;
				}
				extentReport.PASS("Double click on Drug name", "Double click action is performed on " + term);
				log.info("Double click action is performed on " + term);
			}

		} catch (Exception e) {
			extentReport.FailWithException(driver, "Double click on Drug name",
					"Double click action is not performed on " + term, e);
			logERROR("Double click action is not performed on " + term, e);
		}
		RedBookSearchResultsPage rbPage = PageFactory.initElements(driver, RedBookSearchResultsPage.class);
		return rbPage;
	}

}