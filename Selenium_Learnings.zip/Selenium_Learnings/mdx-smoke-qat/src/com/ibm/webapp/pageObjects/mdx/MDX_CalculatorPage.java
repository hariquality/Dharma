package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class MDX_CalculatorPage extends Selenese {
	private final WebDriver driver;

	@FindBy(id = "calcTitle")
	private WebElement calculatorTitle;

	@FindBy(xpath = "//a[contains(text(),'Alcohols/Ethylene Glycol Blood Level')]")
	private WebElement alcoholEthyl;

	@FindBy(xpath = "//a[contains(text(),'Norepinephrine Dosing Calculator - Pediatric')]")
	private WebElement norepinephrinePediatric;

	@FindBy(xpath = "//a[contains(text(),'Body Mass Index Calculator')]")
	private WebElement bmiCalc;

	@FindBy(id = "hcs.calculator.patientWeightValue_index_0")
	private WebElement patientWeight;

	@FindBy(id = "hcs.calculator.bodyLengthValue_index_0")
	private WebElement patientHeight;

	@FindBy(id = "hcs.calculator.amountValue_index_0")
	private WebElement amountIngested;

	@FindBy(xpath = "//input[@value='lb']")
	private WebElement lbs;

	@FindBy(id = "hcs.calculator.solutionValue_index_0")
	private WebElement percentInput;

	@FindBy(xpath = "//input[@name = 'hcs.calculator.solutionUnit_index_0' and @value='proof']")
	private WebElement proof;

	@FindBy(xpath = "//input[@name = 'hcs.calculator.bodyLengthUnit_index_0' and @value='in']")
	private WebElement inches;

	@FindBy(id = "PFFormActionId_calc.BloodLevel.DoCalc")
	private WebElement submitBtn;

	@FindBy(xpath = "//*[@id='calculator']/table//tr[2]//table//td[@align='center'][@class='highlight']")
	private WebElement verifyText;

	@FindBy(xpath = "//*[@id=\"mainActionForm\"]/table/tbody/tr[1]/td/a[2]")
	private WebElement closeFrame;

	@FindBy(xpath = "//td[@valign='top'][@class='highlight']")
	private WebElement verifyText1;

	@FindBy(id = "PFFormActionId_calc.Drugs.calc.PediatricNorepinephrineDosing.Calculate")
	private WebElement submitNorEpinephrinePediatricBtn;

	@FindBy(id = "PFFormActionId_calc.BodyMassIndex.DoCalc")
	private WebElement submitBmiBtn;

	@FindBy(xpath = "//*[@id='calculator']/table//td[@class='highlight']")
	private WebElement verifyText2;

	public MDX_CalculatorPage(WebDriver driver) throws IOException {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		try {
			wait.until(ExpectedConditions.visibilityOf(calculatorTitle));
		} catch (Exception e) {
			extentReport.FAIL(driver, "Calculator Page Display", "Calculator Page is not displayed");
			log.error("Calculator Page is not displayed");
		}
	}

	public void alcEthyleneGlycolBloodLevel() throws IOException, InterruptedException {
		click(driver, "Alcohols/Ethylene Glycol Blood Level", alcoholEthyl);
		Thread.sleep(1000);
		driver.switchTo().frame(0);
		sendKeys(driver, "Patient Weight", patientWeight, "140");
		click(driver, "Patient weight", lbs);
		sendKeys(driver, "Amount ingested", amountIngested, "240");
		sendKeys(driver, "Percent", percentInput, "90");
		click(driver, "proof", proof);
		click(driver, "submit", submitBtn);
		String actualResult = verifyText.getText();
		if (actualResult.equals("Potential blood level of 253   mg/dL   ( 54.9   mmol/L )")) {
			extentReport.PASS("alcEthyleneGlycolBloodLevel Validation", "results are correct");
		} else {
			extentReport.FAIL(driver, "alcEthyleneGlycolBloodLevel Validation",
					"results are incorrect: " + "ActualResult: " + actualResult + ","
							+ "Expected Result: Potential blood level of 253   mg/dL   ( 54.9   mmol/L )");
		}
		closeFrame.click();
	}

	public void norepinephrinePediatric() throws IOException, InterruptedException {
		click(driver, "Norepinephrine - Pediatric", norepinephrinePediatric);
		Thread.sleep(1000);
		driver.switchTo().frame(0);
		sendKeys(driver, "Patient Weight", patientWeight, "15");
		click(driver, "submit", submitNorEpinephrinePediatricBtn);
		String actualResult = verifyText1.getText();
		if (actualResult.equals("Dose Calculation Results:")) {
			extentReport.PASS("norepinephrinePediatric", "results are correct");
		} else {
			extentReport.FAIL(driver, "norepinephrinePediatric",
					"results are incorrect: " + "ActualResult: " + actualResult + ","
							+ "Expected Result: Dilute 1 mL (1 mg) norepinephrine bitartrate (Levophed�) in "
							+ "250 mL D5W or D5% in saline and infuse at a rate of 11.3 mL/hr (microdrops/min).");
		}

		closeFrame.click();
	}

	public void bmiCalculator() throws IOException, InterruptedException {
		click(driver, "Body Mass Index Calculator", bmiCalc);
		Thread.sleep(1000);
		driver.switchTo().frame(0);
		sendKeys(driver, "Patient Weight", patientWeight, "100");
		sendKeys(driver, "Patient Height", patientHeight, "50");
		click(driver, "inches", inches);
		click(driver, "submit", submitBmiBtn);
		String actualResult = verifyText2.getText();
		if (actualResult.equals("Body Mass Index Results:  62")) {
			extentReport.PASS("BMI calculator", "BMI results are correct");
		} else {
			extentReport.FAIL(driver, "BMI calculator", "BMI results are incorrect: " + "ActualResult: " + actualResult
					+ "," + "Expected Result: Body Mass Index Results:  62");
		}
		closeFrame.click();
	}

}
