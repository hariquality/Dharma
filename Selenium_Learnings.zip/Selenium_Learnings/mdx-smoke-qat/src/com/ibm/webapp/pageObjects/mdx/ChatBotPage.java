package com.ibm.webapp.pageObjects.mdx;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class ChatBotPage extends Selenese {
	public WebDriver driver;

	public WebDriverWait _webDriverwait;

	private List<String> _resultsListToWrite = null;

	private static final String NA = "NA";

	private static final String NO = "No";

	private static final String YES = "yes";

	private static final String POSITIVE = "Positive";

	private static final String NEGATIVE = "Negative";

	private static final String QUICK_ANSWERS = "Quick";

	private static final String IN_DEPTH_ANSWERS = "InDepth";

	private static final String QUICK = "Quick";

	private static final String INDEPTH = "InDepth";

	private static final String DONOTCONFUSE = "Do Not Confuse";

	private static final String CHAT_WINDOW_WATERMARK_TEXT = "Type a quick question...";

	private static final String TYPE_SOMETHING = "Type something...";

	private static final String FEEDBACK_POSITIVE = "Thank you for your feedback.";

	private static final String FEEDBACK_NEGATIVE = "I'm sorry I am not able to answer your question. Can you tell me what information you were expecting?";

	private static final String STATUS_PASS = "PASS";

	public static final String STATUS_FAIL = "FAIL";

	private static String _resultStatus = STATUS_PASS;

	private static final String PEDIATRIC_SECTION = "Pediatric Dosing";

	private static final String ADULT_SECTION = "Adult Dosing";

	private static final String IBM_WELCOME_MESSAGE = "Hello! What can I help you find?";

	private static final String IBM_CHATWINDOW_TITLENAME = "IBM Micromedex Watson Assistant";

	private static final String FEEDBACK_LABEL = "Was this helpful?";

	private static final String CONTRAINDICATIONS = "Contraindications";

	private static final String PRECAUTIONS = "Precautions";

	@FindBy(xpath = "//div[@id='watsonNavigateBtn']/img")
	private WebElement chatArrowIcon;

	@FindBy(xpath = "//div[@class='chatResponse highlightResponse']/div/a")
	private WebElement clickMoreHighlighted;

	@FindBy(xpath = "//div[@id='collapseDiv']/span")
	private WebElement askWatsonBubble;

	@FindBy(xpath = "//div[@class='chatbox-contentpane']//div[@class='chatResponse highlightResponse']")
	private WebElement chatResponseHighlighted;

	@FindBy(xpath = "//div[@class='chatResponse highlightResponse']/div/a[contains(text(),'In-Depth')]")
	private WebElement inDepthAnswersChatLink;

	@FindBy(id = "watsonSearchInput")
	private WebElement chatBot_searchInput;

	@FindBy(id = "watsonLogo")
	private WebElement chatBot_icon;

	@FindBy(xpath = "//div[@id='loadingImage'][@class='no_background_Image']")
	private List<WebElement> loadingImageList;

	@FindBy(id = "mdxChatBotDiv")
	private WebElement chatBot;

	@FindBy(xpath = "//div[@class='chatResponse highlightResponse']//a")
	private List<WebElement> askWatsonExampleLinks;

	@FindBy(id = "chatbotTextInput")
	private WebElement chatBot_inputPoint;

	@FindBy(xpath = "//div[@id='chatHead']//span[@class='chatTitle']")
	private WebElement chatBotTitle;

	@FindBy(xpath = "//div[@class='chatResponse highlightResponse']/div/a[contains(text(),'Quick Answers')]")
	private WebElement quickAnswersChatLink;

	@FindBy(xpath = "//div[@class='chatbox-contentpane']//div[@class='chatResponse highlightResponse']")
	private List<WebElement> chatResponseHighlightedList;

	@FindBy(id = "feedback-label")
	private WebElement feedbackLabel;

	@FindBy(xpath = "//*[@id='chatbox-contentpane']/div[5]/text()")
	private WebElement positivefeedbackLabel;

	@FindBy(xpath = "//*[@id='chatbox-contentpane']/div[3]")
	private WebElement negativefeedbackLabel;

	@FindBy(id = "chatThumbsUp")
	private WebElement chatThumbsUp;

	@FindBy(id = "chatThumbsDown")
	private WebElement chatThumbsDown;

	@FindBy(xpath = "//div[@class='context-filter']")
	private List<WebElement> contextManagerForFilters;

	@FindBy(id = "chatCloseIcon")
	private WebElement chatBotWindowCloseIcon;

	@FindBy(xpath = "//div[@class='chatResponse highlightResponse']//ul/li/a")
	private List<WebElement> chatResponsePickList;

	@FindBy(id = "okButton")
	private WebElement button_Ok;

	@FindBy(id = "cancelButton")
	private WebElement button_Close;

	private int _intialCountOfResponse;

	/**
	 * Default Constructor for chatbotwindow class
	 * 
	 * @throws IOException
	 */
	public ChatBotPage(WebDriver driver) throws IOException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		WebDriverWait wait = new WebDriverWait(driver, 20);
		try {
			wait.until(ExpectedConditions.visibilityOf(chatArrowIcon));
		} catch (Exception e) {
			extentReport.FAIL(driver, "ChatBotUIPage", "Chat Arrow icon is not visible");
			logERROR("Chat Arrow icon  is not visible in the MDX home page");
		}
	}

	/**
	 * Constructor overloading is done, since in other mdx pages(except Home
	 * page) chaticon will not be present, as askwatson will be located at the
	 * bottom of the page
	 * 
	 * @param driver
	 * @param otherLandingPage
	 *            (set true or false) , if this constructor has to be invoked in
	 *            other landing pages
	 * @throws IOException
	 */
	public ChatBotPage(WebDriver driver, boolean otherLandingPage) throws IOException {
		this.driver = driver;
		if (driver.getCurrentUrl().contains("micromedexsolutions.com")) {
			PageFactory.initElements(driver, this);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			try {
				wait.until(ExpectedConditions.visibilityOf(askWatsonBubble));
			} catch (Exception e) {
				extentReport.FAIL(driver, "ChatBotUIPage", "askWatsonBubble is not visible");
				logERROR("askWatsonBubble  is not visible in the MDX home page");
			}
		}
	}

	/**
	 * Search bar focus and water mark text in Home page captured
	 * 
	 * @throws IOException
	 */
	public void homePageSearchBarFocus() throws IOException {
		try {
			assertTrue(chatBot_searchInput.getAttribute("value").equals(CHAT_WINDOW_WATERMARK_TEXT),
					"AskWatson WaterMark text is not present in the HomePage");
			extentReport.PASS("ChatBot Page Verification homePageSearchBarFocus",
					"homePageSearchBarFocus is working correctly");
			log.info("Verified homePageSearchBarFocus");
		} catch (Exception e) {
			extentReport.FAIL(driver, "ChatBotUIPage", "Default cursor is not present");
			logERROR("EXCEPTION:: Default Cursor is not present in the HomePage search bar");
		}

	}

	/**
	 * To click the home page chat icon
	 * 
	 * @throws IOException
	 */
	public void clickHomePageChatIcon() throws IOException {
		try {

			WebDriverWait wait = new WebDriverWait(this.driver, 20);
			wait.until(ExpectedConditions.visibilityOf(chatBot_icon));
			chatBot_icon.click();
			Thread.sleep(2000);
			extentReport.PASS("ChatBot Page Verification clickHomePageChatIcon",
					"clickHomePageChatIcon is working correctly");
			log.info("Verified clickHomePageChatIcon");
			while (!isChatWindowOpened("block")) {
				chatBot_icon.click();
				Thread.sleep(1000);
			}
			ajaxCallComplete();

		} catch (Exception e) {
			extentReport.FAIL(driver, "ChatBotUIPage", "askWatsonIcon is not visible");
			logERROR("Chat Icon is not clickable in the HomePage");
		}

	}

	/**
	 * verifies chat window is opened or not
	 * 
	 * @return true if chat window is opened
	 * @throws IOException
	 */
	public boolean isChatWindowOpened(String chatWindowStyleAttribute) throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(this.driver, 20);
			wait.until(ExpectedConditions.visibilityOf(chatBot));
			boolean isChatWindowOpenedClosed = false;
			String askWatsonStyle = chatBot.getAttribute("style");
			if (askWatsonStyle.contains(chatWindowStyleAttribute)) {
				isChatWindowOpenedClosed = true;
			}
			return isChatWindowOpenedClosed;
		} catch (Exception e) {
			extentReport.FAIL(driver, "ChatBotPage", "verify chat window is opened or not");
			logERROR("Chat window is not opened in the HomePage");
		}
		return false;
	}

	/**
	 * verifies the last sample anchor tag is formed in chat window when a new
	 * chat window is opened
	 * 
	 * @return true if chat window is opened
	 * @throws IOException
	 */
	public boolean ajaxCallComplete() throws IOException {
		try {

			boolean flag = false;
			WebDriverWait wait = new WebDriverWait(this.driver, 20);
			wait.until(ExpectedConditions.visibilityOfAllElements(askWatsonExampleLinks));
			List<WebElement> sampleLinks = askWatsonExampleLinks;
			int i = 0;
			while (i < 3) {
				if (sampleLinks.size() == 8) {
					flag = true;
					break;
				}
				sampleLinks = askWatsonExampleLinks;
				i++;
			}
			return flag;
		} catch (Exception e) {
			extentReport.FAIL(driver, "ChatBotUIPage", "verify last opened chat is present or not");
			logERROR("previous window is opened in the HomePage");
		}
		return false;
	}

	/**
	 * Verifies the Welcome Message & PlaceHolder Text in the chat window
	 * present in the HomePage
	 * 
	 * @throws IOException
	 */
	public void checkDefaultTextinChatWindow() throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(this.driver, 20);
			wait.until(ExpectedConditions.visibilityOf(chatBot_inputPoint));
			assertTrue(chatBot_inputPoint.getAttribute("placeholder").equals(TYPE_SOMETHING),
					"Type something text is not displayed in the chatwindow");

			assertTrue(getChatResponseTitle(0).equals(IBM_WELCOME_MESSAGE), "Welcome message is incorrect");
			assertTrue(chatBotTitle.getText().equals(IBM_CHATWINDOW_TITLENAME),
					"ChatBot Window Title Name is incorrect");
			extentReport.PASS("ChatBot Page Verification checkDefaultTextinChatWindow",
					"checkDefaultTextinChatWindow is working correctly");
			log.info("Verified checkDefaultTextinChatWindow");
		} catch (Exception e) {
			extentReport.FAIL(driver, "ChatBotUIPage",
					"verify default text in chat window, welcome message is not present");
			logERROR("default text and welcome message are not present in the HomePage");
		}
	}

	/**
	 * Gets the label text or any other chat response highlighted currently in
	 * the chat window
	 * 
	 * @throws IOException
	 */
	private String getChatResponseTitle(int responseHeaderOrder) throws IOException {
		String content = null;
		try {
			if (waitUntilChatResponse()) {
				Thread.sleep(1000);
				String script = "return document.getElementsByClassName('chatResponse highlightResponse')[0].childNodes["
						+ responseHeaderOrder + "].textContent";
				JavascriptExecutor js = (JavascriptExecutor) driver;
				content = (String) js.executeScript(script);
				log.info("ChatResponse : " + content.replaceAll("\n", "").trim());
			}

			else {
				logERROR("chat window Input Point is Clickbale");
			}
		} catch (Exception e) {
			extentReport.FAIL(driver, "ChatBotUIPage", "verify the user query and chat response");
			logERROR("Label text is incorrect for the user query or chat response is not displayed");
		}

		return content.replaceAll("\n", "").trim();

	}

	/**
	 * Verify the highlighted content in the chat window
	 * 
	 * @throws IOException
	 */
	public boolean waitUntilChatResponse() throws IOException {
		boolean flag = false;
		try {
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfAllElements(chatResponseHighlightedList));
			List<WebElement> highlightedChatContent = chatResponseHighlightedList;
			int i = 0;
			while (i < 3) {
				if (!highlightedChatContent.isEmpty()) {
					flag = true;
					break;
				}
				highlightedChatContent = chatResponseHighlightedList;
				i++;
			}
			if (highlightedChatContent.isEmpty()) {
				flag = false;
				logERROR("There is no response from the chatWindow");
			}
		} catch (Exception e) {
			extentReport.FAIL(driver, "ChatBotPage", "verify the user query and chat response");
			logERROR("There is no response from the chatWindow");
			flag = false;
			log.info("\n");
		}
		return flag;

	}

	/**
	 * Verify the Feed back text and links
	 * 
	 * @throws IOException
	 */
	public boolean verifyTextForFeedbackAndLinks() throws IOException {
		boolean flag = true;
		try {
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOf(chatBot_inputPoint));

			assertTrue(feedbackLabel.getText().equals(FEEDBACK_LABEL), "Feedback label is incorrect");
			extentReport.PASS("ChatBot Page Verification verifyTextForFeedbackAndLinks",
					"verifyTextForFeedbackAndLinks is working correctly");
			log.info("Verified verifyTextForFeedbackAndLinks");
		} catch (Exception e) {
			extentReport.FAIL(driver, "ChatBotUIPage", "The Feed back label is correct or incorrect");
			logERROR("Feedback label is incorrect");
			flag = false;
			log.info("\n");
		}
		return flag;
	}

	/**
	 * Verify the feed back response by clicking the positive and negative feed
	 * back
	 * 
	 * @throws IOException
	 */
	public void verifyPositiveFeedback() throws IOException {
		try

		{

			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOf(chatThumbsUp));
			chatThumbsUp.click();
			Thread.sleep(2000);
			assertTrue(positivefeedbackLabel.getText().equals(FEEDBACK_POSITIVE), "Feedback label is incorrect");
			extentReport.PASS("ChatBot Positive feedback label Verification",
					"Positive feedback label displayed correctly");
			log.info("Positive feedback label displayed correctly");
			waitUntilChatResponse();
			Thread.sleep(2000);
		} catch (Exception e) {
			extentReport.FAIL(driver, "ChatBotUIPage", "There is no Positive response from the chatWindow");
			logERROR("There is no positive response from the chatWindow");

		}

	}

	public void verifyNegativeFeedback() throws IOException {
		try

		{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOf(chatThumbsDown));
			chatThumbsDown.click();
			Thread.sleep(2000);
			assertTrue(negativefeedbackLabel.getText().equals(FEEDBACK_NEGATIVE), "Feedback label is incorrect");
			extentReport.PASS("ChatBot Negative Feedback label Verification",
					"Negative feedback label displayed correctly");
			log.info("Negative feedback label displayed correctly");
			waitUntilChatResponse();
			Thread.sleep(2000);
		} catch (Exception e) {
			extentReport.FAIL(driver, "ChatBotUIPage", "There is no Negative response from the chatWindow");
			logERROR("There is no Negative response from the chatWindow");

		}
	}

	/**
	 * Types user's search query in the chat window and waits until the chat
	 * response is displayed
	 * 
	 * @throws IOException
	 */
	public Boolean searchQueryInChatWindowUI(String searchQuery) throws IOException {
		Boolean result = true;
		try {

			{
				chatBot_inputPoint.clear();
				List<WebElement> numberOfResponses = driver.findElements(By.className("chatResponse"));
				_intialCountOfResponse = numberOfResponses.size();
				// added a string message to record this message in logs
				chatBot_inputPoint.sendKeys(searchQuery + " ######THISISATESTQUERYPLEASEIGNORE######" + Keys.RETURN);
				log.info("UserInputQuery :" + searchQuery);
				extentReport.PASS("ChatBotPage", "Getting response from Chat window");
				log.info("Getting response for search keyword entered");
			}

		} catch (Exception e) {
			extentReport.FAIL(driver, "ChatBotUIPage", "There is no response from the chatWindow");
			logERROR("There is no response from the chatWindow");
			result = false;
		}
		return result;

	}

	/**
	 * Gets the List of Filter Values added to the Chat Window filters and
	 * returns the values in a List.
	 * 
	 * @throws IOException
	 */
	public List<String> getFilterNames() throws IOException {
		List<String> getDrugNamesAddedToTheFilter = new ArrayList<>();
		for (WebElement filterValue : contextManagerForFilters) {
			String filterNamesAddedinChatWindow = filterValue.getText();
			getDrugNamesAddedToTheFilter.add(filterNamesAddedinChatWindow);
		}
		return getDrugNamesAddedToTheFilter;
	}

	/**
	 * Clicks the arrow icon present in the mdx HomePage
	 * 
	 * @throws IOException
	 */
	public void clickArrowIcon() throws IOException {
		try {
			if (isWelcomeMessageDisplayed()) {
				_webDriverwait.until(ExpectedConditions.elementToBeClickable(chatBot_icon));
				chatBot_icon.click();
			}
		} catch (Exception e) {
			extentReport.FAIL(driver, "ChatBotUIPage", "Arrow Icon is not clickable in the HomePage");
			logERROR("EXCEPTION:: Arrow Icon is not clickable in the HomePage");

		}

	}

	/**
	 * verifies chat window is opened or not
	 * 
	 * @return true if chat window is opened
	 * @throws IOException
	 */
	public boolean isWelcomeMessageDisplayed() throws IOException {
		try {
			Boolean flag = false;
			int i = 0;
			while (i < 10) {
				i++;
				if (IBM_WELCOME_MESSAGE.equals(getChatResponseTitle(0)))
					extentReport.PASS("ChatBotPage - welcome message displayed", "welcome message displayed");
				log.info("welcome message displayed");
				{
					flag = true;
					break;
				}
			}
			return flag;
		} catch (Exception e) {
			extentReport.FAIL(driver, "ChatBotUIPage", "Welcome message not displayed in the HomePage");
			logERROR("Welcome message not displayed in the HomePage");

		}
		return false;
	}

	/**
	 * Closes chat window present in the HomePage or any other MDX-Application
	 * Pages
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public boolean closeChatWindow() throws IOException, InterruptedException {
		boolean flag = true;
		try {
			Thread.sleep(2000);
			chatBotWindowCloseIcon.click();
			// while (!isChatWindowOpened("none"))
			// {
			// chatBotWindowCloseIcon.click();
			// }
		}

		catch (Exception e) {
			extentReport.FAIL(driver, "ChatBotUIPage",
					"Chat window is not closed as expected or close icon is not present for the chatwindow");
			logERROR("Chat window is not closed as expected or close icon is not present for the chatwindow");
			flag = false;
			searchQueryInChatWindow("clear");
		}

		return flag;
	}

	/**
	 * Logic for verifying the common section in Watson ChatBot
	 * 
	 * @param rowList
	 * @return
	 * @throws InterruptedException
	 * @throws IOException
	 */

	public List<String> logicForCommonSection(List<List<String>> _rowList) throws InterruptedException, IOException {
		_resultsListToWrite = new ArrayList<String>();
		for (List<String> columnList : _rowList) {
			if (!searchQueryInChatWindow(columnList.get(0))) {
				fail();
			} else if (!selectSalt(columnList.get(1))) {
				fail();
			} else if (columnList.get(3).equalsIgnoreCase("NA") && columnList.get(4).equalsIgnoreCase("NA")) {
				if (verifyChatLabel(columnList.get(2), 0))
					pass();
				else
					fail();
			}

			else if (columnList.get(3).equals(NA) && !columnList.get(4).equals(NA)) {
				if (clickUserNavigationLinkinWatsonAssistant(IN_DEPTH_ANSWERS, columnList.get(5)))
					pass();
				else
					fail();
			} else if (!verifyChatLabelandLink(columnList.get(2), 0, columnList.get(3), columnList.get(4))) {
				fail();
			}

			else {
				if (!columnList.get(3).equals(NA)
						&& clickUserNavigationLinkinWatsonAssistant(QUICK_ANSWERS, columnList.get(5))) {
					clickUserNavigationLinkinWatsonAssistant(QUICK_ANSWERS, columnList.get(5));

					List<String> chatResponseContentList = getChatResponseContent(columnList.get(3));
					List<String> landingPageSectionContentList = paraContentfromDrugLandingPage();
					_resultStatus = compareBothListContent(chatResponseContentList, landingPageSectionContentList);
					if (!columnList.get(4).equals(NA) && _resultStatus.equals(STATUS_PASS)
							&& !clickUserNavigationLinkinWatsonAssistant(IN_DEPTH_ANSWERS, columnList.get(5))) {
						_resultStatus = STATUS_FAIL;
					}
					writeResultsAndCloseChatWindow(_resultStatus);
				} else
					fail();
				log.info("\n");
			}
		}
		return _resultsListToWrite;
	}

	/**
	 * Logic for logicForIVCompatibility
	 * 
	 * @param rowList
	 * @return
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public List<String> logicForIVCompatibility(List<List<String>> _rowList) throws InterruptedException, IOException {
		_resultsListToWrite = new ArrayList<String>();
		for (List<String> columnList : _rowList) {
			if (!searchQueryInChatWindow(columnList.get(0))) {
				fail();
				continue;
			}

			if (!columnList.get(1).equalsIgnoreCase(NO) && !selectSalt(columnList.get(1))) {
				fail();
				continue;
			}
			if (columnList.get(3).equalsIgnoreCase(NA)) {
				if (verifyChatLabel(columnList.get(2), 0)) {
					pass();
					continue;
				} else {
					fail();
					continue;
				}
			}
			if (!verifyChatLabel(columnList.get(2), 0)) {
				fail();
				continue;
			}
			if (!columnList.get(12).contains(NO)) {
				IvCompatibilityResultsPage ivSingleResultsPage = (IvCompatibilityResultsPage) getIVCompatibilityResultPage(
						columnList.get(4));
				if (ivSingleResultsPage == null) {
					fail();
					continue;
				}
				_resultStatus = ivSingleResultsPage.verifySingleIVCompatibilityName(columnList.get(2));
				writeResultsAndCloseChatWindow(_resultStatus);
			}

			else {
				IvCompatibilityResultsPage ivMultipleResultsPage = (IvCompatibilityResultsPage) getIVCompatibilityResultPage(
						columnList.get(12));
				if (ivMultipleResultsPage == null) {
					fail();
					continue;
				}
				if (verifyDrugFilterAddedForDIandIV(columnList.get(4), getFilterNames()) && ivMultipleResultsPage
						.verifyDrugNamesInIVCompatibilityResultsPage(columnList.get(4), columnList.get(2))) {
					if (!columnList.get(5).equalsIgnoreCase(NA)) {
						if (!searchQueryInChatWindow(columnList.get(5))) {
							fail();
							continue;
						}
						if (columnList.get(6).equalsIgnoreCase(NO) && !selectSalt(columnList.get(6))) {
							fail();
							continue;
						}

						else if (columnList.get(8).equalsIgnoreCase("NA") && columnList.get(9).equalsIgnoreCase("NA")) {
							if (verifyChatLabel(columnList.get(7), 0))
								_resultStatus = STATUS_PASS;
							else
								fail();
						}
						if (!verifyChatLabelandLink(columnList.get(7), 0, columnList.get(8), columnList.get(9))) {
							fail();
							continue;
						}

						else if (columnList.get(8).equals(NA) && !columnList.get(9).equals(NA)) {
							if (clickUserNavigationLinkinWatsonAssistant(IN_DEPTH_ANSWERS, columnList.get(11)))
								_resultStatus = STATUS_PASS;
							else
								fail();
						}

						else if (!columnList.get(8).equals(NA)
								&& clickUserNavigationLinkinWatsonAssistant(QUICK_ANSWERS, columnList.get(11))) {
							_resultStatus = STATUS_PASS;

							if (_resultStatus.equals(STATUS_PASS) && !columnList.get(9).equals(NA)
									&& !clickUserNavigationLinkinWatsonAssistant(IN_DEPTH_ANSWERS,
											columnList.get(11))) {
								fail();
							}
						}
						List<String> filterNamesPresentInChatWindow = getFilterNames();
						if (columnList.get(10).contains(":")) {
							if (filterNamesPresentInChatWindow
									.contains(columnList.get(10).substring(0, columnList.get(10).indexOf(":")))
									&& filterNamesPresentInChatWindow.contains(columnList.get(10).substring(
											columnList.get(10).indexOf(":") + 1, columnList.get(10).lastIndexOf(":")))
									&& filterNamesPresentInChatWindow.contains(
											columnList.get(10).substring(columnList.get(10).lastIndexOf(":") + 1))) {

								writeResultsAndCloseChatWindow(_resultStatus);
							}
						} else {
							if (!filterNamesPresentInChatWindow.contains(columnList.get(10))) {
								fail();
							} else {
								writeResultsAndCloseChatWindow(_resultStatus);
							}
						}

					} else {
						pass();
					}
				}

				else {
					fail();
				}
			}

			log.info("\n");
		}

		return _resultsListToWrite;

	}

	/**
	 * call this method to invoke the IvCompatibilitySingleResultsPage
	 * 
	 * @return IvCompatibilitySingleResultsPage.class or
	 *         IvCompatibilityResultsPage.class
	 * @throws InterruptedException
	 */
	private Object getIVCompatibilityResultPage(String drugNameUsed) throws InterruptedException {
		Object ivPage = null;
		try {
			clickMoreHighlighted.click();
			if (!drugNameUsed.equalsIgnoreCase(NO)) {
				ivPage = PageFactory.initElements(driver, IvCompatibilityResultsPage.class);
			} else {
				ivPage = PageFactory.initElements(driver, IvCompatibilityResultsPage.class);
			}
		} catch (Exception e) {
			if (e instanceof RuntimeException) {
				// Occurs when blank page is displayed in the MDX application
				e.printStackTrace();
				logERROR("IV page is not displayed in MDX application page");
			}
		}
		return ivPage;
	}

	/**
	 * selects link present in the chat response. usually links will be
	 * displayed for partial Drugs or Partial conditions
	 * 
	 * @param Partial
	 *            drug selection or partial condition selection
	 * @throws IOException
	 */
	private boolean selectSalt(String selectSalt) throws IOException {
		boolean result = true;
		String pickListType = null, pickListname = selectSalt;
		if (selectSalt.contains(":")) {
			pickListname = selectSalt.substring(0, selectSalt.lastIndexOf(":"));
			pickListType = selectSalt.substring(selectSalt.indexOf(":") + 1);
		}
		if (!selectSalt.equalsIgnoreCase(NO)) {
			waitForElementVisibility(driver, chatBot_inputPoint);
			// _webDriverwait.until(ExpectedConditions.elementToBeClickable(chatBot_inputPoint));
			List<String> chatResponsePossibilitiesList = getListOfPossibilities(chatResponsePickList);
			if (chatResponsePossibilitiesList.contains(pickListname)) {
				if (selectSalt.contains(":") && !getLabelTextForSaltBaseSearch(pickListType)) {
					return result = false;
				}
				for (WebElement baseName : chatResponsePickList) {
					try {
						String saltName = baseName.getText();
						if (saltName.equals(pickListname)) {
							baseName.sendKeys(Keys.ENTER);
							Thread.sleep(2000);
							log.info("User Selection From ChatResponse : " + pickListname);
							result = true;
							waitForElementVisibility(driver, chatBot_inputPoint);
							// _webDriverwait.until(ExpectedConditions.elementToBeClickable(chatBot_inputPoint));
							break;
						}
					} catch (Exception e) {
						// Catch when the link expected is not present in the
						// userquery
						e.printStackTrace();
						logERROR(
								"EXCEPTION:: Unable to select a link in chat response or expected link is not present for the userQuery");
						result = false;
					}
				}
			} else {
				logERROR("Expected PickList link is not present for the userQuery or the PickList is empty");
				result = false;
			}
		}
		return result;
	}

	/**
	 * Verifies the displayed label text and user link present [i.e., current
	 * highlighted Response] in the chat window.
	 * 
	 * @param chatTitle
	 * @param userLinkToBeNavigated
	 * @return
	 */
	private boolean verifyChatLabel(String chatTitle, int responseHeaderOrder) {
		boolean flag = true;
		try {
			waitUntilChatResponse();
			String labelText = getChatResponseTitle(responseHeaderOrder).replaceAll("\n", "");

			if (!(removeAllSpace(chatTitle).equals(removeAllSpace(labelText)))) {
				flag = false;
				logERROR("Label Text " + labelText + " is incorrect");
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
		}
		return flag;
	}

	/**
	 * Use this method to write test data results as fail and store the result
	 * in resultWriteList
	 * 
	 * @throws IOException
	 */
	public void fail() throws InterruptedException, IOException {
		writeResultsAndCloseChatWindow(STATUS_FAIL);
	}

	/**
	 * Use this method to write test data results as pass and store the result
	 * in resultWriteList
	 * 
	 * @throws IOException
	 */
	public void pass() throws InterruptedException, IOException {
		writeResultsAndCloseChatWindow(STATUS_PASS);
	}

	/**
	 * Clicks on the current highlighted link(drug point link) in the chat
	 * response
	 */
	private boolean clickUserNavigationLinkinWatsonAssistant(String linkToNavigate, String sectionName) {
		boolean flag = true;
		if (sectionName.toLowerCase().contains("ped")) {
			sectionName = PEDIATRIC_SECTION;
		}
		if (sectionName.toLowerCase().contains("adu")) {
			sectionName = ADULT_SECTION;
		}
		String navItemURLParameter = null, pageURL = null;
		boolean isTabSelected = false;
		try {
			switch (linkToNavigate) {
			case QUICK:
				quickAnswersChatLink.sendKeys(Keys.ENTER);
				Thread.sleep(2000);
				isLoadingImagedisabled();
				pageURL = driver.getCurrentUrl();
				isTabSelected = getDashBoardPage().quickAnswerTabselected();
				navItemURLParameter = "navitem=cognitivemdxquickansdoclink#";
				break;

			case INDEPTH:
				inDepthAnswersChatLink.sendKeys(Keys.ENTER);
				Thread.sleep(2000);
				isLoadingImagedisabled();
				pageURL = driver.getCurrentUrl();
				isTabSelected = getDashBoardPage().isIndepthAnswerTabselected();
				navItemURLParameter = "navitem=cognitivemdxindepthansdoclink#";
				break;
			}
			if (isTabSelected && !getDashBoardPage().isApplicationerrorMessageDisplayed()) {
				if (pageURL.contains(navItemURLParameter)) {
					if (!isSubsectionSelected(sectionName, linkToNavigate)) {
						logERROR(
								"For the ChatBot UserNavigation, Incorrect Section is Selected in the DrugLanding Page ");
						flag = false;
					}
				} else {
					flag = false;
					logERROR("For " + linkToNavigate + " Answers " + navItemURLParameter
							+ " is not present in DrugLanding Page");
				}
			} else {
				flag = false;
				logERROR(linkToNavigate
						+ " Answers Tab is not selected in DrugLanding Page OR Application Error Message Displayed");
			}
		}

		catch (Exception e) {
			logERROR(
					"EXCEPTION:: Navigation link present in the chatBot icon is not clickable or expected link is not present");
			flag = false;
		}
		return flag;
	}

	/**
	 * Verifies the displayed label text and user link present [i.e., current
	 * highlighted Response] in the chat window.
	 * 
	 * @param chatTitle
	 * @param userLinkToBeNavigated
	 * @return
	 */
	private boolean verifyChatLabelandLink(String chatTitle, int titleOrder, String quickAnswersLink,
			String indepthAnswersLink) {
		boolean flag = true;
		try {
			waitUntilChatResponse();
			if (!chatTitle.contains("did not")) {
				chatTitle = Character.toUpperCase(chatTitle.charAt(0))
						+ chatTitle.substring(1).replaceFirst(" us ", " US ").replaceFirst(" rems ", " REMS ");
			}

			String labelText = getChatResponseTitle(titleOrder).replaceAll("\n", "");
			if (!(removeAllSpace(chatTitle).equals(removeAllSpace(labelText))
					&& getChatResponseHighlightedLink(quickAnswersLink, indepthAnswersLink))) {
				logERROR("LABEL TEXT :" + labelText + " - is incorrect for the user query." + "\n");
				return flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return flag = false;

		}
		return flag;
	}

	/**
	 * Gets text contents from the chat response displayed to the user. Invoke
	 * this method to verify the sections DoNotConfuse, TradeNames, Precautions,
	 * Contraindications, Monitoring, Regulatory Status, Mechanism Of Action,
	 * Dose Adjustments.
	 * 
	 * @param section
	 *            name to be passed
	 * @return List of all the chatResponse content which is highlighted.
	 */
	private List<String> getChatResponseContent(String section) {
		List<String> chatWindowresponseContentList = new ArrayList<String>();
		try {
			waitForElementVisibility(driver, chatResponseHighlighted);
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		int i = 1;
		try {
			switch (section) {
			case CONTRAINDICATIONS:
			case PRECAUTIONS:
				i = 2;
			}
			List<WebElement> responseContent = driver
					.findElements(By.xpath("//div[@class='chatResponse highlightResponse']//ul[" + i + "]//li"));
			for (WebElement content : responseContent) {

				String highlightedContent = content.getText();
				if (DONOTCONFUSE.equals(section)) {
					highlightedContent = highlightedContent.replaceFirst("--", "-");
				}
				log.info("ChatResponse : " + highlightedContent.trim());
				chatWindowresponseContentList.add(removeAllSpace(highlightedContent));
			}
		} catch (Exception e) {
			logERROR("EXCEPTION:: Chat Response content is not displayed", e);
		}
		return chatWindowresponseContentList;
	}

	/**
	 * Gets text contents from the drug landing page NOTE: this method is useful
	 * when there is no headers present for the Drug Landing page contents and
	 * only the para contents alone are displayed as the bulletin points
	 * 
	 * @return List of all the para content which is displayed in the drug
	 *         landing page
	 */
	private List<String> paraContentfromDrugLandingPage() {
		List<String> drugLandingPageContents = new ArrayList<String>();
		List<WebElement> landingPageSectionContent = driver.findElements(By.xpath("//*[@id='sectionArea']//li"));
		try {
			for (WebElement elementContent : landingPageSectionContent) {
				String textContent = elementContent.getText();

				Pattern patt = Pattern.compile("\\[\\d+\\]");
				Matcher match = patt.matcher(textContent);
				if (match.find()) {
					String highlightedContentText = removeCitationLinks(elementContent, textContent);
					drugLandingPageContents.add(removeAllSpace(highlightedContentText));
				} else {
					drugLandingPageContents.add(removeAllSpace(textContent));
				}
			}
		} catch (Exception e) {
			logERROR("Drug Landing Page content is not displayed");
		}
		return drugLandingPageContents;
	}

	/**
	 * Compares two lists Condition: ListA and ListB size should be same use
	 * this method to verify content in ListA is present in ListB or viceversa
	 * 
	 * @return listA , list B (use this method to compare chatResponse and
	 *         landing page content with no headers)
	 */
	private String compareBothListContent(List<String> listA, List<String> listB) {
		String result = STATUS_PASS;
		if (!(listA.isEmpty() && listB.isEmpty())) {
			if (listA.size() == listB.size()) {
				for (String listAContent : listA) {
					if (!listB.contains(listAContent)) {
						logERROR("THE CONTENT " + listAContent + " is not present");
						result = STATUS_FAIL;
					}
				}
			} else {

				result = STATUS_FAIL;
				logERROR("Both the ChatContent Size and Landing Page Content size are not same");
			}
		} else {
			result = STATUS_FAIL;
			logERROR("Either ChatContent Size or Landing Page Content size is empty");
		}

		return result;
	}

	/**
	 * Common steps to writeTestCase Results and to close chat window and then
	 * reopen it.
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 */
	private void writeResultsAndCloseChatWindow(String resultStatus) throws InterruptedException, IOException {
		_resultsListToWrite.add(resultStatus);
		if (closeChatWindow()) {
			if (driver.getTitle().equalsIgnoreCase("Home - MICROMEDEX")) {
				clickHomePageChatIcon();
			} else {
				clickAskWatsonBubble();
			}
		}
	}

	/**
	 * Types user's search query in the chat window and waits until the chat
	 * response is displayed
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public Boolean searchQueryInChatWindow(String searchQuery) throws InterruptedException, IOException {
		Boolean result = true;
		try {
			if (waitUntilChatResponse()) {
				chatBot_inputPoint.clear();
				List<WebElement> numberOfResponses = driver.findElements(By.className("chatResponse"));
				_intialCountOfResponse = numberOfResponses.size();
				// added a string message to record this message in logs
				chatBot_inputPoint.sendKeys(searchQuery + " ######THISISATESTQUERYPLEASEIGNORE######" + Keys.RETURN);

				log.info("UserInputQuery :" + searchQuery);
				result = waitUntilUserPointisClickable();
			} else {
				result = false;
				logERROR("Chat Point is not clickable");
			}
		} catch (Exception e) {
			extentReport.FailWithException(driver, "ChatBot Page", "Search query method failed", e);
			logERROR("Search query method failed");
		}
		return result;
	}

	/**
	 * Invoke this method to get the list of finding possibilities for the
	 * userquery. Usually in the chat response finding possibilities will be
	 * displayed in the link mode.
	 * 
	 * @param findingsList
	 */
	private List<String> getListOfPossibilities(List<WebElement> findingsList) {
		List<String> listOfPossibilities = new ArrayList<String>();
		try {
			for (WebElement linkName : findingsList) {
				log.info("ChatResponse With List Of Possibilities: " + linkName.getText());
				listOfPossibilities.add(linkName.getText());
			}
		} catch (Exception e) {
			logERROR("EXCEPTION:: Chat Response is not displaying the possibilities list for the userQuery", e);
		}
		return listOfPossibilities;
	}

	/**
	 * Verify label text for partial drug and partial condition and salt/base
	 * search queries
	 * 
	 * @param selectSalt
	 * @throws IOException
	 */
	private boolean getLabelTextForSaltBaseSearch(String pickListType) throws IOException {
		boolean flag = true;
		if (pickListType.toLowerCase().contains("drug") && !getChatResponseTitle(0)
				.equals("I've found multiple results for drug. Which one are you looking for?")) {
			flag = false;
			logERROR("Label text is Incorrect for the query with partial drug");
		} else if (pickListType.contains("condition") && !getChatResponseTitle(0)
				.equals("I've found multiple results for condition. Which one are you looking for?")) {
			logERROR("Label text is Incorrect for the query with partial condition");
			flag = false;
		}
		return flag;
	}

	/**
	 * Call this method to verify, whether the page loading icon is completely
	 * disabled. (i.e.,) use this after the user clicks on the highlighted link
	 * present in chat window.
	 */
	private void isLoadingImagedisabled() {
		int i = 0;
		try {

			String script = "return document.readyState";
			JavascriptExecutor js = (JavascriptExecutor) driver;
			String pageLoadState = (String) js.executeScript(script);
			while (!pageLoadState.equals("complete")) {
				pageLoadState = (String) js.executeScript(script);
			}
			List<WebElement> pageLoadingImage = loadingImageList;
			while (i < 3) {
				if (!pageLoadingImage.isEmpty()) {
					break;
				}
				pageLoadingImage = loadingImageList;
				i++;
			}
		} catch (Exception e) {
			logERROR("EXCEPTION:: Loading image is not displayed");
		}
	}

	/**
	 * Invoke this method, to call the methods and variables of
	 * DashBoardPage.class
	 * 
	 * @return DashBoardPage class
	 */
	private DashBoardPage getDashBoardPage() {
		return PageFactory.initElements(driver, DashBoardPage.class);
	}

	public boolean isSubsectionSelected(String subSection, String tabName) {
		boolean flag = false;
		String tab;
		try {
			if (tabName.equalsIgnoreCase("Quick")) {
				tab = "quickanspanel_taxonomy_panel";
			} else {
				tab = "indepthpanel_taxonomy_panel";
			}

			WebElement child = driver
					.findElement(By.xpath("//div[@id='" + tab + "']//li/a[@title='" + subSection + "']"));
			WebElement parent = child.findElement(By.xpath(".."));
			if (parent.getAttribute("class").equals("active")) {
				if (!subSection.equals(parent.getText()) && getDashBoardPage().isApplicationerrorMessageDisplayed()) {
					flag = false;
				}
				flag = true;
			}
		} catch (NoSuchElementException e) {
			flag = false;
		}

		return flag;
	}

	/**
	 * Gets text of the current highlighted link in the chat response
	 */
	private boolean getChatResponseHighlightedLink(String quickAnswersWatsonLink, String indepthAnswersWatsonLink) {
		boolean flag = false;
		try {
			if (waitUntilChatResponse()) {

				if (quickAnswersWatsonLink.equals(NA) && (indepthAnswersWatsonLink.equals(NA))
						|| (!indepthAnswersWatsonLink.equals(NA))) {
					flag = true;
				}
				if (!quickAnswersWatsonLink.equals(NA) && (removeAllSpace(quickAnswersChatLink.getText())
						.equals(removeAllSpace(quickAnswersWatsonLink)))) {

					log.info("ChatResponse_User_Link : " + quickAnswersChatLink.getText().trim());
					flag = true;
				}

				if (flag && !indepthAnswersWatsonLink.equals(NA)) {
					if (removeAllSpace(inDepthAnswersChatLink.getText())
							.equals(removeAllSpace(indepthAnswersWatsonLink))) {
						log.info("ChatResponse_User_Link : " + inDepthAnswersChatLink.getText().trim());
						flag = true;
					} else {
						flag = false;
					}
				}
			}
		}

		catch (Exception e) {
			logERROR("EXCEPTION:: Expected UserNavigation Link is not displayed");
			flag = false;
		}

		return flag;

	}

	/**
	 * Call this method to remove citations from the para content present in the
	 * drug landingpage
	 * 
	 * @return element, textparaContent
	 */
	private String removeCitationLinks(WebElement element, String pageContent) {
		try {
			List<WebElement> citationLinkList = element.findElements(By.className("modalid"));
			for (WebElement citationElement : citationLinkList) {
				String citationLink = citationElement.getText();
				pageContent = pageContent.replace(citationLink, "").trim();
			}
		} catch (Exception e) {
			logERROR("Unable to Identify the Citation Link in the DrugLanding Page");
		}
		return pageContent;
	}

	/**
	 * Clicks the ASKWATSON image present in the mdx pages Note:This method will
	 * not click the watson icon present in the HomePage.
	 */
	public void clickAskWatsonBubble() {
		try {
			askWatsonBubble.click();
			Thread.sleep(2000);
			while (!isChatWindowOpened("block")) {
				askWatsonBubble.click();
				Thread.sleep(2000);
			}
			ajaxCallComplete();
		} catch (Exception e) {
			logERROR("EXCEPTION::Ask Watson image is not clickable in the MDX other Page");
		}
	}

	/**
	 * Waits until the userInput point is blinkable in the chat window
	 */

	private Boolean waitUntilUserPointisClickable() {
		Boolean result = true;
		int i = 0;
		try {
			int expectedResponseCount = _intialCountOfResponse + 1;
			while (expectedResponseCount > _intialCountOfResponse && i < 5) {
				Thread.sleep(2000);
				List<WebElement> numberOfResponses = driver.findElements(By.className("chatResponse"));
				_intialCountOfResponse = numberOfResponses.size();
				i++;
			}
		} catch (Exception e) {
			logERROR("There is no response from the chatWindow");
			result = false;
		}
		return result;
	}

	/**
	 * Compares the Drug Filters Added in chatWindow with the DrugNames present
	 * for Drug Interaction and IV Compatibility in the TestData sheet
	 */
	private boolean verifyDrugFilterAddedForDIandIV(String getDrugNamesFromTestData,
			List<String> filterNamesPresentinChatWindow) throws InterruptedException {
		List<String> expectedDrugNameToPresentinWAFilter = new ArrayList<>();
		try {
			String[] drugs = getDrugNamesFromTestData.split(":");
			expectedDrugNameToPresentinWAFilter = Arrays.asList(drugs);
			expectedDrugNameToPresentinWAFilter.replaceAll(String::toLowerCase);
			Collections.sort(expectedDrugNameToPresentinWAFilter);
			filterNamesPresentinChatWindow.replaceAll(String::toLowerCase);

			for (String expectedDrugName : expectedDrugNameToPresentinWAFilter)
				if (!filterNamesPresentinChatWindow.contains(expectedDrugName)) {
					return false;
				}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;

	}

	/**
	 * Logic for DrugInteractions
	 * 
	 * @param rowList
	 * @return
	 * @throws InterruptedException
	 * @throws IOException
	 */

	public List<String> logicForDrugInteractions(List<List<String>> _rowList) throws InterruptedException, IOException {
		HashMap<String, String> chatResponseDImap = new HashMap<>();
		HashMap<String, String> DIPopUpContentMap = new HashMap<>();
		_resultsListToWrite = new ArrayList<String>();
		for (List<String> columnList : _rowList) {
			if (!searchQueryInChatWindow(columnList.get(0))) {
				fail();
				continue;
			}

			if (!columnList.get(1).equalsIgnoreCase(NO) && !selectSalt(columnList.get(1))) {
				fail();
				continue;
			}

			if (!columnList.get(0).toLowerCase().contains("interact")) {
				if (STATUS_FAIL.equals(verifySearchPrompt(null, "druginteraction", null))) {
					fail();
					continue;
				}
				searchQueryInChatWindow(YES);
			}

			if (!verifyChatLabel(columnList.get(3), 0)) {
				fail();
				continue;
			}

			if (columnList.get(4).equalsIgnoreCase(NA)) {
				if (!verifyChatLabel(columnList.get(3), 0)) {
					fail();
					continue;
				}
				pass();
				log.info("\n");
				continue;
			}

			if (!columnList.get(2).equalsIgnoreCase(NA)) {
				if (columnList.get(2).contains(YES)) {
					chatResponseDImap = getChatResponseForDrugInteractions();
					if (!isExpectedInteractionPageDisplayed(columnList.get(5), "DrugInteractionsSingleResultsPage")) {
						continue;
					}

					DrugInteractionsResultsPage diMultipleResultsPage = new DrugInteractionsResultsPage(driver);
					String drugDrugName = removeAllSpace(diMultipleResultsPage.drugDrugLink.getText().toLowerCase());

					if (drugDrugName.contains(removeAllSpace(getValues(columnList.get(5).toLowerCase(), 0)))
							&& drugDrugName.contains(removeAllSpace(getValues(columnList.get(5).toLowerCase(), 1)))) {
						DrugInteractionsResultsPage diResultPage = diMultipleResultsPage.clickPopDrugLink();
						DIPopUpContentMap = diResultPage.getDrugDrugInteractionsPopContent();
						diMultipleResultsPage.closeDrugDrugPopUp.click();

						if (chatResponseDImap.equals(DIPopUpContentMap)) {
							pass();
							log.info("\n");
							continue;
						} else {
							fail();
							logERROR("Content Mismatches b/w chat response content and DI results Page Content");
							continue;
						}

					} else {
						fail();
						logERROR("User Queried drug Names are not present in the Di results Page Drug-Drug Link");
						continue;
					}
				}

				else {
					if (!isExpectedInteractionPageDisplayed(columnList.get(5), "DrugInteractionsSingleResultsPage")) {
						continue;
					}
					DrugInteractionsResultsPage diMultipleResultsPage = new DrugInteractionsResultsPage(driver);

					if (!diMultipleResultsPage.jumpToLinksPrint.isEmpty()
							&& !diMultipleResultsPage.isJumpToLinkPresent("DRUG-DRUG")) {

						if (diMultipleResultsPage.verifyDrugNamesInDrugInteractionResultsPage(columnList.get(5),
								columnList.get(3))) {
							pass();
							log.info("\n");
							continue;
						} else {
							fail();
							logERROR("Drug Names present in DI results page is incorrect");
							continue;
						}
					} else {
						fail();
						logERROR(
								"Instead of other drug interactions details, DRUG-DRUG interaction link is displayed which is incorrect.");
						continue;
					}
				}
			}

			if (columnList.get(2).contains(NA) && !columnList.get(5).contains(":")) {
				if (!isExpectedInteractionPageDisplayed(columnList.get(5), "DrugInteractionsResultsPage")) {
					continue;
				}
				DrugInteractionsSingleResultsPageForWatson diSingleResultsPage = new DrugInteractionsSingleResultsPageForWatson(
						driver);
				writeResultsAndCloseChatWindow(diSingleResultsPage.verifySingleDrugInteractionName(columnList.get(4)));
			} else {
				if (!isExpectedInteractionPageDisplayed(columnList.get(5), "DrugInteractionsSingleResultsPage")) {
					continue;
				}
				DrugInteractionsResultsPage diMultipleResultsPage = new DrugInteractionsResultsPage(driver);
				if (verifyDrugFilterAddedForDIandIV(columnList.get(5), getFilterNames()) && diMultipleResultsPage
						.verifyDrugNamesInDrugInteractionResultsPage(columnList.get(5), columnList.get(3))) {
					if (!columnList.get(6).equalsIgnoreCase(NA)) {
						if (!searchQueryInChatWindow(columnList.get(6))) {
							fail();
							continue;
						}
						if (columnList.get(7).equalsIgnoreCase(NO) && !selectSalt(columnList.get(7))) {
							fail();
							continue;
						} else if (columnList.get(9).equalsIgnoreCase("NA")
								&& columnList.get(10).equalsIgnoreCase("NA")) {
							if (verifyChatLabel(columnList.get(8), 0))
								_resultStatus = STATUS_PASS;
							else
								fail();
						}
						if (!verifyChatLabelandLink(columnList.get(8), 0, columnList.get(9), columnList.get(10))) {
							fail();
							continue;
						} else if (columnList.get(9).equals(NA) && !columnList.get(10).equals(NA)) {
							if (clickUserNavigationLinkinWatsonAssistant(IN_DEPTH_ANSWERS, columnList.get(12)))
								_resultStatus = STATUS_PASS;
							else {
								fail();
								continue;
							}

						} else if (STATUS_PASS.equals(_resultStatus) && !columnList.get(9).equals(NA)
								&& !clickUserNavigationLinkinWatsonAssistant(QUICK_ANSWERS, columnList.get(12))) {
							fail();
							continue;
						} else if (STATUS_PASS.equals(_resultStatus) && !columnList.get(10).equals(NA)
								&& !clickUserNavigationLinkinWatsonAssistant(IN_DEPTH_ANSWERS, columnList.get(12))) {
							fail();
							continue;
						}
						List<String> filterNamesPresentInChatWindow = getFilterNames();
						filterNamesPresentInChatWindow.replaceAll(String::toLowerCase);
						if (columnList.get(11).contains(":")) {
							if (filterNamesPresentInChatWindow.contains(getValues(columnList.get(11).toLowerCase(), 0))
									&& filterNamesPresentInChatWindow
											.contains(getValues(columnList.get(11).toLowerCase(), 1))
									&& filterNamesPresentInChatWindow
											.contains(getValues(columnList.get(11).toLowerCase(), 2))) {
								pass();
							} else
								fail();
						} else {
							if (!filterNamesPresentInChatWindow.contains(columnList.get(11).toLowerCase())) {
								fail();
							} else
								pass();
						}
					} else
						pass();
				} else
					fail();
			}

			log.info("\n");
		}

		return _resultsListToWrite;

	}

	/**
	 * Invoke this method to verify, whether the chat response Prompt for drug
	 * alone,condition alone,drug and condition and dosing Intents are returned,
	 * when the user searches for the related query
	 * 
	 * @param drugCondition
	 */
	private String verifySearchPrompt(String drugName, String promptName, String drugCondition) {
		String drugSearchPrompt = null;
		String result = STATUS_PASS;
		try {
			waitForElementVisibility(driver, chatBot_inputPoint);

			if (drugName != null && drugName.contains(":")) {
				drugName = drugName.substring(0, drugName.lastIndexOf(":"));
			}

			if (drugCondition != null && drugCondition.contains(":")) {
				drugCondition = drugCondition.substring(0, drugCondition.lastIndexOf(":"));
			}
			switch (promptName) {
			case "drug":
				drugSearchPrompt = "Would you like to see the uses of " + drugName.toLowerCase() + "?";
				break;

			case "drugAndCondition":
				drugSearchPrompt = "Would you like to see the " + drugName.toLowerCase() + " dosing for "
						+ drugCondition.toLowerCase() + "?";
				break;

			case "condition":
				drugSearchPrompt = "Would you like to see drugs used for " + drugCondition.toLowerCase() + "?";
				break;
			case "druginteraction":
				drugSearchPrompt = "Would you like to see the drug interactions for the selected drugs?";
				break;
			}

			if (!removeAllSpace(drugSearchPrompt).equals(removeAllSpace(getChatResponseTitle(0)))) {

				result = STATUS_FAIL;
				logERROR("Drug Recognition is Incorrect OR chat question prompt to the user is incorrect");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * Drug-Drug Interaction chat response will be stored in this method.
	 * key->header values->content
	 * 
	 * @throws IOException
	 */
	public HashMap<String, String> getChatResponseForDrugInteractions() throws IOException {
		HashMap<String, String> chatResponseDImap = new HashMap<>();
		chatResponseDImap.put(removeAllSpace(getChatResponseTitle(5)), removeAllSpace(getChatResponseTitle(7)));
		chatResponseDImap.put(removeAllSpace(getChatResponseTitle(11)), removeAllSpace(getChatResponseTitle(14)));
		chatResponseDImap.put(removeAllSpace(getChatResponseTitle(19)), removeAllSpace(getChatResponseTitle(22)));
		chatResponseDImap.put(removeAllSpace(getChatResponseTitle(27)), removeAllSpace(getChatResponseTitle(28)));
		chatResponseDImap.put(removeAllSpace(getChatResponseTitle(33)), removeAllSpace(getChatResponseTitle(34)));

		return chatResponseDImap;

	}

	/**
	 * for the drug interaction intent Verifies interaction result page is
	 * available
	 * 
	 * @param columnValue
	 *            = mdx drug names from chatbot test data
	 * @param className=
	 *            expected classname should not be present
	 * @throws IOException
	 */
	public boolean isExpectedInteractionPageDisplayed(String columnValue, String className)
			throws InterruptedException, IOException {
		Object obj = getDrugInteractionsResultPage(columnValue);
		if (obj instanceof Boolean || obj.getClass().getSimpleName().equalsIgnoreCase(className)) {
			isInteractionResultPageAvailable();
			return false;
		}
		return true;
	}

	/**
	 * call this method to invoke the DrugInteractionsSingleResultsPage
	 * 
	 * @return DrugInteractionsSingleResultsPage.class
	 */
	private Object getDrugInteractionsResultPage(String drugNameUsed) {
		try {
			Thread.sleep(3000);
			clickMoreHighlighted.click();
			if (!drugNameUsed.contains(":")) {
				return PageFactory.initElements(driver, DrugInteractionsSingleResultsPageForWatson.class);
			} else {
				return PageFactory.initElements(driver, DrugInteractionsResultsPage.class);
			}
		} catch (InterruptedException e) {
			// will throw error if drug interaction results page is not
			// displayed
			e.printStackTrace();
			return false;
		}

	}

	/**
	 * Logic for TestCase Validates the definition of each and every Feedback
	 * intent
	 * 
	 * @param _rowList
	 * @return pass/fail status for each user query
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public List<String> logicForFeedbackResponse(List<List<String>> _rowList) throws InterruptedException, IOException {
		_resultsListToWrite = new ArrayList<String>();

		for (List<String> columnList : _rowList) {
			if (!searchQueryInChatWindow(columnList.get(0))) {
				fail();
			}
			if (!columnList.get(1).equalsIgnoreCase(NA)) {
				if (!columnList.get(2).equalsIgnoreCase(NA)) {
					if (clickFeedback(columnList.get(2), columnList.get(7))) {
						searchQueryInChatWindow(columnList.get(3));
					} else {
						fail();
						continue;
					}
				}
			}

			else {
				if (!verifyChatLabel(columnList.get(5), 0)) {
					fail();
					continue;
				}
			}
			if (!columnList.get(6).equalsIgnoreCase(NA)) {
				if (!clickFeedback(columnList.get(6), columnList.get(7))) {
					fail();
				} else {
					pass();
				}
			} else {
				pass();
			}
		}
		return _resultsListToWrite;
	}

	public boolean clickFeedback(String userAction, String userInput) throws InterruptedException, IOException {

		boolean flag = true;

		if (userAction.contains(POSITIVE) && userInput.equals(NA)) {
			chatThumbsUp.click();
			/*
			 * _webDriverwait.until(ExpectedConditions
			 * .elementToBeClickable(chatBot_inputPoint));
			 */
			if (userAction.contains(":") && !userAction.equals(NA)) {
				userAction = userAction.substring(userAction.lastIndexOf(":") + 1);
				if (!getChatResponseTitle(0).equals(userAction)) {
					flag = false;
				}
			} else {
				if (!getChatResponseTitle(0).equals(FEEDBACK_POSITIVE)) {
					flag = false;
				}
			}

		}
		if (userAction.contains(NEGATIVE) && !userInput.equals(NA)) {
			chatThumbsDown.click();
			/*
			 * _webDriverwait.until(ExpectedConditions
			 * .elementToBeClickable(chatBot_inputPoint));
			 */
			if (userAction.contains(":")) {
				userAction = userAction.substring(userAction.lastIndexOf(":") + 1);
				if (!getChatResponseTitle(0).equals(userAction)) {
					flag = false;
				}
				searchQueryInChatWindow(userInput);
				if (!getChatResponseTitle(0).equals(FEEDBACK_POSITIVE)) {
					flag = false;
				}
			} else {
				if (!getChatResponseTitle(0).equals(FEEDBACK_NEGATIVE)) {
					flag = false;
				}

			}
		}
		return flag;
	}

	/**
	 * for the drug interaction intent Verifies interaction result page is
	 * available
	 * 
	 * @throws IOException
	 */
	public void isInteractionResultPageAvailable() throws InterruptedException, IOException {
		if (isNoInteractionAvailablePopUpPresent()) {
			fail();
			logERROR("Interaction unavailable pop-Up message is displayed");
		} else {
			fail();
			logERROR("Drug interaction Result page is incorrect");
		}
	}

	/**
	 * for the drug interaction intent Use this method to verify whether No
	 * interaction popup is displayed
	 */
	public boolean isNoInteractionAvailablePopUpPresent() throws InterruptedException {

		Object isPopUpPresent = ((JavascriptExecutor) driver)
				.executeScript("return document.getElementById('invalidDrugs_title');");

		if (isPopUpPresent == null) {
			return false;
		} else {
			closePopUp();
			return true;

		}
	}

	/**
	 * for the drug interaction intent closes No interaction popup
	 */
	public void closePopUp() throws InterruptedException {
		if (isContinueDisplayedInPopUp()) {
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", button_Close);
			Thread.sleep(3000);
		} else {
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", button_Ok);
			Thread.sleep(3000);
		}
	}

	/**
	 * for the drug interaction intent verifies No interaction popup displays
	 * continue button in it or not
	 */
	public boolean isContinueDisplayedInPopUp() {
		Object continueButtonDisplayed = ((JavascriptExecutor) driver)
				.executeScript("return document.getElementById('submitButton');");

		if (continueButtonDisplayed == null) {
			return false;
		}

		return true;
	}

	/**
	 * for the drug interaction intent Verifies interaction result page is
	 * available
	 * 
	 * @throws IOException
	 */
	public void isInteractionResultPageAvailable1() throws InterruptedException, IOException {
		if (isNoInteractionAvailablePopUpPresent()) {
			fail();
			logERROR("Interaction unavailable pop-Up message is displayed");
		} else {
			fail();
			logERROR("Drug interaction Result page is incorrect");
		}
	}

	/**
	 * Use this method to get a single value from String arrays. ex
	 * drugA:drugB:drugC
	 * 
	 * @param first
	 *            orderNumber ->0 or 1 or 2
	 */
	public String getValues(String drugNames, int orderNumber) {
		String[] drug = drugNames.split(":");
		return drug[orderNumber];
	}
}
