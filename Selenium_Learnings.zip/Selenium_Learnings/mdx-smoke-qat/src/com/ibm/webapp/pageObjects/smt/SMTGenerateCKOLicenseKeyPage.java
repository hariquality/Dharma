package com.ibm.webapp.pageObjects.smt;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class SMTGenerateCKOLicenseKeyPage extends Selenese {
	WebDriver driver;

	@FindBy(xpath = "//*[text()='Generate CKO License Key']")
	private WebElement generateCKOLicenseKeyHeading;

	@FindBy(linkText = "System Management Tool")
	private WebElement applcationvrsn_link;

	@FindBy(xpath = "//*[@id='customerID_index_0']")
	private WebElement customerId;

	@FindBy(xpath = "//*[@id='activationKey_index_0']")
	private WebElement activationCode;

	@FindBy(xpath = "//*[@id= 'PFFormActionId_systemmanagementtool.status.save.key.cko']")
	private WebElement generateLicenseKeyButton;

	@FindBy(xpath = "//p[text()='The Customer ID and Activation Code cannot be blank.']")
	private WebElement errorMsgBoth;

	@FindBy(xpath = "//p[text()='The License Key data was successfully generated.']")
	private WebElement licenseKeyGeneratedMsg;

	@FindBy(xpath = "//p[text()='Error generating License Key. Check your Customer ID and Activation Code.']")
	private WebElement licenseKeyGenerateErrorMsg;

	public SMTGenerateCKOLicenseKeyPage(WebDriver driver) throws IOException {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		try {
			wait.until(ExpectedConditions.visibilityOf(customerId));
		} catch (Exception e) {
			extentReport.FAIL(driver, "GenerateCKOLicense Key", "GenerateCKOLicense Key page is not displayed");
			log.error("GenerateCKOLicense Key page is not displayed");
		}
	}

	/**
	 * generates a cko license key
	 * 
	 * @throws IOException
	 */
	public void generateCKOLicenseKey() throws IOException {
		customerId.sendKeys("607030001");
		activationCode.sendKeys("7FA5-1E40");
		driver.findElements(By.xpath("//input[@type='radio']")).get(1).click();
		generateLicenseKeyButton.click();
		String homePath = System.getProperty("user.home");
		String dirPath = homePath + "/Downloads";
		if (isFileDownloaded(dirPath, "license.txt"))
			licenseKeyGeneratedSuccessMsgValidation();
	}

	public void errorMsgValidation() throws IOException {
		String expectedText = "The Customer ID and Activation Code cannot be blank.";
		String actualText = errorMsgBoth.getText();
		if (expectedText.equals(String.valueOf(actualText))) {
			extentReport.PASS("LicenseKeyError Message Validation", "LicenseKey Error Message is displayed correctly");
		} else {
			extentReport.FAIL(driver, "LicenseKey Error Message Validation",
					"LicenseKey is not generated successfully. " + "Actual Value:" + actualText + " , "
							+ "Expected Value" + expectedText);
		}
	}

	public void licenseKeyGeneratedSuccessMsgValidation() throws IOException {
		String expectedText = "The License Key data was successfully generated.";
		String actualText = licenseKeyGeneratedMsg.getText();
		if (expectedText.equals(String.valueOf(actualText))) {
			extentReport.PASS("LicenseKeyMessage Validation", "LicenseKey is generated successfully");
		} else {
			extentReport.FAIL(driver, "LicenseKeyMessage Validation", "LicenseKey is not generated successfully. "
					+ "Actual Value:" + actualText + " , " + "Expected Value" + expectedText);
		}
	}

	public void licenseKeyGenerateFailMsgValidation() throws IOException {
		String expectedText = "Error generating License Key. Check your Customer ID and Activation Code.";
		String actualText = licenseKeyGenerateErrorMsg.getText();
		if (expectedText.equals(String.valueOf(actualText))) {
			extentReport.PASS("LicenseKeyGenerate Fail Message Validation",
					"LicenseKey Fail message is verified successfully");
		} else {
			extentReport.FAIL(driver, "LicenseKeyGenerate Fail Message Validation",
					"LicenseKey Fail message is incorrect " + "Actual Value:" + actualText + " , " + "Expected Value"
							+ expectedText);
		}
	}

	public static Boolean isFileDownloaded1(String fileName) {
		boolean flag = false;

		String dirPath = "C:\\Users\\vC-PUC8\\Downloads";
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files.length == 0 || files == null) {
			System.out.println("The directory is empty");
			flag = false;
		} else {
			for (File listFile : files) {
				if (listFile.getName().contains(fileName)) {
					System.out.println(fileName + " is present");
					break;
				}
				flag = true;
			}
		}
		return flag;
	}

	public boolean isFileDownloaded(String downloadPath, String fileName) {
		File dir = new File(downloadPath);
		// System.out.println(dir);
		File[] dirContents = dir.listFiles();
		System.out.println(dirContents.length);
		for (int i = 0; i < dirContents.length; i++) {
			if (dirContents[i].getName().equals(fileName)) {
				System.out.println("License.txt has been downloaded successfully");
				// File has been found, it can now be deleted:
				dirContents[i].delete();
				return true;
			}
		}
		return false;
	}
}
