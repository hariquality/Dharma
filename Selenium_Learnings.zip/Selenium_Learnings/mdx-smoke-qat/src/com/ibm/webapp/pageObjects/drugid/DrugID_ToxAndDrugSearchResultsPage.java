package com.ibm.webapp.pageObjects.drugid;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.pageObjects.mdx.MDX_HeaderPage;
import com.ibm.webapp.utils.Selenese;

public class DrugID_ToxAndDrugSearchResultsPage extends Selenese


{
   WebDriver driver;

 
   @FindBy(xpath = "//table[@id= 'PSN_Table']/tbody/tr")
   private List<WebElement> toxAndDrugSearchSmokeResults;
   
   @FindBy(xpath = "//*[@id=\"PSN_Table\"]/tbody/tr[1]/td[2]/a")
   private WebElement firstDrugLink;

   public DrugID_ToxAndDrugSearchResultsPage(WebDriver driver)
   {
      this.driver = driver;
      PageFactory.initElements(driver, this);
      driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
   }


   public MDX_HeaderPage getHeaderPage() {
      MDX_HeaderPage headerPage = PageFactory.initElements(driver, MDX_HeaderPage.class);
    return headerPage;
   }

	/**
	 * Return true if Tox and Drug Search Results is displayed otherwise return
	 * false
	 *
	 * @return
	 * @throws IOException
	 */
	public void isToxAndDrugSearchResultsDisplayed() throws IOException {
		if (toxAndDrugSearchSmokeResults.size() > 0) {
			extentReport.PASS("Tox and Drug Search Results Validation", "Tox and Drug Results page is displayed");
			log.info("Tox and Drug Results page is displayed");
		} else {
			extentReport.FAIL(driver, "Tox and Drug Search Results Validation",
					"Tox and Drug Results page is displayed");
			log.error("first drug not clicked");
		}
	}

   
   public void clickFirstDrugLink() throws IOException
   {
      //firstDrugLink.click();
      try
      {
         click(driver,"click first drug",firstDrugLink);
         extentReport.PASS("first drug clicked", "first drug clicked");
         log.info("first drug not clicked");
      }
      catch (IOException e)
      {
         // TODO Auto-generated catch block
         extentReport.FAIL(driver, "first drug not clicked", "first drug not clicked");
         log.error("first drug not clicked");
         e.printStackTrace();
         
      }
   }


}