package com.ibm.webapp.pageObjects.formularyadmin;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class FormularyAdmin_PublishPage extends Selenese
{
   private final WebDriver driver;

   @FindBy(xpath = "//strong[contains(text(),'Publish')]")
   private WebElement pageHeader;

   @FindBy(id = "PFFormActionId_formularyadmin.PublishFormulary")
   private WebElement publishBtn;

   public FormularyAdmin_PublishPage(WebDriver driver)
   {
      this.driver = driver;
      PageFactory.initElements(this.driver, this);
      WebDriverWait wait = new WebDriverWait(this.driver, 20);
      wait.until(ExpectedConditions.visibilityOf(pageHeader));
   }

   /**
    * click on Publish button in formulary admin
    * @return
    * @throws IOException 
    */
   public FormularyAdmin_HomePage publishFormulary() throws IOException
   {
      //publishBtn.click();
      click(driver, "Publish", publishBtn);
      FormularyAdmin_HomePage home = PageFactory
            .initElements(driver, FormularyAdmin_HomePage.class);
      return home;
   }

}
