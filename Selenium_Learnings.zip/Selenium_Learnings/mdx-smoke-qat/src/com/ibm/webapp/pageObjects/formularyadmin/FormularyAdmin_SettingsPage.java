package com.ibm.webapp.pageObjects.formularyadmin;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class FormularyAdmin_SettingsPage extends Selenese
{
   private final WebDriver driver;

   @FindBy(id = "managementSettings.formularyName_index_0")
   private WebElement formularyName;

   @FindBy(xpath = "//strong[contains(text(),' Settings ')]")
   private WebElement settingsLbl;

   @FindBy(id = "PFFormActionId_formularyadmin.CreateFormulary")
   private WebElement createNewBtn;

   @FindBy(xpath = "//td/span[2]/strong")
   private WebElement formularyCreateSuccessmsg;

   @FindBy(xpath = "(//td[@width='360'])[2]")
   private WebElement currentFormularydatelbl;

   @FindBy(id = "PFFormActionId_formularyadmin.AddEditStatusTiers")
   private WebElement saveChangesBtn;

   @FindBy(xpath = "(//td[@width='360'])[1]")
   private WebElement currentFormularylbl;

   @FindBy(xpath = "//strong[text()='OPTIONAL: Choose icons:']")
   private WebElement iconSelectlbl;

   @FindBy(id = "Settings.costDisplay_index_0")
   private List<WebElement> costRdoBtn;

   @FindBy(xpath = "//input[contains(@id,'Settings.symbol_index_')]")
   private List<WebElement> costSymbol;

   @FindBy(xpath = "//input[contains(@name,'Settings.amount')]")
   private List<WebElement> costMeaning;

   @FindBy(id = "PFFormActionId_formularyadmin.SaveFormularyCostSettings")
   private WebElement setCostDisplaybtn;

   @FindBy(id = "stMeaning_index_0")
   private WebElement statusTierMeaning;

   @FindBy(id = "stAbbrev_index_0")
   private WebElement statusAbbreviation;

   @FindBy(name = "stDefault_index_0")
   private WebElement defaultStatusTierchkbox;

   @FindBy(name = "Add.")
   private WebElement addBtn;

   @FindBy(name = "stOnFormulary")
   private WebElement statusabbreviationlist;
   
   @FindBy(linkText="1. Settings")
   private WebElement settingslnk;
   
   @FindBy(linkText="2. Edit List")
   private WebElement editListlnk;
   
   @FindBy(linkText="3. Edit Items")
   private WebElement editItemslnk;
   
   @FindBy(linkText="4. Publish")
   private WebElement publishlnk;


   public FormularyAdmin_SettingsPage(WebDriver driver)
   {
      this.driver = driver;
      PageFactory.initElements(this.driver, this);
      WebDriverWait wait = new WebDriverWait(this.driver, 20);
      wait.until(ExpectedConditions.visibilityOf(settingsLbl));
   }

   /**
    * method to enter formulary name during formulary creation
    * @return String
    */
   public String enterFormularyName()
   {
      String name = RandomStringUtils.randomAlphabetic(8);
      //formularyName.sendKeys(name);
      try
      {
         sendKeys(driver, "formulary name", formularyName, name);
      }
      catch (IOException e)
      {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
      return name;
   }

   /**
    * click on create new formulary
    * @return boolean
    */
   public boolean createFormulary()
   {
      try
      {
         createNewBtn.click();
         waitForElementVisibility(driver, formularyCreateSuccessmsg);
      }
      catch (IOException e)
      {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
      if (formularyCreateSuccessmsg.getText()
            .equalsIgnoreCase("Formulary creation was successful."))
         return true;
      else
         return false;
   }

   /**
    * 
    * @return
    */
   public boolean verifyFormularyModifiedDate()
   {
      Date curDate = new Date();
      SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, YYYY");
      if (currentFormularydatelbl.getText().contains(sdf.format(curDate)))
         return true;
      else
         return true;
   }

   public boolean verifyFormularyName(String name)
   {
      if (currentFormularylbl.getText().contains(name))
         return true;
      else
         return false;
   }
   /**method to click on Cost button
    * 
    * @param cost
    * @throws IOException 
    */
   public void selectFormularyCost(String cost) throws IOException
   {
      for (WebElement ele : costRdoBtn)
      {
         if (ele.getAttribute("value").contentEquals("formularyCost" + cost))
         {
            //ele.click();
            click(driver, "formularyCost", ele);
            break;
         }
      }
   }
   /**method to enter the cost and its meaning
    * 
    * @param symbol, its meaning
 */
   public void enterCostandMeaning(String symbol, String meaning)
   {
      String[] symbolArray = symbol.split(";");
      String[] meaningArray = meaning.split(";");

      System.out.println(costSymbol.size());
      System.out.println(costMeaning.size());

      for (int i = 0; i < symbolArray.length; i++)
      {
         costSymbol.get(i).sendKeys(symbolArray[i]);
         costMeaning.get(i).sendKeys(meaningArray[i]);
      }

      setCostDisplaybtn.click();
   }

   /**
    * 
    * @param abbreviation
    *           {enter multiple with semicolon seperated}
    * @param meaning
    *           {enter multiple with semicolon seperated}
    * 
    */
   public void addStatusTier(String abbreviation, String meaning)
   {
      String[] abbreviationArray = abbreviation.split(";");
      String[] meaningArray = meaning.split(";");

      for (int i = 0; i < abbreviationArray.length; i++)
      {
         statusAbbreviation.clear();
         statusTierMeaning.clear();
         statusAbbreviation.sendKeys(abbreviationArray[i]);
         statusTierMeaning.sendKeys(meaningArray[i]);
         addBtn.click();
      }
   }
   /**method to add status tiers
    * 
    * @param abbreviation, meaning for the abbreviation, default Formulary
    * @throws IOException 
    */
   public void addStatusTier(String abbreviation,
                             String meaning,
                             char defaultFormulary)
   {
      statusAbbreviation.clear();
      statusTierMeaning.clear();
      statusAbbreviation.sendKeys(abbreviation);
      statusTierMeaning.sendKeys(meaning);
      if (!defaultStatusTierchkbox.isSelected())
         defaultStatusTierchkbox.click();

      addBtn.click();
   }

   public boolean saveChanges(String abbreviation, String meaning)
   {
      String[] abbreviationArray = abbreviation.split(";");
      String[] meaningArray = meaning.split(";");

      boolean result = true;

      saveChangesBtn.click();
      Select statusTier = new Select(statusabbreviationlist);
      List<WebElement> statusList = statusTier.getOptions();

      int i = 0;
      for (WebElement e : statusList)
      {
         if (!e.getText().equalsIgnoreCase(abbreviationArray[i] + " " + "-"
               + " " + meaningArray[i]))
         {
            result = false;
            break;
         }
         i = i + 1;
      }

      if (result == true && !iconSelectlbl.isDisplayed())
         result = false;
      return result;
   }
   /**method to click on edit list link
    * 
    * return edit list page 
    */
   public FormularyAdmin_EditListPage clickOnEditList(){
      editListlnk.click();
      FormularyAdmin_EditListPage editListPage = PageFactory.initElements(driver, FormularyAdmin_EditListPage.class);
      return editListPage;
     }

}
