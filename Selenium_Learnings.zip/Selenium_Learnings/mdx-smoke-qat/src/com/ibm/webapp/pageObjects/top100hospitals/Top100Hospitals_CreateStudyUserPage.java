package com.ibm.webapp.pageObjects.top100hospitals;

import java.io.IOException;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class Top100Hospitals_CreateStudyUserPage extends Selenese
{

   private final WebDriver driver;

   @FindBy(xpath = "//*[@id='createUpdateUserMenu']/table/tbody/tr[2]/td/h4")
   private WebElement CreateUser;

   @FindBy(xpath = "//*[@id='User.HospitalName_index_0']")
   private WebElement HospitalName;

   @FindBy(xpath = "//*[@id='User.HospitalId_index_0']")
   private WebElement HospitalId;

   @FindBy(xpath = "//*[@id='User.FirstName_index_0']")
   private WebElement FirstName;

   @FindBy(xpath = "//*[@id='User.LastName_index_0']")
   private WebElement LastName;

   @FindBy(xpath = "//*[@id='User.Email_index_0']")
   private WebElement EmailID;

   @FindBy(xpath = "//*[@id='User.UserName_index_0']")
   private WebElement UserName;

   @FindBy(xpath = "//*[@id='User.Password_index_0']")
   private WebElement Password;

   @FindBy(xpath = "//*[@id='Submit']")
   private WebElement CreateUserButton;

   @FindBy(xpath = "//*[@id='Cancel']")
   private WebElement CancelButton;

   Top100Hospitals_UserProvisioningPage userProvPage;

   Top100Hospitals_AdministrativeTasksPage administrativetask;

   public Top100Hospitals_CreateStudyUserPage(WebDriver driver) throws IOException
   {
      this.driver = driver;
      PageFactory.initElements(this.driver, this);
      WebDriverWait wait = new WebDriverWait(this.driver, 20);

      try
      {
         wait.until(ExpectedConditions.visibilityOf(FirstName));
      }
      catch (Exception e)
      {
         extentReport.FAIL(driver,
                           "Top100Hospitals_CreateStudyUserPage",
                           "Create study user link is not visible");
         log.error("Create study user link is not visible");
      }
   }

   /**
    * create new user
    * 
    * @return
    * @throws InterruptedException
    * @throws IOException
    */
   public Top100Hospitals_AdministrativeTasksPage createNewUser() throws InterruptedException,
                                                                  IOException
   {
      String hospName = RandomStringUtils.randomAlphabetic(10);
      sendKeys(driver, "hospital name", HospitalName, hospName);
      Random random_HospID = new Random();
      int tenDigits = random_HospID.nextInt(1_000_000_000) + 1_000_000_000;
      String hospID = Integer.toString(tenDigits);
      sendKeys(driver, "hospital id", HospitalId, hospID);
      sendKeys(driver,
               "first name",
               FirstName,
               RandomStringUtils.randomAlphabetic(10));
      sendKeys(driver,
               "last name",
               LastName,
               RandomStringUtils.randomAlphabetic(10));
      String uniqueid = RandomStringUtils.randomAlphabetic(8);
      String mailID_userName = uniqueid + "@test.com";
      sendKeys(driver, "email id", EmailID, mailID_userName);
      sendKeys(driver, "user name", UserName, mailID_userName);
      sendKeys(driver, "password", Password, "QATest@Test123");
      click(driver, "click on create user button", CreateUserButton);

      administrativetask = PageFactory
            .initElements(driver,
                          Top100Hospitals_AdministrativeTasksPage.class);
      return administrativetask;
   }
}
