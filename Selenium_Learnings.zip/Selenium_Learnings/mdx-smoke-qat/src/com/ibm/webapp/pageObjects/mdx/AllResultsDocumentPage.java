package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.utils.Selenese;

public class AllResultsDocumentPage extends Selenese {
	private final WebDriver driver;

	@FindBy(xpath = "//div[@id='docInfoTop']/div[@id='pgContent']/div[@id='drugTitle']")
	private WebElement drugTitle;

	public AllResultsDocumentPage(WebDriver driver) throws IOException {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		waitForElementVisibility(driver, drugTitle);

	}

	/**
	 * Use this method to verify the document title present in all results page
	 * 
	 * @param docTitle
	 *            =pass the document title to all results document page and
	 *            verify that element visibility
	 * 
	 * @throws IOException
	 */

	public void isDocumentTitleEqualsLink(String docTitle) throws IOException {
		try {
			if (drugTitle.getText().trim().equalsIgnoreCase(docTitle)) {
				extentReport.PASS("Document title verification", docTitle + " is displayed in all results document page");
				log.info(docTitle + " is displayed in all results document page");
			}
		} catch (Exception e) {
			extentReport.FailWithException(driver, "Document title verification", docTitle + " is not displayed in all results document page", e);
			logERROR(docTitle + " is not displayed in all results document page", e);
		}

	}

}
