package com.ibm.webapp.pageObjects.top100hospitals;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.ibm.webapp.utils.Selenese;

public class Top100Hospitals_UserProvisioningPage extends Selenese
{

   private final WebDriver driver;

   @FindBy(xpath = "//*[@id=\"userProvisioningMenu\"]/table/tbody/tr[1]/td/h3/span")
   private WebElement UserProvisioning;

   @FindBy(xpath = "//*[@id=\"id_of_tablebody\"]/tr[7]/td[2]/a")
   private WebElement NationalBenchmark2013;

   @FindBy(xpath = "//a[contains(text(),'Create a new Cardiovascular Benchmarks Study Group')]")
   private WebElement createCardioStudyGrp;

   @FindBy(xpath = "//a[contains(text(),'Create a new National Benchmarks Study Group')]")
   private WebElement createNationalStudyGrp;

   @FindBy(xpath = "//*[@id=\"userProvisioningMenu\"]/table/tbody/tr[2]/td/div/h3/strong/span")
   private WebElement studyGrpCreationSuccessMsg;

   // @FindBy(xpath = "//*[@id=\"userProvisioningMenu\"]/table/tbody/tr[2]")
   @FindBy(xpath = "//*[@id=\"id_of_tablebody\"]")
   private WebElement userProvTable;

   @FindBy(xpath = "//a[contains(text(),'Logout')]")
   private WebElement LogoutLink;

   @FindBy(xpath = "//*[@id=\"id_of_tablebody\"]/tr[1]/td[2]/a")
   private WebElement clickonFirstNationalStudyWinnerLink;

   Top100Hospitals_CreateStudyGroupPage createStudyGrpPage;

   Top100Hospitals_CreateStudyUserPage createStudyUserPage;

   Top100Hospitals_AdministrativeTasksPage adminTasksPage;

   public Top100Hospitals_UserProvisioningPage(WebDriver driver) throws IOException
   {
      this.driver = driver;
      PageFactory.initElements(this.driver, this);
      WebDriverWait wait = new WebDriverWait(this.driver, 20);
     
      try
      {
         wait.until(ExpectedConditions.visibilityOf(UserProvisioning));
      }
      catch (Exception e)
      {
         extentReport.FAIL(driver,
                           "Top100Hospitals_UserProvisioningPage",
                           "User provisioning page is not displayed");
         log.error("User provisioning page is not displayed");
      }

   }

   /**
    * click log out link
    * @throws IOException
    */
   public void clickLogOut() throws IOException
   {
      
      click(driver,"log out",LogoutLink);
   }

   /**
    * click on the first benchmark
    * @return
    * @throws IOException
    */
   public Top100Hospitals_AdministrativeTasksPage clickNationalBenchmark2013() throws IOException
   {
      
      click(driver,"first benchmark",NationalBenchmark2013);
      adminTasksPage = PageFactory
            .initElements(driver,
                          Top100Hospitals_AdministrativeTasksPage.class);
      return adminTasksPage;
   }

   /**
    * click on create cardio study group link
    * @return
    * @throws IOException 
    */
   public Top100Hospitals_CreateStudyGroupPage clickCreateCardioStudyGrp() throws IOException
   {
      click(driver,"create cardio study group",createCardioStudyGrp);
      createStudyGrpPage = PageFactory
            .initElements(driver, Top100Hospitals_CreateStudyGroupPage.class);
      return createStudyGrpPage;
   }

   /**
    * get the list of cardiovascular study groups in the page
    * @return list
    */
   public List<Integer> getListOfCardioStudyGrps()
   {
      List<Integer> listOfYrs = new ArrayList<Integer>();

      List<WebElement> li = driver.findElements(By
            .xpath("//td[contains(text(),'Cardiovascular Benchmark Study Group -')]"));
      System.out.println(li.size());
      for (int i = 0; i < li.size(); i++)
      {
         String text = li.get(i).getText();
         String lastFourChar;
         lastFourChar = text.substring(text.length() - 4);
         System.out.println(lastFourChar);
         listOfYrs.add(i, Integer.parseInt(lastFourChar));
      }

      return listOfYrs;
   }

   /**
    * verify success msg after study group created successfully
    */
   public void verifyStudyGrpCreationSuccessMsg()
   {
      Assert.assertEquals(studyGrpCreationSuccessMsg.getText(),
                          "Study Group Creation Successful");
   }

   /**
    * get the list of total rows of cardiovascular benchmarks in user provisioning
    * @return
    */
   public Top100Hospitals_AdministrativeTasksPage totalRowsofCardioBenchmarkInUserProvTable()
   {

      List<WebElement> totalRows = userProvTable.findElements(By.tagName("tr"));

      for (WebElement col : totalRows)
      {
         List<WebElement> secondCol = col.findElements(By.xpath("//td[2]"));
         for (int i = 1; i < secondCol.size(); i++)
         {
            String cellValue = secondCol.get(i).getText();
            System.out.println("CellValue------------" + cellValue);
            System.out.println(i);
            if (cellValue.equals("Cardiovascular Benchmarks Study Winners"))
            {
               i++;
               System.out.println("xpath of cardio-----------/tr" + i + "/td");
               driver.findElement(By.xpath("//*[@id=\"id_of_tablebody\"]/tr["
                     + i + "]/td[2]/a")).click();
               break;
            }
            else
            {
               continue;
            }

         }
         break;
      }
      adminTasksPage = PageFactory
            .initElements(driver,
                          Top100Hospitals_AdministrativeTasksPage.class);
      return adminTasksPage;

   }



}
