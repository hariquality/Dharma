package com.ibm.webapp.pageObjects.carenotes;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.webapp.utils.Selenese;

public class CareNotes_SelectDocumentsPage extends Selenese {

	protected final WebDriver driver;

	@FindBy(xpath = "//div[@id = 'docTableContainer']")
	private WebElement docTableContainer;

	@FindBy(xpath = "//*[contains(text(),'LOGOUT')]")
	private WebElement logoutLink;

	public CareNotes_SelectDocumentsPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		WebDriverWait wait = new WebDriverWait(this.driver, 20);
		wait.until(ExpectedConditions.visibilityOf(docTableContainer));
	}

	public void LogOut() throws IOException {
		click(driver, "LOGOUT", logoutLink);
	}

}
