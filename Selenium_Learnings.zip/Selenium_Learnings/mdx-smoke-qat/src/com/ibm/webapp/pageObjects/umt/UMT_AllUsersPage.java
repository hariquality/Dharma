package com.ibm.webapp.pageObjects.umt;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.utils.Selenese;


public class UMT_AllUsersPage extends Selenese
{
   WebDriver driver;
   
   @FindBy(id="search.lastName_index_0")
   private WebElement SearchLastName;
   
   @FindBy(id="search.firstName_index_0")
   private WebElement SearchFirstName;

   @FindBy(id="umt.SearchUserForTHC")
   private WebElement UserSearch;
   
   @FindBy(xpath="//table[@cellspacing='1' and @cellpadding='5']//tr//td[1]/a")
   private WebElement selectSearchResult;

   

 

   public UMT_AllUsersPage(WebDriver driver)
   {
      this.driver = driver;
      PageFactory.initElements(driver, this);
      driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
   }

   public void LastName_SearchBox(String term){
      SearchLastName.sendKeys(term);}
   
   public void FirstName_SearchBox(String term){
      SearchFirstName.sendKeys(term);   }
   
   public void clickUserSearchButton_valid(){
      UserSearch.click();}
   
   public UMT_EditUserNamePage SelectUserResult(){
      selectSearchResult.click();
      UMT_EditUserNamePage editPage = PageFactory.initElements(driver, UMT_EditUserNamePage.class);
      return editPage;   
   }

}
