package com.ibm.webapp.pageObjects.mdx;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibm.webapp.utils.Selenese;

/**
 * @author APeavy
 * 
 */
public class DrugComparisonPage extends Selenese {
	private final WebDriver driver;

	@FindBy(id = "WordWheel_SearchTerm_index_0")
	private WebElement searchTermInputBox;

	@FindBy(xpath = "//input[@title='Submit']")
	private WebElement submitButton;

	@FindBy(xpath = "//a/img[contains(@src,'arrow_next.gif')]")
	private WebElement moveDrugRightButton;

	@FindBy(xpath = "//div[@id = 'WordWheel_list']/div")
	private List<WebElement> matchingDrugNames;

	@FindBy(id = "WordWheel_list")
	private WebElement wwList;

	public DrugComparisonPage(WebDriver driver) throws IOException {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		waitForElementVisibility(driver, wwList);
		
	}

	/**
	 * Use this method to type the new drug name in search box and wait for some
	 * time to filter the results
	 * 
	 * @param searchInput
	 *            = pass the searchInput to be entered in textBox
	 * @throws IOException
	 */

	public void typeNewCharsIntoSearchBoxAndWaitForWordWheel(String searchInput) throws IOException {

		try {
			// clearField(driver,searchTermInputBox);

			sendKeys(driver, " search box", searchTermInputBox, searchInput);
			Thread.sleep(4000);
			extentReport.PASS("Drug name is entered and wait for word wheel to filter the results",
					searchInput +" is entered into the search box and waited for word wheel to filter the results");
			log.info(searchInput +" is entered into the search box and waited for word wheel to filter the results");
		} catch (Exception e) {
			extentReport.FAIL(driver,
					searchInput +" is not entered into the search box and waited for word wheel to filter the results",
					e.getMessage());
			logERROR(searchInput +" is not entered into the search box and waited for word wheel to filter the results",
					e);
		}

	}

	/**
	 * Use this method to move the drug from left to right section by clicking
	 * the arrow mark
	 * 
	 * @param drugName
	 *            = pass the drug name and compared with the list of elements
	 *            and click on target one
	 * @throws IOException
	 */

	public void moveDrugFromLeftToRight(String drugName) throws IOException {
		try {

			Iterator<WebElement> itr = matchingDrugNames.iterator();
			System.out.println("matchingDrugNames size=" + matchingDrugNames.size());
			while (itr.hasNext()) {
				WebElement element = itr.next();
				if (element.getAttribute("fullname").compareTo(drugName) == 0) {
					click(driver, "Drug name ", element);
					click(driver, "Arrow mark ", moveDrugRightButton);
					
					break;
				}
			}
			
		} catch (Exception e) {
			extentReport.FAIL(driver,
					"Arrow mark is not clicked "+drugName+" is not moved from left to right",
					e.getMessage());
			logERROR("Arrow mark is not clicked "+drugName+" is not moved from left to right", e);
		}

	}

	/**
	 * Use this method to verify the drug comparison results page is reached by
	 * clicking on submit button in drug comparison page
	 * 
	 * @throws IOException
	 */

	public DrugCompareResultsPage clickSubmitButton() throws IOException {
		try {
			click(driver, "Submit button", submitButton);
			Thread.sleep(3000);
			
		} catch (Exception e) {
			extentReport.FAIL(driver, "Submit button is not clicked", e.getMessage());
			logERROR("Submit button is not clicked", e);
		}
		return PageFactory.initElements(driver, DrugCompareResultsPage.class);
	}

}
