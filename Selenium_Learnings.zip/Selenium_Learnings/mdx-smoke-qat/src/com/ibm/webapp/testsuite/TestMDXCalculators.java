package com.ibm.webapp.testsuite;

import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.pageObjects.LoginPage;
import com.ibm.webapp.pageObjects.mdx.MDX_CalculatorPage;
import com.ibm.webapp.pageObjects.mdx.MDX_HomePage;
import com.ibm.webapp.utils.TestBase;

public class TestMDXCalculators extends TestBase {
	/**
	 * TC222285,TC222362,TC222389
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "MDX", "All" })
	public void TC_testMDXCalculators() throws Exception {
		extentReporter.createTest("TestMDXCalculator",
				"Testing Alcohol/Ethylene Glycol,Norepinephrine Pediatric and BMI calculators in MDX calculators");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		MDX_CalculatorPage mdxCalcPage = mdxPage.clickCalculator();
		mdxCalcPage.alcEthyleneGlycolBloodLevel();
		mdxCalcPage.norepinephrinePediatric();
		mdxCalcPage.bmiCalculator();
		mdxPage.LogOut();
	}

}
