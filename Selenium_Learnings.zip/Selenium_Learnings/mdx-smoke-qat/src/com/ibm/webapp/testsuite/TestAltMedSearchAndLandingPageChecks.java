package com.ibm.webapp.testsuite;

import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.pageObjects.LoginPage;
import com.ibm.webapp.pageObjects.mdx.DrugLandingPage;
import com.ibm.webapp.pageObjects.mdx.MDX_HomePage;
import com.ibm.webapp.utils.TestBase;

public class TestAltMedSearchAndLandingPageChecks extends TestBase {

	/**
	 * Use this method to verify the related results sections is having the sub
	 * sections of quick, In-depth and all answers tab by searching the Altmed
	 * 
	 * @throws Exception
	 */

	@Test(groups = {"MDX", "All" })
	public void TC_RelatedResultsOfAltMedSearch() throws Exception {
		extentReporter.createTest("TestRelatedResultsOfAltMedSearch",
				"Verifying the related results of quick,Indepth and all results tab by searching the AltMed.");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		DrugLandingPage drugLand = mdxPage.searchAndReturnAltMedLandingPage("Ginger");
		drugLand.clickOnQuickTab();
		drugLand.isRelatedResultsHeadingdisplayed("Quick Answer");
		drugLand.verifyRelatedResults("Quick Answer",
				"Related Results\nDrug\nToxicology\nInteractions Handouts\nMartindale\nPatient Handouts\nProduct Lookup - Martindale\nProduct Lookup - Tox & Drug");
		Thread.sleep(2000);
		drugLand.clickOnInDepthTab();
		drugLand.isRelatedResultsHeadingdisplayed("In-Depth Answer");
		drugLand.verifyRelatedResults("In-Depth Answer",
				"Related Results\nDrug\nToxicology\nInteractions Handouts\nMartindale\nPatient Handouts\nProduct Lookup - Martindale\nProduct Lookup - Tox & Drug");
		drugLand.clickOnAllResultsTab();
		drugLand.isRelatedResultsHeadingdisplayed("All Results");
		drugLand.verifyRelatedResults("All Results",
				"Related Results\nDrug\nToxicology\nInteractions Handouts\nMartindale\nPatient Handouts\nProduct Lookup - Martindale\nProduct Lookup - Tox & Drug");
		mdxPage.LogOut();
		log.info("****************TC_RelatedResultsOfALtMedSearch Completed*******************\n");

	}

	/**
	 * Use this method to verify the content availability and functionality of
	 * header and sun headers of quick, In-Depth and all results tab by
	 * searching the AltMed
	 * 
	 * @throws Exception
	 */

	@Test(groups = {"MDX", "All" })
	public void TC_ContentAvailabilityOfQuickIndepthAndAllResultstabOfAltMedSearch() throws Exception {
		extentReporter.createTest("TestContentAvailabilityOfQuickIndepthAndAllResultstabOfAltMedSearch",
				"Testing the availability of contents and functionality of header and sun headers of quick, In-Depth and all results tab by searchng the AltMed.");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		DrugLandingPage drugLand = mdxPage.searchAndReturnAltMedLandingPage("Honey");
		drugLand.clickOnQuickTab();
		drugLand.isContentdisplayedForQuickAnswerTab("Name Info", "Class");
		drugLand.clickOnInDepthTab();
		drugLand.isContentdisplayedForInDepthAnswerTab("Pharmacokinetics", "Onset And Duration");
		drugLand.clickOnAllResultsTab();
		drugLand.verifyFilteringContentOfAllResultsTab("Alternative Medicine");
		mdxPage.LogOut();
		log.info(
				"****************TC_TestContentAvailabilityOfQuickIndepthAndAllResultstabOfAltMedSearch Completed*******************\n");
	}

}