package com.ibm.webapp.testsuite;

import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.pageObjects.LoginPage;
import com.ibm.webapp.pageObjects.mdx.DrugLandingPage;
import com.ibm.webapp.pageObjects.mdx.MDX_HomePage;
import com.ibm.webapp.utils.TestBase;

public class TestDiseaseSearch extends TestBase {

	/**
	 * Use this method to verify the relevant results are displayed in the
	 * related results section of quick, In-depth and all answers tab by
	 * searching the disease
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "MDX", "All" })
	public void TC_RelatedResultsOfDiseaseSearch() throws Exception {
		extentReporter.createTest("TestRelatedResultsOfDiseaseSearch",
				"Verifying the related results of quick,Indepth and all results tab by searching the disease.");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		DrugLandingPage drugLand = mdxPage.searchAndReturnDiseasesLandingPage("Diabetes mellitus");
		drugLand.clickOnQuickTab();
		drugLand.isRelatedResultsHeadingdisplayed("Quick Answer");
		drugLand.verifyRelatedResults("Quick Answer",
				"Related Results\nAlternative Medicine\nDrug\nToxicology\nClinical Checklist\nDisease Other Titles");
		Thread.sleep(2000);
		drugLand.clickOnInDepthTab();
		drugLand.isRelatedResultsHeadingdisplayed("In-Depth Answer");
		drugLand.verifyRelatedResults("In-Depth Answer",
				"Related Results\nAlternative Medicine\nDrug\nToxicology\nClinical Checklist\nDisease Other Titles");
		drugLand.clickOnAllResultsTab();
		drugLand.isRelatedResultsHeadingdisplayed("All Results");
		drugLand.verifyRelatedResults("All Results",
				"Related Results\nAlternative Medicine\nDrug\nToxicology\nClinical Checklist\nDisease Other Titles");
		mdxPage.LogOut();
		log.info("****************TC_RelatedResultsOfDiseaseSearch Completed*******************\n");

	}

	/**
	 * Use this method to verify the headers and sub headers are displayed in
	 * the quick or In-depth answer tab by searching the disease
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "MDX", "All" })
	public void TC_verifyHeaderAndSubheaderOfDiseaseSearch() throws Exception {
		extentReporter.createTest("TestVerifyHeaderAndSubheaderOfDiseaseSearch",
				"Testing the Drug comparison results by searchng the drugs.");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		DrugLandingPage drugLand = mdxPage.searchAndReturnDiseasesLandingPage("Diabetes mellitus");
		drugLand.clickOnQuickTab();
		drugLand.verifyHeaderAndSubheader("Quick Answer", "Treatment",
				"Drug Therapy\nProcedural Therapy\nNon-Procedural Therapy");
		drugLand.clickOnInDepthTab();
		drugLand.verifyHeaderAndSubheader("In-Depth Answer", "History And Physical",
				"Summary\nMedical History\nFindings");
		mdxPage.LogOut();
		log.info("****************TC_verifyHeaderAndSubheaderOfDiseaseSearch Completed*******************\n");
	}
}
