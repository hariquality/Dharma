package com.ibm.webapp.testsuite;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.pageObjects.LoginPage;
import com.ibm.webapp.pageObjects.mdx.DrugMonograph_DrugLandingPage;
import com.ibm.webapp.pageObjects.mdx.DrugMonograph_Homepage;
import com.ibm.webapp.pageObjects.mdx.DrugMonograph_ViewFullDocumentPage;
import com.ibm.webapp.pageObjects.mdx.EnteralFormulaPage;
import com.ibm.webapp.pageObjects.mdx.MDX_HomePage;
import com.ibm.webapp.utils.TestBase;

public class TestNeofaxPediatricSearch extends TestBase {

	/**
	 * Use this method to verify the drug search for drug monograph module and
	 * also validation of ViewFullDocument section for NEOPED users Scenario
	 * Drug:acetaminophen.
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "Neofax", "All" })
	public void TC_TestDrugMonograh() throws Exception {
		extentReporter.createTest("TestDrugMonograh",
				"Verifying of drug search for drug monograph module and also validation of ViewFullDocument section for NEOPED users Scenario ");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("NeoPedUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		DrugMonograph_Homepage dm = mdxPage.clickTab("NeoPed");
		DrugMonograph_DrugLandingPage dmLandPage = dm.selectDrugByClicking("ac", "acetaminophen");
		dmLandPage.verifySearchInputText_LandingPage("acetaminophen");
		dmLandPage.getNeofaxUtility().isTabHighlighted("Neo", "DM");
		dmLandPage.getNeofaxUtility().isTabDisplayed("Ped");
		dmLandPage.getNeofaxUtility().clickTab("Ped", "DM");
		dmLandPage.verifyHeaderSectionName("Ped");
		dmLandPage.verifysubHeaderSectionName("Ped");
		DrugMonograph_ViewFullDocumentPage viewFullPage = dmLandPage.clickViewFullDoc();
		viewFullPage.enterSearchInput("and", "Ped");
		mdxPage.LogOut();
		Thread.sleep(1000);
		log.info("****************TC_TestDrugMonograh Completed*******************\n");

	}

	/**
	 * Use this method to verify the drug search for Enteral comparison between
	 * 3 drugs and validation of product notes for NEOPED users Scenario Drugs:
	 * Similac� PM 60/40, Similac� Soy Isomil� (19 cal/fl oz), PTHM + Enfamil�
	 * Human Milk Fortifier Acidified Liquid 24
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "Neofax", "All" })
	public void TC_TestEnteralFormula() throws Exception {
		extentReporter.createTest("TestEnteralFormula",
				"Verification of drug search for Enteral comparison between 3 drugs and validation of product notes");
		Thread.sleep(2000);
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("NeoPedUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		DrugMonograph_Homepage dm = mdxPage.clickTab("NeoPed");
		EnteralFormulaPage ef = dm.getNeofaxUtility().clickEF_tab();
		ef.getNeofaxUtility().isTabHighlighted("Neo", "EF");
		ef.getNeofaxUtility().scrollUp(150);
		ef.clickClearButton();
		ef.selectRadio("Per Both");
		ef.selectFormula("Neo", "Similac� PM 60/40");
		ef.selectFormula("Neo", "Similac� Soy Isomil� (19 cal/fl oz)");
		ef.selectFormula("Neo", "PTHM + Enfamil� Human Milk Fortifier Acidified Liquid 24");
		ef.clickDisplayButton();
		boolean ThreeformulaDisplayedinNutrientTable = ef.verifySelectedFormulaName(new String[] { "Similac� PM 60/40",
				"Similac� Soy Isomil� (19 cal/fl oz)", "PTHM + Enfamil� Human Milk Fortifier Acidified Liquid 24" },
				"Nutrient");
		boolean perBothThreeFormulaName = ef.formatToBeDisplayed("Per Both", 3);
		Assert.assertTrue(perBothThreeFormulaName, "Expected Display Format is not displayed");
		Assert.assertTrue(ThreeformulaDisplayedinNutrientTable,
				"Expected FormulaName is not displayed in Nutrient Table");
		mdxPage.LogOut();
		log.info("****************TC_TestEnteralFormula Completed*******************\n");
	}

}