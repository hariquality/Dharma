package com.ibm.webapp.testsuite;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.pageObjects.LoginPage;
import com.ibm.webapp.pageObjects.mdx.DrugInteractionsHomePage;
import com.ibm.webapp.pageObjects.mdx.DrugInteractionsResultsPage;
import com.ibm.webapp.pageObjects.mdx.MDX_HomePage;
import com.ibm.webapp.utils.TestBase;

public class TestDrugInteractions extends TestBase {

	@Test(groups = { "MDX", "All" })

	public void TC_testDrugInteractionResult() throws IOException, InterruptedException {
		extentReporter.createTest("TC_testDrugInteraction", "Testing the Drug Interaction functionality");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		DrugInteractionsHomePage diPage = mdxPage.clickOnDrugInteractionsToolbarLink();
		diPage.typeNewCharsIntoSearchBoxAndWaitForWordWheel("acetaminophen");
		diPage.moveDrugFromLeftToRight("Acetaminophen");
		DrugInteractionsResultsPage diResultPage = diPage.clickSubmitButtonSingle();
		String firstDrugDrugIntSummary = diResultPage.getFirstDrugDrugInteractionSummary();
		assertEquals(firstDrugDrugIntSummary, "ISONIAZID [Systemic] -- ACETAMINOPHEN [Systemic]");
		diResultPage.isModifyButtonDisplayed();
		diResultPage.isSeverityTextEqualTo("All");
		diResultPage.clickSeverityBtn();
		diResultPage.clickSeverityUpdateBtn();
		diResultPage.isDocTextEqualTo("All");
		diResultPage.clickDocBtn();
		diResultPage.clickDocUpdateBtn();
		diResultPage.isTypeTextEqualTo("All");
		diResultPage.clickTypeBtn();
		diResultPage.clickTypeUpdateBtn();
		mdxPage.LogOut();
	}

	@Test(groups = { "MDX", "All" })

	public void TC_testDrugInteractionJumptoLinks() throws IOException, InterruptedException {
		extentReporter.createTest("TC_testDrugInteractionJumptoLinks",
				"Testing the Drug Interaction Jump to functionality");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		DrugInteractionsHomePage diPage = mdxPage.clickOnDrugInteractionsToolbarLink();
		diPage.typeNewCharsIntoSearchBoxAndWaitForWordWheel("acetaminophen");
		diPage.moveDrugFromLeftToRight("Acetaminophen");
		DrugInteractionsResultsPage diResultPage = diPage.clickSubmitButtonSingle();
		diResultPage.getJumpToLinks("Jump To");
		diResultPage.clickOnJumpToLink();
		diResultPage.clickModifyInteraction();
		mdxPage.LogOut();
	}
}
