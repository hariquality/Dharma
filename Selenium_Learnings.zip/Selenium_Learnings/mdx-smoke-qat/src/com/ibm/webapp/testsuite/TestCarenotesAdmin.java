package com.ibm.webapp.testsuite;

import java.io.IOException;
import java.util.Calendar;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.pageObjects.LoginPage;
import com.ibm.webapp.pageObjects.carenotes.CareNotes_HomePage;
import com.ibm.webapp.pageObjects.carenotes.CareNotes_SelectDocumentsPage;
import com.ibm.webapp.pageObjects.carenotesadmin.CareNotesAdmin_AddImagePage;
import com.ibm.webapp.pageObjects.carenotesadmin.CareNotesAdmin_DocumentsTabPage;
import com.ibm.webapp.pageObjects.carenotesadmin.CareNotesAdmin_ImagesTabPage;
import com.ibm.webapp.pageObjects.carenotesadmin.CareNotesAdmin_LocationPage;
import com.ibm.webapp.pageObjects.carenotesadmin.CareNotesAdmin_PropertiesTabPage;
import com.ibm.webapp.pageObjects.carenotesadmin.CareNotesAdmin_PublishUnpublishDocPage;
import com.ibm.webapp.utils.TestBase;

public class TestCarenotesAdmin extends TestBase {
	@Test(groups = { "CarenotesAdmin", "All" })
	public void TC_testCreatePublishUnPublishSaveNotes() throws IOException, InterruptedException {
		extentReporter.createTest("TestCarenotesAdminCreateSaveNote",
				"Testing create and publish save note functionality in Carenotes Admin");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("careNotesAdminUser");
		CareNotesAdmin_LocationPage carenotesLocPage = (CareNotesAdmin_LocationPage) gateWay
				.goToApplication("CarenotesAdmin");
		CareNotesAdmin_PropertiesTabPage propPage = carenotesLocPage.clickOnLocation("Auto'ICN");
		CareNotesAdmin_DocumentsTabPage docPage = propPage.clickDocumentsTab();
		docPage.clickCreateLink();
		docPage.clickcreateDocFromScratch();
		Calendar cal = Calendar.getInstance();
		String snname = "Care and Condition Title SaveNote" + cal.get(Calendar.SECOND) + cal.get(Calendar.MILLISECOND);
		docPage.enterTitleText(snname);
		docPage.enterDocumentDescriptionText("Care and Condition SaveNote description");
		docPage.verifyRbtn();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true)", docPage.documentDescriptionText);
		docPage.selectDocumentType("General Information");
		docPage.selectLanguage("English");
		docPage.enterArea("sampletest");
		JavascriptExecutor jc = (JavascriptExecutor) driver;
		jc.executeScript("arguments[0].scrollIntoView(false)", docPage.aboutUs);
		docPage.clickPublish();
		docPage.verifyPublishMessage(snname, "document is published to the Auto'ICN location.");
		// search in carenotes for the savenotes created above and verify
		// whether
		// it is present
		login = launchApp();
		GatewayPage gateWay1 = login.loginAs("careNotesAdminUser");
		CareNotes_HomePage carenotesSearchPage = (CareNotes_HomePage) gateWay1.goToApplication("CareNotes");
		carenotesSearchPage.chooseLocation("Auto'ICN");
		CareNotes_SelectDocumentsPage carenotesSelectDocPage = carenotesSearchPage.search(snname);
		carenotesSelectDocPage.LogOut();
		// unpublish the published savenotes
		login = launchApp();
		gateWay = login.loginAs("adminuser");
		carenotesLocPage = (CareNotesAdmin_LocationPage) gateWay.goToApplication("CarenotesAdmin");
		propPage = carenotesLocPage.clickOnLocation("Auto'ICN");
		docPage = propPage.clickDocumentsTab();
		docPage.enterSearchForText(snname);
		CareNotesAdmin_PublishUnpublishDocPage pubUnpubPage = docPage.clicksearchbutton();
		pubUnpubPage.clickdocumentLink(snname);
		pubUnpubPage.unselectAllCheckbx();
		pubUnpubPage.clickSaveChanges();
		pubUnpubPage.verifyunPublishMessage("Selected Documents were unpublished from this Location successfully.");
		pubUnpubPage.clickmicromedexTitle();
		// verify whether the unpublished savenotes in not present in the
		// carenotes app
		carenotesSearchPage = (CareNotes_HomePage) gateWay.goToApplication("CareNotes");
		carenotesSearchPage.chooseLocation("Auto'ICN");
		carenotesSearchPage.searchUnpublished(snname);
		carenotesSelectDocPage.LogOut();

	}

	@Test(groups = { "CarenotesAdmin", "All" })
	public void TC_testUploadImageJpg() throws IOException, Exception {
		extentReporter.createTest("TestCarenotesAdminCreateSaveNote",
				"Testing create and publish save note functionality in Carenotes Admin");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("careNotesAdminUser");
		CareNotesAdmin_LocationPage carenotesLocPage = (CareNotesAdmin_LocationPage) gateWay
				.goToApplication("CarenotesAdmin");
		CareNotesAdmin_PropertiesTabPage propPage = carenotesLocPage.clickOnLocation("Auto'ICN");
		CareNotesAdmin_ImagesTabPage imgPage = propPage.clickImagesTab();
		CareNotesAdmin_AddImagePage addImagePage = imgPage.clickNewImageButton();
		addImagePage.clickChooseImageButton();
		Calendar cal = Calendar.getInstance();
		String imgNameConcat = "QA_TestImage" + cal.get(Calendar.SECOND) + cal.get(Calendar.MILLISECOND);
		addImagePage.enterImgTitleTxt(imgNameConcat);
		addImagePage.enterImgDescriptionTxt(".jpg image upload using robot");
		CareNotesAdmin_ImagesTabPage imgPage1 = addImagePage.clickSaveButton();
		imgPage1.imageValidation(imgNameConcat);
		imgPage1.LogOut();

	}

}
