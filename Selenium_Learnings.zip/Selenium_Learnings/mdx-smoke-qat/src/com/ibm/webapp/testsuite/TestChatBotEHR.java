package com.ibm.webapp.testsuite;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.mdx.ChatBotEHRPage;
import com.ibm.webapp.utils.TestBase;

public class TestChatBotEHR extends TestBase {

	/**
	 * Use this method to Validate the EHR chatbot application functionality of
	 * full size window with using User name and password by using IP and
	 * validate the Watson assistant using query Query: adult dose for 9vHPV for
	 * anal cancer
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "EHR", "All" })
	public void TC_TestChatBotEHRForFullWindowWithUserNameAndPassword() throws Exception {
		extentReporter.createTest("TestChatBotEHRForFullSizeWindowWithUserNameAndPassword",
				"Validation of EHR chatbot application functionality of full size window with using User name and password");
		ChatBotEHRPage chatPage = goStraightToEHRwatsonaccessuiWithUserNamePasswordForFullWindow("mdxUser");
		chatPage.enterText("show me the Azithromycin adult dosage for Bacterial conjunctivitis?");
		String quickAnswersLink = chatPage.getLastLinkText("Quick");
		String inDepthAnswersLink = chatPage.getLastLinkText("InDepth");
		chatPage.clickOnLastResponseATag("Quick");
		boolean chatBotVisibility = chatPage.isChatBotVisible("LandingPage");
		boolean quickAnswersValidation = chatPage.verifyNavItemTabSelectionandSectionName("Quick", "Adult Dosing");
		chatPage.switchWindowTo("librarian/watsonaccess");
		chatPage.clickOnLastResponseATag("InDepth");
		boolean chatBotVisibility1 = chatPage.isChatBotVisible("LandingPage");
		boolean InDepthAnswersValidation = chatPage.verifyNavItemTabSelectionandSectionName("InDepth", "Adult Dosing");
		chatPage.switchWindowTo("librarian/watsonaccess");
		Assert.assertEquals("Quick Answers Adult Dosing for Azithromycin", quickAnswersLink);
		Assert.assertEquals("In-Depth Answers Adult Dosing for Azithromycin", inDepthAnswersLink);
		Assert.assertTrue(quickAnswersValidation, "Problems in Navigating from EHR tool to QuickAnswers Page");
		Assert.assertTrue(InDepthAnswersValidation, "Problems in Navigating from EHR tool to In-Depth Answers Page");
		Assert.assertFalse(chatBotVisibility && chatBotVisibility1,
				"AskWatson option is enabled in MDX Landing Page,when navigating from EHR tool");

		log.info(
				"****************TC_TestChatBotEHRForFullSizeWindowWithUserNameAndPassword Completed*******************\n");

	}

	/**
	 * Use this method to Validate the EHR chatbot application functionality of
	 * small window servlets(Javascript) by using IP and validate the Watson
	 * assistant using query Query: adult dose for 9vHPV for anal cancer
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "EHR", "All" })
	public void TC_TestChatBotEHRForSmallWindowWithIPAuthenticate() throws Exception {
		extentReporter.createTest("TestChatBotEHRForSmallWindowWithIPAuthenticate",
				"Validation of EHR chatbot application functionality of small window servlets(Javascript) with IP authenticate");
		ChatBotEHRPage chatPage = goStraightToEHRwatsonaccessuiWithIP();
		chatPage.enterText("adult dose for 9vHPV for anal cancer");
		String quickAnswersLink = chatPage.getLastLinkText("Quick");
		String inDepthAnswersLink = chatPage.getLastLinkText("InDepth");
		chatPage.clickOnLastResponseATag("Quick");
		boolean chatBotVisibility = chatPage.isChatBotVisible("LandingPage");
		boolean quickAnswersValidation = chatPage.verifyNavItemTabSelectionandSectionName("Quick", "Adult Dosing");
		chatPage.switchWindowTo("librarian/watsonaccess");
		chatPage.clickOnLastResponseATag("InDepth");
		boolean chatBotVisibility1 = chatPage.isChatBotVisible("LandingPage");
		boolean InDepthAnswersValidation = chatPage.verifyNavItemTabSelectionandSectionName("InDepth", "Adult Dosing");
		chatPage.switchWindowTo("librarian/watsonaccess");
		chatPage.enterText("clear");
		Assert.assertEquals("Quick Answers Adult Dosing for Human Papillomavirus 9-valent Vaccine, Recombinant",
				quickAnswersLink);
		Assert.assertEquals("In-Depth Answers Adult Dosing for Human Papillomavirus 9-valent Vaccine, Recombinant",
				inDepthAnswersLink);
		Assert.assertTrue(quickAnswersValidation, "Problems in Navigating from EHR tool to QuickAnswers Page");
		Assert.assertTrue(InDepthAnswersValidation, "Problems in Navigating from EHR tool to In-Depth Answers Page");
		Assert.assertFalse(chatBotVisibility && chatBotVisibility1,
				"AskWatson option is enabled in MDX Landing Page,when navigating from EHR tool");
		// driver.close();
		log.info("****************TC_TestChatBotEHRForSmallWindowWithIPAuthenticate Completed*******************\n");

	}

}
