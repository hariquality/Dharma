package com.ibm.webapp.testsuite;

import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.healthcheck.HealthCheckApplicationPage;
import com.ibm.webapp.pageObjects.healthcheck.HealthCheckServicesPage;
import com.ibm.webapp.utils.TestBase;

public class TestHealthCheck extends TestBase {

	@Test(groups = { "Healthcheck", "All" })
	public void TC_testHealthCheckApplication() throws Exception {
		extentReporter.createTest("HealthCheckApplicationPage", "To check for the Application/Module Status");
		HealthCheckApplicationPage health = healthCheckAppLaunch();
		health.checkHealth();
		Thread.sleep(2000);
	}

	@Test(groups = { "Healthcheck", "All" })
	public void TC_testHealthCheckServices() throws Exception {
		extentReporter.createTest("HealthCheckServicesPage", "To check for the Service Status");
		HealthCheckServicesPage health = healthCheckServiceLaunch();
		health.checkServiceStatus();
	}
}
