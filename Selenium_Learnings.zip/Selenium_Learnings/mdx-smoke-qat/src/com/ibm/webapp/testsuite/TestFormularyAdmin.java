package com.ibm.webapp.testsuite;

import java.io.IOException;

import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.pageObjects.LoginPage;
import com.ibm.webapp.pageObjects.formulary.Formulary_HomePage;
import com.ibm.webapp.pageObjects.formularyadmin.FormularyAdmin_EditItemPage;
import com.ibm.webapp.pageObjects.formularyadmin.FormularyAdmin_EditListPage;
import com.ibm.webapp.pageObjects.formularyadmin.FormularyAdmin_FilesPage;
import com.ibm.webapp.pageObjects.formularyadmin.FormularyAdmin_HomePage;
import com.ibm.webapp.pageObjects.formularyadmin.FormularyAdmin_PublishPage;
import com.ibm.webapp.pageObjects.formularyadmin.FormularyAdmin_SectionsPage;
import com.ibm.webapp.pageObjects.formularyadmin.FormularyAdmin_SettingsPage;
import com.ibm.webapp.utils.TestBase;

public class TestFormularyAdmin extends TestBase {
	
	@Test(groups = { "FormularyAdmin", "All" })
	public void TC_testCreatePublishFormulary() throws IOException, InterruptedException {
		extentReporter.createTest("TestCreatePublishFormulary",
				"Testing create and publish formulary functionality in Formulary Admin");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("formularyAdminUser");
		FormularyAdmin_HomePage homePage = (FormularyAdmin_HomePage) gateWay.goToApplication("FormularyAdmin");
		FormularyAdmin_SettingsPage settingsPage = homePage.clickOnCreateNew();
		String formularyName = settingsPage.enterFormularyName();
		settingsPage.createFormulary();
		settingsPage.verifyFormularyModifiedDate();
		settingsPage.verifyFormularyName(formularyName);
		settingsPage.selectFormularyCost("Both");
		settingsPage.enterCostandMeaning("$;$$", "<$5;$5-$10");
		settingsPage.addStatusTier("F;NF;ZT", "On Formulary;Non Formulary;Z To Delete");
		settingsPage.saveChanges("F;NF;ZT", "On Formulary;Non Formulary;Z To Delete");
		FormularyAdmin_EditListPage editListPage = settingsPage.clickOnEditList();
		editListPage.searchForDrug("Aspirin");
		editListPage.addDrugstoFormulary("ACETAMINOPHEN|AcetaDrinkNBRAND|");
		FormularyAdmin_EditItemPage editPage = editListPage.saveandEdit();
		editPage.selectItemFromList("AcetaDrink (OTC) (B): Tablet, Effervescent Oral route 500 MG");

		FormularyAdmin_PublishPage publishPage = homePage.clickOnPublish();
		homePage = publishPage.publishFormulary();
		homePage.clickmicromedexTitle();
		Formulary_HomePage formHomePage = (Formulary_HomePage) gateWay.goToApplication("Formulary");
		formHomePage.selectFormulary(formularyName);
		formHomePage.LogOut();

		// File upload in Formulary Admin
		login = launchApp();
		gateWay = login.loginAs("formularyAdminUser");
		homePage = (FormularyAdmin_HomePage) gateWay.goToApplication("FormularyAdmin");
		editListPage = homePage.selectFormulary(formularyName);
		FormularyAdmin_SectionsPage sectionsPage = editListPage.clickOnPharmacyInformation();
		FormularyAdmin_FilesPage filesPage = sectionsPage.clickOnFiles();
		String filePath = System.getProperty("user.dir") + "\\Uploads\\test doc.docx";
		filesPage.enterFileNameandUpload("fileSelenium", filePath);
		filesPage.isFileUploaded("fileSelenium");
		homePage.logout();

	}
}