package com.ibm.webapp.testsuite;

import java.io.IOException;
import java.util.List;

import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.top100hospitals.Top100Hospitals_AddUsersPage;
import com.ibm.webapp.pageObjects.top100hospitals.Top100Hospitals_AdministrativeTasksPage;
import com.ibm.webapp.pageObjects.top100hospitals.Top100Hospitals_CreateStudyGroupPage;
import com.ibm.webapp.pageObjects.top100hospitals.Top100Hospitals_CreateStudyUserPage;
import com.ibm.webapp.pageObjects.top100hospitals.Top100Hospitals_HomePage;
import com.ibm.webapp.pageObjects.top100hospitals.Top100Hospitals_LoginPage;
import com.ibm.webapp.pageObjects.top100hospitals.Top100Hospitals_UserProvisioningPage;
import com.ibm.webapp.utils.TestBase;

public class TestTop100Hospitals extends TestBase {

	@Test(groups = { "Top100Hospitals", "All" })
	public void TC_testCreateNewStudyGroup() throws IOException, InterruptedException {
		extentReporter.createTest("TestCreateNewStudyGroup", "Testing create new study group in top100");
		Top100Hospitals_HomePage homePage = launchtop100App();
		Top100Hospitals_LoginPage loginPage = homePage.ClickMemberLogin();
		homePage = loginPage.loginToTop100("top100user");
		Top100Hospitals_UserProvisioningPage userprovisioning = homePage.clickUserProvisioning();
		@SuppressWarnings("rawtypes")
		List l = userprovisioning.getListOfCardioStudyGrps();
		Top100Hospitals_CreateStudyGroupPage createStudyGrpPage = userprovisioning.clickCreateCardioStudyGrp();
		String year = createStudyGrpPage.verifyYearIsAlreadyCreatedInUserProv(l);
		userprovisioning = createStudyGrpPage.createStudyGroup(year);
		userprovisioning.clickLogOut();
	}

	@Test(groups = { "Top100Hospitals", "All" })
	public void TC_createNewCardioUser() throws Exception {
		extentReporter.createTest("TestCreateNewUser", "Testing create new cardio user in top100");
		Top100Hospitals_HomePage homePage = launchtop100App();
		Top100Hospitals_LoginPage loginPage = homePage.ClickMemberLogin();
		homePage = loginPage.loginToTop100("top100user");
		Top100Hospitals_UserProvisioningPage userprovisioning = homePage.clickUserProvisioning();
		Top100Hospitals_AdministrativeTasksPage administrativetask = userprovisioning
				.totalRowsofCardioBenchmarkInUserProvTable();
		Top100Hospitals_CreateStudyUserPage createStudyUserPage = administrativetask.click_createUserForGroup();
		administrativetask = createStudyUserPage.createNewUser();
		administrativetask.verifyStudyUserCreationSuccessMsg();
		administrativetask.click_removeUserForGroup();
		administrativetask.verifyStudyUserRemovalSuccessMsg();
		administrativetask.clickLogOut();
	}

	@Test(groups = { "Top100Hospitals", "All" })
	public void TC_AddUser() throws Exception {
		extentReporter.createTest("TestAddUserToGroup", "Testing add user to a group in top100");
		Top100Hospitals_HomePage homePage = launchtop100App();
		Top100Hospitals_LoginPage loginPage = homePage.ClickMemberLogin();
		homePage = loginPage.loginToTop100("top100user");
		Top100Hospitals_UserProvisioningPage userprovisioning = homePage.clickUserProvisioning();
		Top100Hospitals_AdministrativeTasksPage administrativetask = userprovisioning.clickNationalBenchmark2013();
		Top100Hospitals_AddUsersPage addusers = administrativetask.AddUserLogin();
		addusers.AddUsers();
		homePage.clickLogOut();
	}

	@Test(groups = { "Top100Hospitals", "All" })
	public void TC_testReportMapWithLoginCardio() throws Exception {
		extentReporter.createTest("TestReportMapWithLogin", "Testing report map with login in top100");
		Top100Hospitals_HomePage homePage = launchtop100App();
		Top100Hospitals_LoginPage loginPage = homePage.ClickMemberLogin();
		homePage = loginPage.loginToTop100("top100user");
		homePage.clickColorado();
		homePage.clickHospitalLink();
		homePage.clickCardioRadioButton();
		homePage.clickColorado();
		homePage.clickCardioNationalHospitalLink();
		homePage.clickLogOut();
	}

}
