package com.ibm.webapp.testsuite;

import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.pageObjects.LoginPage;
import com.ibm.webapp.pageObjects.umt.UMT_AllUsersPage;
import com.ibm.webapp.pageObjects.umt.UMT_EditUserNamePage;
import com.ibm.webapp.pageObjects.umt.UMT_HeaderPage;
import com.ibm.webapp.pageObjects.umt.UMT_HomePage;
import com.ibm.webapp.utils.TestBase;

public class TestUMTApp extends TestBase {

	@Test(groups = { "UMT", "All" })
	public void testuserGroup_AddNewGroup() throws Exception {
		extentReporter.createTest("TestAddNewUserGroupFunctionality", "Adding a new User Group in UMT");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("umtuser");
		UMT_HomePage umtHomePage = (UMT_HomePage) gateWay.goToApplication("UMT");
		UMT_AllUsersPage allusersrchPage = umtHomePage.clickAll_UsersPage();
		allusersrchPage.LastName_SearchBox("geogre");
		allusersrchPage.FirstName_SearchBox("san");
		allusersrchPage.clickUserSearchButton_valid();
		UMT_EditUserNamePage editUserPage = allusersrchPage.SelectUserResult();
		UMT_HeaderPage umtheaderPage = editUserPage.UserGroupLink();
		UMT_EditUserNamePage addUserPage = umtheaderPage.addNewUserLink();
		String uniqueName = RandomStringUtils.randomAlphabetic(8);
		addUserPage.UserGroupname(uniqueName);
		addUserPage.SaveUserGroupname();
		System.out.println("A new User group is created");
		addUserPage.getHeaderPage().logout();
	}

	/*
	 * @Test(priority = 2, groups = { "UMT","All" }) public void
	 * testUsers_AddNewUser() throws Exception { extentReporter
	 * .createTest("TestAddNewUserFunctionality",
	 * "Adding a new User in a User Group in UMT"); LoginPage login =
	 * launchApp(); GatewayPage gateWay = login.loginTo("adminuser");
	 * UMT_HomePage umtHomePage = (UMT_HomePage) gateWay
	 * .goToApplication("UMT"); UMT_AllUsersPage allusersrchPage
	 * =umtHomePage.clickAll_UsersPage();
	 * allusersrchPage.LastName_SearchBox("geogre");
	 * allusersrchPage.FirstName_SearchBox("san");
	 * allusersrchPage.clickUserSearchButton_valid(); UMT_EditUserNamePage
	 * editUserPage = allusersrchPage.SelectUserResult(); UMT_HeaderPage
	 * umtheaderPage = editUserPage.UserLink(); UMT_EditUserNamePage addUserPage
	 * =umtheaderPage.addNewUserLink(); String uniqueid =
	 * RandomStringUtils.randomAlphabetic(8); addUserPage.enterUserID(uniqueid);
	 * addUserPage.enterUserPwd("user*added"); String uniqueName =
	 * RandomStringUtils.randomAlphabetic(8);
	 * addUserPage.enterUserfirstName(uniqueName);
	 * addUserPage.CheckBoxActiveUser();
	 * addUserPage.enterUserlastName("testuser");
	 * addUserPage.EnterZipCode("56932");
	 * addUserPage.EnterJobTitle("Clicizian");
	 * addUserPage.Email_ID("sansung.geogre@care.com");
	 * addUserPage.CheckBoxCarenote(); addUserPage.EnterUserCityName("newyork");
	 * addUserPage.EnterUserStateName("DC");
	 * addUserPage.EnterUserCountryName("USA"); addUserPage.Savebutton();
	 * System.out.println("Save newly added user");
	 * umtHomePage.getHeaderPage().logout();
	 * 
	 * }
	 */
	@Test(groups = { "UMT", "All" })
	@SuppressWarnings("unused")
	public void testUsers_AddNewUser_Active() throws Exception {
		extentReporter.createTest("TestAddNewUserFunctionality", "Adding a new User in a User Group in UMT");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("umtuser");
		UMT_HomePage umtHomePage = (UMT_HomePage) gateWay.goToApplication("UMT");
		UMT_AllUsersPage allusersrchPage = umtHomePage.clickAll_UsersPage();
		allusersrchPage.LastName_SearchBox("geogre");
		allusersrchPage.FirstName_SearchBox("san");
		allusersrchPage.clickUserSearchButton_valid();
		UMT_EditUserNamePage editUserPage = allusersrchPage.SelectUserResult();
		UMT_HeaderPage umtheaderPage = editUserPage.UserLink();
		UMT_EditUserNamePage addUserPage = umtheaderPage.addNewUserLink();
		String uniqueid = RandomStringUtils.randomAlphabetic(8);
		addUserPage.enterUserID(uniqueid);
		addUserPage.enterUserPwd("user*added");
		String uniqueName = RandomStringUtils.randomAlphabetic(8);
		addUserPage.enterUserfirstName(uniqueName);
		addUserPage.enterUserlastName("testuser");
		addUserPage.EnterZipCode("56932");
		addUserPage.EnterJobTitle("Clicizian");
		addUserPage.Email_ID("sansung.geogre@care.com");
		addUserPage.CheckBoxCarenote();
		addUserPage.EnterUserCityName("newyork");
		addUserPage.EnterUserStateName("DC");
		addUserPage.EnterUserCountryName("USA");
		addUserPage.Savebutton();
		System.out.println("Save newly added user");
		addUserPage.getHeaderPage().logout();
		LoginPage login1 = launchApp();
		GatewayPage gateway1 = editUserPage.loginToApplicationFailure(uniqueid, "user*added");
	}

}
