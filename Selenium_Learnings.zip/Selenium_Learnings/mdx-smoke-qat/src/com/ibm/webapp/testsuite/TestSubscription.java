package com.ibm.webapp.testsuite;

import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.ibm.webapp.fileReader.ExcelReader;
import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.pageObjects.LoginPage;
import com.ibm.webapp.pageObjects.mdx.DC_DrugSelectionPage;
import com.ibm.webapp.pageObjects.mdx.DC_PatientInformationPage;
import com.ibm.webapp.pageObjects.mdx.DC_T22_Aliquot_IM;
import com.ibm.webapp.pageObjects.mdx.DC_T7_ContinuousInfusion_min;
import com.ibm.webapp.pageObjects.mdx.DC_Template_Utility;
import com.ibm.webapp.pageObjects.mdx.DrugMonograph_Homepage;
import com.ibm.webapp.pageObjects.mdx.MDX_HomePage;
import com.ibm.webapp.utils.TestBase;

/**
 * smoke test to verify the MDX subscriptions
 * 
 */

public class TestSubscription  extends TestBase {
	// excel constants
	public String fileName = "MDX_Subscription_TestData";

	public List<List<String>> _rowList = null;

	@Test(groups = { "Subscription", "All" })
	public void testSubscriptionForMDX_DI_IV() throws Exception {
		extentReporter.createTest("testSubscriptionForMDX_DI_IV",
				"Testing the MDX Application Tools subscription");
		ExcelReader.openExcelSheet(fileName, "Subscription");
		_rowList = ExcelReader.readDataFromExcel(1, 3, 6);
		for (List<String> columnList : _rowList) {
			LoginPage login = launchApp();
			GatewayPage gateWay = login.loginTo(columnList.get(1), columnList.get(2));
			MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
			mdxPage.validateToolLinkPage(columnList.get(0));
			mdxPage.LogOut();
			Thread.sleep(1000);
			mdxPage.clearCache();
		}
	}

	/**
	 * Verify the Drug Usage Information Functionality for Dosing Calculators
	 * for NEO users Scenario to verify when patient age = 0 days(i.e.,Today),
	 * USER = NEO for Drug:Sodium Nitroprusside Template7 Neo Today
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 */

	@Test(groups = { "Subscription", "All" })
	public void TC_TestDosingCalulatorForNeonatalDrugSearch() throws InterruptedException, IOException, ParseException {

		double weight = 2.3;
		extentReporter.createTest("TestDosingCalulatorForNeonatalDrugSearch",
				"Verification of Neonatal drug search and calculate the dose amount , dose volume and delivery rate by providing valid patient information");
		LoginPage login = launchApp();
		ExcelReader.openExcelSheet(fileName, "Subscription");

		_rowList = ExcelReader.readDataFromExcel(8, 9, 4);
		GatewayPage gateWay = login.loginTo(_rowList.get(0).toString().split(",")[0].toString().replace("[", ""),
				_rowList.get(0).toString().split(",")[1].toString().replace(" ", "").replace("]", ""));
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		DrugMonograph_Homepage dm = mdxPage.clickTab("Neo");
		DC_PatientInformationPage dc_pi = dm.getNeofaxUtility().clickDC_tab();
		dc_pi.enterBirthDate(0, 0, 0, "NA");
		dc_pi.selectGestationAge(28, 0);
		dc_pi.enterWeight(weight);
		DC_DrugSelectionPage dc_drugSel = dc_pi.clickProceedToCalculator();
		HashMap<String, String> drugSel_patientDetails = dc_drugSel.getPatientInformation("Neo");
		dc_drugSel.enterDrugName("Sodium");
		DC_Template_Utility dcUtils_page = dc_drugSel.selectDrugfromDrugbox("Sodium Nitroprusside");
		DC_T7_ContinuousInfusion_min dc_temp7 = (DC_T7_ContinuousInfusion_min) dcUtils_page.goToTemplate(7);
		Assert.assertTrue(dcUtils_page.verifyDrugNameInTemplatePage("Sodium Nitroprusside"),
				"The drug name in the landing page is incorrect");
		Assert.assertTrue(dcUtils_page.verifyPopulationModeInTemplatePage("Neonatal"),
				"The population mode in the template page is incorrect");
		HashMap<String, String> templatePage_patientDetails = dc_drugSel.getPatientInformation("Neo");
		boolean rightPaneText = dcUtils_page.comparePatientInfo_DrugSelPage_TemplatePage(drugSel_patientDetails,
				templatePage_patientDetails);
		Assert.assertTrue(rightPaneText, "Patient Information Text in Right Pane is Incorrect");
		Assert.assertTrue(dcUtils_page.isFirstDrugUseSelected(), "First Drug Use Not Selected by default");
		Assert.assertTrue(dcUtils_page.isFirstDrugRouteSelected(), "First Drug Route Not Selected by default");
		dcUtils_page.select_druguse_drugroute("Usual Dose", "IV");
		dcUtils_page.validate_Template_Dosing_Units(dc_temp7.fieldUnits_ContinousInfusion_min, dc_temp7.resultUnits);
		dc_temp7.doseRange();
		dcUtils_page.click_btn("calculate");
		boolean defaultCalculatedValue = dc_temp7.verifyCalculation("rate", weight);
		Assert.assertTrue(defaultCalculatedValue, "Default Calculated value is incorrect");
		dcUtils_page.click_btn("resetform");
		dcUtils_page.validateCommentsBtn();
		dcUtils_page.validatePrintBtn();
		dcUtils_page.validateDosevsRateBtn();
		mdxPage.LogOut();
		mdxPage.clearCache();
		log.info("****************TC_TestDosingCalculatorForNeonatalDrugSearch Completed*******************\n");
	}

	/**
	 * Verify the Drug Usage Information Functionality for Dosing Calculators
	 * for PED users Scenario to verify when patient age = 12Years, USER = PED
	 * for Drug:Bumetanide.
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 */

	@Test(groups = { "Subscription", "All" })
	public void TC_verifyTemplate22_Ped_12Years() throws InterruptedException, IOException, ParseException {
		extentReporter.createTest("TestDosingCalculatorForPediatricSearch",
				"Verification of Pediatric drug search and calculate the dose amount , dose volume and delivery rate by providing valid patient information");
		LoginPage login = launchApp();
		ExcelReader.openExcelSheet(fileName, "Subscription");
		_rowList = ExcelReader.readDataFromExcel(13, 14, 4);
		GatewayPage gateWay = login.loginTo(_rowList.get(0).toString().split(",")[0].toString().replace("[", ""),
				_rowList.get(0).toString().split(",")[1].toString().replace(" ", "").replace("]", ""));
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		DrugMonograph_Homepage dm = mdxPage.clickTab("Ped");
		DC_PatientInformationPage dc_pi = dm.getNeofaxUtility().clickDC_tab();
		dc_pi.enterBirthDate(0, 0, 12, "NA");
		Assert.assertFalse(dc_pi.isPopulationTypeEnabled(), "Population type should be disabled but it is enabled");
		dc_pi.enterWeight(28);
		DC_DrugSelectionPage dc_drugSel = dc_pi.clickProceedToCalculator();
		HashMap<String, String> drugSel_patientDetails = dc_drugSel.getPatientInformation("Ped");
		dc_drugSel.enterDrugName("Bumetanide");
		DC_Template_Utility dcUtils_page = dc_drugSel.selectDrugfromDrugbox("Bumetanide");
		dcUtils_page.select_druguse_drugroute("Hypertension", "Oral");
		DC_T22_Aliquot_IM dc_temp22 = (DC_T22_Aliquot_IM) dcUtils_page.goToTemplate(22);
		Assert.assertTrue(dcUtils_page.verifyDrugNameInTemplatePage("Bumetanide"),
				"The drug name in the template page is incorrect");
		Assert.assertTrue(dcUtils_page.verifyPopulationModeInTemplatePage("Pediatric"),
				"The population mode in the template page is incorrect");
		HashMap<String, String> templatePage_patientDetails = dc_drugSel.getPatientInformation("Ped");
		boolean rightPaneText = dcUtils_page.comparePatientInfo_DrugSelPage_TemplatePage(drugSel_patientDetails,
				templatePage_patientDetails);
		Assert.assertTrue(rightPaneText, "Patient Information Text in Right Pane is Incorrect");
		dc_temp22.validationForTemplate22(28, "default");
		mdxPage.LogOut();
		mdxPage.clearCache();
		log.info(
				"****************TC_TestDosingCalculatorForPediatricSearch22_Ped_12Years Completed*******************\n");

	}

}