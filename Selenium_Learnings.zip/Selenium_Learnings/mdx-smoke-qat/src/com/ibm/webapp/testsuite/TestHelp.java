package com.ibm.webapp.testsuite;

import java.io.IOException;

import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.pageObjects.LoginPage;
import com.ibm.webapp.pageObjects.mdx.MDX_HomePage;
import com.ibm.webapp.utils.TestBase;

public class TestHelp extends TestBase {

	/**
	 * Use this method to verify User guide window displayed with expected title
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "Help", "All" })
	public void TC_testHelpPage() throws IOException, InterruptedException {
		extentReporter.createTest("TestHelpPage", "Testing the Help Page in MDX home page");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("adminuser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		String parentWindow = mdxPage.getParentWindow(driver);
		mdxPage.clickHelpLink().verifyHelpPageHeader();
		driver.switchTo().window(parentWindow);
		mdxPage.LogOut();
	}

}
