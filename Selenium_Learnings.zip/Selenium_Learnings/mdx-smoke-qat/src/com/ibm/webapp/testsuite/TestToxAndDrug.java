package com.ibm.webapp.testsuite;

import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.pageObjects.LoginPage;
import com.ibm.webapp.pageObjects.ToxandDrugProduct.TOD_HomePage;
import com.ibm.webapp.pageObjects.ToxandDrugProduct.TOD_SearchResultPage;
import com.ibm.webapp.pageObjects.mdx.MDX_HomePage;
import com.ibm.webapp.utils.TestBase;

/**
 * smoke test to verify Tox & Drug Product Lookup search is functional
 * 
 * 
 * 
 */

public class TestToxAndDrug extends TestBase {
	@Test(groups = { "MDX", "All" })
	public void testToxAndDrugByProductOrSubstanceName() throws Exception {
		extentReporter.createTest("testToxAndDrugByProductOrSubstanceName",
				"Testing the Tox And Drug By Product Or Substance Name");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxHomePage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		TOD_HomePage todPage = mdxHomePage.clickOnOtherToolsToxAndDrugToolbarLink();
		todPage.isTODPageDisplayed();
		todPage.verifyProtocol();
		todPage.typeCharsIntoSearchBox("Clorox");
		TOD_SearchResultPage todResultPage = todPage.clickOnSubmitButton();
		todResultPage.isTODResultPageDisplayed();
		todResultPage.isResultTableDisplayed();
		todPage.verifyProtocol();
		if (todResultPage.isToxAndDrugSearchResultsDisplayed()) {
			extentReporter.PASS("Tox And Drug Search result Page Validation", "Tox And Drug Search results displayed");
		} else {
			extentReporter.FAIL(driver, "Tox And Drug Search results", "Tox And Drug Search results not displayed");
		}
		mdxHomePage.LogOut();
	}
}