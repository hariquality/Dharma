package com.ibm.webapp.testsuite;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.pageObjects.LoginPage;
import com.ibm.webapp.pageObjects.drugid.DrugIDPage;
import com.ibm.webapp.pageObjects.drugid.DrugID_DescriptionPage;
import com.ibm.webapp.pageObjects.drugid.DrugID_ImageResultsPage;
import com.ibm.webapp.pageObjects.drugid.DrugID_InformationPopupPage;
import com.ibm.webapp.pageObjects.drugid.DrugID_MDXLandingPage;
import com.ibm.webapp.pageObjects.drugid.DrugID_ResultsPage;
import com.ibm.webapp.pageObjects.drugid.DrugID_ToxAndDrugSearchResultsPage;
import com.ibm.webapp.pageObjects.mdx.MDX_HeaderPage;
import com.ibm.webapp.pageObjects.mdx.MDX_HomePage;
import com.ibm.webapp.utils.TestBase;

public class TestDrugIDApp extends TestBase {
	/**
	 * Use this method to verify whether Login to Open Athens is successful,
	 * 
	 * @throws IOException
	 */
	@Test(groups = { "MDX", "All" })
	public void TestDrugIDImprint() throws IOException, InterruptedException {
		extentReporter.createTest("TestDrugIDImprint", "Testing the Imprint functionality of Drug ID");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		MDX_HeaderPage headerPage = mdxPage.getHeaderPage();
		DrugIDPage diPage = headerPage.clickOnDrugIdentToolbarLink();
		diPage.enterNewImprintIntoSide1("tylenol codeine 3");
		DrugID_ResultsPage diResultPage = diPage.clickSearchButton();
		diResultPage.isResultRow1Displayed();
		DrugID_InformationPopupPage diInformationPopupPage = diResultPage.clickFirstDrugNameToToxLink();
		diInformationPopupPage.isDrugPopupDisplayed("Open");
		DrugID_ToxAndDrugSearchResultsPage tdResultsPage = diInformationPopupPage.clickOnToxAndDrugLink();
		tdResultsPage.isToxAndDrugSearchResultsDisplayed();
		mdxPage.getHeaderPage().logout();
	}

	@Test(groups = { "MDX", "All" })
	public void TestDrugIDByDescription() throws Exception {
		extentReporter.createTest("TestDrugIDByDescription",
				"Testing the search by description functionality of Drug ID");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		MDX_HeaderPage headerPage = mdxPage.getHeaderPage();
		DrugIDPage diPage = headerPage.clickOnDrugIdentToolbarLink();
		DrugID_DescriptionPage diDescriptionPage = diPage.clickSearchByDescriptionLink();
		diDescriptionPage.isSelectShapeDropdownVisible();
		diDescriptionPage.isSelectPatternDropdownVisible();
		diDescriptionPage.clickBlackCheckbox_CapsuleShape();
		DrugID_ImageResultsPage diImageResultPage = diDescriptionPage.clickSearchImagesButton();
		Boolean resultFound = diImageResultPage.isResultRow1Displayed();
		DrugID_ResultsPage diResultsPage = diImageResultPage.clickFirstDrugNameToToxLink();
		DrugID_ToxAndDrugSearchResultsPage tdResultsPage = diResultsPage.clickOnToxAndDrugLink();
		tdResultsPage.isToxAndDrugSearchResultsDisplayed();
		mdxPage.getHeaderPage().logout();
		Assert.assertTrue(resultFound, "Drug Ident Result row 1 not found");

	}

	@Test(groups = { "MDX", "All" })
	public void TestDrugID_Martindale() throws IOException, InterruptedException {
		extentReporter.createTest("TestDrugID_Martindale", "Testing the Martindale content of Drug ID");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		MDX_HeaderPage headerPage = mdxPage.getHeaderPage();
		DrugIDPage diPage = headerPage.clickOnDrugIdentToolbarLink();
		diPage.enterNewImprintIntoSide1("tylenol codeine 3");
		DrugID_ResultsPage diResultPage = diPage.clickSearchButton();
		diResultPage.isResultRow1Displayed();
		DrugID_InformationPopupPage diInformationPopupPage = diResultPage.clickFirstDrugNameToToxLink();
		diInformationPopupPage.isDrugPopupDisplayed("Open");
		DrugID_ToxAndDrugSearchResultsPage tdResultsPage = diInformationPopupPage.clickOnMartindaleLink();
		tdResultsPage.isToxAndDrugSearchResultsDisplayed();
		tdResultsPage.clickFirstDrugLink();

		mdxPage.getHeaderPage().logout();
	}

	@Test(groups = { "MDX", "All" })
	public void TestDrugID_PoisindexLink() throws IOException, InterruptedException {
		extentReporter.createTest("TestDrugID_PoisindexLink", "Testing the Poisindex link and its functionality");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		MDX_HeaderPage headerPage = mdxPage.getHeaderPage();
		DrugIDPage diPage = headerPage.clickOnDrugIdentToolbarLink();
		diPage.enterNewImprintIntoSide1("tylenol codeine 3");
		DrugID_ResultsPage diResultPage = diPage.clickSearchButton();
		diResultPage.isResultRow1Displayed();
		DrugID_MDXLandingPage drugPage = diResultPage.clickOnPoisindexLink();
		drugPage.verifyLandingPageDrugTitle();
		mdxPage.getHeaderPage().logout();
	}

}
