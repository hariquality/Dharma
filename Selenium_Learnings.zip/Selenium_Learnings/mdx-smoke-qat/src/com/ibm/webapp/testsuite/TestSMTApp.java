package com.ibm.webapp.testsuite;

import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.pageObjects.LoginPage;
import com.ibm.webapp.pageObjects.smt.SMTGenerateCKOLicenseKeyPage;
import com.ibm.webapp.pageObjects.smt.SMTGenerateLicenseKeyPage;
import com.ibm.webapp.pageObjects.smt.SMT_HomePage;
import com.ibm.webapp.utils.TestBase;

public class TestSMTApp extends TestBase {

	@Test(groups = { "SMT", "All" }, enabled = true)
	public void SMTGenerate_license_key() throws Exception {
		extentReporter.createTest("TestSMTApp", "Testing the SMTGenerate_license_key");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("smtuser");
		SMT_HomePage smtPage = (SMT_HomePage) gateWay.goToApplication("SMT");
		SMTGenerateLicenseKeyPage genLicensekeyPage = smtPage.clickOnGenerateLicenseKey();
		genLicensekeyPage.generateLicenseKey();
	}

	@Test(groups = { "SMT", "All" })
	public void SMTGenerate_ckolicense_key() throws Exception {
		extentReporter.createTest("TestSMTApp", "SMTGenerate_ckolicense_key");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("smtuser");
		SMT_HomePage smtPage = (SMT_HomePage) gateWay.goToApplication("SMT");
		SMTGenerateCKOLicenseKeyPage genCKOLicensekeyPage = smtPage.clickOnGenerateCKOLicenseKey();
		genCKOLicensekeyPage.generateCKOLicenseKey();
		// smtHomePage.getHeaderPage().logout();
	}

}
