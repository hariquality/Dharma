package com.ibm.webapp.testsuite;

import java.io.IOException;

import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.pageObjects.LoginPage;
import com.ibm.webapp.pageObjects.carenotes.CareNotes_CareAndConditionTitlesPage;
import com.ibm.webapp.pageObjects.carenotes.CareNotes_HomePage;
import com.ibm.webapp.pageObjects.carenotes.CareNotes_HotlistPage;
import com.ibm.webapp.pageObjects.carenotes.CareNotes_LabTitlesPage;
import com.ibm.webapp.pageObjects.carenotes.CareNotes_MedicationTitlesPage;
import com.ibm.webapp.utils.TestBase;

public class TestCareNotes extends TestBase {
	@Test(groups = {"CarenotesAdmin", "All" })
	public void TC_testDocDisplaySaveNotes() throws IOException, InterruptedException {
		extentReporter.createTest("TestCarenotesCheckPublishedHotList",
				"Verify whether hot lists page does not have showstoppers");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("careNotesUser");
		CareNotes_HomePage carenotesHomePage = (CareNotes_HomePage) gateWay.goToApplication("CareNotes");
		carenotesHomePage.chooseLocation("Auto'ICN");
		CareNotes_HotlistPage hotlistPage = carenotesHomePage.clickHotListLink();
		hotlistPage.clickFirstHotList();
		hotlistPage.getHeaderPage().logout();
	}

	@Test(groups = {"CarenotesAdmin", "All" })
	public void TC_testCareAndConditionTitles() throws IOException, InterruptedException {
		extentReporter.createTest("TestCarenotesCareAndConditionTitles",
				"Verify whether care and condition titles page does not have showstoppers");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("careNotesUser");
		CareNotes_HomePage carenotesHomePage = (CareNotes_HomePage) gateWay.goToApplication("CareNotes");
		carenotesHomePage.chooseLocation("Auto'ICN");
		CareNotes_CareAndConditionTitlesPage careAndCondTitlesPage = carenotesHomePage
				.clickCareAndConditionTitlesLink();
		careAndCondTitlesPage.clickFirstCareCondTitle();
		careAndCondTitlesPage.getHeaderPage().logout();
	}

	@Test(groups = {"CarenotesAdmin", "All" })
	public void TC_testMedicationTitles() throws IOException, InterruptedException {
		extentReporter.createTest("TestCarenotesMedicationTitles",
				"Verify whether medication titles page does not have showstoppers");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("careNotesUser");
		CareNotes_HomePage carenotesHomePage = (CareNotes_HomePage) gateWay.goToApplication("CareNotes");
		carenotesHomePage.chooseLocation("Auto'ICN");
		CareNotes_MedicationTitlesPage medTitlesPage = carenotesHomePage.clickMedicationTitlesLink();
		medTitlesPage.clickMedTitleWithA();
		medTitlesPage.getHeaderPage().logout();
	}

	@Test(groups = {"CarenotesAdmin", "All" })
	public void TC_testLabTitles() throws IOException, InterruptedException {
		extentReporter.createTest("TestCarenotesLabTitles",
				"Verify whether lab titles page does not have showstoppers");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("careNotesUser");
		CareNotes_HomePage carenotesHomePage = (CareNotes_HomePage) gateWay.goToApplication("CareNotes");
		carenotesHomePage.chooseLocation("Auto'ICN");
		CareNotes_LabTitlesPage medTitlesPage = carenotesHomePage.clickLabTitlesLink();
		medTitlesPage.browseTests("acetaminophen");
		medTitlesPage.getHeaderPage().logout();

	}

}
