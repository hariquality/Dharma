package com.ibm.webapp.testsuite;

import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.pageObjects.LoginPage;
import com.ibm.webapp.pageObjects.mdx.DrugLandingPage;
import com.ibm.webapp.pageObjects.mdx.MDX_HomePage;
import com.ibm.webapp.utils.TestBase;

public class TestToxSearchAndLandingPageChecks extends TestBase {

	/**
	 * Use this method to verify the related results sections is having the sub
	 * sections of quick, In-depth and all answers tab by searching the disease
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "MDX", "All" })
	public void TC_RelatedResultsOfToxSearch() throws Exception {
		extentReporter.createTest("TestRelatedResultsOfToxSearch",
				"Verifying the related results of quick,Indepth and all results tab by searching the Tox.");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		DrugLandingPage drugLand = mdxPage.searchAndReturnToxLandingPage("Benzene");
		drugLand.clickOnQuickTab();
		drugLand.isRelatedResultsHeadingdisplayed("Quick Answer");
		drugLand.verifyRelatedResults("Quick Answer",
				"Related Results\nDisease\nDrug\nToxicology\nHazard Management Information\nMartindale\nMedical Management Information\nProduct Lookup - Martindale\nProduct Lookup - Tox & Drug");
		drugLand.clickOnInDepthTab();
		drugLand.isRelatedResultsHeadingdisplayed("In-Depth Answer");
		drugLand.verifyRelatedResults("In-Depth Answer",
				"Related Results\nDisease\nDrug\nToxicology\nHazard Management Information\nMartindale\nMedical Management Information\nProduct Lookup - Martindale\nProduct Lookup - Tox & Drug");
		drugLand.clickOnAllResultsTab();
		drugLand.isRelatedResultsHeadingdisplayed("All Results");
		drugLand.verifyRelatedResults("All Results",
				"Related Results\nDisease\nDrug\nToxicology\nHazard Management Information\nMartindale\nMedical Management Information\nProduct Lookup - Martindale\nProduct Lookup - Tox & Drug");
		mdxPage.LogOut();
		log.info("****************TC_RelatedResultsOfToxSearch Completed*******************\n");

	}

	/**
	 * Use this method to verify the content availability and functionality of
	 * header and sun headers of quick, In-Depth and all results tab by
	 * searching the disease
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "MDX", "All" })
	public void TC_ContentAvailabilityOfQuickIndepthAndAllResultstabOfToxSearch() throws Exception {
		extentReporter.createTest("TestContentAvailabilityOfQuickIndepthAndAllResultstabOfToxSearch",
				"Testing the availability of contents and functionality of header and sun headers of quick, In-Depth and all results tab by searchng the tox.");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		DrugLandingPage drugLand = mdxPage.searchAndReturnToxLandingPage("Benzene");
		drugLand.clickOnQuickTab();
		drugLand.isContentdisplayedForQuickAnswerTab("Overview", "Life Support");
		drugLand.clickOnInDepthTab();
		drugLand.isContentdisplayedForInDepthAnswerTab("Substances Included/ Synonyms", "Therapeutic/ Toxic Class");
		drugLand.clickOnAllResultsTab();
		drugLand.verifyFilteringContentOfAllResultsTab("Drug");
		mdxPage.LogOut();
		log.info(
				"****************TC_TestContentAvailabilityOfQuickIndepthAndAllResultstabOfToxSearch Completed*******************\n");
	}

}