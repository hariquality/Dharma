package com.ibm.webapp.testsuite;

import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.pageObjects.LoginPage;
import com.ibm.webapp.pageObjects.mdx.AllResultsDocumentPage;
import com.ibm.webapp.pageObjects.mdx.DrugLandingPage;
import com.ibm.webapp.pageObjects.mdx.MDX_HomePage;
import com.ibm.webapp.utils.TestBase;

public class TestDrugSearch extends TestBase {

	/**
	 * Use this method to verify the relevant results are displayed in the
	 * related results section of quick, In-depth and all answers tab by
	 * searching the drug
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "MDX", "All" })
	public void TC_RelatedResultsOfDiseaseSearch() throws Exception {
		extentReporter.createTest("TestRelatedResultsOfDrugSearch",
				"Verifying the related results of quick, Indepth and all results tab by searching the drug.");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		DrugLandingPage drugLand = mdxPage.searchAndReturnDrugLandingPage("Aspirin");
		drugLand.clickOnQuickTab();
		drugLand.isRelatedResultsHeadingdisplayed("Quick Answer");
		drugLand.verifyRelatedResults("Quick Answer",
				"Related Results\nAlternative Medicine\nDisease\nToxicology\nConsumer Drug Information\nDrug Consults\neMC SmPC (UK)\nIndex Nominum\nMartindale\nP&T QUIK REPORTS\nPDR�\nProduct Lookup - Martindale\nProduct Lookup - RED Book\nProduct Lookup - Tox & Drug");
		Thread.sleep(2000);
		drugLand.clickOnInDepthTab();
		drugLand.isRelatedResultsHeadingdisplayed("In-Depth Answer");
		drugLand.verifyRelatedResults("In-Depth Answer",
				"Related Results\nAlternative Medicine\nDisease\nToxicology\nConsumer Drug Information\nDrug Consults\neMC SmPC (UK)\nIndex Nominum\nMartindale\nP&T QUIK REPORTS\nPDR�\nProduct Lookup - Martindale\nProduct Lookup - RED Book\nProduct Lookup - Tox & Drug");
		drugLand.clickOnAllResultsTab();
		drugLand.isRelatedResultsHeadingdisplayed("All Results");
		drugLand.verifyRelatedResults("All Results",
				"Related Results\nAlternative Medicine\nDisease\nToxicology\nConsumer Drug Information\nDrug Consults\neMC SmPC (UK)\nIndex Nominum\nMartindale\nP&T QUIK REPORTS\nPDR�\nProduct Lookup - Martindale\nProduct Lookup - RED Book\nProduct Lookup - Tox & Drug");
		mdxPage.LogOut();
		log.info("****************TC_RelatedResultsOfDrugSearch Completed*******************\n");

	}

	/**
	 * Use this method to verify the headers and sub headers are displayed in
	 * the quick or In-depth answer tab by searching the drug
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "MDX", "All" })
	public void TC_verifyHeaderAndSubheaderOfDiseaseSearch() throws Exception {
		extentReporter.createTest("TestHeaderAndSubheaderOfDrugSearch",
				"Testing the headers and sub headers of quick, In-depth answer tab by searchng the drugs.");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		DrugLandingPage drugLand = mdxPage.searchAndReturnDrugLandingPage("Aspirin");
		drugLand.clickOnQuickTab();
		drugLand.verifyHeaderAndSubheader("Quick Answer", "Toxicology",
				"Clinical Effects\nRange of Toxicity\nTreatment");
		drugLand.clickOnInDepthTab();
		drugLand.verifyHeaderAndSubheader("In-Depth Answer", "Medication Safety",
				"Contraindications\nPrecautions\nAdverse Effects\nBlack Box Warning\nREMS\nDrug Interactions (single)\nIV Compatibility (single)\nPregnancy & Lactation\nMonitoring\nDo Not Confuse");
		mdxPage.LogOut();
		log.info("****************TC_verifyHeaderAndSubheaderOfDrugSearch Completed*******************\n");
	}

	/**
	 * Use this method to verify the content in drug landing page for quick or
	 * In-depth answer tab by searching the drug
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "MDX", "All" })
	public void TC_verifyContentInDruglandingPageForQuickIndepthAllanswerTab() throws Exception {
		extentReporter.createTest("TestContentsForQuickAndIndepthOfDrugSearch",
				"Testing the content in drug landing page for quick or In-depth answer tab by searchng the drugs.");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		DrugLandingPage drugLand = mdxPage.searchAndReturnDrugLandingPage("Aspirin");
		drugLand.verifyDrugHeadersInDrugResultPage("Aspirin");
		drugLand.clickOnQuickTab();
		drugLand.verifyTopicHeadersInDrugResultPage("Quick", "Dosing/Administration");
		drugLand.clickOnInDepthTab();
		drugLand.verifyTopicHeadersInDrugResultPage("In-Depth", "Dosing/Administration");
		drugLand.clickOnAllResultsTab();
		AllResultsDocumentPage Allresultdocpage = drugLand.isClickedDocumentdisplayed("Aspirin Tablets BP 75 mg");
		Allresultdocpage.isDocumentTitleEqualsLink("Aspirin Tablets BP 75 mg");
		mdxPage.LogOut();
		log.info("****************TC_verifyContentsForQuickAndIndepthOfDrugSearch Completed*******************\n");
	}

}
