package com.ibm.webapp.testsuite;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.List;

import org.testng.annotations.Test;

import com.ibm.webapp.fileReader.ExcelReader;
import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.pageObjects.LoginPage;
import com.ibm.webapp.pageObjects.mdx.ChatBotPage;
import com.ibm.webapp.pageObjects.mdx.IvCompatibilityPage;
import com.ibm.webapp.pageObjects.mdx.IvCompatibilityResultsPage;
import com.ibm.webapp.pageObjects.mdx.MDX_HomePage;
import com.ibm.webapp.utils.TestBase;

public class TestMDXApp extends TestBase {

	private String fileName = "ChatBot_SmokeTestData";

	private List<List<String>> _rowList = null;

	@Test(groups = { "MDX", "All" })

	public void TC_testDrugLandingPage() throws IOException {
		extentReporter.createTest("TestMDXHomePAge", "Testing the Drug Search functionality in MDX home page");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		mdxPage.LogOut();
	}

	@Test(groups = { "MDX", "All" })

	public void TC_testHomePagse() throws IOException {
		extentReporter.createTest("TestMDXHomePAge2", "Testing the Drug Search functionality in MDX home page");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		mdxPage.LogOut();
		log.info("********  MDX Smoke TestSuite Run Completed ************");
	}

	@Test(groups = { "MDX", "All" })
	public void TC_testChatBotUI() throws IOException, InterruptedException {
		extentReporter.createTest("TC_testChatBotUI", "Testing the ChatBot UI & Feedback functionality");
		ExcelReader.openExcelForReadWrite(fileName, "WA_FeedbackTestCase");
		_rowList = ExcelReader.readDataFromExcel(2, 9);
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		ChatBotPage chatBotPage = mdxPage.getChatWindowComponent();
		chatBotPage.homePageSearchBarFocus();
		chatBotPage.clickHomePageChatIcon();
		chatBotPage.checkDefaultTextinChatWindow();
		chatBotPage.verifyTextForFeedbackAndLinks();
		chatBotPage.isWelcomeMessageDisplayed();
		List<String> writeResultsFeedback = chatBotPage.logicForFeedbackResponse(_rowList);
		ExcelReader.writeResultsToExcel(fileName, writeResultsFeedback, 9);
		compareTextByEqual(writeResultsFeedback.size() + "", _rowList.size() + "",
				"Validate Number of test data read and results captured");
		compareListByContains(writeResultsFeedback, "Fail", "Verify the Excel sheet : DrugNotes for Test Results",
				false);
		mdxPage.LogOut();
	}

	@Test(groups = { "MDX", "All" })
	public void TC_testCommonSectionsAndOtherFunctionalitiesInWA() throws IOException, InterruptedException {
		extentReporter.createTest("TC_testCommonSectionsAndOtherFunctionalitiesInWA",
				"Testing the WA common section and  other functionality in Watson Assistant");
		ExcelReader.openExcelForReadWrite(fileName, "WA_CommonSection");
		_rowList = ExcelReader.readDataFromExcel(2, 7);
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		ChatBotPage chatBotPage = mdxPage.getChatWindowComponent();
		chatBotPage.clickHomePageChatIcon();
		List<String> writeResults = chatBotPage.logicForCommonSection(_rowList);
		ExcelReader.writeResultsToExcel(fileName, writeResults, 7);
		compareTextByEqual(writeResults.size() + "", _rowList.size() + "",
				"Validate Number of test data read and results captured");
		compareListByContains(writeResults, "Fail", "Verify the Excel sheet : DrugNotes for Test Results", false);
		mdxPage.LogOut();
	}

	@Test(groups = { "MDX", "All" })

	public void TC_testDrugInteractionsAndOtherFunctionalitiesInWA() throws IOException, InterruptedException {
		extentReporter.createTest("TC_testDrugInteractionsAndOtherFunctionalitiesInWA",
				"Testing the Drug interaction functionality in Watson Assistant");
		ExcelReader.openExcelForReadWrite(fileName, "WA_DrugInteractions");
		_rowList = ExcelReader.readDataFromExcel(2, 14);
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		ChatBotPage chatBotPage = mdxPage.getChatWindowComponent();
		chatBotPage.clickHomePageChatIcon();
		List<String> testDataResultsList = chatBotPage.logicForDrugInteractions(_rowList);
		ExcelReader.writeResultsToExcel(fileName, testDataResultsList, 14);
		compareTextByEqual(testDataResultsList.size() + "", _rowList.size() + "",
				"Validate Number of test data read and results captured");
		compareListByContains(testDataResultsList, "Fail", "Verify the Excel sheet : DrugNotes for Test Results",
				false);
		mdxPage.LogOut();
	}

	@Test(groups = { "MDX", "All" })

	public void TC_testIVCompatibilityAndOtherFunctionalitiesInWA() throws IOException, InterruptedException {
		extentReporter.createTest("TC_testIVCompatibilityAndOtherFunctionalitiesInWA",
				"Testing the WA_IVCompatibility and  other functionality in Watson Assistant");
		ExcelReader.openExcelForReadWrite(fileName, "WA_IVCompatibility");
		_rowList = ExcelReader.readDataFromExcel(2, 14);
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		ChatBotPage chatBotPage = mdxPage.getChatWindowComponent();
		chatBotPage.clickHomePageChatIcon();
		List<String> writeResultsIV = chatBotPage.logicForIVCompatibility(_rowList);
		ExcelReader.writeResultsToExcel(fileName, writeResultsIV, 14);
		compareTextByEqual(writeResultsIV.size() + "", _rowList.size() + "",
				"Validate Number of test data read and results captured");
		compareListByContains(writeResultsIV, "Fail", "Verify the Excel sheet : DrugNotes for Test Results", false);
		mdxPage.LogOut();
	}

	@Test(groups = { "MDX", "All" })

	public void TC_testIVCompatibilitySingleDrugAndSolution() throws Exception {
		extentReporter.createTest("TC_testIVCompatibilitySingleDrugAndSolution",
				"Testing the IVCompatibility Single Drug And Solution");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		IvCompatibilityPage ivPage = mdxPage.clickOnIVCompatToolbarLink();
		ivPage.drugSelection("hepa");
		ivPage.SolnSelection("d5w");
		IvCompatibilityResultsPage ivResultspage = ivPage.viewcompbutton();
		boolean isDrugSolutionTabPresent = ivResultspage.isDrugSolutionTextEqualTo("Drug-Solution");
		assertTrue(isDrugSolutionTabPresent, "Drug-Solution tab is not displayed");
		ivResultspage.solutionLinkinDrugSolutionTabForSingleDrugSolution();
		mdxPage.LogOut();
	}

	@Test(groups = { "MDX", "All" })

	public void TC_testIVCompatibilityFilterResultsWithSingleDrug() throws Exception {
		extentReporter.createTest("TC_testIVCompatibilityFilterResultsWithSingleDrug",
				"Testing the IVCompatibility Filter Results With Single Drug");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		IvCompatibilityPage ivPage = mdxPage.clickOnIVCompatToolbarLink();
		ivPage.drugSelection("hepa");
		ivPage.SolnSelection("d5w");
		IvCompatibilityResultsPage ivResultspage = ivPage.viewcompbutton();
		boolean ySiteTabFound = ivResultspage.isYsiteTextEqualTo("Y-Site");
		assertTrue(ySiteTabFound, "Y-Site is not displayed");
		ivResultspage.clickYsiteTab();
		boolean AdmixtureTabFound = ivResultspage.isAdmixtureTextEqualTo("Admixture");
		assertTrue(AdmixtureTabFound, "Admixture is not displayed");
		ivResultspage.clickAdmixtureTab();
		boolean syringeFound = ivResultspage.isSyringeTextEqualTo("Syringe");
		assertTrue(syringeFound, "Syringe is displayed");
		ivResultspage.clickSyringeTab();
		boolean tpnTnaFound = ivResultspage.isTpnTnaTextEqualTo("TPN/TNA");
		assertTrue(tpnTnaFound, "TPN/TNA is displayed");
		ivResultspage.clickTpnTnaTab();
		mdxPage.LogOut();
	}

	@Test(groups = { "MDX", "All" })

	public void TC_testIVCompatibilityMultipleDrugAndSolution() throws Exception {
		extentReporter.createTest("TC_testIVCompatibilityMultipleDrugAndSolution",
				"Testing the IVCompatibility Multiple Drug And Solution");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		IvCompatibilityPage ivPage = mdxPage.clickOnIVCompatToolbarLink();
		ivPage.drugSelection("hepa");
		ivPage.drugSelection("clin");
		ivPage.drugSelection("vancom");
		ivPage.SolnSelection("d5w");
		ivPage.SolnSelection("nor");
		IvCompatibilityResultsPage ivResultspage = ivPage.viewcompbutton();
		boolean isDrugSolutionTabPresent = ivResultspage.isDrugSolutionTextEqualTo("Drug-Solution");
		assertTrue(isDrugSolutionTabPresent, "Drug-Solution tab is not displayed");
		ivResultspage.solutionLinkCheckinDrugSolutionTab();
		mdxPage.LogOut();
	}

	@Test(groups = { "MDX", "All" })

	public void TC_testIVCompatibilityFilterResultsWithMultipeDrug() throws Exception {
		extentReporter.createTest("TC_testIVCompatibilityFilterResultsWithMultipeDrug",
				"Testing the IVCompatibility Filter Results With Multiple Drug");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		IvCompatibilityPage ivPage = mdxPage.clickOnIVCompatToolbarLink();
		ivPage.drugSelection("hepa");
		ivPage.drugSelection("clin");
		ivPage.drugSelection("vancom");
		ivPage.SolnSelection("d5w");
		ivPage.SolnSelection("nor");
		IvCompatibilityResultsPage ivResultspage = ivPage.viewcompbutton();
		boolean drugDrugYsiteFound = ivResultspage.isDrugYsiteTextEqualTo("Drug-Drug: Y-Site");
		assertTrue(drugDrugYsiteFound, "Drug-Drug: Y-Site tab is not displayed");
		ivResultspage.clickDrugYsiteTab();
		boolean drugAdmixureFound = ivResultspage.isDrugAdmixtureTextEqualTo("Drug-Drug: Admixture");
		assertTrue(drugAdmixureFound, "Drug-Drug: Admixture tab is not displayed");
		ivResultspage.clickDrugAdmixureTab();
		boolean drugSyringeFound = ivResultspage.isDrugSyringeTextEqualTo("Drug-Drug: Syringe");
		assertTrue(drugSyringeFound, "Drug-Drug: Syringe tab is not displayed");
		ivResultspage.clickDrugSyringeTab();
		mdxPage.LogOut();
	}

	@Test(groups = { "MDX", "All" })

	public void TC_testIVCompatibilityFiltersInCompatibilitySettings() throws Exception {
		extentReporter.createTest("TC_testIVCompatibilityFiltersInCompatibilitySettings",
				"Testing the IVCompatibility Filters in Compatibility Settings");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		IvCompatibilityPage ivPage = mdxPage.clickOnIVCompatToolbarLink();
		ivPage.drugSelection("hepa");
		ivPage.drugSelection("clin");
		ivPage.drugSelection("vancom");
		ivPage.SolnSelection("Ring");
		ivPage.SolnSelection("lacta");
		IvCompatibilityResultsPage ivResultspage = ivPage.viewcompbutton();
		ivResultspage.multipleCompatFilters();
		ivResultspage.multipleCautionVariableFilters();
		ivResultspage.multipleIncompatibleFilters();
		ivResultspage.multipleUncertainFilters();
		ivResultspage.multipleNotTestedFilters();
		ivResultspage.multipleDrugFilters();
		mdxPage.LogOut();
	}
}
