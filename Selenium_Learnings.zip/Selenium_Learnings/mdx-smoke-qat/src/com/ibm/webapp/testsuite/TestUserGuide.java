package com.ibm.webapp.testsuite;

import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.pageObjects.LoginPage;
import com.ibm.webapp.pageObjects.mdx.MDX_HomePage;
import com.ibm.webapp.utils.TestBase;

public class TestUserGuide extends TestBase {

	/**
	 * Use this method to verify help window displayed with expected title
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "UserGuide", "All" })
	public void TC_testUserGuidePage() throws Exception {
		extentReporter.createTest("TestUserGuidePage", "Testing the User guide page in MDX home page");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("adminuser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		String parentWindow = mdxPage.getParentWindow(driver);
		mdxPage.clickUserGuideLink().verifyUserGuideHeader();
		driver.switchTo().window(parentWindow);
		mdxPage.LogOut();

	}

}
