package com.ibm.webapp.testsuite;

import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.pageObjects.LoginPage;
import com.ibm.webapp.pageObjects.mdx.MDX_HomePage;
import com.ibm.webapp.pageObjects.mdx.RedBookPage;
import com.ibm.webapp.pageObjects.mdx.RedBookSearchResultsPage;
import com.ibm.webapp.utils.TestBase;

public class TestRedBook extends TestBase {

	/**
	 * Use this method to verify the relevant search results in the RED BOOK
	 * Search Results page
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "MDX2", "All" })
	public void TC_testRedBookSearchResults() throws Exception {
		extentReporter.createTest("TestRedBookPage", "Testing the Red book search results by searching the drugs.");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		RedBookPage rbPage = mdxPage.clickRedbookLink();
		rbPage = rbPage.typeCharsIntoSearchBox("DIGOXIN");
		rbPage.singleClickTermInWordWheel("DIGOXIN");
		RedBookSearchResultsPage rbSearchResultsPage = rbPage.clickSubmitButton();
		rbSearchResultsPage.isRedBookSearchResultsDisplayed("DIGOXIN");
		mdxPage.LogOut();
		log.info("****************TC_testRedBookSearchResults completed*******************\n");
	}

	/**
	 * Use this method to verify contents in Red book product details, Find
	 * similar products and manufacturer details in red book search results page
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "MDX2", "All" })
	public void TC_testRedBookSearchPopups() throws Exception {
		extentReporter.createTest("TestRedBookSearchPopups", "Content verification in Red book popup windows");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("mdxUser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		RedBookPage rbPage = mdxPage.clickRedbookLink();
		rbPage = rbPage.typeCharsIntoSearchBox("DIGOXIN");
		rbPage.singleClickTermInWordWheel("DIGOXIN");
		RedBookSearchResultsPage rbSearchResultsPage = rbPage.clickSubmitButton();
		rbSearchResultsPage.isRedBookSearchResultsDisplayed("DIGOXIN");
		rbSearchResultsPage.clickOnProductPopupLink();
		Thread.sleep(1000);
		rbSearchResultsPage.getProductPopupTitle();
		rbSearchResultsPage.clickOnProductPopupCloseBtn();
		Thread.sleep(1000);
		rbSearchResultsPage.clickOnActiveIngredientPopupLink();
		Thread.sleep(1000);
		rbSearchResultsPage.getActiveIngredientPopupTitle();
		rbSearchResultsPage.clickOnActiveIngredientPopupCloseBtn();
		Thread.sleep(1000);
		rbSearchResultsPage.clickOnManufacturerPopupLink();
		Thread.sleep(1000);
		rbSearchResultsPage.getManufacturerPopupTitle();
		rbSearchResultsPage.clickOnManufacturerPopupCloseBtn();
		mdxPage.LogOut();
		log.info("****************TC_testRedBookSearchPopups completed*******************\n");
	}

}
