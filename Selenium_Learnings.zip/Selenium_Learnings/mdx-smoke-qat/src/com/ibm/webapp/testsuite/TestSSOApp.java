package com.ibm.webapp.testsuite;

import java.io.IOException;

import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.GatewayPage;
import com.ibm.webapp.pageObjects.LoginPage;
import com.ibm.webapp.pageObjects.carenotes.CareNotes_HomePage;
import com.ibm.webapp.pageObjects.formulary.Formulary_HomePage;
import com.ibm.webapp.pageObjects.mdx.MDX_HomePage;
import com.ibm.webapp.pageObjects.smt.SMT_HomePage;
import com.ibm.webapp.pageObjects.sso.MyAthensDashboardPage;
import com.ibm.webapp.pageObjects.sso.OpenAthens_LoginPage;
import com.ibm.webapp.pageObjects.umt.UMT_HomePage;
import com.ibm.webapp.utils.TestBase;

public class TestSSOApp extends TestBase {
	/**
	 * Use this method to verify whether Micromedex could be accessed from Open
	 * Athens Page,
	 * 
	 * @throws IOException
	 */
	@Test(groups = { "SSO", "All" })
	public void LoginToOpenAthensviaMDX() throws IOException, InterruptedException {
		extentReporter.createTest("TestSSOHomePAge", "Testing the Open Athens Login Page");
		OpenAthens_LoginPage login = launchOpenAthens();
		MyAthensDashboardPage dashboard = login.loginTo("openathensuser");
		dashboard.isDashboardPageDisplayed();
		dashboard.LogOut();
	}

	/**
	 * Use this method to verify whether Micromedex could be accessed from
	 * Single Sign On Page,
	 * 
	 * @throws IOException
	 */
	@Test(groups = { "SSO", "All" })
	public void TestMicromedexfromSSO() throws IOException, InterruptedException {
		extentReporter.createTest("TestMDXHomePAge2", "Testing the Drug Search functionality in MDX home page");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("adminuser");
		MDX_HomePage mdxPage = (MDX_HomePage) gateWay.goToApplication("Micromedex");
		mdxPage.LogOut();
	}

	/**
	 * Use this method to verify whether CareNotes could be accessed from Single
	 * Sign On Page,
	 * 
	 * @throws IOException
	 */
	@Test(groups = { "SSO", "All" })
	public void TestCareNotesfromSSO() throws IOException {
		extentReporter.createTest("TestCareNotesHomePAge", "Testing if CareNotes could be accessed from SSO Page");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("adminuser");
		CareNotes_HomePage carenotesPage = (CareNotes_HomePage) gateWay.goToApplication("CareNotes");
		carenotesPage.isHomePageDisplayed();
		carenotesPage.LogOut();

	}

	/**
	 * Use this method to verify whether Formulary could be accessed from Single
	 * Sign On Page,
	 * 
	 * @throws IOException
	 */

	@Test(groups = { "SSO", "All" })
	public void TestFormularyfromSSO() throws IOException {
		extentReporter.createTest("TestFormularyHomePage", "Testing if Formulary could be accessed from SSO page");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("adminuser");
		Formulary_HomePage formularyPage = (Formulary_HomePage) gateWay.goToApplication("Formulary");
		formularyPage.isHomePageDisplayed();
		formularyPage.LogOut();
	}

	/**
	 * Use this method to verify whether UMT could be accessed from Single Sign
	 * On Page,
	 * 
	 * @throws IOException
	 */
	@Test(groups = { "SSO", "All" })
	public void TestUMTfromSSO() throws IOException {
		extentReporter.createTest("TestUMTHomePage", "Testing if UMT could be accessed from SSO page");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("adminuser");
		UMT_HomePage umtPage = (UMT_HomePage) gateWay.goToApplication("UMT");
		umtPage.isHomePageDisplayed();
		umtPage.UMTLogout();

	}

	/**
	 * Use this method to verify whether SMT could be accessed from Single Sign
	 * On Page,
	 * 
	 * @throws IOException
	 */
	@Test(groups = { "SSO", "All" })
	public void TestSMTfromSSO() throws IOException {
		extentReporter.createTest("TestSMTHomePage", "Testing if SMT could be accessed from SSO page");
		LoginPage login = launchApp();
		GatewayPage gateWay = login.loginAs("smtuser");
		SMT_HomePage smtPage = (SMT_HomePage) gateWay.goToApplication("SMT");
		smtPage.isHomePageDisplayed();
		smtPage.SMTLogout();

	}

}
