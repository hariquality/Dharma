package com.ibm.webapp.testsuite;

import org.testng.annotations.Test;

import com.ibm.webapp.pageObjects.PDXSimulator.PDXSearchResultPage;
import com.ibm.webapp.pageObjects.ToxandDrugProduct.TOD_SearchResultPage;
import com.ibm.webapp.utils.TestBase;

/**
 * smoke test to verify Tox & Drug Product Lookup search is functional
 * 
 * 
 * 
 */

public class TestPDXSimulator extends TestBase
{
   
   @Test (groups = { "PDX", "All" })
   public void testPDXSimulatorToxAndDrugByProduct() throws Exception
   {
      extentReporter
            .createTest("testPDXSimulatorToxAndDrugByProduct",
                        "Testing the PDX Simulator for Tox And Drug By Product");
    
      TOD_SearchResultPage todResultPage = gotoTargetURLToxResultsPage("mdxUser", "Clorox", "Product", "833238", "THC_CASEPRO_833238_202009041311");
      todResultPage.isTODResultPageDisplayed();
      todResultPage.isResultTableDisplayed();
      if (todResultPage.isToxAndDrugSearchResultsDisplayed())
      {
         extentReporter
               .passWithScreenShot(driver,
                                   "Tox And Drug Search results displayed for Product search type.");
      }
      else
      {
         extentReporter.FAIL(driver,
                             "Tox And Drug Search results",
                             "Tox And Drug Search results not displayed for Product search type.");
      }
      PDXSearchResultPage pdxResultPage = todResultPage.clickSelectProductLink();
      pdxResultPage.validateResponseDocument("mdxUser", "THC_CASEPRO_833238_202009041311", "json");
      pdxResultPage.validateResponseDocument("mdxUser", "THC_CASEPRO_833238_202009041311", "xml");
   }
   
   @Test (groups = { "PDX", "All" })
   public void testPDXSimulatorToxAndDrugByCode() throws Exception
   {
      extentReporter
            .createTest("testPDXSimulatorToxAndDrugByCode",
                        "Testing the PDX Simulator for Tox And Drug By Code");
    
      TOD_SearchResultPage todResultPage = gotoTargetURLToxResultsPage("mdxUser", "201026", "Code", "615093", "THC_CASEPRO_615093_202009041650");
      todResultPage.isTODResultPageDisplayed();
      todResultPage.isResultTableDisplayed();
      if (todResultPage.isToxAndDrugSearchResultsDisplayed())
      {
         extentReporter
               .passWithScreenShot(driver,
                                   "Tox And Drug Search results displayed for Code search type.");
      }
      else
      {
         extentReporter.FAIL(driver,
                             "Tox And Drug Search results",
                             "Tox And Drug Search results not displayed for Code search type.");
      }
      PDXSearchResultPage pdxResultPage = todResultPage.clickSelectProductLink();
      pdxResultPage.validateResponseDocument("mdxUser", "THC_CASEPRO_615093_202009041650", "json");
      pdxResultPage.validateResponseDocument("mdxUser", "THC_CASEPRO_615093_202009041650", "xml");
   }
  
   @Test (groups = { "PDX", "All" })
   public void testPDXSimulatorToxAndDrugById() throws Exception
   {
      extentReporter
            .createTest("testPDXSimulatorToxAndDrugById",
                        "Testing the PDX Simulator for Tox And Drug By Id");
    
      TOD_SearchResultPage todResultPage = gotoTargetURLToxResultsPage("mdxUser", "6922664", "Id", "908234", "THC_CASEPRO_908234_202009041652");
      todResultPage.isTODResultPageDisplayed();
      todResultPage.isResultTableDisplayed();
      if (todResultPage.isToxAndDrugSearchResultsDisplayed())
      {
         extentReporter
               .passWithScreenShot(driver,
                                   "Tox And Drug Search results displayed for Id search type.");
      }
      else
      {
         extentReporter.FAIL(driver,
                             "Tox And Drug Search results",
                             "Tox And Drug Search results not displayed for Id search type.");
      }
      PDXSearchResultPage pdxResultPage = todResultPage.clickSelectProductLink();
      pdxResultPage.validateResponseDocument("mdxUser", "THC_CASEPRO_908234_202009041652", "json");
      pdxResultPage.validateResponseDocument("mdxUser", "THC_CASEPRO_908234_202009041652", "xml");
   }
   
   @Test (groups = { "PDX", "All" })
   public void testPDXSimulatorToxAndDrugByIngredient() throws Exception
   {
      extentReporter
            .createTest("testPDXSimulatorToxAndDrugByIngredient",
                        "Testing the PDX Simulator for Tox And Drug By Ingredient");
    
      TOD_SearchResultPage todResultPage = gotoTargetURLToxResultsPage("mdxUser", "red+dye", "Ingredient", "313449", "THC_CASEPRO_313449_202009041654");
      todResultPage.isTODResultPageDisplayed();
      todResultPage.isResultTableDisplayed();
      if (todResultPage.isToxAndDrugSearchResultsDisplayed())
      {
         extentReporter
               .passWithScreenShot(driver,
                                   "Tox And Drug Search results displayed for Ingredient search type.");
      }
      else
      {
         extentReporter.FAIL(driver,
                             "Tox And Drug Search results",
                             "Tox And Drug Search results not displayed for Ingredient search type.");
      }
      PDXSearchResultPage pdxResultPage = todResultPage.clickSelectProductLink();
      pdxResultPage.validateResponseDocument("mdxUser", "THC_CASEPRO_313449_202009041654", "json");
      pdxResultPage.validateResponseDocument("mdxUser", "THC_CASEPRO_313449_202009041654", "xml");
      
   }
   
   @Test (groups = { "PDX", "All" })
   public void testPDXSimulatorToxAndDrugByDefault() throws Exception
   {
      extentReporter
            .createTest("testPDXSimulatorToxAndDrugByDefault",
                        "Testing the PDX Simulator for Tox And Drug By Default");
    
      TOD_SearchResultPage todResultPage = gotoTargetURLToxResultsPage("mdxUser", "aspirin", "Default", "208631", "THC_CASEPRO_208631_202009041654");
      todResultPage.isTODResultPageDisplayed();
      todResultPage.isResultTableDisplayed();
      if (todResultPage.isToxAndDrugSearchResultsDisplayed())
      {
         extentReporter
               .passWithScreenShot(driver,
                                   "Tox And Drug Search results displayed for Default search type.");
      }
      else
      {
         extentReporter.FAIL(driver,
                             "Tox And Drug Search results",
                             "Tox And Drug Search results not displayed for Default search type.");
      }
      PDXSearchResultPage pdxResultPage = todResultPage.clickSelectProductLink();
      pdxResultPage.validateResponseDocument("mdxUser", "THC_CASEPRO_208631_202009041654", "json");
      pdxResultPage.validateResponseDocument("mdxUser", "THC_CASEPRO_208631_202009041654", "xml");
   }
  
}