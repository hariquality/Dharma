package com.ibm.webapp.config;

//OB: ExtentReports extent instance created here. That instance can be reachable by getReporter() method.

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Protocol;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentReporter
{
   ExtentReports extent;

   WebDriver driver;

   static String getExecutionType = "";

   ExtentTest eachTest;

   ExtentTest eachNode;

   public static ExtentReporter extentInstance = null;

   protected Logger log = Logger.getLogger(ExtentReporter.class);

   protected static ExtentSparkReporter extentSparkInstance = null;

   public static ExtentReporter getInstance()
   {
      if (extentInstance == null)
         extentInstance = new ExtentReporter();
      return extentInstance;
   }

   public void getExtendReport() throws IOException
   {
      String environment =Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("Env");
      String browser =Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("browserName");
      if (extent == null)
      {
         extent = new ExtentReports();
         DateTimeFormatter dtf = DateTimeFormatter
               .ofPattern("yyyy_MM_dd(HH-mm-ss)");
         LocalDateTime now = LocalDateTime.now();
         String outputFolderName = "WEBApps_Reports";
         File outputReportFolder = new File(outputFolderName);
         if (!outputReportFolder.exists())
         {
            outputReportFolder.mkdir();
         }

         File outputFile = new File(outputFolderName + File.separator
               + "Report_" + dtf.format(now) + ".html");

         extentSparkInstance = new ExtentSparkReporter(outputFile);
         extentSparkInstance.config().setCSS("css-string");
         extentSparkInstance.config().setDocumentTitle("Smoke Test Report");
         extentSparkInstance.config().setEncoding("utf-8");
         extentSparkInstance.config().setJS("js-string");
         extentSparkInstance.config().setProtocol(Protocol.HTTP);
         extentSparkInstance.config()
               .setReportName("IBM Micromedex Applications WEB Applications Smoke Test Report");
         extentSparkInstance.config().setTheme(Theme.DARK);
         extentSparkInstance.config()
               .setTimeStampFormat("MMM dd, yyyy HH:mm:ss");
         extent.setSystemInfo("OS", System.getProperty("os.name"));
         extent.setSystemInfo("Environment", environment);
         extent.setSystemInfo("Browser", browser);
         extent.attachReporter(extentSparkInstance);
      }
   }

   public void createTest(String testname, String testDesciption)
   {
      eachTest = extent.createTest(testname, testDesciption);
      log.info("***********Started Executing TestCase: " + testname
            + "  ***********");
   }

   public void PASS(String nodeName, String description)
   {
      eachTest.createNode(nodeName, description)
            .pass(MarkupHelper.createLabel(description, ExtentColor.GREEN));
   }
   
   public void PASS( String description)
   {
      eachTest.createNode(description)
            .pass(MarkupHelper.createLabel(description, ExtentColor.GREEN));
   }
   
   public void FAIL(String description) 
   {
      eachTest.createNode(description)
            .fail(MarkupHelper.createLabel(description, ExtentColor.RED));
   }

   public void FAIL(WebDriver driver,
                    String nodeName,
                    String description) throws IOException
   {
      String screenshotPath = getScreenShot(driver, "Screenshot");
      eachTest.createNode(nodeName, description)
            .fail(MarkupHelper.createLabel(description, ExtentColor.RED))
            .addScreenCaptureFromPath(screenshotPath);
   }

   public void FailWithException(WebDriver driver,
                    String nodeName,
                    String description,
                    Exception e) throws IOException
   {
      String screenshotPath = getScreenShot(driver, "Screenshot");
      eachTest.createNode(nodeName, description)
            .fail(MarkupHelper.createLabel(description
                  + "Failed with an Exception: " + e.getMessage(),
                                           ExtentColor.RED))
            .addScreenCaptureFromPath(screenshotPath);
      throw new AssertionError(" Method Failed", e);
   }

   public void passWithScreenShot(WebDriver driver,
                                  String description) throws IOException
   {
      String screenshotPath = getScreenShot(driver, "Screenshot");
      eachTest.createNode(description, description)
            .pass(MarkupHelper.createLabel(description, ExtentColor.GREEN))
            .addScreenCaptureFromPath(screenshotPath);
   }

   public void failWithScreenShot(WebDriver driver,
                                  String description) throws IOException
   {

      String screenshotPath = getScreenShot(driver, "Screenshot");
      eachTest.createNode(description, description)
            .fail(MarkupHelper.createLabel("FAIL", ExtentColor.RED))
            .addScreenCaptureFromPath(screenshotPath);
   }

   public void infoWithScreenShot(WebDriver driver,
                                  String description) throws IOException
   {
      String screenshotPath = getScreenShot(driver, "Screenshot");
      eachTest.createNode(description, description)
            .pass(MarkupHelper.createLabel("INFO", ExtentColor.BLUE))
            .addScreenCaptureFromPath(screenshotPath);
   }

   public void SKIPPED(String description) throws IOException
   {
      eachTest.createNode(description, description)
            .pass(MarkupHelper.createLabel("SKIPPED", ExtentColor.ORANGE));
   }

   // This method is to capture the screenshot and return the path of the
   // screenshot.
   public static String getScreenShot(WebDriver driver,
                                      String screenshotName) throws IOException
   {
      String dateName = new SimpleDateFormat("yyyyMMddhhmmss")
            .format(new Date());
      TakesScreenshot ts = (TakesScreenshot) driver;
      File source = ts.getScreenshotAs(OutputType.FILE);
      // after execution, you could see a folder "FailedTestsScreenshots" under
      // src folder
      String destination = System.getProperty("user.dir") + "/Screenshots/"
            + screenshotName + dateName + ".png";
      File finalDestination = new File(destination);
      FileUtils.copyFile(source, finalDestination);
      return destination;
   }
   
   public void FAIL(String nodeName,
                           String description) 
          {
             eachTest.createNode(nodeName, description)
                   .fail(MarkupHelper.createLabel(description, ExtentColor.RED));
          }

   public void flush()
   {
      extent.flush();
   }

}
