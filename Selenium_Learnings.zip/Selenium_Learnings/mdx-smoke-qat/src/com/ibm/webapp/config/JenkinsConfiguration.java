package com.ibm.webapp.config;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

public class JenkinsConfiguration
{

   public static String executionEnv = "";
   
   public static String isAdminUser = "";

   public static Properties props = new Properties();

   static InputStream input = null;

   @BeforeClass(alwaysRun=true)
   @Parameters({ "ExecuteInJenkins", "isRemote", "browserName", "Env",
		         "adminUser","platformName", "browserVersion"})
   public void initConfigurations(@Optional String ExecuteInJenkins,
           @Optional String isRemote,
           @Optional String browserName,
           @Optional String Env,
           @Optional String adminUser,
           @Optional String platformName,
           @Optional String browserVersion
           )
   {
      try
      {
         input = new FileInputStream("./properties/WebAppURLConfig.properties");
         props.load(input);
         executionEnv = Env;
         isAdminUser = adminUser;
         if (ExecuteInJenkins.equalsIgnoreCase("Yes"))
         {
            executionEnv = System.getenv("Env");
         }
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
   }

   public static String getValueFromPropertiesFile(String valueName)
   {
      return props.getProperty(valueName);
   }

}
